window.Global = {
    userInfo: null,
    gameConfig: null,
    gameConfigSetting: null,
    gameMode: null,
    hostServerIp: "127.0.0.1",
    hostServerPort: "9001",
    hostHttpProtocol: "http",
    privateClientChanle: null,
    joinRoomNumber: null,
    userList: [],
    subid: 0,
    chuPaiActionType: "",
    huanSanZhangPaiList: []
};