var messageDomain = {
	messageBelongsToPrivateChanleNumber: 0,
	//sendToOther,sendToServer,sendToSingleUser
	messageAction: "",
	messageType: "",
	messageBody: ""
};
module.exports = {
	messageDomain: messageDomain
};