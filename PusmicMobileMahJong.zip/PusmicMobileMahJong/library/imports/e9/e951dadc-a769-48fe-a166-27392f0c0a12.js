var gameUser = { id: 0,
  nickName: "",
  headimgurl: "",
  country: "",
  diamondsNumber: 0,
  openid: "",
  unionid: "",
  userCode: "",
  //userGameingStatu:"",
  publicIp: "",
  paiList: "",
  gameReadyStatu: "",
  gameRoundScore: "",
  gameScoreCount: "",
  pointIndex: "",
  headImageFileName: "",
  zhuang: "",
  //follow propertity only work on client
  paiListArray: [],
  huanSanZhangPaiList: [],
  pengPaiList: [],
  gangPaiList: [],
  pengGangPaiPoint: 0,
  quePai: "",
  chupaiListX: 0,
  chupaiListY: 0,
  chuPaiCount: 0,
  chuPaiPointX: 0,
  userMoPai: "",
  //hupai 
  huPai: "",
  //ziMo,normalHu,gangShangHua,gangShangPao ,haiDi,tianHu,diHu
  huPaiType: ""
};
//gameingStatu:"",
module.exports = {
  gameUser: gameUser
};