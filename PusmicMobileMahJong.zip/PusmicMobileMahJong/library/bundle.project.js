require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"AudioMng":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'c3d868opm9BB4LH+VYKqsqc', 'AudioMng');
// script/audio/AudioMng.js

var gameConfigSetting;
cc.Class({
    "extends": cc.Component,

    properties: {
        gameStartAudio: {
            "default": null,
            url: cc.AudioClip
        },
        winAudio: {
            "default": null,
            url: cc.AudioClip
        },

        loseAudio: {
            "default": null,
            url: cc.AudioClip
        },

        cardAudio: {
            "default": null,
            url: cc.AudioClip
        },

        buttonAudio: {
            "default": null,
            url: cc.AudioClip
        },

        chipsAudio: {
            "default": null,
            url: cc.AudioClip
        },

        bgm: {
            "default": null,
            url: cc.AudioClip
        }
    },

    // use this for initialization
    onLoad: function onLoad() {

        var o = cc.sys.localStorage.getItem("gameConfig");

        if (o != null && o != undefined && o != "" && o != "\"\"") {
            Global.gameConfigSetting = JSON.parse(o);
        }

        if (Global.gameConfigSetting == null || Global.gameConfigSetting == undefined || Global.gameConfigSetting == "") {
            Global.gameConfigSetting = require("gameConfigSetting").gameConfigSetting;
        }
        gameConfigSetting = Global.gameConfigSetting;
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

    playMusic: function playMusic() {
        gameConfigSetting = Global.gameConfigSetting;
        if (gameConfigSetting.music == "1") {
            cc.audioEngine.playMusic(this.bgm, true);
        }
    },
    stopMusic: function stopMusic() {
        cc.audioEngine.stopMusic();
    },

    pauseMusic: function pauseMusic() {
        cc.audioEngine.pauseMusic();
    },

    resumeMusic: function resumeMusic() {
        cc.audioEngine.resumeMusic();
    },

    _playSFX: function _playSFX(clip) {
        cc.audioEngine.playEffect(clip, false);
    },

    playWin: function playWin() {
        this._playSFX(this.winAudio);
    },

    playLose: function playLose() {
        this._playSFX(this.loseAudio);
    },

    playCard: function playCard() {
        this._playSFX(this.cardAudio);
    },

    playChips: function playChips() {
        this._playSFX(this.chipsAudio);
    },

    playButton: function playButton() {
        this._playSFX(this.buttonAudio);
    }
});

cc._RFpop();
},{"gameConfigSetting":"gameConfigSetting"}],"ButtonScaler":[function(require,module,exports){
"use strict";
cc._RFpush(module, '56194H6FxlN4piguuTlYo5J', 'ButtonScaler');
// script/ui/ButtonScaler.js

cc.Class({
    'extends': cc.Component,

    properties: {
        pressedScale: 1,
        transDuration: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        var audioMng = cc.find('ScriptPlayBgm/AudioMng') || cc.find('Script/AudioMng');
        if (audioMng) {
            audioMng = audioMng.getComponent('AudioMng');
        }
        self.initScale = this.node.scale;
        self.button = self.getComponent(cc.Button);
        self.scaleDownAction = cc.scaleTo(self.transDuration, self.pressedScale);
        self.scaleUpAction = cc.scaleTo(self.transDuration, self.initScale);
        function onTouchDown(event) {
            this.stopAllActions();
            if (audioMng) audioMng.playButton();
            this.runAction(self.scaleDownAction);
        }
        function onTouchUp(event) {
            this.stopAllActions();
            this.runAction(self.scaleUpAction);
        }
        this.node.on('touchstart', onTouchDown, this.node);
        this.node.on('touchend', onTouchUp, this.node);
        this.node.on('touchcancel', onTouchUp, this.node);
    }
});

cc._RFpop();
},{}],"DataTime":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'bd2dfiGkfxCEbgrnkUlYWi0', 'DataTime');
// script/ui/DataTime.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        timeLable: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        //show time
        var dateTimeUpte = function dateTimeUpte() {
            var currentdate = new Date();
            var hour = currentdate.getHours() + ":";
            var min = currentdate.getMinutes() + "";
            var second = currentdate.getSeconds() + "";

            if (min.length == 1) {
                min = "0" + min;
            }
            if (second.length == 1) {
                second = "0" + second;
            }
            var currentTiem = hour + min;

            var lable = this.timeLable.getComponent(cc.Label);
            lable.string = currentTiem;
        };

        this.schedule(dateTimeUpte, 1);
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"GameModeActionScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e8878ueXLJLUY1LZpUPZdES', 'GameModeActionScript');
// script/controllers/GameModeActionScript.js

var infoTextNode;
var gameMode;
var fanArray = [];
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        modeInfoRightRichText: cc.Node,
        ziMoJiaDi: cc.Node,
        ziMoJiaFan: cc.Node,
        ziMoHu: cc.Node,
        dianPaoHu: cc.Node,
        huanSanZhang: cc.Node,
        dianGangHua_dianPao: cc.Node,
        dianGangHua_ziMo: cc.Node,
        dai19JiangDui: cc.Node,
        mengQingZhongZhang: cc.Node,
        tianDiHu: cc.Node,
        fan2: cc.Node,
        fan3: cc.Node,
        fan4: cc.Node,
        fan6: cc.Node,
        roundCount4: cc.Node,
        roundCount8: cc.Node,
        gamePeopleNumber: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        fanArray = [2, 3, 4, 6];
        infoTextNode = this.modeInfoRightRichText.getComponent(cc.RichText);
        gameMode = require("gameMode").gameMode;
        if (Global.gameMode != null) {
            gameMode = Global.gameMode;
        }
        gameMode.gamePeopleNumber = 4;
        this.initalGameModeUIByModeData();
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

    xueZhanDaoDi: function xueZhanDaoDi() {
        infoTextNode.string = "血战到底：血战麻将即指“血战到底”玩法，指1家胡了并不结束该局，而是未胡的玩家继续打，直到有3家都胡或者余下的玩家流局。";
        gameMode.gamePeopleNumber = "4";
    },
    xueLiuChengHe: function xueLiuChengHe() {
        infoTextNode.string = "血流成河：此规则和血战基本一样，不允许天胡，必须换三张。";
        gameMode.gamePeopleNumber = "4";
    },
    sanRenMahJong: function sanRenMahJong() {
        infoTextNode.string = "三人麻将：此规则和血战基本一样，只是人数为三人即可开始。";
        gameMode.gamePeopleNumber = "3";
    },
    erRenMahJong: function erRenMahJong() {
        infoTextNode.string = "二人麻将：此规则和血战基本一样，只是人数为二人即可开始。";
        gameMode.gamePeopleNumber = "2";
    },
    //-------------option select function---------------------------------------------------------
    //ziMoJiadiToggle,ziMoJiadiToggle,ziMoJiadiToggle,daiYaojiuToggle,menQingToggle,tianDiHuToggle,fan2Toggle,fan3Toggle,fan4Toggle,fan6Toggle
    //ju8Toggle,ju4Toggle,
    setGameMode: function setGameMode(porpertitesName, tog) {
        if (tog != null) {
            // if (porpertitesName == "ziMoJiadiToggle") {
            if (tog.isChecked) {
                eval("gameMode." + porpertitesName + " = '1'");
                if (porpertitesName == "ziMoJiaDi") {
                    eval("gameMode.ziMoJiaFan = '0'");
                }
                if (porpertitesName == "ziMoJiaFan") {
                    eval("gameMode.ziMoJiaDi = '0'");
                }
                if (porpertitesName == "dianGangHua_dianPao") {
                    eval("gameMode.dianGangHua_ziMo = '0'");
                }
                if (porpertitesName == "dianGangHua_ziMo") {
                    eval("gameMode.dianGangHua_dianPao = '0'");
                }
                if (porpertitesName.indexOf("fan") >= 0) {
                    if (porpertitesName == "fan2") {
                        fanArray.splice(0, 1);
                    }
                    if (porpertitesName == "fan3") {
                        fanArray.splice(1, 1);
                    }
                    if (porpertitesName == "fan4") {
                        fanArray.splice(2, 1);
                    }
                    if (porpertitesName == "fan6") {
                        fanArray.splice(3, 1);
                    }
                    for (var i = 0; i < fanArray.length; i++) {
                        eval("gameMode.fan" + fanArray[i] + " = '0'");
                    }
                }

                if (porpertitesName == "roundCount4") {
                    eval("gameMode.roundCount8 = '0'");
                }
                if (porpertitesName == "roundCount8") {
                    eval("gameMode.roundCount4 = '0'");
                }
            } else {
                eval("gameMode." + porpertitesName + " = '0'");
            }

            //}
        }

        Global.gameMode = gameMode;
    },
    optionSelectFunction: function optionSelectFunction(event) {
        var node = event.target;
        cc.log(node.name);
        var partentNode = node.parent;
        var tog = partentNode.getComponent(cc.Toggle);
        if (tog != null) {
            cc.log("partentNode:" + partentNode.name + "-" + tog.isChecked);
            if (partentNode.name == "ziMoJiadiToggle") {
                this.setGameMode("ziMoJiaDi", tog);
            }
            if (partentNode.name == "ziMoJiaFanToggle") {
                this.setGameMode("ziMoJiaFan", tog);
            }
            if (partentNode.name == "dianGangDianPaoToggle") {
                this.setGameMode("dianGangHua_dianPao", tog);
            }
            if (partentNode.name == "huanSanZhangToggle") {
                this.setGameMode("huanSanZhang", tog);
            }
            if (partentNode.name == "dianGangZiMoToggle") {
                this.setGameMode("dianGangHua_ziMo", tog);
            }
            if (partentNode.name == "daiYaojiuToggle") {
                this.setGameMode("dai19JiangDui", tog);
            }
            if (partentNode.name == "menQingToggle") {
                this.setGameMode("mengQingZhongZhang", tog);
            }
            if (partentNode.name == "tianDiHuToggle") {
                this.setGameMode("tianDiHu", tog);
            }
            if (partentNode.name == "fan2Toggle") {
                this.setGameMode("fan2", tog);
            }
            if (partentNode.name == "fan3Toggle") {
                this.setGameMode("fan3", tog);
            }
            if (partentNode.name == "fan4Toggle") {
                this.setGameMode("fan4", tog);
            }
            if (partentNode.name == "fan6Toggle") {
                this.setGameMode("fan6", tog);
            }
            if (partentNode.name == "ju4Toggle") {
                this.setGameMode("roundCount4", tog);
            }
            if (partentNode.name == "ju8Toggle") {
                this.setGameMode("roundCount8", tog);
            }
            this.initalGameModeUIByModeData();
        }
    },

    initalGameModeUIByModeData: function initalGameModeUIByModeData() {
        if (gameMode.ziMoJiaDi + "" == "1") {
            this.ziMoJiaDi.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.ziMoJiaDi.getComponent(cc.Toggle).isChecked = false;
        }

        if (gameMode.ziMoJiaFan + "" == "1") {
            this.ziMoJiaFan.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.ziMoJiaFan.getComponent(cc.Toggle).isChecked = false;
        }
        // if (gameMode.ziMoHu + "" == "1") {
        //     this.ziMoHu.getComponent(cc.Toggle).isChecked = true
        // } else {
        //     this.ziMoHu.getComponent(cc.Toggle).isChecked = false
        // }
        // if (gameMode.dianPaoHu + "" == "1") {
        //     this.dianPaoHu.getComponent(cc.Toggle).isChecked = true
        // } else {
        //     this.dianPaoHu.getComponent(cc.Toggle).isChecked = false
        // }
        // if (gameMode.huanSanZhang + "" == "1") {
        //     this.huanSanZhang.getComponent(cc.Toggle).isChecked = true
        // } else {
        //     this.huanSanZhang.getComponent(cc.Toggle).isChecked = false
        // }
        if (gameMode.dianGangHua_dianPao + "" == "1") {
            this.dianGangHua_dianPao.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.dianGangHua_dianPao.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.dianGangHua_ziMo + "" == "1") {
            this.dianGangHua_ziMo.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.dianGangHua_ziMo.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.dai19JiangDui + "" == "1") {
            this.dai19JiangDui.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.dai19JiangDui.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.mengQingZhongZhang + "" == "1") {
            this.mengQingZhongZhang.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.mengQingZhongZhang.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.tianDiHu + "" == "1") {
            this.tianDiHu.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.tianDiHu.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.fan2 + "" == "1") {
            this.fan2.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.fan2.getComponent(cc.Toggle).isChecked = false;
        }
        cc.log("gameMode.fan3:" + gameMode.fan3);
        if (gameMode.fan3 + "" == "1") {
            this.fan3.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.fan3.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.fan4 + "" == "1") {
            this.fan4.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.fan4.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.roundCount4 + "" == "1") {
            this.roundCount4.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.roundCount4.getComponent(cc.Toggle).isChecked = false;
        }
        if (gameMode.roundCount8 + "" == "1") {
            this.roundCount8.getComponent(cc.Toggle).isChecked = true;
        } else {
            this.roundCount8.getComponent(cc.Toggle).isChecked = false;
        }
    },
    // setting all values into  gobal mode object and swtich to table sence.
    buildNewRoom: function buildNewRoom() {
        //Global.gameMode = gameMode;
        //cc.director.loadScene('table');
    }
});

cc._RFpop();
},{"gameMode":"gameMode"}],"GameModeOptionController":[function(require,module,exports){
"use strict";
cc._RFpush(module, '857f0feyVtAi6xSUtNGTFCX', 'GameModeOptionController');
// script/controllers/GameModeOptionController.js

var gameModeModel = require('gameMode').gameMode;
var checkLableColor = new cc.Color(231, 28, 77);
var noCheckLableColor = new cc.Color(121, 81, 44);
var gameModeLayer;
var btnListLayer;
var topInfoLayer;
cc.Class({
  "extends": cc.Component,

  properties: {
    // foo: {
    //    default: null,      // The default value will be used only when the component attaching
    //                           to a node for the first time
    //    url: cc.Texture2D,  // optional, default is typeof default
    //    serializable: true, // optional, default is true
    //    visible: true,      // optional, default is true
    //    displayName: 'Foo', // optional
    //    readonly: false,    // optional, default is false
    // },
    // ...
    noCheckBoxBg: cc.SpriteFrame,
    CheckBoxBg: cc.SpriteFrame
  },

  // gameModeModel:cc.script
  // use this for initialization
  onLoad: function onLoad() {
    gameModeLayer = cc.find("Canvas/gameModeSelectLayer/mainSelectMode/mainModeOption/GameModeOption1/ListLayout");
    btnListLayer = cc.find("Canvas/gameModeSelectLayer/mainSelectMode/BtnList");
    topInfoLayer = cc.find("Canvas/topInfoLayer");
    gameModeModel.ziMoJiaDi = 1;
    gameModeModel.ziMoHu = 0;
    gameModeModel.huanSanZhang = 0;
    gameModeModel.ziMoJiaFan = 0;
    gameModeModel.dianPaoHu = 0;
    gameModeModel.dianGangHua_dianPao = 0;
    gameModeModel.dianGangHua_ziMo = 0;
    gameModeModel.dai19JiangDui = 0;
    gameModeModel.mengQingZhongZhang = 0;
    gameModeModel.tianDiHu = 0;
    gameModeModel.fan2 = 0;
    gameModeModel.fan3 = 0;
    gameModeModel.fan4 = 0;
    gameModeModel.roundCount4 = 0;
    gameModeModel.roundCount8 = 0;
    //
    this.initlZiMoJiaDi();
  },

  // called every frame, uncomment this function to activate update callback
  // update: function (dt) {

  // },
  /*
  normalSprite SpriteFrame
  普通状态下按钮所显示的 Sprite 。
  pressedSprite SpriteFrame
  按下状态时按钮所显示的 Sprite 。
  hoverSprite SpriteFrame
  悬停状态下按钮所显示的 Sprite 。
  disabledSprite SpriteFrame
    */
  initlZiMoJiaDi: function initlZiMoJiaDi() {

    //var btn= gameModeLayer.getChildByName("zibojiadiBtn");
    var btn = cc.find("rowOption1/zibojiadiBtn", gameModeLayer);
    var btnBtn = btn.getComponent(cc.Button);
    var btnLable = cc.find("rowOption1/ziMoJiaDiLabel", gameModeLayer);
    if (gameModeModel.ziMoJiaDi == 1) {
      btnBtn.normalSprite = this.CheckBoxBg;
      btnBtn.pressedSprite = this.CheckBoxBg;
      btnBtn.hoverSprite = this.CheckBoxBg;
      btnLable.color = checkLableColor;
    };

    for (var i = 2; i < 6; i++) {
      var btnLayerName = "BtnLay" + i;
      var arrowName = "Arrow" + i;
      var arrow = cc.find("" + btnLayerName + "/" + arrowName, btnListLayer);
      //console.log("arrow:"+"Canvas/gameModeSelectLayer/mainSelectMode/BtnList/"+btnLayerName+"/"+arrowName);
      arrow.active = false;
    }
    //disable dianPaoHu
    var dianPaoHubtn = cc.find("rowOption1/dianPaoHuBtn", gameModeLayer);
    var dianPaoHuLable = cc.find("rowOption1/dianPaoHuLabel", gameModeLayer);
    this.disableBtnAndLable(dianPaoHubtn, dianPaoHuLable);
    dianPaoHubtn = cc.find("rowOption2/ziMoHuBtn", gameModeLayer);
    dianPaoHuLable = cc.find("rowOption2/ziMoHuLabel", gameModeLayer);
    this.disableBtnAndLable(dianPaoHubtn, dianPaoHuLable);
  },
  //自摸加底 option
  updateZiMoJiaDi: function updateZiMoJiaDi() {
    console.log("gameModeModel:" + gameModeModel.ziMoJiaDi);
    //cc.log(comp.uuid);
    var btn = cc.find("rowOption1/zibojiadiBtn", gameModeLayer);
    var btnBtn = btn.getComponent(cc.Button);

    // var parent=btn.getpa
    var btnLable = cc.find("rowOption1/ziMoJiaDiLabel", gameModeLayer);
    gameModeModel.ziMoJiaDi = this.updateUtilsBtnAndLable(btnBtn, btnLable, gameModeModel.ziMoJiaDi);
  },
  updateZiMoJiaFan: function updateZiMoJiaFan() {
    console.log("gameModeModel:" + gameModeModel.ziMoJiaFan);
    //cc.log(comp.uuid);
    var btn = cc.find("rowOption1/zibojiafanBtn", gameModeLayer);
    var btnBtn = btn.getComponent(cc.Button);
    var btnLable = cc.find("rowOption1/ziMoJiaFanLabel", gameModeLayer);
    gameModeModel.ziMoJiaFan = this.updateUtilsBtnAndLable(btnBtn, btnLable, gameModeModel.ziMoJiaFan);
  },
  updateDianGangHua_dianPao: function updateDianGangHua_dianPao() {},
  updateDianGangHua_ziMo: function updateDianGangHua_ziMo() {},
  updateDai19JiangDui: function updateDai19JiangDui() {},
  updateMengQingZhongZhang: function updateMengQingZhongZhang() {},
  updateTianDiHu: function updateTianDiHu() {},
  updateFan2: function updateFan2() {},
  updateFan3: function updateFan3() {},
  updateFan4: function updateFan4() {},
  updateRoundCount4: function updateRoundCount4() {},
  updateRoundCount8: function updateRoundCount8() {},
  updateHuanSanZhang: function updateHuanSanZhang() {},
  updateZiMoHu: function updateZiMoHu() {},
  updateDianPaoHu: function updateDianPaoHu() {},

  //----------------------------Utils function--------------------------------------------------------
  updateUtilsBtnAndLable: function updateUtilsBtnAndLable(btnBtn, btnLable, confValue) {
    if (confValue == 1) {
      btnBtn.normalSprite = this.noCheckBoxBg;
      btnBtn.pressedSprite = this.noCheckBoxBg;
      btnBtn.hoverSprite = this.noCheckBoxBg;
      btnLable.color = noCheckLableColor;
      return 0;
    } else {
      btnBtn.normalSprite = this.CheckBoxBg;
      btnBtn.pressedSprite = this.CheckBoxBg;
      btnBtn.hoverSprite = this.CheckBoxBg;
      btnLable.color = checkLableColor;
      return 1;
    }
  },
  disableBtnAndLable: function disableBtnAndLable(btnBtn, btnLable) {
    btnBtn.active = false;
    btnLable.active = false;
  },
  //----------------------------Utils function end--------------------------------------------------------
  //Left button mode click function...........
  //zibojiadiBtn,ziMoJiaDiLabel,zibojiafanBtn,ziMoJiaFanLabel,dianPaoHuBtn,dianPaoHuLabel
  //dianGangHuaDianPaoBtn,dianGangHuaDianPaoLabel
  xueZhanDaoDiButtonClick: function xueZhanDaoDiButtonClick() {},
  xueLiuChengHeButtonClick: function xueLiuChengHeButtonClick() {},
  DaoDaoHuButtonClick: function DaoDaoHuButtonClick() {},
  NeiJiangMaJiangButtonClick: function NeiJiangMaJiangButtonClick() {},
  SanRenLiangFangButtonClick: function SanRenLiangFangButtonClick() {}

});

cc._RFpop();
},{"gameMode":"gameMode"}],"GameTableController":[function(require,module,exports){
"use strict";
cc._RFpush(module, '3e9f5gjELJBgpz05ThUKn9O', 'GameTableController');
// script/controllers/GameTableController.js

var gameMode;
var userInfo;
var serverUrl;
var socket;
var roomNumber;
var messageDomain;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        tableNode: cc.Node,
        user1Node: cc.Node,
        user2Node: cc.Node,
        user3Node: cc.Node,
        user4Node: cc.Node,
        userReadyOK: cc.SpriteFrame,
        userReadyNotOk: cc.SpriteFrame

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.user1Node.active = false;
        this.user2Node.active = false;
        this.user3Node.active = false;
        this.user4Node.active = false;
    },

    showUserInfo: function showUserInfo() {
        var userList = Global.userList;
        if (userList != null && userList != undefined) {
            for (var i = 0; i < userList.length; i++) {
                var user = userList[i];
            }
        }
    },

    initalUserInfoFromGobalList: function initalUserInfoFromGobalList() {
        var numberOrder = [3, 4, 1, 2];
        var userList = Global.userList;
        var userInfo = Global.userInfo;
        var index = -1;
        if (userList != null && userList != undefined) {
            var tempList = [];
            //1.find the start index
            for (var i = 0; i < userList.length(); i++) {
                var tableUserInfo = userList[i];
                if (index < 0) {
                    if (userInfo.openid == tableUserInfo.openid) {
                        tempList.push(tableUserInfo);
                        index = i;
                    }
                } else {
                    tempList.push(tableUserInfo);
                }
            }

            if (index > 0) {
                for (var i = 0; i < index; i++) {
                    tempList.push(userList[i]);
                }
            }

            //start fill the user info from index
            for (var i = 0; i < tempList.length(); i++) {
                var gameUser = tempList[i];
                var userNodeName = "user" + numberOrder[i] + "Node";
                var userNode = cc.find(userNodeName, this.tableNode);
                userNode.active = true;
                var userInfoNode = cc.find("userInfoNode", userNode);
                var userReadyNode = cc.find("userReadyNode", userInfoNode);
                var readyButton = cc.find("readyButton", userReadyNode);
                var s = readyButton.getComponent(cc.Sprite);
                if (gameUser.gameReadyStatu == "1") {
                    s.spriteFrame = this.userReadyOK;
                } else {
                    s.spriteFrame = this.userReadyNotOk;
                }
            }
        }
    }
});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"GameTableNetWork":[function(require,module,exports){
"use strict";
cc._RFpush(module, '76eeauiX4dOwp5EyKPFN5lL', 'GameTableNetWork');
// script/service/GameTableNetWork.js

var client;
var roomNumber;
var userInfo;
var actionUIScriptNode;
var alertMessageUI;
var serverUrl;
var socket;
var messageDomain;
var connect_callback;
var userInfoScript;
var huanSanZhangScript;
var quePaiScript;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        actionNodeScript: cc.Node,
        alertMessageNodeScirpt: cc.Node,
        userInfoScriptNode: cc.Node,

        huanSanZhangNode: cc.Node,
        quePaiScriptNode: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        actionUIScriptNode = self.actionNodeScript.getComponent("gameConfigButtonListAction");
        alertMessageUI = self.alertMessageNodeScirpt.getComponent("alertMessagePanle");
        userInfoScript = self.userInfoScriptNode.getComponent("tableUserInfo");
        messageDomain = require("messageDomain").messageDomain;
        Global.subid = 0;
        connect_callback = function (error) {
            // display the error's message header:
            alert(error.headers.message);
        };

        huanSanZhangScript = self.huanSanZhangNode.getComponent("huanPaiUI");
        quePaiScript = self.quePaiScriptNode.getComponent("quepaiScript");
    },
    connectByPrivateChanel: function connectByPrivateChanel() {
        if (client == null || client == undefined) {
            userInfo = require("userInfoDomain").userInfoDomain;
            userInfo = Global.userInfo;
            roomNumber = userInfo.roomNumber;
            serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;
            socket = new SockJS(serverUrl + "/stomp");
            console.log("conect to server");
            client = Stomp.over(socket);
        }
    },
    subscribeToPrivateChanelNoConnetAgain: function subscribeToPrivateChanelNoConnetAgain(thisRooNumber) {
        client.subscribe("/queue/privateUserChanel" + thisRooNumber, (function (message) {
            var bodyStr = message.body;
            cc.log("######################");
            cc.log(bodyStr);
            var obj = JSON.parse(bodyStr);
            if (obj != undefined && obj != null) {
                for (var p in obj) {
                    messageDomain[p] = obj[p];
                }
                actionUIScriptNode.closeLoadingIcon();
                // actionUIScriptNode.showGameTalbe();
                if (messageDomain.messageAction == "buildNewRoundLun") {
                    cc.log(messageDomain.messageBody);
                    var userObj = JSON.parse(messageDomain.messageBody);
                    var userList = [];
                    userObj.pointIndex = "3";
                    userObj.zhuang = "1";
                    userList.push(userObj);
                    Global.userList = userList;
                    actionUIScriptNode.showGameTalbe("1");
                    /*
                    if (userInfo.openid==userObj.openid) {
                       //inital the gobal user list by self user             
                    } else {
                       alertMessageUI.text = messageDomain.messageBody;
                       alertMessageUI.setTextOfPanel();
                    }*/
                }

                //intalUserInfoReadyIcon
                if (messageDomain.messageAction == "userReadyStatuChange") {
                    var Obj = JSON.parse(messageDomain.messageBody);
                    if (Obj.messageExecuteFlag == "success") {
                        var userList = Global.userList;
                        var gameUserList = JSON.parse(Obj.messageExecuteResult);
                        cc.log("%%%%%%Obj:" + Obj.messageExecuteResult);
                        for (var j = 0; j < gameUserList.length; j++) {
                            var gameUser = gameUserList[j];
                            for (var i = 0; i < userList.length; i++) {
                                var user = userList[i];
                                if (user.openid == gameUser.openid) {
                                    user.gameReadyStatu = gameUser.gameReadyStatu;
                                }
                            }
                        }
                        Global.userList = userList;
                        cc.log("Global.userList:" + Global.userList.toString());
                        userInfoScript.intalUserInfoReadyIcon();
                    } else {
                        alertMessageUI.text = Obj.messageExecuteResult;
                        alertMessageUI.setTextOfPanel();
                    }
                };
                //--------------------------------------------------
                if (messageDomain.messageAction == "joinRoom") {
                    var Obj = JSON.parse(messageDomain.messageBody);
                    cc.log("%%%%%%Obj.messageExecuteFlag:" + Obj.messageExecuteFlag);
                    if (Obj.messageExecuteFlag == "success") {
                        Global.joinRoomNumber = messageDomain.messageBelongsToPrivateChanleNumber;
                        var joinRoomJson = JSON.parse(Obj.messageExecuteResult);
                        var gameUserList = JSON.parse(joinRoomJson.userList);
                        var joinMode = JSON.parse(joinRoomJson.gameMode);
                        if (joinMode != null && joinMode != undefined) {
                            Global.gameMode = joinMode;
                            cc.log("joinMode:" + Global.gameMode.toString());
                        }
                        var existFlag = false;

                        cc.log("%%%%%%Obj:" + Obj.messageExecuteResult);
                        cc.log("%%%%%%gameUserList:" + gameUserList.length);
                        // cc.log("%%%%%%gameUser:"+gameUser.toString());
                        var userList = [];
                        for (var j = 0; j < gameUserList.length; j++) {
                            var getUser = gameUserList[j];
                            cc.log("%%%%%%gamegetUser:" + getUser.openid);
                            userList.push(getUser);
                        }

                        cc.log("userList 1:" + userList.toString());
                        Global.userList = userList;
                        //show game table
                        if (Global.joinRoomNumber == Global.userInfo.roomNumber) {
                            actionUIScriptNode.showGameTalbe("1");
                        } else {
                            actionUIScriptNode.showGameTalbe("0");
                        }
                    } else {
                        alertMessageUI.text = Obj.messageExecuteResult;
                        alertMessageUI.setTextOfPanel();
                    }
                }

                if (messageDomain.messageAction == "faPai") {
                    var gameUserList = JSON.parse(messageDomain.messageBody);
                    var userList2 = Global.userList;
                    var userInfo = Global.userInfo;
                    for (var j = 0; j < gameUserList.length; j++) {
                        var gameUser = gameUserList[j];
                        for (var i = 0; i < userList2.length; i++) {
                            var user = userList2[i];
                            if (user.openid == gameUser.openid) {
                                var paiListString = gameUser.paiList;

                                paiListString = this.changeJsonListStringToArrayString(paiListString);
                                cc.log("gameUser.paiList:" + paiListString);
                                user.paiList = paiListString;
                            }

                            //   if (user.openid == userInfo.openid) {
                            //       cc.log("found 3:"+user.openid);
                            //        user.pointIndex =3
                            //   }
                        }
                    }
                    Global.userList = userList2;
                    //table user info

                    userInfoScript.initalUserPai("inital");
                }

                //huan sanzhang
                if (messageDomain.messageAction == "huanSanZhangFaPai") {}
                //--------------------------------------Game Action  -----------------------------------------------
                if (messageDomain.messageAction == "gameAction") {
                    var userList = Global.userList;
                    var userInfo = Global.userInfo;
                    var obj = JSON.parse(messageDomain.messageBody);
                    var fromUserOpenid = obj.fromUserOpenid;
                    if (obj.actionName == "chuPai") {
                        for (var i = 0; i < userList.length; i++) {
                            if (userList[i].openid == userInfo.openid) {
                                //play chupai action on self
                            } else {
                                    //play chupai action on other side
                                }
                        }
                    }
                }

                // if (messageDomain.messageAction == "userReadyStatuChange") {
                //     if (messageDomain.messageBody.indexOf("success") >= 0) {
                //         var temp = messageDomain.messageBody.split(":");
                //         var openid = temp[1];
                //     } else {
                //         alertMessageUI.text = messageDomain.messageBody;
                //         alertMessageUI.setTextOfPanel();
                //     }
                // }
            } else {

                    console.log("No found correct user info return from server ,please check .");
                }
        }).bind(this), function () {
            cc.log("websocket connect subscribe Error:233");
            //client.disconnect();
        });
    },
    subscribeToPrivateChanel: function subscribeToPrivateChanel(thisRooNumber) {
        client.connect({}, (function () {
            this.subscribeToPrivateChanelNoConnetAgain(thisRooNumber);
        }).bind(this), function () {
            cc.log("websocket connect  Error:234");
            //client.disconnect();
        });
    },
    initalClient: function initalClient() {
        if (client == null || client == undefined) {
            this.connectByPrivateChanel();
            this.subscribeToPrivateChanel(roomNumber);
        }
    },
    //-------------------------------chu pai action---------------------------------------------
    chuPaiAction: function chuPaiAction(userOpenId, paiNumber) {
        var joinRoomNumber = Global.joinRoomNumber;
        var o = new Object();
        //var gameStep = require("gameStep").gameStep;

        o.fromUserOpenid = userOpenId;
        o.actionName = "chuPai";
        o.paiNumber = paiNumber;
        o.toUserOpenid = userOpenId;

        var messageObj = this.buildSendMessage(JSON.stringify(o), joinRoomNumber, "gameAction");
        this.sendMessageToServer(messageObj);
    },
    //--------------------------------------------------------------------------------------------------------
    joinRoom: function joinRoom(joinRoomNumber) {
        Global.joinRoomNumber = joinRoomNumber;
        client.unsubscribe("sub-" + Global.subid);

        //client.disconnect();
        //this.connectByPrivateChanel();
        this.subscribeToPrivateChanelNoConnetAgain(joinRoomNumber);
        Global.subid = Global.subid + 1;
        cc.log("Global.subid:" + Global.subid);
        userInfo = Global.userInfo;
        var openId = userInfo.openid;
        var messageObj = this.buildSendMessage(openId, joinRoomNumber, "joinRoom");
        this.sendMessageToServer(messageObj);
    },
    checkRoomNumber: function checkRoomNumber() {},
    //--------------------------------------------------------------------------------------------------------
    buildNewGameRound: function buildNewGameRound() {
        // this.initalClient();
        cc.log("buildNewGameRound-----------------------");
        var gameMode = Global.gameMode;
        if (gameMode == null) {
            gameMode = require("gameMode").gameMode;
        }
        userInfo = Global.userInfo;
        Global.joinRoomNumber = userInfo.roomNumber;
        if (gameMode != null) {
            roomNumber = userInfo.roomNumber;
            var o = new Object();
            o.userOpenId = userInfo.openid;
            //add limit for mode
            if (Global.gameConfigSetting != null && Global.gameConfigSetting != undefined) {
                gameMode.publicIpLimit = Global.gameConfigSetting.publicIpLimit;
                gameMode.gpsLimit = Global.gameConfigSetting.gpsLimit;
            } else {
                gameMode.publicIpLimit = "0";
                gameMode.gpsLimit = "0";
            }
            o.gameMode = gameMode;
            cc.log("buildNewGameRound2-----------------------");
            var messageObj = this.buildSendMessage(JSON.stringify(o), roomNumber, "buildNewRoundLun");

            this.sendMessageToServer(messageObj);
            cc.log("buildNewGameRound3-----------------------");
        }
        Global.gameMode = gameMode;

        actionUIScriptNode.showLoadingIcon();
    },
    closeGameRoundLun: function closeGameRoundLun() {
        userInfo = Global.userInfo;
        if (userInfo != null) {
            roomNumber = userInfo.roomNumber;
            var messageObj = this.buildSendMessage(roomNumber, roomNumber, "closeGameRoundLun");
            this.sendMessageToServer(messageObj);
        }
    },
    getFaPai: function getFaPai() {
        var messageObj = this.buildSendMessage("", roomNumber, "faPai");
        this.sendMessageToServer(messageObj);
    },
    //-------------------send huan sanzhang -----------------------------------------------
    //Global.huanSanZhangPaiList
    sendQuePai: function sendQuePai() {

        userInfo = Global.userInfo;
        var que = userInfo.quePai;
        var userOpenId = userInfo.openid;
        var joinRoomNumber = Global.joinRoomNumber;
        var o = new Object();
        o.huanSanZhangPaiList = paiList;
        o.openid = userOpenId;
        var messageObj = this.buildSendMessage(JSON.stringify(o), joinRoomNumber, "userHuanSanZhang");
        this.sendMessageToServer(messageObj);
    },

    //-------------------send huan sanzhang -----------------------------------------------
    //Global.huanSanZhangPaiList
    sendHuanSanZhang: function sendHuanSanZhang() {
        var paiList = "";
        for (var i = 0; i < 3; i++) {
            paiList = paiList + Global.huanSanZhangPaiList[i] + ",";
        }
        paiList = paiList.substring(0, paiList.length - 1);
        userInfo = Global.userInfo;
        var userOpenId = userInfo.openid;
        var joinRoomNumber = Global.joinRoomNumber;
        var o = new Object();
        o.huanSanZhangPaiList = paiList;
        o.openid = userOpenId;
        var messageObj = this.buildSendMessage(JSON.stringify(o), joinRoomNumber, "userHuanSanZhang");
        this.sendMessageToServer(messageObj);
    },
    //-------------------User ready action-------------------------------------------------
    sendUserReadyToServer: function sendUserReadyToServer(event) {
        var node = event.target;
        var readyStatu = "0";
        cc.log("node:" + node.name);
        var s = node.getComponent(cc.Sprite);
        cc.log("s:" + s.spriteFrame.name);
        if (s.spriteFrame.name == "26") {
            readyStatu = "1";
        } else {
            readyStatu = "0";
        }
        userInfo = Global.userInfo;
        var userOpenId = userInfo.openid;
        var joinRoomNumber = Global.joinRoomNumber;
        var o = new Object();
        o.userReadyStatu = readyStatu;
        o.openid = userOpenId;
        var messageObj = this.buildSendMessage(JSON.stringify(o), joinRoomNumber, "userReadyStatuChange");
        this.sendMessageToServer(messageObj);
    },

    //--------------------------------------------------------------------------------------------------------

    sendMessageToServer: function sendMessageToServer(messageObj) {

        client.send("/app/user_private_message", {}, JSON.stringify(messageObj));
    },

    buildSendMessage: function buildSendMessage(messageBody, roomNum, action) {
        var messageDomain = require("messageDomain").messageDomain;
        messageDomain.messageBelongsToPrivateChanleNumber = roomNum;
        messageDomain.messageAction = action;
        messageDomain.messageBody = messageBody;

        return messageDomain;
    },
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    //----------------untils-------------------------------
    changeJsonListStringToArrayString: function changeJsonListStringToArrayString(tempString) {
        var str = "";
        if (tempString != null && tempString != undefined) {
            tempString = tempString.replace("[", "");
            tempString = tempString.replace("]", "");
            var list = tempString.split(",");
            for (var i = 0; i < list.length; i++) {
                if (list[i] != null && list[i] != undefined) {
                    var s = list[i] + "";
                    s = s.trim();
                    str = str + s + ",";
                }
            }
        }
        if (str.substring(str.length - 1) == ",") {
            str = str.substring(0, str.length - 1);
        }
        return str;
    }
});

cc._RFpop();
},{"gameMode":"gameMode","messageDomain":"messageDomain","userInfoDomain":"userInfoDomain"}],"GameTableRoom":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6644burEGRNWp50bOhkoa6a', 'GameTableRoom');
// script/service/GameTableRoom.js

var userListArray;
var privateClient;
var serverUrl;
var socket;
var paiListArray;
var gameModeModel = require('gameMode').gameMode;
var preRoomNumber;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        createRoomBtn: cc.Node,
        backRoomBtn: cc.Node,
        tableNode: cc.Node,
        gameModeNode: cc.Node,
        gameMainMenu: cc.Node,
        roomNumberLayer: cc.Node,
        userReadyLayer: cc.Node,
        userReady1Node: cc.Node,
        userReady2Node: cc.Node,
        userReady3Node: cc.Node,
        userReady4Node: cc.Node,
        changeUserStatusYesBtnImage: cc.SpriteFrame,
        changeUserStatusNoBtnImage: cc.SpriteFrame,
        userStatusYesImage: cc.SpriteFrame,
        userStatusNoImage: cc.SpriteFrame,
        quePaiNode: cc.Node,
        huanPaiNode: cc.Node,
        tableCenterNode: cc.Node,
        w1: cc.SpriteFrame,
        w2: cc.SpriteFrame,
        w3: cc.SpriteFrame,
        w4: cc.SpriteFrame,
        w5: cc.SpriteFrame,
        w6: cc.SpriteFrame,
        w7: cc.SpriteFrame,
        w8: cc.SpriteFrame,
        w9: cc.SpriteFrame,
        t1: cc.SpriteFrame,
        t2: cc.SpriteFrame,
        t3: cc.SpriteFrame,
        t4: cc.SpriteFrame,
        t5: cc.SpriteFrame,
        t6: cc.SpriteFrame,
        t7: cc.SpriteFrame,
        t8: cc.SpriteFrame,
        t9: cc.SpriteFrame,
        a1: cc.SpriteFrame,
        a2: cc.SpriteFrame,
        a3: cc.SpriteFrame,
        a4: cc.SpriteFrame,
        a5: cc.SpriteFrame,
        a6: cc.SpriteFrame,
        a7: cc.SpriteFrame,
        a8: cc.SpriteFrame,
        a9: cc.SpriteFrame
    },

    // use this for initialization
    onLoad: function onLoad() {
        cc.log("***********:" + this.name);
        //inital the websokect public var
        serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;
        socket = new SockJS(serverUrl + "/stomp");

        //hide the join room layer
        this.roomNumberLayer.active = false;
        this.userReadyLayer.active = false;
        this.backRoomBtn.active = false;
        this.createRoomBtn.active = true;
        //this.userReady1Node.active

        userListArray = new Array();
        paiListArray = new Array();
        if (Global.userInfo == undefined || Global.userInfo == null) {
            console.log("Error: no found correct user ,please check server or network.");
        } else {
            var userInfo = Global.userInfo;
        }
        //intal the userList by self point 3
        userListArray[0] = null;
        userListArray[1] = null;
        //status 0-offline ,1-online ,2-not ready, 3-ready,4-gameing,5-other
        userInfo.gameingStatu = "1";
        userInfo.zhuangStatu = "0";
        userListArray[2] = userInfo;
        userListArray[3] = null;
        //inital the user ready icon
        this.initalUserReadyLayer();
        //intal the websokect
        this.initalPrivateChanleForUser(userInfo.roomNumber, "");

        //inital the game mode domain 
        if (gameModeModel.gamePeopleNumber == 0) {
            gameModeModel.gamePeopleNumber = 4;
        }
    },

    //--------------------------------------Game Table Function Starting----------------------------------------------------------
    createRoom_clearTableInitalUserInfo: function createRoom_clearTableInitalUserInfo() {
        cc.log("createRoom_clearTableInitalUserInfo starting......");
        for (var i = 1; i < 5; i++) {
            cc.log("i:" + i);
            var user1PaiListLayerNode = this.tableNode.getChildByName("user" + i + "PaiListLayer");
            user1PaiListLayerNode.active = false;
            var user1HidePaiLayerNode = this.tableNode.getChildByName("user" + i + "HidePaiLayer");
            user1HidePaiLayerNode.active = false;
            var user1ChuPaiLayerNode = this.tableNode.getChildByName("user" + i + "ChuPaiLayer");
            user1ChuPaiLayerNode.active = false;
            //hide other uer info icon,until other user join this room
            var userInfo = this.tableNode.getChildByName("user" + i + "Layer");
            if (i != 3) {
                userInfo.active = false;
            } else {
                //inital the user self to center of the x point
                //x 602,y -165,top 490
                userInfo.x = 0;
                var userWiget = userInfo.getComponent(cc.Widget);
                userWiget.top = 600;
                //userWiget.right = 617;
                userWiget.isAlignHorizontalCenter = true;
                userWiget.horizontalCenter = 0;
                //inital self user info
                this.initalUserInfoLayer(userInfo);
                //inital self user icon

                this.userReady3Node.active = true;
            }
        }
    },
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    //end the room
    endToRoom: function endToRoom() {
        this.backRoomBtn.action = false;
        //build remove all online room from server
        // this.buildCanleUserMessageAndSendIt(userListArray[2].roomNumber);
    },
    //back to room by preRoomNumber
    backToRoom: function backToRoom() {
        if (privateClient != null || privateClient != undefined) {
            privateClient.unsubscribe();
        }
        socket = new SockJS(serverUrl + "/stomp");
        this.initalPrivateChanleForUser(preRoomNumber, "send");
    },
    //create a new room
    createRoomAndEnterTable: function createRoomAndEnterTable() {

        if (privateClient == null || privateClient == undefined) {
            var userInfo = Global.userInfo;
            socket = new SockJS(serverUrl + "/stomp");
            userListArray[2] = userInfo;
            this.initalPrivateChanleForUser(userInfo.roomNumber, "update");
        } else {
            this.buildGameModeMessageAndSendIt(userListArray[2].roomNumber);
        }
        //create a new room ,will default as zhuang
        userListArray[2].zhuangStatu = "1";

        this.showGameTable();
    },
    closeRoomNumberLayer: function closeRoomNumberLayer() {
        var listButton = this.gameMainMenu.getChildByName("ListButton");
        var topInfoUser = this.gameMainMenu.getChildByName("topInfoUserLayer");
        listButton.active = true;
        topInfoUser.active = true;
        this.roomNumberLayer.active = false;
        //this.roomNumberLayer.opacity = 255;
    },
    showRoomNumberLayer: function showRoomNumberLayer() {
        //this.showGameTable();
        //close the private wesokect
        var listButton = this.gameMainMenu.getChildByName("ListButton");
        var topInfoUser = this.gameMainMenu.getChildByName("topInfoUserLayer");
        listButton.active = false;
        topInfoUser.active = false;
        this.roomNumberLayer.active = true;
        this.roomNumberLayer.opacity = 255;
    },
    joinRoomAndEnterTable: function joinRoomAndEnterTable() {

        //1. get other room number
        var roomNumber = "";
        var roomLayout = this.roomNumberLayer.getChildByName("roomNumberLayout");
        for (var i = 1; i < 7; i++) {
            var roomNumNode = roomLayout.getChildByName("Num" + i);
            var roomNumEditBox = roomNumNode.getComponent(cc.EditBox);
            roomNumber = roomNumber + roomNumEditBox.string;
        }

        cc.log("new roomNumNode:" + roomNumber);
        if (roomNumber.length != 6) {
            cc.log("Get room number error");
        }
        //3. check the room number
        this.checkOnlineRoomNumber(roomNumber, this);
    },
    showGameTable: function showGameTable() {
        this.gameMainMenu.active = false;
        this.gameModeNode.active = false;
        this.tableNode.active = true;
        this.tableNode.opacity = 255;
        //hide other UI .
        this.quePaiNode.active = false;
        this.tableCenterNode.active = false;
        this.createRoom_clearTableInitalUserInfo();
        //this.initalUserReadyLayer();
    },
    showGameMenu: function showGameMenu() {
        this.gameMainMenu.active = true;
        this.gameModeNode.active = false;
        this.tableNode.active = false;
        this.roomNumberLayer.active = false;
        this.userReadyLayer.active = false;
    },
    //TODO
    userBackToMainMeau: function userBackToMainMeau() {
        //.pre setup
        this.showGameMenu();
        this.createRoomBtn.active = false;
        this.backRoomBtn.active = true;
        //0. this.initalPrivateChanleForUser(userInfo.roomNumber, "");

        //1. client send the user openid to server

        //2. server get the new openid and old openid, set the user room number as new openid
        //3. public the all users to old private chanle ,to update the user list
        if (userListArray[2].zhuangStatu == "1") {
            preRoomNumber = userListArray[2].roomNumber;
        } else {
            preRoomNumber = null;
        }
        this.buildCanleUserMessageAndSendIt(userListArray[2].roomNumber);

        //preRoomNumber
        //4. hide the ready icon for empry user
    },
    //This function will commit a private room number to server
    //Server public a message to the private chanle ,any active client will send back active message and key to server
    //Server public the active client in the private chanle again ,client get which client is active
    checkOnlineUserInThePrivateChanle: function checkOnlineUserInThePrivateChanle() {},

    //change user statu to ready or canle the ready
    changeUserStatu: function changeUserStatu() {
        var useropenid = userListArray[2].openid;
        var roomNumber = userListArray[2].roomNumber;
        var status = parseInt(userListArray[2].gameingStatu);
        cc.log("send status1:" + status);
        //status 0-offline ,1-online ,2-not ready, 3-ready,4-gameing,5-other
        if (status == 1) {
            status = 3;
        } else if (status == 2) {
            status = 3;
        } else if (status == 3) {
            status = 2;
        }

        cc.log("send status2:" + status);
        this.buildChangeUserStatusMessageAndSendIt(useropenid, roomNumber, status);
    },
    checkUserStatu: function checkUserStatu() {},

    //-------------------------------------------Game Table function End-----------------------------------------------------
    showGameMode: function showGameMode() {
        cc.log("createRoom_clearTableInitalUserInfo starting......");
        this.gameMainMenu.active = false;
        //self.gameMainMenu.opacity=0;
        this.gameModeNode.active = true;
        this.gameModeNode.opacity = 0;
        this.tableNode.active = false;

        this.gameModeNode.opacity = 255;
    },

    //-------------------------------------------------------------------------------
    //inital uer info layer by gobal userinfo object, the self user only user3 .
    initalUserInfoLayer: function initalUserInfoLayer(userInfoNode) {
        cc.log("initalUserInfoLayer starting......");
        var userLayout = userInfoNode.getChildByName("user3LayoutLayer");
        var userTextInfoLayer = userLayout.getChildByName("userinfoFrameBg");
        var userNameLableNode = userTextInfoLayer.getChildByName("userNickNameLabel");
        var userScortLableNode = userTextInfoLayer.getChildByName("scortLabel");
        var userNickNameLable = userNameLableNode.getComponent(cc.Label);
        var userScortLable = userScortLableNode.getComponent(cc.Label);

        if (Global.userInfo != null) {
            userNickNameLable.string = Global.userInfo.nickName;
            userScortLable.string = Global.userInfo.diamondsNumber;
        } else {
            userNickNameLable.string = 'test123';
            userScortLable.string = '2321';
        }
    },
    initalUserInfoLayerById: function initalUserInfoLayerById(userInfoNode, id) {
        var userInfo = this.tableNode.getChildByName("user" + id + "Layer");
        userInfo.active = true;
        if (id == 1) {
            var userWidget = userInfo.getComponent(cc.Widget);
            userWidget.isAlignHorizontalCenter = true;
            userWidget.horizontalCenter = 0;
            // userInfo.x=0;
        }
        var userLayout = userInfo.getChildByName("user" + id + "LayoutLayer");
        var userTextInfoLayer = userLayout.getChildByName("userinfoFrameBg");
        var userNameLableNode = userTextInfoLayer.getChildByName("userNickNameLabel");
        var userScortLableNode = userTextInfoLayer.getChildByName("scortLabel");
        var userNickNameLable = userNameLableNode.getComponent(cc.Label);
        var userScortLable = userScortLableNode.getComponent(cc.Label);

        userNickNameLable.string = userInfoNode.nickName;
        userScortLable.string = userInfoNode.diamondsNumber;
    },
    initalUserReadyLayer: function initalUserReadyLayer() {
        this.userReadyLayer.active = true;
        this.userReady1Node.active = false;
        this.userReady2Node.active = false;
        this.userReady3Node.active = false;
        this.userReady4Node.active = false;
    },
    //----------------------------------web sokec connect and subscribe and handle resive message------------------------
    initalPrivateChanleForUser: function initalPrivateChanleForUser(roomNumber, action) {
        cc.log("initalPrivateChanleForUser roomNumber:" + roomNumber);
        //reset the room for user List
        userListArray[2].roomNumber = roomNumber;
        privateClient = Stomp.over(socket);
        // var messageDomain = require("messageDomain").messageDomain;
        privateClient.connect({}, (function () {
            privateClient.subscribe("/queue/privateRoomChanle" + roomNumber, (function (message) {
                var bodyStr = message.body;
                cc.log("get meesge from private chanle:privateRoomChanle" + roomNumber);
                var messageDomain = require("messageDomain").messageDomain;
                var obj = JSON.parse(bodyStr);
                if (obj != undefined && obj != null) {
                    for (var p in obj) {
                        messageDomain[p] = obj[p];
                    }
                }
                //1. join new user to room-------------------------------------------------------------------------
                if (messageDomain.messageAction == "addNewUserToPrivateChanle") {
                    var userListJsonStr = messageDomain.messageBody;
                    var userList = JSON.parse(userListJsonStr);
                    //gameingStatu

                    for (var i = 0; i < userList.length; i++) {
                        var u = userList[i];
                        var existFlag = false;
                        //check the user if already exist in the user list
                        for (var j = 0; j < userListArray.length; j++) {
                            if (userListArray[j] != null) {
                                if (u.openid == userListArray[j].openid) {

                                    existFlag = true;
                                }
                            }
                        }

                        if (!existFlag) {
                            for (var j = 0; j < userListArray.length; j++) {
                                if (!existFlag) {
                                    if (userListArray[j] == null) {
                                        //status 0-offline ,1-online ,2-not ready, 3-ready,4-gameing,5-other
                                        cc.log("inital user game user u.gameingStatu:" + u.gameingStatu);
                                        if (u.gameingStatu == null || u.gameingStatu == undefined) {
                                            u.gameingStatu = "2";
                                        } else if (parseInt(u.gameingStatu) == 0 || parseInt(u.gameingStatu) == 1) {
                                            u.gameingStatu = "2";
                                        }

                                        userListArray[j] = u;

                                        //userListArray[j].gameingStatu = 2;
                                        this.setUserStautsAndImage(j, userListArray[j].gameingStatu);
                                        var userReadNode = this.userReadyLayer.getChildByName("user" + (j + 1) + "ReadyNode");
                                        userReadNode.active = true;
                                        this.initalUserInfoLayerById(u, j + 1);
                                        existFlag = true;
                                    }
                                }
                            }
                        }
                        //userListArray
                    }
                }
                //2. CHANGE user status-----------------------------------------------------------------------
                if (messageDomain.messageAction == "changeUserStatusInPrivateChanle") {
                    var o = JSON.parse(messageDomain.messageBody);
                    var useropenid = o.openid;
                    var userStatus = o.status;
                    if (useropenid != null && useropenid != undefined) {
                        for (var j = 0; j < userListArray.length; j++) {
                            if (userListArray[j] != null && userListArray[j] != undefined) {
                                if (useropenid == userListArray[j].openid) {
                                    userListArray[j].gameingStatu = userStatus;
                                    this.setUserStautsAndImage(j, userStatus);
                                }
                            }
                        }
                    }
                }
                //3. get all pai from server---------------------------------------------------------------------
                if (messageDomain.messageAction == "publicAllPai") {
                    //var paiStr = messageDomain.messageBody;
                    //inital the pai list
                    //paiListArray = paiStr.split(",");

                    //remove the all user ready icon
                    this.userReadyLayer.active = false;
                    var obj = JSON.parse(messageDomain.messageBody);
                    var paiStr = obj.paiRestList;
                    paiListArray = paiStr.split(",");
                    var userPaiList = obj.userPaiList;
                    for (var i = 0; i < userPaiList.length; i++) {
                        for (var j = 0; j < userListArray.length; j++) {
                            if (userPaiList[i].openid == userListArray[j].openid) {}
                        }
                    }
                }
                //4. cancle the user from the room------------------------------------------------------------------
                if (messageDomain.messageAction == "userCanleRoom") {
                    var cancleUserOpenId = messageDomain.messageBody;
                    cc.log("cancleUserOpenId canle!!" + cancleUserOpenId);
                    for (var j = 0; j < userListArray.length; j++) {
                        //this is other user

                        if (userListArray[j] != null && userListArray[j] != undefined) {
                            if (cancleUserOpenId == userListArray[j].openid) {
                                userListArray[j] = "";
                                //hide the user ready icon Laryer
                                var userReadNode = this.userReadyLayer.getChildByName("user" + (j + 1) + "ReadyNode");
                                userReadNode.active = false;
                                //hide the user info layer
                                var userInfo = this.tableNode.getChildByName("user" + (j + 1) + "Layer");
                                userInfo.active = false;
                            }
                        }
                    }

                    //disconnect the connect from room
                    if (privateClient != null && privateClient != undefined) {
                        privateClient.unsubscribe();
                        privateClient = null;
                        cc.log("privateClient canle!!");
                    }

                    cc.log("privateClient canle 111!!");
                }
            }).bind(this));
            if (action == "send") {
                this.buildAddNewUserMessageAndSendIt(roomNumber);
            };
            if (action == "update") {
                this.buildUpdateRoomNumberOfOnlineUserMessage(userListArray[2].roomNumber, userListArray[2].openid);
                this.buildGameModeMessageAndSendIt(userListArray[2].roomNumber);
            }
        }).bind(this), function () {
            cc.log("connect private chanle error !");
        });
    },
    //----------------------------------send message to server----------------------------------------------------
    sendWebSokectMessageToServer: function sendWebSokectMessageToServer(messageObj) {
        // var o = new Object();
        // o.token = "test word"
        privateClient.send("/app/resiveAllUserChanlePusmicGame", {}, JSON.stringify(messageObj));
    },
    //-----------------------------------------------------------------------------------------------------------------
    removeOnlineUserById: function removeOnlineUserById() {
        var xhr = new XMLHttpRequest();
        var url = serverUrl + "/user/removeOnlinUserById?userId=" + Global.userInfo.id;
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
                var response = xhr.responseText;
                console.log(response);
            }
        };
        xhr.open("GET", url, true);
        xhr.send();
    },
    checkOnlineRoomNumber: function checkOnlineRoomNumber(roomNumber, self) {
        var xhr = new XMLHttpRequest();
        var url = serverUrl + "/room/checkOnlineRoomNumberCorrect?roomNumber=" + roomNumber + "&openunid=" + Global.userInfo.openid;
        //url = serverUrl + "/user/getLoginUserIP";
        xhr.onreadystatechange = (function () {
            cc.log("xhr.status:" + xhr.status);
            cc.log("xhr.readyState:" + xhr.readyState);

            cc.log("-----------");

            if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
                //let self=this;
                var response = xhr.responseText;
                cc.log(response);
                if (response == "correct") {
                    //1. close private chanle
                    if (privateClient != null && privateClient != undefined) {
                        privateClient.unsubscribe();
                    }
                    //2. connect to new private chanle
                    socket = new SockJS(serverUrl + "/stomp");
                    this.initalPrivateChanleForUser(roomNumber, "send");

                    //3. build a message for add new user for all in the private chanle

                    //4. send a message to server for public the new join user .

                    //5. show game table sence

                    this.gameMainMenu.active = false;
                    this.gameModeNode.active = false;
                    this.tableNode.active = true;
                    this.tableNode.opacity = 0;
                    this.createRoom_clearTableInitalUserInfo();
                    this.tableNode.opacity = 255;
                    //this.initalUserReadyLayer();
                    //messageDomain = require("messageDomain").messageDomain;
                    //messageDomain.messageBelongsToPrivateChanleNumber = roomNumber;
                } else {
                        //full --- room alredy full
                        // show the is a incorerct room number
                    }
            } else {
                    // show net work issue
                }
        }).bind(this);
        //xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        xhr.open("GET", url, true);
        xhr.send();
    },
    onDestroy: function onDestroy() {
        var self = this;
        self.removeOnlineUserById();
        cc.log("remove success");
        //colse the websokect
        privateClient.disconnect();
    },
    //------------------------------------until function in this classs---------------------------------------------
    //add the new user to private chanle
    buildAddNewUserMessageAndSendIt: function buildAddNewUserMessageAndSendIt(roomNumber) {
        var messageDomain = require("messageDomain").messageDomain;
        messageDomain.messageBelongsToPrivateChanleNumber = roomNumber;
        messageDomain.messageAction = "addNewUserToPrivateChanle";
        messageDomain.messageBody = "";
        this.sendWebSokectMessageToServer(messageDomain);
    },
    //change the user status
    buildChangeUserStatusMessageAndSendIt: function buildChangeUserStatusMessageAndSendIt(useropenid, roomNumber, stauts) {
        var messageDomain = require("messageDomain").messageDomain;
        messageDomain.messageBelongsToPrivateChanleNumber = roomNumber;
        messageDomain.messageAction = "changeUserStatusInPrivateChanle";
        var o = new Object();
        o.openid = useropenid;
        o.status = stauts;
        var bodyStr = JSON.stringify(o);
        messageDomain.messageBody = bodyStr;

        this.sendWebSokectMessageToServer(messageDomain);
    },
    //send game mode to server
    buildGameModeMessageAndSendIt: function buildGameModeMessageAndSendIt(roomNumber) {
        var messageDomain = require("messageDomain").messageDomain;
        messageDomain.messageBelongsToPrivateChanleNumber = roomNumber;
        messageDomain.messageAction = "publicGameMode";
        messageDomain.messageBody = JSON.stringify(gameModeModel);
        this.sendWebSokectMessageToServer(messageDomain);
    },
    //send the canle user openid to server and public to other
    buildCanleUserMessageAndSendIt: function buildCanleUserMessageAndSendIt(roomNumber) {
        var messageDomain = require("messageDomain").messageDomain;
        messageDomain.messageBelongsToPrivateChanleNumber = roomNumber;
        messageDomain.messageAction = "userCanleRoom";
        messageDomain.messageBody = userListArray[2].openid;
        this.sendWebSokectMessageToServer(messageDomain);
    },
    //build update room number for user message
    buildUpdateRoomNumberOfOnlineUserMessage: function buildUpdateRoomNumberOfOnlineUserMessage(roomNumber, myopenid) {
        var messageDomain = require("messageDomain").messageDomain;
        messageDomain.messageBelongsToPrivateChanleNumber = roomNumber;
        messageDomain.messageAction = "updateOnlineUserRoomNumber";
        messageDomain.messageBody = myopenid;
        this.sendWebSokectMessageToServer(messageDomain);
    },
    setUserStautsAndImage: function setUserStautsAndImage(i, userStatus) {
        cc.log("setUserStautsAndImage:" + i + "-" + userStatus);
        var userReadNode = this.userReadyLayer.getChildByName("user" + (i + 1) + "ReadyNode");
        if (i == 2) {
            var userBtn = userReadNode.getChildByName("userReadyBtn");
            userReadNode = userReadNode.getChildByName("userStatuImage");

            if (userStatus == 2) {
                userBtn.normalSprite = this.changeUserStatusNoBtnImage;
                userBtn.pressedSprite = this.changeUserStatusNoBtnImage;
                userBtn.hoverSprite = this.changeUserStatusNoBtnImage;
            }
            if (userStatus == 3) {
                userBtn.normalSprite = this.changeUserStatusYesBtnImage;
                userBtn.pressedSprite = this.changeUserStatusYesBtnImage;
                userBtn.hoverSprite = this.changeUserStatusYesBtnImage;
            }
        } else {}

        var s = userReadNode.getComponent(cc.Sprite);
        if (userStatus == 2) {
            s.spriteFrame = this.userStatusNoImage;
        }
        if (userStatus == 3) {
            s.spriteFrame = this.userStatusYesImage;
        }

        userListArray[i].gameingStatu = userStatus;
    }
});

cc._RFpop();
},{"gameMode":"gameMode","messageDomain":"messageDomain"}],"Global":[function(require,module,exports){
"use strict";
cc._RFpush(module, '8df21LbC7VA97Co/90BONyx', 'Global');
// script/domainClass/Global.js

window.Global = {
    userInfo: null,
    gameConfig: null,
    gameConfigSetting: null,
    gameMode: null,
    hostServerIp: "127.0.0.1",
    hostServerPort: "9001",
    hostHttpProtocol: "http",
    privateClientChanle: null,
    joinRoomNumber: null,
    userList: [],
    subid: 0,
    chuPaiActionType: "",
    huanSanZhangPaiList: []
};

cc._RFpop();
},{}],"HuPaiAction":[function(require,module,exports){
"use strict";
cc._RFpush(module, '7e9d7MFvrlCA5I+AZQVunqv', 'HuPaiAction');
// script/ui/HuPaiAction.js

var tableActionScript;
var tableUserInfoScript;
var tableMoPaiActionScript;
var sourcePaiList;
var sourcePaiCount;
var huFlag = false;
var jiangFlag = false;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        tableNode: cc.Node,
        tableAction: cc.Node,
        moPaiPrefab: cc.Prefab,
        user3PaiListNode: cc.Node,
        tableUserInfo: cc.Node,
        tableMoPaiNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        tableActionScript = this.tableAction.getComponent("tablePaiAction");
        tableUserInfoScript = this.tableUserInfo.getComponent("tableUserInfo");
        tableMoPaiActionScript = this.tableMoPaiNode.getComponent("tableMoPaiAction");
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    testHuPai: function testHuPai() {
        this.huPaiAction("19", "testUser2");
        this.huPaiAction("19", "testUser0");
        this.huPaiAction("19", "testUser1");
        this.huPaiAction("19", "testUser3");
    },

    huPaiAction: function huPaiAction(paiNumber, userOpenId) {
        var currentUser = tableActionScript.getCorrectUserByOpenId(userOpenId);
        var paiList = currentUser.paiListArray;
        var latstIndex = 0;
        if (paiList.length == 13) {
            latstIndex = 13;
        } else {
            latstIndex = paiList.length;
        }
        var userPoint = currentUser.pointIndex;
        var paiPath = tableActionScript.getChuPaiNameByNodeName(paiNumber, userPoint);

        var paiNode = cc.instantiate(this.moPaiPrefab);
        var sprite = paiNode.getComponent(cc.Sprite);
        paiNode.name = "pai" + latstIndex + "_" + paiNumber;
        //paiNode.active = false;
        var sprite = paiNode.getComponent(cc.Sprite);
        cc.loader.loadRes(paiPath, function (err, sp) {
            cc.log("61:" + paiPath);
            if (err) {
                cc.log("Error:" + err);
                return;
            }
            cc.log("65:");
            sprite.spriteFrame = new cc.SpriteFrame(sp);
            paiNode.active = true;
        });
        paiNode = this.getCureentPostionFromUserPointAndPaiList(paiList, userPoint, paiNode);
        var userNodeName = "user" + userPoint + "PengPaiListNode";
        cc.log("userNodeName:" + userNodeName);
        var userNodePaiList = cc.find(userNodeName, this.tableNode);
        userNodePaiList.addChild(paiNode);
        //---data layer-----------------
        var userList = Global.userList;
        var user;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == userOpenId) {
                user = userList[i];
                break;
            }
        }
        user.userMoPai = paiNumber;
        tableActionScript.insertMoPaiIntoPaiList(user);
        tableMoPaiActionScript.updateUserListInGobal(user);
        tableActionScript.disableAllSlefPai();
    },
    //decide the painumber if hu or not hu .
    hupaiLogic: function hupaiLogic(paiNumber, userOpenId) {
        //var currentUser = tableActionScript.getCorrectUserByOpenId(userOpenId);
        var huFlagDetails = false;
        var paiList = tableActionScript.insertPaiIntoPaiListByPaiAndOpenId(paiNumber, userOpenId);
        if (this.checkQiaoQiDui(paiList)) {
            return true;
        } else {

            for (var i = 0; i < paiList.length; i++) {
                paiList.splice(i, 1);
                i = 0;
                cc.log("hupaiLogic paiList:" + paiList);
                //huFlagDetails = this.startDecideHu(paiList);
            }
        }
    },
    startDecideHu: function startDecideHu(paiList) {
        cc.log("106 paiList:" + paiList.toString());
        if (sourcePaiCount == 0) {
            sourcePaiList = [];
            sourcePaiList = this.deepCopyArray(paiList, sourcePaiList);
        }

        sourcePaiCount++;
        for (var i = 0; i < paiList.length; i++) {
            var pai = paiList[i];
            var count = this.countElementAccount(pai, paiList);
            var oldLen = paiList.length;
            var oldPaiList = [];
            oldPaiList = this.deepCopyArray(paiList, oldPaiList);

            paiList = this.checkLianSanZhan(pai, paiList);
            var newLen = paiList.length;
            cc.log("116:" + paiList.toString());
            if (oldLen != newLen) {
                huFlag = this.startDecideHu(paiList);
            }

            if (count >= 2) {
                var oldPaiList2 = [];
                oldPaiList2 = this.deepCopyArray(oldPaiList, oldPaiList2);
                oldLen = oldPaiList.length;
                oldPaiList = this.liangZhang(pai, oldPaiList);
                newLen = oldPaiList.length;
                if (oldLen != newLen) {
                    jiangFlag = true;
                    huFlag = this.startDecideHu(oldPaiList);
                }
            }

            if (count >= 3) {
                oldLen = oldPaiList.length;
                oldPaiList = this.checkSanZhang(pai, oldPaiList);
                newLen = oldPaiList.length;
                if (oldLen != newLen) {

                    huFlag = this.startDecideHu(oldPaiList);
                }
            }
        }
        cc.log("paiList:" + paiList.toString());

        //cc.log("oldPaiList:" + oldPaiList.toString());

        if (paiList.length == 2 && paiList[0] == paiList[1]) {
            huFlag = true;
        } else if (jiangFlag == true && paiList.length == 0) {
            huFlag = true;
            // var list = [];
            // list = this.deepCopyArray(sourcePaiList, list);
            // list.splice(0, 1);
            // sourcePaiCount = 0;
            // huFlag = this.startDecideHu(list);
        }

        return huFlag;
    },
    checkLianSanZhan: function checkLianSanZhan(pai, paiList) {

        var paiNumber = pai[1];
        var prePai = -1;
        var nextPai = -1;
        var executeFlag = false;
        if (paiNumber + "" == "1") {
            prePai = pai + 1;
            nextPai = pai + 2;
        } else if (paiNumber + "" == "9") {
            prePai = pai - 1;
            nextPai = pai - 2;
        } else {
            prePai = pai - 1;
            nextPai = pai + 1;
        }
        if (this.contains(paiList, prePai) && this.contains(paiList, nextPai)) {
            executeFlag = true;
        } else {
            prePai = pai + 1;
            nextPai = pai + 2;
            cc.log("prePai:" + prePai + "--" + "nextPai:" + nextPai);
            if (this.contains(paiList, prePai) && this.contains(paiList, nextPai)) {
                executeFlag = true;
            } else {
                prePai = pai - 1;
                nextPai = pai - 2;
                if (this.contains(paiList, prePai) && this.contains(paiList, nextPai)) {
                    executeFlag = true;
                } else {
                    executeFlag = false;;
                }
            }
        }

        if (executeFlag) {
            paiList = tableActionScript.removeElementByNumberByPaiListFromUser(paiList, prePai, 1);
            paiList = tableActionScript.removeElementByNumberByPaiListFromUser(paiList, nextPai, 1);
            paiList = tableActionScript.removeElementByNumberByPaiListFromUser(paiList, pai, 1);
        }

        return paiList;
    },
    removeLianSanZhang: function removeLianSanZhang(pai, paiList) {},
    liangZhang: function liangZhang(pai, paiList) {
        var count = this.countElementAccount(pai, paiList);
        if (count == 2 || count == 4) {
            paiList = tableActionScript.removeElementByNumberByPaiListFromUser(paiList, pai, 2);
        }
        return paiList;
    },
    checkSanZhang: function checkSanZhang(pai, paiList) {
        var count = this.countElementAccount(pai, paiList);
        if (count >= 3) {
            paiList = tableActionScript.removeElementByNumberByPaiListFromUser(paiList, pai, 3);
        }

        return paiList;
    },
    checkQiaoQiDui: function checkQiaoQiDui(paiList) {

        for (var i = 0; i < paiList.length; i++) {
            var sourceLen = paiList.length;
            paiList = this.liangZhang(paiList[i], paiList);
            cc.log("paiList:" + paiList);
            var oldLen = paiList.length;
            if (sourceLen != oldLen) {
                i = 0;
            }
        }

        cc.log("paiList:" + paiList.toString());

        if (paiList.length == 0) {
            return true;
        } else {
            return false;
        }
    },

    testQiaoQiDui: function testQiaoQiDui() {

        var paiList = [15, 15, 18, 18, 22, 22, 25, 25, 25, 25, 29, 29, 38, 38];

        var f = this.checkQiaoQiDui(paiList);
        cc.log("check qiaoqidui:" + f);
    },
    testHu: function testHu() {
        var paiList = [15, 15, 16, 16, 17, 17, 18, 18, 18, 36, 36];
        sourcePaiCount = 0;
        huFlag = false;
        jiangFlag = false;

        cc.log("testHU 1:" + this.startDecideHu(paiList));
        huFlag = false;
        jiangFlag = false;
        paiList = [15, 16, 17, 19, 19, 19, 23, 23, 35, 36, 37];
        cc.log("testHU 2:" + this.startDecideHu(paiList));
        huFlag = false;
        jiangFlag = false;
        paiList = [11, 11, 17, 17, 17, 18, 19, 20, 35, 36, 37];
        cc.log("testHU 3:" + this.startDecideHu(paiList));
        huFlag = false;
        jiangFlag = false;
        paiList = [15, 16, 17, 17, 17, 18, 19, 20, 21, 36, 36];
        cc.log("testHU 4:" + this.startDecideHu(paiList));
    },
    //------------------------------------Untils----------------------------------------------------
    deepCopyArray: function deepCopyArray(soureArray, descArray) {
        if (soureArray != null && soureArray.length > 0) {
            for (var i = 0; i < soureArray.length + 1; i++) {
                if (soureArray[i] != null && soureArray[i] != undefined) descArray.push(soureArray[i]);
            }
        }

        return descArray;
    },

    countElementAccount: function countElementAccount(pai, paiList) {
        var count = 0;
        for (var i = 0; i < paiList.length + 1; i++) {
            if (paiList[i] == pai) {
                count++;
            }
        }

        return count;
    },
    contains: function contains(array, obj) {
        var i = array.length;
        while (i--) {
            if (array[i] + "" === obj + "") {
                return true;
            }
        }
        return false;
    },
    getCureentPostionFromUserPointAndPaiList: function getCureentPostionFromUserPointAndPaiList(paiArray, point, paiNode) {
        var startX = 0;
        var startY = 0;
        var latestX = 0;
        var latestY = 0;
        var startPoint = -520;
        for (var i = 0; i < paiArray.length + 1; i++) {
            if (paiArray[i] != null && paiArray[i] != undefined) {
                //fix the user 1
                if (point == "1") {
                    startX = 380;
                    // latestX=startX - i * 55;
                    // latestY=0
                    paiNode.position = cc.p(startX - i * 55, 0);
                    //this.user1PaiListNode.addChild(paiNode);
                }

                if (point == "2") {
                    startX = 0;
                    startY = -400;
                    paiNode.position = cc.p(startX, startY + i * 28);
                    paiNode.zIndex = paiArray.length - i;
                    paiNode.width = 40;
                    paiNode.height = 85;
                    //paiNode.setLocalZOrder(1000);
                    //paiNode.zIndex = 1000;
                    //parentNode
                }
                if (point == "3") {
                    if (i == 13) {
                        paiNode.position = cc.p(startPoint + i * 80, 0);
                    } else {
                        paiNode.position = cc.p(startPoint + i * 79, 0);
                    }
                }

                if (point == "4") {
                    startX = 0;
                    startY = -200;
                    paiNode.position = cc.p(startX, startY + i * 28);

                    paiNode.width = 40;
                    paiNode.height = 85;
                }
            }
        }
        if (point == "1") {
            paiNode.position = cc.p(paiNode.position.x + 85, paiNode.position.y);
        } else if (point == "2") {
            paiNode.position = cc.p(paiNode.position.x, paiNode.position.y - 25);
        } else if (point == "4") {
            paiNode.position = cc.p(paiNode.position.x, paiNode.position.y - 85);
            paiNode.setLocalZOrder(1000);
            paiNode.zIndex = 1000;
        } else if (point == "3") {
            paiNode.position = cc.p(paiNode.position.x - 90, paiNode.position.y + 10);

            paiNode.width = 75;
            paiNode.height = 110;
        }
        cc.log("paiNode position:" + paiNode.position);
        return paiNode;
    }
});

cc._RFpop();
},{}],"InitalGameMain":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e0dbfCHWtZLuJIN+fRPPsM8', 'InitalGameMain');
// script/controllers/InitalGameMain.js

var userInfo;
var userInfoLayer;
var gameModeLayer;
var topInfoLayer;
var mainListButtonLayer;
var serverUrl;
var socket;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        audioMng: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;

        serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;
        socket = new SockJS(serverUrl + "/stomp");

        //play bgm
        this.audioMng = this.audioMng.getComponent('AudioMng');
        this.audioMng.playMusic();
        //hide the game mode
        gameModeLayer = cc.find("Canvas/GameModeSelect");
        gameModeLayer.active = false;

        topInfoLayer = cc.find("Canvas/topInfoUserLayer");
        mainListButtonLayer = cc.find("Canvas/ListButton");
        //inital user info in the gameMain sence
        if (Global.userInfo == undefined || Global.userInfo == null) {
            console.log("Error: no found correct user ,please check server or network.");
        } else {
            userInfo = Global.userInfo;
            //intal the user info text
            //userInfoLayer = cc.find("Canvas/topInfoLayer/userInfoLayout/userInfoTxtLayout");
            self.initalPrivateChanleForUser(userInfo.roomNumber);
        }

        //
    },
    showGameModeNode: function showGameModeNode() {
        gameModeLayer.active = true;
        topInfoLayer.active = false;
        mainListButtonLayer.active = false;
    },
    hideGameModeNode: function hideGameModeNode() {
        gameModeLayer.active = false;
        topInfoLayer.active = true;
        mainListButtonLayer.active = true;
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

    initalPrivateChanleForUser: function initalPrivateChanleForUser(roomNumber) {
        cc.log("roomNumber:" + roomNumber);
        var privateClient = Stomp.over(socket);

        privateClient.connect({}, function () {
            privateClient.subscribe("/queue/privateRoomChanle" + roomNumber, function (message) {
                var bodyStr = message.body;
                cc.log("get meesge from private chanle:privateRoomChanle" + roomNumber);
            });
        }, function () {
            cc.log("connect private chanle error !");
        });
    }

});

cc._RFpop();
},{}],"JoinRoomController":[function(require,module,exports){
"use strict";
cc._RFpush(module, '9bcd3hPGGlK35uCEiuNEOJq', 'JoinRoomController');
// script/controllers/JoinRoomController.js

var roomNumberLableList = [];
var gameAction;
var tableNetWork;
var alertMessageUI;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        roomInputLableNode: cc.Node,
        keyBoardNode: cc.Node,
        loadingIconNode: cc.Node,
        gameoConfigScriptNode: cc.Node,
        tableNetworkNode: cc.Node,
        alertMessageNodeScirpt: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        gameAction = this.gameoConfigScriptNode.getComponent("gameConfigButtonListAction");
        tableNetWork = this.tableNetworkNode.getComponent("GameTableNetWork");
        alertMessageUI = this.alertMessageNodeScirpt.getComponent("alertMessagePanle");
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

    keyBoradClickEvent: function keyBoradClickEvent(event) {
        if (roomNumberLableList.length <= 5) {
            var node = event.target;
            var name = node.name;
            name = name.replace("Num", "");
            name = name.replace("Node", "");
            roomNumberLableList.push(name);
            this.intalTheNumberLableByList();
        }
        cc.log(roomNumberLableList.toString());
    },
    intalTheNumberLableByList: function intalTheNumberLableByList() {
        var node = this.roomInputLableNode;
        for (var i = 0; i < roomNumberLableList.length; i++) {
            var lableName = "input" + (i + 1) + "Node";
            var lableNode = cc.find(lableName, node);
            if (lableNode != null && lableNode !== undefined) {
                var lable = lableNode.getComponent(cc.Label);
                lable.string = roomNumberLableList[i];
            }
        }
    },
    deleteNumber: function deleteNumber() {
        roomNumberLableList.splice(-1, 1);
        cc.log(roomNumberLableList.toString());
        this.cleanLable();
        this.intalTheNumberLableByList();
    },
    getRoomNumber: function getRoomNumber() {
        var roomNumber = "";
        if (roomNumberLableList.length < 6) {
            alertMessageUI.text = "你必须输入6位数的房间号！";
            alertMessageUI.setTextOfPanel();
            return false;
        } else {

            for (var i = 0; i < roomNumberLableList.length; i++) {
                roomNumber = roomNumber + roomNumberLableList[i];
            }
        }
        return roomNumber;
    },

    cleanLable: function cleanLable() {
        var node = this.roomInputLableNode;
        for (var i = 0; i < 6; i++) {
            var lableName = "input" + (i + 1) + "Node";
            var lableNode = cc.find(lableName, node);
            if (lableNode != null && lableNode !== undefined) {
                var lable = lableNode.getComponent(cc.Label);
                lable.string = "";
            }
        }
    },
    joinRoomAction: function joinRoomAction() {
        var roomNumber = "";
        if (roomNumberLableList.length < 6) {
            alertMessageUI.text = "你必须输入6位数的房间号！";
            alertMessageUI.setTextOfPanel();
            return false;
        } else {

            for (var i = 0; i < roomNumberLableList.length; i++) {
                roomNumber = roomNumber + roomNumberLableList[i];
            }
            gameAction.showLoadingIcon();
            tableNetWork.joinRoom(roomNumber);
        }
        /*
        if (roomNumber == "") {
            alertMessageUI.text = "你必须输入6位数的房间号！";
            alertMessageUI.setTextOfPanel();
            return false
        }*/
    }

});

cc._RFpop();
},{}],"PersistRootNode":[function(require,module,exports){
"use strict";
cc._RFpush(module, '2d5f7V4inZIbpEKEgWPGubS', 'PersistRootNode');
// script/service/PersistRootNode.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        scriptNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        cc.game.addPersistRootNode(self.scriptNode);
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"PlayBgm":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'fc3efM4yNBMRJmwKAynE/fU', 'PlayBgm');
// script/audio/PlayBgm.js

cc.Class({
    'extends': cc.Component,

    properties: {
        audioMng: cc.Node,
        alertMessage: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.audioMng = this.audioMng.getComponent('AudioMng');
        this.audioMng.playMusic();
    },

    playGame: function playGame() {
        cc.director.loadScene('table');
    },

    // called every frame
    update: function update(dt) {}
});

cc._RFpop();
},{}],"SwitchScene":[function(require,module,exports){
"use strict";
cc._RFpush(module, '2f01dgus7tKwbntjWDlwS9h', 'SwitchScene');
// script/controllers/SwitchScene.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        scene: {
            'default': null,
            type: cc.Scene
        }

    },

    // use this for initialization
    onLoad: function onLoad() {},
    gotoGameCenter: function gotoGameCenter() {
        cc.director.loadScene('gameCenter');
    },
    gotoGameMain: function gotoGameMain() {
        cc.director.loadScene('gameMain2');
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    gotoGameCenterScene: function gotoGameCenterScene() {}
});

cc._RFpop();
},{}],"actionMesageDomain":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'b8016Av/9ZN54zYr0NRWMsw', 'actionMesageDomain');
// script/domainClass/actionMesageDomain.js

var actionMessageDomain = {
	messageAction: "",
	messageExecuteFlag: "",
	messageExecuteResult: "",
	useropenid: ""
};
module.exports = {
	actionMessageDomain: actionMessageDomain
};

cc._RFpop();
},{}],"alertMessagePanle":[function(require,module,exports){
"use strict";
cc._RFpush(module, '931179MAbNBzr/O4NfnmRjO', 'alertMessagePanle');
// script/ui/alertMessagePanle.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        text: String,
        alertPanelNode: cc.Node,
        textNode: cc.Node,
        buttonNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.alertPanelNode.active = false;
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

    setTextOfPanel: function setTextOfPanel() {
        this.alertPanelNode.active = true;
        var r = this.textNode.getComponent(cc.RichText);
        r.string = this.text;
    },

    closePanel: function closePanel() {
        this.alertPanelNode.active = false;
    },

    closeButton: function closeButton() {
        this.buttonNode.active = false;
    },

    showButton: function showButton() {
        this.buttonNode.active = true;
    }
});

cc._RFpop();
},{}],"caCheScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, '928c2g7oABC36efzPKVkOkg', 'caCheScript');
// script/lib/caCheScript.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});

/**
 * 动态加载图片后释放
 * 
 * var spriteFrame = node.getComponent(cc.Sprite).spriteFrame;
var deps = cc.loader.getDependsRecursively(spriteFrame);
cc.loader.release(deps);
 * 
 */

/**
 * 
 * loadNative = function(url, callback){
    var dirpath =  jsb.fileUtils.getWritablePath() + 'img/';
    var filepath = dirpath + MD5(url) + '.png';

    function loadEnd(){
        cc.loader.load(filepath, function(err, tex){
            if( err ){
                cc.error(err);
            }else{
                var spriteFrame = new cc.SpriteFrame(tex);
                if( spriteFrame ){
                    spriteFrame.retain();
                    callback(spriteFrame);
                }
            }
        });

    }

    if( jsb.fileUtils.isFileExist(filepath) ){
        cc.log('Remote is find' + filepath);
        loadEnd();
        return;
    }

    var saveFile = function(data){
        if( typeof data !== 'undefined' ){
            if( !jsb.fileUtils.isDirectoryExist(dirpath) ){
                jsb.fileUtils.createDirectory(dirpath);
            }

            if( jsb.fileUtils.writeDataToFile(  new Uint8Array(data) , filepath) ){
                cc.log('Remote write file succeed.');
                loadEnd();
            }else{
                cc.log('Remote write file failed.');
            }
        }else{
            cc.log('Remote download file failed.');
        }
    };
    
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        cc.log("xhr.readyState  " +xhr.readyState);
        cc.log("xhr.status  " +xhr.status);
        if (xhr.readyState === 4 ) {
            if(xhr.status === 200){
                xhr.responseType = 'arraybuffer';
                saveFile(xhr.response);
            }else{
                saveFile(null);
            }
        }
    }.bind(this);
    xhr.open("GET", url, true);
    xhr.send();
};
 */
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"gameConfigButtonListAction":[function(require,module,exports){
"use strict";
cc._RFpush(module, '1a841fq2F5L8q3KUAaQS+wi', 'gameConfigButtonListAction');
// script/controllers/gameConfigButtonListAction.js


var boyBtn = null;
var grilBtn = null;
var tableNetWork = null;
var showGameMode = null;
var gameConfigScript = null;
var tableUserInfo = null;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        indexNode: cc.Node,
        mainMenuNode: cc.Node,
        mainMenuGrailBtn: cc.Node,
        mainMenuBoyBtn: cc.Node,
        gameModeNode: cc.Node,
        joinRoomNumberUINode: cc.Node,
        gameConfigNode: cc.Node,
        alertMessageNode: cc.Node,

        gameTable: cc.Node,
        gameTableHead: cc.Node,
        gameTableModeBarNode: cc.Node,

        userNickNameNode: cc.Node,
        userCodeNode: cc.Node,
        userImageNode: cc.Node,

        tableNetWorkNode: cc.Node,

        loadingNode: cc.Node,
        loadIconNode: cc.Node,
        showGameModeScript: cc.Node,

        //table room
        closeRoomBtn: cc.Node,
        //mainMenu
        backRoomBtn: cc.Node,
        newRoomBtn: cc.Node,

        gameConfigSettingScript: cc.Node,
        tableUserInfoScript: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {

        grilBtn = this.mainMenuGrailBtn.getComponent(cc.Button);
        boyBtn = this.mainMenuBoyBtn.getComponent(cc.Button);
        tableNetWork = this.tableNetWorkNode.getComponent("GameTableNetWork");
        this.loadingNode.active = false;
        this.backRoomBtn.active = false;
        this.newRoomBtn.active = true;

        showGameMode = this.showGameModeScript.getComponent("showGameMode");
        gameConfigScript = this.gameConfigSettingScript.getComponent("gameConfigController");
        tableUserInfo = this.tableUserInfoScript.getComponent("tableUserInfo");
    },
    //----------Join room--------------------------------------------------------------------
    showJoinRoomNode: function showJoinRoomNode() {
        this.joinRoomNumberUINode.active = true;
        boyBtn.enabled = false;
        grilBtn.enabled = false;
    },
    closeJoenRoomNode: function closeJoenRoomNode() {
        this.joinRoomNumberUINode.active = false;
        boyBtn.enabled = true;
        grilBtn.enabled = true;
    },
    showUserNickNameAndCode: function showUserNickNameAndCode() {
        var userInfo = Global.userInfo;
        if (userInfo != null && userInfo != undefined) {
            var userNickname = this.userNickNameNode.getComponent(cc.Label);
            var userCode = this.userCodeNode.getComponent(cc.Label);

            userNickname.string = userInfo.nickName;
            userCode.string = userInfo.userCode;
        }
        var serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;

        var testHeaImageurl = serverUrl + "/webchatImage/" + userInfo.headImageFileName;
        cc.log("testHeaImageurl:" + testHeaImageurl);
        var userImage = this.userImageNode.getComponent(cc.Sprite);
        cc.loader.load(testHeaImageurl, function (err, texture) {
            var frame = new cc.SpriteFrame(texture);
            userImage.spriteFrame = frame;
        });
    },

    // action 1,build a  new room ,0, back to room
    enterMainEntry: function enterMainEntry(action) {
        tableNetWork.initalClient();
        this.indexNode.active = false;
        this.mainMenuNode.active = true;
        grilBtn.enabled = true;
        boyBtn.enabled = true;
        if (action == "1") {
            this.backRoomBtn.active = false;
            this.newRoomBtn.active = true;
        } else {
            this.backRoomBtn.active = true;
            this.newRoomBtn.active = false;
        }
    },
    showGameConfig: function showGameConfig() {
        this.gameConfigNode.active = true;
        gameConfigScript.initalGameConfig();
        boyBtn.enabled = false;
        grilBtn.enabled = false;
    },
    closeGameConfig: function closeGameConfig() {
        if (Global.gameConfigSetting != null && Global.gameConfigSetting != undefined && Global.gameConfigSetting != "") {
            cc.sys.localStorage.setItem('gameConfig', JSON.stringify(Global.gameConfigSetting));
        }

        this.gameConfigNode.active = false;
        boyBtn.enabled = true;
        grilBtn.enabled = true;

        cc.log("closeGameConfig:" + Global.gameConfigSetting);
    },
    showGameModePanel: function showGameModePanel() {
        if (this.backRoomBtn.active == true) {
            this.backTableAction();
        } else {
            this.gameModeNode.active = true;
            boyBtn.enabled = false;
            grilBtn.enabled = false;
        }
    },
    closeGameModePanel: function closeGameModePanel() {
        this.gameModeNode.active = false;
        boyBtn.enabled = true;
        grilBtn.enabled = true;
    },

    existGame: function existGame() {
        cc.game.end();
    },

    //read the game user from Gobal user list and inital the user

    showGameTalbe: function showGameTalbe(roomOwner) {
        this.gameTable.active = true;
        this.joinRoomNumberUINode.active = false;
        this.gameModeNode.active = false;
        this.indexNode.active = false;
        this.mainMenuNode.active = false;

        this.gameTableHead.active = false;
        this.gameTableModeBarNode.active = true;

        if (roomOwner == "1") {
            this.closeRoomBtn.active = true;
        } else {
            this.closeRoomBtn.active = false;
        }

        showGameMode.showGameMode();
        //now we need instal the user info for each user
        tableUserInfo.initalUserInfoFromGobalList();
    },
    closeGameTable: function closeGameTable() {
        this.gameTable.active = false;
        //this.mainMenuNode.active = true;
        tableNetWork.closeGameRoundLun();
        Global.joinRoomNumber = "";
        this.enterMainEntry("1");
    },

    showLoadingIcon: function showLoadingIcon() {
        this.loadingNode.active = true;
        var seq = cc.repeatForever(cc.rotateBy(3, 360));
        this.loadIconNode.runAction(seq);
        cc.log("showLoadingIcon");
    },
    closeLoadingIcon: function closeLoadingIcon() {
        this.loadIconNode.stopAllActions();
        this.loadingNode.active = false;
    },

    backRoomAction: function backRoomAction() {
        this.gameTable.active = false;
        this.enterMainEntry("0");
    },

    backTableAction: function backTableAction() {
        var userInfo = Global.userInfo;
        var roomNumber = userInfo.roomNumber;
        if (Global.joinRoomNumber == roomNumber) {
            this.showGameTalbe("1");
        } else {
            this.showGameTalbe("0");
        }
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"gameConfigController":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'bbbf26brTpIEIxUOXXB/RWL', 'gameConfigController');
// script/controllers/gameConfigController.js

var gameConfigSetting;
var alertMessageUI;
var musicScript;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        musicToggle: cc.Node,
        musicEffectToggle: cc.Node,
        publicIpLimitToggele: cc.Node,
        gpsLimitNode: cc.Node,
        alertMessageNode: cc.Node,
        musicNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        alertMessageUI = this.alertMessageNode.getComponent("alertMessagePanle");
        //this.initalGameConfig();
        musicScript = this.musicNode.getComponent("AudioMng");
    },

    togglerClick: function togglerClick(event) {
        gameConfigSetting = Global.gameConfigSetting;
        if (gameConfigSetting == null || gameConfigSetting == undefined) {
            gameConfigSetting = require("gameConfigSetting").gameConfigSetting;
        }
        var node = event.target;
        var parent = node.parent;
        var toggle = parent.getComponent(cc.Toggle);
        //musicEffectToggle,musicToggle,publicIpToggle
        if (parent.name == "musicEffectToggle") {
            if (toggle.isChecked) {
                gameConfigSetting.musicEffect = "1";
            } else {
                gameConfigSetting.musicEffect = "0";
            }
        }

        if (parent.name == "musicToggle") {
            if (toggle.isChecked) {
                gameConfigSetting.music = "1";
                musicScript.playMusic();
            } else {
                gameConfigSetting.music = "0";
                musicScript.stopMusic();
            }
        }

        if (parent.name == "publicIpToggle") {
            if (toggle.isChecked) {
                gameConfigSetting.publicIpLimit = "1";
            } else {
                gameConfigSetting.publicIpLimit = "0";
            }
        }

        cc.log(JSON.stringify(Global.gameConfigSetting));
    },

    editBoxChange: function editBoxChange() {

        gameConfigSetting = Global.gameConfigSetting;
        //var node = event.target;
        //cc.log("editBoxChange name:" + node.name);
        var edit = this.gpsLimitNode.getComponent(cc.EditBox);
        if (edit.string.length > 0) {
            if (isNaN(edit.string)) {
                alertMessageUI.text = "你必须在GPS距离限制中输入数字，请检查后重新输入！";
                alertMessageUI.setTextOfPanel();
            } else {
                gameConfigSetting.gpsLimit = edit.string;
            }
        }

        Global.gameConfigSetting = gameConfigSetting;
    },

    initalGameConfig: function initalGameConfig() {
        //cc.sys.localStorage.setItem('gameConfig', null);
        var o = cc.sys.localStorage.getItem("gameConfig");
        //cc.log("initalGameConfig o:" + (o) + ":");
        if (o != null && o != undefined && o != "" && o != "\"\"") {
            Global.gameConfigSetting = JSON.parse(o);
        }
        // JSON.parse(bodyStr)

        gameConfigSetting = Global.gameConfigSetting;
        if (gameConfigSetting == null || gameConfigSetting == undefined || gameConfigSetting == "") {
            gameConfigSetting = require("gameConfigSetting").gameConfigSetting;
        }

        cc.log("initalGameConfig:" + gameConfigSetting + ":");
        var musictoggle = this.musicToggle.getComponent(cc.Toggle);
        var musciEffectToggle = this.musicEffectToggle.getComponent(cc.Toggle);
        var publicIpToggle = this.publicIpLimitToggele.getComponent(cc.Toggle);
        if (gameConfigSetting.music == "1") {
            musictoggle.isChecked = true;
        } else {
            musictoggle.isChecked = false;
        }

        if (gameConfigSetting.musicEffect == "1") {
            musciEffectToggle.isChecked = true;
        } else {
            musciEffectToggle.isChecked = false;
        }

        if (gameConfigSetting.publicIpLimit == "1") {
            publicIpToggle.isChecked = true;
        } else {
            publicIpToggle.isChecked = false;
        }
        var edit = this.gpsLimitNode.getComponent(cc.EditBox);
        if (gameConfigSetting.gpsLimit != undefined && gameConfigSetting.gpsLimit != null) {
            if (gameConfigSetting.gpsLimit != "0" && gameConfigSetting.gpsLimit.length > 0) {
                edit.string = gameConfigSetting.gpsLimit;
            }
        }
        Global.gameConfigSetting = gameConfigSetting;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{"gameConfigSetting":"gameConfigSetting"}],"gameConfigSetting":[function(require,module,exports){
"use strict";
cc._RFpush(module, '89dfbS5ihZHIZmZ0IY625wG', 'gameConfigSetting');
// script/domainClass/gameConfigSetting.js

var gameConfigSetting = {
	music: "1",
	musicEffect: "1",
	publicIpLimit: "0",
	gpsLimit: "0"
};
module.exports = {
	gameConfigSetting: gameConfigSetting
};

cc._RFpop();
},{}],"gameConfig":[function(require,module,exports){
"use strict";
cc._RFpush(module, '04c3c9hL21BfpcYmeJK6KmP', 'gameConfig');
// script/ui/gameConfig.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        alertMessage: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},

    helpButn: function helpButn() {
        this.alertMessage = this.alertMessage.getComponent("alertMessagePanle");
        this.alertMessage.text = "  GPS距离限制指的是你可以设置一个数字，这个数字代表了玩家之间的GPS距离，如果该距离小于你设定的值，那么将拒绝玩家加入你创建的房间。<br/>";
        this.alertMessage.text = this.alertMessage.text + "  每个新玩家加入此房间将根据GPS自动测算与房间中已有玩家之间的实际距离，如果距离小于你设置的值，将拒绝该玩家加入！";
        this.alertMessage.setTextOfPanel();
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"gameMode":[function(require,module,exports){
"use strict";
cc._RFpush(module, '93e5dsxrulPuY66y0C8yi17', 'gameMode');
// script/domainClass/gameMode.js

var gameMode = {
  ziMoJiaDi: 1,
  ziMoJiaFan: 0,
  ziMoHu: 1,
  dianPaoHu: 0,
  huanSanZhang: 1,
  dianGangHua_dianPao: 1,
  dianGangHua_ziMo: 0,
  dai19JiangDui: 1,
  mengQingZhongZhang: 0,
  tianDiHu: 0,
  fan2: 0,
  fan3: 1,
  fan4: 0,
  fan6: 0,
  roundCount4: 1,
  roundCount8: 0,
  gamePeopleNumber: 0,
  publicIpLimit: 0,
  gpsLimit: 0
};
module.exports = {
  gameMode: gameMode
};

cc._RFpop();
},{}],"gameStep":[function(require,module,exports){
"use strict";
cc._RFpush(module, '5e1156K9w1DRJRcTEQQXtx0', 'gameStep');
// script/domainClass/gameStep.js

var gameStep = { id: 0,
  fromUserOpenid: "",
  actionName: "",
  paiNumber: "",
  toUserOpenid: "",
  joinRoomNumber: ""

};
//gameingStatu:"",
module.exports = {
  gameStep: gameStep
};

cc._RFpop();
},{}],"gameUser":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e951drcp2lI/qFmJzkvDAoS', 'gameUser');
// script/domainClass/gameUser.js

var gameUser = { id: 0,
  nickName: "",
  headimgurl: "",
  country: "",
  diamondsNumber: 0,
  openid: "",
  unionid: "",
  userCode: "",
  //userGameingStatu:"",
  publicIp: "",
  paiList: "",
  gameReadyStatu: "",
  gameRoundScore: "",
  gameScoreCount: "",
  pointIndex: "",
  headImageFileName: "",
  zhuang: "",
  //follow propertity only work on client
  paiListArray: [],
  huanSanZhangPaiList: [],
  pengPaiList: [],
  gangPaiList: [],
  pengGangPaiPoint: 0,
  quePai: "",
  chupaiListX: 0,
  chupaiListY: 0,
  chuPaiCount: 0,
  chuPaiPointX: 0,
  userMoPai: "",
  //hupai 
  huPai: "",
  //ziMo,normalHu,gangShangHua,gangShangPao ,haiDi,tianHu,diHu
  huPaiType: ""
};
//gameingStatu:"",
module.exports = {
  gameUser: gameUser
};

cc._RFpop();
},{}],"huanPaiUI":[function(require,module,exports){
"use strict";
cc._RFpush(module, '5f8b3i4e8lGlYu1dUS5hhW2', 'huanPaiUI');
// script/ui/huanPaiUI.js

var timerUpate;
var timeCount;
var tableUserInfo;
var alerMessage;
var gameTableNetWork;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        huanPaiNode: cc.Node,
        huanPaiTimeLable: cc.Node,
        tableUserInfoNode: cc.Node,
        alertMessageNode: cc.Node,
        gameTableNetWorkNode: cc.Node,
        waitPanleNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {

        tableUserInfo = this.tableUserInfoNode.getComponent("tableUserInfo");
        alerMessage = this.alertMessageNode.getComponent("alertMessagePanle");
        gameTableNetWork = this.gameTableNetWorkNode.getComponent("GameTableNetWork");

        timeCount = 14;
        timerUpate = function () {

            var showTimerStr = "(" + timeCount + ")";
            var lable = this.huanPaiTimeLable.getComponent(cc.Label);
            lable.string = showTimerStr;
            timeCount--;

            if (timeCount == -1) {
                this.endTimer();
            }
        };
    },

    showHuanPaiNode: function showHuanPaiNode() {
        this.huanPaiNode.active = true;
        this.stratTimer();
        tableUserInfo.disabledHuanSanZhangPai();
        Global.chuPaiActionType = "huanSanZhang";
    },

    stratTimer: function stratTimer() {
        //timeCount = 10;
        var self = this;
        self.schedule(timerUpate, 1);
        //
    },
    endTimer: function endTimer() {
        var self = this;
        self.unschedule(timerUpate);
        // Global.chuPaiActionType = ""
        //auto select latest pai
        if (Global.huanSanZhangPaiList.length < 3) {}
        //tableUserInfo.forceFillHuanSanZhangList()

        //
    },

    sendHuanSanZhang: function sendHuanSanZhang() {
        if (Global.huanSanZhangPaiList.length < 3) {
            alerMessage.text = "你必须选择三张牌！";
            alerMessage.setTextOfPanel();
            alerMessage.alertPanelNode.active = true;
        } else {
            //Global.chuPaiActionType = ""
            this.waitPanleNode.active = true;
            gameTableNetWork.sendHuanSanZhang();
            tableUserInfo.disableAllPai();
            this.unschedule(timerUpate);
        }
    },

    closeWaitPanle: function closeWaitPanle() {
        this.waitPanleNode.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"iniGameTable":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ea520g3DaVCNIEueX4OHm2n', 'iniGameTable');
// script/service/iniGameTable.js



cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        audioMng: cc.Node,
        tableNode: cc.Node,
        gameModeNode: cc.Node,
        gameMainMenu: cc.Node,
        userNickNameLableNode: cc.Node,
        userCodeLable: cc.Node,
        userDemondNumberLable: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {

        var self = this;

        //serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;
        //socket = new SockJS(serverUrl + "/stomp");

        var messageUser = require("messageDomain").messageDomain;
        //var messageUser;
        //-----------music :play bgm-------------------------------------------------------------------------------
        this.audioMng = this.audioMng.getComponent('AudioMng');
        this.audioMng.playMusic();
        //hide the game mode
        self.gameModeNode.active = false;
        self.tableNode.active = false;
        self.gameMainMenu.active = true;
        self.gameMainMenu.opacity = 255;
        //----------------------------------------------------------------------------------------------------------

        //inital user info in the gameMain sence
        if (Global.userInfo == undefined || Global.userInfo == null) {
            console.log("Error: no found correct user ,please check server or network.");
        } else {
            var userInfo = Global.userInfo;

            //intal user Text
            self.intalUserInfoOnGameMainLayer();
            //self.initalUserInfoLayer(userInfo);
            //inital the user message
            messageUser.messageBelongsToPrivateChanleNumber = userInfo.roomNumber;
            //messageAction
            messageUser.messageAction = "sendToOther";
            messageUser.messageType = "user";
            messageUser.messageBody = JSON.stringify(userInfo);
            //self.sendWebSokectMessageToServer(messageUser)
        };

        // cc.game.onStop = function () {
        //     cc.log("stopApp");
        // }
    },

    //----------------------------------Create room button event---------------------------------------------------------

    joinRoom_initalUserInfo: function joinRoom_initalUserInfo() {
        this.initalUserInfoLayer();
    },

    //----------------------------------inital user info layer-----------------------------------------------------------
    intalUserInfoOnGameMainLayer: function intalUserInfoOnGameMainLayer() {
        // var topUserLayer = this.gameMainMenu.getChildByName("topInfoUserLayer");
        // var topUserInfoLayer = topUserLayer.getChildByName("userInfoLayer");
        // var topUserLayout = topUserInfoLayer.getChildByName("userInfoLayout");
        // var topUserLayout2 = topUserLayout.getChildByName("userInfoTextLayout");

        // var userNameLableNode = topUserLayout2.getChildByName("userNickNameLable");
        // var userCodeLableNode = topUserLayout2.getChildByName("userCodeLable");
        // var userDemondLableNode = topUserLayout2.getChildByName("userDemondNumber");

        var userNameLable = this.userNickNameLableNode.getComponent(cc.Label);
        var userCodeLable = this.userCodeLable.getComponent(cc.Label);
        var userDemondLable = this.userDemondNumberLable.getComponent(cc.Label);

        userNameLable.string = Global.userInfo.nickName;
        userDemondLable.string = Global.userInfo.diamondsNumber;
        userCodeLable.string = Global.userInfo.userCode;
    },

    //----------------------------------web sokec connect and subscribe and handle resive message------------------------

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    //------------------------------- when tha table sence end ,it will need remove online user and close websokect---------

    //open user ip login url

    //--------------------------------update user ip---------------------------
    updateUserIP: function updateUserIP(id) {
        var xhr = new XMLHttpRequest();
        var url = serverUrl + "/user/getLoginUserIP?userId=" + id;
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
                var response = xhr.responseText;
                console.log(response);
                Global.userInfo.publicIPAddress = response;
                cc.director.loadScene('table');
            }
        };
        xhr.open("GET", url, true);
        xhr.send();
    }
});

cc._RFpop();
},{"messageDomain":"messageDomain"}],"iniIndex":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'f811fBatU1FtajDrq8CeSU5', 'iniIndex');
// script/service/iniIndex.js

var client;
var privateClient;
var userInfo;
var serverUrl;
var socket;
var gameActionListGet;
var onlineCheckUser;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        gameActionList: cc.Node,
        checkOnlineUser: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {

        //webchat head img test-------------------------------
        /*
        var url = "http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/46";
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            console.log("xhr readyState:" + xhr.readyState);
            if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400)) {
                var response = xhr.responseText;
                 console.log("xhr:" + response);
                console.log("xhr responseType:" + xhr.responseType);
             }
        };
        xhr.open("GET", url, true);
        xhr.send();*/
        //----------------------------------------------------
        gameActionListGet = this.gameActionList.getComponent("gameConfigButtonListAction");
        onlineCheckUser = this.checkOnlineUser.getComponent("onlineUserCheck");
        userInfo = require("userInfoDomain").userInfoDomain;
        serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;
        socket = new SockJS(serverUrl + "/stomp");
        console.log("conect to server");
        client = Stomp.over(socket);
        var csrfHeaderName = "Set-Cookie";
        var csrfToken = "session=B227654DB13B28329F96DB2959FAE26B";
        var headers = {};
        headers[csrfHeaderName] = csrfToken;
        client.connect(headers, function () {
            client.subscribe("/queue/pusmicGamePushLoginUserInfoChanle", function (message) {
                var bodyStr = message.body;
                cc.log("######################");
                cc.log(bodyStr);
                var obj = JSON.parse(bodyStr);
                if (obj != undefined && obj != null) {
                    for (var p in obj) {
                        userInfo[p] = obj[p];
                    }
                    //************we must check user in here*******************************
                    //NEED TO DO ********************

                    if (Global.userInfo == null || Global.userInfo == undefined) {

                        console.log("userInfo.nickname:" + userInfo.nickName);
                        console.log("userInfo.headImageFileName:" + userInfo.headImageFileName);
                        Global.userInfo = userInfo;
                        //update the user public ip from url call
                        //self.updateUserIP(userInfo.id);
                        //
                        //self.initalPrivateChanleForUser(userInfo.roomNumber);

                        //user login success ,go to game main sence
                        //cc.director.loadScene('table');
                        client.disconnect();
                        client = null;
                        gameActionListGet.enterMainEntry("1");
                        gameActionListGet.showUserNickNameAndCode();
                        gameActionListGet.closeLoadingIcon();
                    }
                } else {

                    console.log("No found correct user info return from server ,please check .");
                }

                //self.testLabel.string = message.body;
                //$("#helloDiv").append(message.body);

                //cc.director.loadScene('gameMain2');
            }, function () {
                cc.log("websocket connect subscribe Error:233");
                //client.disconnect();
            });
        }, function () {
            cc.log("websocket connect  Error:234");
            //client.disconnect();
        });

        //onlineCheckUser.client = client;
        onlineCheckUser.checkonlineUser(client);

        cc.game.onStop = function () {
            cc.log("stopApp$$$$$$$$$$$$$$$$$");
            // client.disconnect();
        };
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    onDestroy: function onDestroy() {
        //colse the websokect
        client.disconnect();
        cc.log("onDestroy");
    },
    //----------------------inital private chanle----------------------------------
    // initalPrivateChanleForUser: function (roomNumber) {
    //     cc.log("roomNumber:"+roomNumber);
    //     privateClient = Stomp.over(socket);

    //         privateClient.connect({}, function () {
    //             privateClient.subscribe("/queue/privateRoomChanle" + roomNumber, function (message) {
    //                 var bodyStr = message.body;
    //                 cc.log("get meesge from private chanle:privateRoomChanle"+roomNumber);
    //             });
    //         },function(){
    //              cc.log("connect private chanle error !");
    //         });

    // privateClientChanle
    // },
    //----------------------game stop-----------------------------------------------
    gameStop: function gameStop() {},
    sendUserCode: function sendUserCode() {
        //client.send("/app/usercode_resive_message", {}, JSON.stringify("test"));
        gameActionListGet.showLoadingIcon();
        client.send("/app/usercode_resive_message", {}, "test");
    }
});

cc._RFpop();
},{"userInfoDomain":"userInfoDomain"}],"loginScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, '5a3421ZWfdBzorgy/ErrBn5', 'loginScript');
// script/controllers/loginScript.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"messageDomain":[function(require,module,exports){
"use strict";
cc._RFpush(module, '08d47EMIsNDzLeRPw7M5PK1', 'messageDomain');
// script/domainClass/messageDomain.js

var messageDomain = {
	messageBelongsToPrivateChanleNumber: 0,
	//sendToOther,sendToServer,sendToSingleUser
	messageAction: "",
	messageType: "",
	messageBody: ""
};
module.exports = {
	messageDomain: messageDomain
};

cc._RFpop();
},{}],"normalTimerScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, '13d2120NChBIIzokcsa0rpZ', 'normalTimerScript');
// script/ui/normalTimerScript.js

var timerUpate;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        timeCount: cc.Integer,
        timerLable: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.timeCount = 10;
        timerUpate = function () {
            var lable = self.timerLable.getComponent(cc.Label);
            lable.string = "(" + self.timeCount + ")";

            self.timeCount--;

            if (self.timeCount == -1) {
                //quePaiTimerLabel,huanPaiTimerLabel
                //
                self.endTimer();
                if (self.timerLable.name == "quePaiTimerLabel") {}
                if (self.timerLable.name == "huanPaiTimerLabel") {}
            }
        };
        self.stratTimer();
    },
    stratTimer: function stratTimer() {

        var self = this;
        self.schedule(timerUpate, 1);
    },
    endTimer: function endTimer() {
        var self = this;
        self.unschedule(timerUpate);
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"onlineUserCheck":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'bfb01GYRJNHYZfnbUrg0Gqd', 'onlineUserCheck');
// script/service/onlineUserCheck.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        // client: null
    },

    // use this for initialization
    onLoad: function onLoad() {},

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

    checkonlineUser: function checkonlineUser(client) {

        this.callback = function () {
            var userInfo = Global.userInfo;

            if (userInfo != null && userInfo != undefined) {
                var openid = userInfo.openid;
                var roomNumber = userInfo.roomNumber;
                var messageObj = this.buildSendMessage(openid, roomNumber, "updateOnlinUserDateTime");
                this.sendMessageToServer(messageObj, client);
            }
        };

        this.schedule(this.callback, 1800);
    },

    removeOnlineUser: function removeOnlineUser(client, roomNumber) {
        var userInfo = Global.userInfo;
        if (userInfo != null && userInfo != undefined) {
            var openid = userInfo.openid;
            var messageObj = this.buildSendMessage(openid, roomNumber, "updateOnlinUserDateTime");
            this.sendMessageToServer(messageObj);
        }
    },
    sendMessageToServer: function sendMessageToServer(messageObj, client) {

        client.send("/app/userResiveMessage", {}, JSON.stringify(messageObj));
    },
    buildSendMessage: function buildSendMessage(messageBody, roomNum, action) {
        var messageDomain = require("messageDomain").messageDomain;
        messageDomain.messageBelongsToPrivateChanleNumber = roomNum;
        messageDomain.messageAction = action;
        messageDomain.messageBody = messageBody;

        return messageDomain;
    }
});

cc._RFpop();
},{"messageDomain":"messageDomain"}],"paiAction":[function(require,module,exports){
"use strict";
cc._RFpush(module, '36b48sC7pVLV7hYdCsCw/lc', 'paiAction');
// script/ui/paiAction.js

var actionWidth = [];
var actionName = [];
var tablePaiActionScript;
var tableUserInfoNodeScript;
cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        actionNode: cc.Node,
        zimoNode: cc.Node,
        pengNode: cc.Node,
        gangNode: cc.Node,
        huNode: cc.Node,
        cancleNode: cc.Node,
        tablePaiActionNode: cc.Node,
        tableUserInfoNode: cc.Node,
        paiChuPaiNode: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        actionName = ['zimo', 'peng', 'gang', 'hu', 'cancle'];
        actionWidth = [225, 166, 137, 121, 112];
        //actionWidth = [225, 156, 157, 141, 112];
        this.actionNode.active = false;
        this.zimoNode.active = false;
        this.pengNode.active = false;
        this.huNode.active = false;
        this.cancleNode.active = false;
        tablePaiActionScript = this.tablePaiActionNode.getComponent('tablePaiAction');
        tableUserInfoNodeScript = this.tableUserInfoNode.getComponent('tableUserInfo');
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    testShowAction: function testShowAction() {
        var actionArray = ['cancle', 'gang', 'peng'];
        this.showAction(actionArray);
    },
    testPengPai: function testPengPai() {
        this.pengAction("testUser2", "33");
        this.pengAction("testUser0", "11");
        this.pengAction("testUser1", "22");
        this.pengAction("testUser3", "28");
        //this.gangAction("testUser2", "23");
        this.pengAction("testUser2", "23");
    },

    showAction: function showAction(actionArray) {
        //from right to left ,the x is reduce.
        var startX = 146;
        var actionWidthTemp = [];
        for (var i = 0; i < actionArray.length; i++) {
            var node = cc.find(actionArray[i] + "ActionNode", this.actionNode);
            node.active = true;
            node.x = startX;
            for (var j = 0; j < actionName.length; j++) {
                if (actionName[j] == actionArray[i]) {
                    //actionWidthTemp.push(actionWidth[j]);
                    startX = startX - actionWidth[j] - 15;
                    cc.log("startX:" + startX);
                }
            }
        }

        this.actionNode.active = true;
    },
    //------------------------Peng,Gang,Hu Action---------------------------------------

    pengAction: function pengAction(userOpenId, paiNumber) {
        var user = tablePaiActionScript.getCorrectUserByOpenId(userOpenId);
        var pointIndex = user.pointIndex;
        //data layer ------
        var paiList = user.paiListArray;
        paiList = this.removeElementByNumberFromUser(paiList, paiNumber, 2);
        cc.log("pengAction paiList:" + paiList);
        user.paiListArray = paiList;
        var pengList = user.pengPaiList;
        if (pengList == null || pengList == undefined) {
            pengList = [];
        }
        pengList.push(paiNumber);
        user.pengPaiList = pengList;
        //update user to gobal
        user = tablePaiActionScript.synchronizationPaiList(user);
        tablePaiActionScript.updateUserListInGobal(user);
        //data layer end -------------------------------------
        //-------show user pai list-----------------
        cc.log("pengAction:" + pointIndex);
        if (pointIndex == "3") {
            tablePaiActionScript.removeAllNodeFromSelfPaiList();
            tableUserInfoNodeScript.intalSelfPaiList(user.paiList);
        } else {
            tablePaiActionScript.removeAllNodeFromOtherPaiList(pointIndex);
            //if (pointIndex != "2")
            tableUserInfoNodeScript.initalOtherPaiList(user.paiList, pointIndex, "pengList");
        }

        this.initalPengAndGangChuPaiList(userOpenId, paiNumber);
    },
    gangAction: function gangAction(userOpenId, paiNumber) {
        var user = tablePaiActionScript.getCorrectUserByOpenId(userOpenId);
        var pointIndex = user.pointIndex;
        //data layer ------
        var paiList = user.paiListArray;
        paiList = this.removeElementByNumberFromUser(paiList, paiNumber, 3);
        cc.log("gangAction paiList:" + paiList);
        user.paiListArray = paiList;
        var gangList = user.gangPaiList;
        if (gangList == null || gangList == undefined) {
            gangList = [];
        }
        gangList.push(paiNumber);
        user.gangPaiList = gangList;
        // mopai
        //update user to gobal
        user = tablePaiActionScript.synchronizationPaiList(user);
        tablePaiActionScript.updateUserListInGobal(user);
        //data layer end -------------------------------------
        //-------show user pai list-----------------
        cc.log("pengAction:" + pointIndex);
        if (pointIndex == "3") {
            tablePaiActionScript.removeAllNodeFromSelfPaiList();
            tableUserInfoNodeScript.intalSelfPaiList(user.paiList);
        } else {
            tablePaiActionScript.removeAllNodeFromOtherPaiList(pointIndex);
            // if (pointIndex != "2") {
            tableUserInfoNodeScript.initalOtherPaiList(user.paiList, pointIndex, "gang");
            //  }
        }

        this.initalPengAndGangChuPaiList(userOpenId, paiNumber);
    },

    huAction: function huAction(userOpenId, paiNumber) {},

    initalPengAndGangChuPaiList: function initalPengAndGangChuPaiList(userOpenId, paiNumber) {
        var user = tablePaiActionScript.getCorrectUserByOpenId(userOpenId);
        var pointIndex = user.pointIndex;
        var tableNode = cc.find("Canvas/tableNode");
        var userPengPaiListNode = cc.find("user" + pointIndex + "PengPaiListNode", tableNode);
        userPengPaiListNode.removeAllChildren();
        cc.log("166:" + userPengPaiListNode.children.length);
        var pengList = user.pengPaiList;
        var gangPaiList = user.gangPaiList;
        var x = 0;
        var y = 0;
        if (pointIndex == "3") {
            user.pengGangPaiPoint = 410;
            y = 0;
            x = user.pengGangPaiPoint;
        } else if (pointIndex == "1") {
            user.pengGangPaiPoint = -270;
            y = 0;
            x = user.pengGangPaiPoint;
        } else if (pointIndex == "2") {
            user.pengGangPaiPoint = -250;
            y = user.pengGangPaiPoint;
            x = 0;
        } else if (pointIndex == "4") {
            user.pengGangPaiPoint = 100;
            y = user.pengGangPaiPoint;
            x = 0;
        }

        this.showPengGangPaiListOnTalbe(pengList, gangPaiList, pointIndex, paiNumber, userPengPaiListNode, "peng", x, y);
    },

    showPengGangPaiListOnTalbe: function showPengGangPaiListOnTalbe(pengList, gangList, pointIndex, paiNumber, userPengPaiListNode, type, x, y) {

        var isGangFlagList = [];
        var finalX = x;
        var finalY = y;
        if (pengList != null && pengList != undefined) {
            for (var i = 0; i < pengList.length; i++) {
                //get final point for gang
                for (var j = 1; j < 4; j++) {

                    var point0 = this.getCorrectPointByIndex(pointIndex, finalX, finalY);
                    finalX = point0[0];
                    finalY = point0[1];
                }
                var tempPai = pengList[i] + "";
                tempPai = tempPai.trim();
                //var isGang
                //eval("var   isGang" + paiNumber+"" + " = false;");
                // isGangFlagList[parseInt(tempPai)] = false;

                // eval("cc.log( 'isGang 216:'+  isGang" + paiNumber+")");
                var paiPath = tablePaiActionScript.getChuPaiNameByNodeName(tempPai, pointIndex);
                var middlePoint = null;
                // cc.log("isGang loadRes:" + isGang);
                cc.loader.loadRes(paiPath, (function (err, sp) {
                    if (err) {
                        cc.log("----" + err.message || err);
                        return;
                    }

                    var sencodPaiX = -1;
                    var sencodPaiY = -1;
                    for (var j = 1; j < 4; j++) {
                        var pNode = cc.instantiate(this.paiChuPaiNode);
                        pNode.name = "pengpai" + pointIndex + "_" + paiNumber;
                        pNode.active = true;
                        cc.log("peng x:" + x + "-----y:" + y);
                        pNode.position = cc.p(x, y);
                        if (j == 2) {
                            sencodPaiX = x;
                            sencodPaiY = y;
                        }

                        if (pointIndex == "2") {
                            pNode.setLocalZOrder(100 - j);
                            pNode.zIndex = 100 - j;
                        }

                        var point = this.getCorrectPointByIndex(pointIndex, x, y);
                        x = point[0];
                        y = point[1];

                        var sprite = pNode.getComponent(cc.Sprite);
                        sprite.spriteFrame = new cc.SpriteFrame(sp);
                        userPengPaiListNode.addChild(pNode);
                    }
                }).bind(this));
            }
        }

        if (gangList != null && gangList != undefined) {
            for (var k = 0; k < gangList.length; k++) {
                var tempPai = gangList[k] + "";
                tempPai = tempPai.trim();
                var paiPath = tablePaiActionScript.getChuPaiNameByNodeName(tempPai, pointIndex);
                cc.loader.loadRes(paiPath, (function (err, sp) {
                    if (err) {
                        cc.log("----" + err.message || err);
                        return;
                    }

                    var sencodPaiX = -1;
                    var sencodPaiY = -1;
                    for (var m = 1; m < 4; m++) {
                        var pNode = cc.instantiate(this.paiChuPaiNode);
                        pNode.name = "pengpai" + pointIndex + "_" + paiNumber;
                        pNode.active = true;
                        cc.log("gang m:" + m);
                        cc.log("gang x:" + finalX + "-----y:" + finalY);
                        pNode.position = cc.p(finalX, finalY);
                        if (m == 2) {
                            sencodPaiX = finalX;
                            sencodPaiY = finalY;
                        }

                        if (pointIndex == "2") {
                            pNode.setLocalZOrder(100 - m);
                            pNode.zIndex = 100 - m;
                        }

                        var point = this.getCorrectPointByIndex(pointIndex, finalX, finalY);
                        finalX = point[0];
                        finalY = point[1];

                        var sprite = pNode.getComponent(cc.Sprite);
                        sprite.spriteFrame = new cc.SpriteFrame(sp);
                        userPengPaiListNode.addChild(pNode);
                    }

                    //if (singleIsGang == true) {
                    var pNode2 = cc.instantiate(this.paiChuPaiNode);
                    if (pointIndex == "3") {
                        sencodPaiY = sencodPaiY + 15;
                    } else if (pointIndex == "1") {
                        sencodPaiY = sencodPaiY - 10;
                    } else if (pointIndex == "2") {
                        sencodPaiX = sencodPaiX + 10;
                    } else {
                        sencodPaiX = sencodPaiX + 10;
                    }

                    cc.log("isGang paiNumber:" + paiNumber);
                    cc.log("isGang paiPath:" + paiPath);

                    pNode2.name = "pengpai" + pointIndex + "_gang" + paiNumber;
                    pNode2.active = true;
                    cc.log("gang x:" + finalX + "-----y:" + finalY);
                    pNode2.position = cc.p(sencodPaiX, sencodPaiY);
                    var sprite2 = pNode2.getComponent(cc.Sprite);
                    sprite2.spriteFrame = new cc.SpriteFrame(sp);
                    userPengPaiListNode.addChild(pNode2);
                    //isGang = false;

                    // }
                }).bind(this));
            }
        }
    },

    getCorrectPointByIndex: function getCorrectPointByIndex(pointIndex, x, y) {
        var point = [];
        if (pointIndex == "3") {
            x = x - 42;
        } else if (pointIndex == "1") {

            x = x + 42;
        } else if (pointIndex == "2") {

            y = y + 35;
        } else {
            y = y - 35;
        }

        point.push(x);
        point.push(y);
        return point;
    },

    //-----------------Action end-------------------------------------------------------

    removeElementByNumberFromUser: function removeElementByNumberFromUser(paiList, paiNumber, b) {
        var c = 1;
        while (c <= b) {
            for (var i = 0; i < paiList.length; ++i) {
                var temp = paiList[i] + "";
                temp = temp.trim();
                if (temp == paiNumber) {
                    paiList.splice(i, 1);

                    break;
                }
            }
            c++;
        }

        return paiList;
    }

});

cc._RFpop();
},{}],"publicMessageController":[function(require,module,exports){
"use strict";
cc._RFpush(module, '22fa07yi7JPdKdmMqommxXs', 'publicMessageController');
// script/controllers/publicMessageController.js

var source_x;
var target_x;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        messageNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        if (source_x == null || source_x == undefined) {
            source_x = this.messageNode.x;
        }
        if (target_x == null || target_x == undefined) {
            target_x = source_x - 1000;
        }

        var y = this.messageNode.y;
        var action = cc.repeatForever(cc.sequence(cc.moveTo(5, cc.p(target_x, y)), cc.place(cc.p(source_x, y))));
        this.messageNode.runAction(action);
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"quepaiScript":[function(require,module,exports){
"use strict";
cc._RFpush(module, '0a892C+JV1AtLSyeQ6cx+RK', 'quepaiScript');
// script/ui/quepaiScript.js

var alerMessage;
var gameTableNetWork;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        tongNode: cc.Node,
        tiaoNode: cc.Node,
        wanNode: cc.Node,
        thisSelectNode: cc.Node,
        waitOtherUserNode: cc.Node,
        quePaiNode: cc.Node,
        alertMessageNode: cc.Node,
        gameTableNetWorkNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.waitOtherUserNode.active = false;
        this.thisSelectNode.active = true;
        // this.quePaiNode.active =false;
        alerMessage = this.alertMessageNode.getComponent("alertMessagePanle");
        gameTableNetWork = this.gameTableNetWorkNode.getComponent("GameTableNetWork");
    },

    quePaiClick: function quePaiClick(event) {
        var node = event.target;
        var name = node.name;
        var que = "";
        if (name == "tong") {
            que = "1";
        }
        if (name == "tiao") {
            que = "2";
        }
        if (name == "wan") {
            que = "3";
        }

        var userList = Global.userList;
        var userInfo = Global.userInfo;

        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == userInfo.openid) {
                userList[i].quePai = que;
                userInfo.quePai = que;
            }
        }
        Global.userInfo = userInfo;
        //show other wait other user select pai 
        this.thisSelectNode.active = false;
        this.waitOtherUserNode.active = true;
        //set action typeof
        Global.chuPaiActionType = "normalChuPai";
    },

    showQuePaiNode: function showQuePaiNode() {
        this.quePaiNode.active = true;
    },

    sendQuePai: function sendQuePai() {
        if (Global.huanSanZhangPaiList.length < 3) {
            alerMessage.text = "你必须选择三张牌！";
            alerMessage.setTextOfPanel();
            alerMessage.alertPanelNode.active = true;
        } else {
            //Global.chuPaiActionType = ""
            this.waitPanleNode.active = true;
            gameTableNetWork.sendHuanSanZhang();
            tableUserInfo.disableAllPai();
            this.unschedule(timerUpate);
        }
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"showGameMode":[function(require,module,exports){
"use strict";
cc._RFpush(module, '3fc2balORNPzr17F9gMav4o', 'showGameMode');
// script/ui/showGameMode.js

cc.Class({
  "extends": cc.Component,

  properties: {
    // foo: {
    //    default: null,      // The default value will be used only when the component attaching
    //                           to a node for the first time
    //    url: cc.Texture2D,  // optional, default is typeof default
    //    serializable: true, // optional, default is true
    //    visible: true,      // optional, default is true
    //    displayName: 'Foo', // optional
    //    readonly: false,    // optional, default is false
    // },
    // ...
    gameModeLable: cc.Node,
    gameRoomNUmber: cc.Node
  },

  // use this for initialization
  onLoad: function onLoad() {},

  showGameMode: function showGameMode() {
    var gameMode = Global.gameMode;
    var userInfo = Global.userInfo;
    if (gameMode == null || gameMode == undefined) {
      gameMode = require("gameMode").gameMode;
    }

    var modeStr = "";
    if (gameMode.ziMoJiaDi + "" == "1") {
      modeStr = modeStr + "自摸加底" + " ";
    }
    if (gameMode.ziMoJiaFan + "" == "1") {
      modeStr = modeStr + "自摸加番" + " ";
    }
    if (gameMode.ziMoHu + "" == "1") {
      modeStr = modeStr + "自摸胡" + " ";
    }
    if (gameMode.dianPaoHu + "" == "1") {
      modeStr = modeStr + "点炮胡" + " ";
    }
    if (gameMode.huanSanZhang + "" == "1") {
      modeStr = modeStr + "换三张" + " ";
    }
    if (gameMode.dianGangHua_dianPao + "" == "1") {
      modeStr = modeStr + "点杠点炮" + " ";
    }
    if (gameMode.dianGangHua_ziMo + "" == "1") {
      modeStr = modeStr + "点杠自摸" + " ";
    }
    if (gameMode.dai19JiangDui + "" == "1") {
      modeStr = modeStr + "带幺九" + " ";
    }
    if (gameMode.mengQingZhongZhang + "" == "1") {
      modeStr = modeStr + "门清中张" + " ";
    }

    if (gameMode.tianDiHu + "" == "1") {
      modeStr = modeStr + "天地胡" + " ";
    }

    if (gameMode.fan2 + "" == "1") {
      modeStr = modeStr + "2番封顶" + " ";
    }
    if (gameMode.fan3 + "" == "1") {
      modeStr = modeStr + "3番封顶" + " ";
    }
    if (gameMode.fan4 + "" == "1") {
      modeStr = modeStr + "4番封顶" + " ";
    }
    if (gameMode.roundCount4 + "" == "1") {
      modeStr = modeStr + "4局一轮" + " ";
    }
    if (gameMode.roundCount8 + "" == "1") {
      modeStr = modeStr + "8局一轮" + " ";
    }

    var modeLable = this.gameModeLable.getComponent(cc.Label);
    var roomLable = this.gameRoomNUmber.getComponent(cc.Label);
    modeLable.string = modeStr;
    roomLable.string = "房间号:" + Global.joinRoomNumber;
  }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{"gameMode":"gameMode"}],"tableActionController":[function(require,module,exports){
"use strict";
cc._RFpush(module, '45682QMUxxKk5knUxwzBWCY', 'tableActionController');
// script/controllers/tableActionController.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        tableNetWorkAction: cc.Node,
        readyIcon: cc.SpriteFrame,
        readyNotIcon: cc.SpriteFrame
    },

    // use this for initialization
    onLoad: function onLoad() {},

    userReadyToggle: function userReadyToggle(event) {

        var node = event.target;
        if (node.active == true) {
            node.active = false;
        } else {
            node.active = true;
        }
        cc.log("userReadyToggle:" + node.name);
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"tableCenterPoint":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'd2303wmCtRHxZznnzxI/frv', 'tableCenterPoint');
// script/ui/tableCenterPoint.js

var timerUpate;
var timeCount;
var pointUpdate;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        user1Point: cc.Node,
        user2Point: cc.Node,
        user3Point: cc.Node,
        user4Point: cc.Node,
        user1Quepai: cc.Node,
        user2Quepai: cc.Node,
        user3Quepai: cc.Node,
        user4Quepai: cc.Node,
        index: String,
        tenPoint: cc.Node,
        numPoint: cc.Node,
        numberSprite: [cc.SpriteFrame],
        centerPointNode: cc.Node
    },

    // use self for initialization
    onLoad: function onLoad() {

        var self = this;
        self.hideAllPoint();
        timeCount = 30;
        this.initalCenterNum();
        this.hideAllQuePai();
        timerUpate = function () {

            // cc.log("timeCount:" + timeCount + "----" + timeCount.length);

            this.initalCenterNum();
            timeCount--;

            if (timeCount == -1) {
                self.endTimer();
            }
        };

        pointUpdate = function () {
            var point;
            if (self.index == "1") {
                point = self.user1Point;
            }
            if (self.index == "2") {
                point = self.user2Point;
            }
            if (self.index == "3") {
                point = self.user3Point;
            }
            if (self.index == "4") {
                point = self.user4Point;
            }

            if (point.active == false) {
                point.active = true;
            } else {
                point.active = false;
            }
        };

        self.index = "1";
        self.stratTimer();
    },
    initalCenterNum: function initalCenterNum() {
        var self = this;
        var ten = -1;
        var num = -1;
        if ((timeCount + "").length < 2) {
            ten = "0";
            num = timeCount + "";
        } else {
            ten = (timeCount + "").substring(0, 1);
            num = (timeCount + "").substring(1);
        }

        if (ten != -1) {
            ten = parseInt(ten);
        }
        if (num != -1) {
            num = parseInt(num);
        }

        var tenScript = self.tenPoint.getComponent(cc.Sprite);
        var numScript = self.numPoint.getComponent(cc.Sprite);

        tenScript.spriteFrame = self.numberSprite[ten];
        numScript.spriteFrame = self.numberSprite[num];
    },

    hideAllQuePai: function hideAllQuePai() {
        this.user1Quepai.active = false;
        this.user2Quepai.active = false;
        this.user3Quepai.active = false;
        this.user4Quepai.active = false;
    },

    hideAllPoint: function hideAllPoint() {
        var self = this;
        self.user1Point.active = false;
        self.user2Point.active = false;
        self.user3Point.active = false;
        self.user4Point.active = false;
    },

    stratTimer: function stratTimer() {
        //timeCount = 10;
        var self = this;
        self.schedule(timerUpate, 1);
        self.schedule(pointUpdate, 0.5);
    },
    endTimer: function endTimer() {
        var self = this;
        self.unschedule(timerUpate);
        self.unschedule(pointUpdate);
        self.hideAllPoint();
    }

});
// called every frame, uncomment self function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"tableMoPaiAction":[function(require,module,exports){
"use strict";
cc._RFpush(module, '85d20bwt4pI8py2x7WBW+Ft', 'tableMoPaiAction');
// script/ui/tableMoPaiAction.js


var tableActionScript;
var tableUserInfoScript;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        tableAction: cc.Node,
        liPaiPrefab: cc.Prefab,
        user3PaiListNode: cc.Node,
        tableUserInfo: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        tableActionScript = this.tableAction.getComponent("tablePaiAction");
        tableUserInfoScript = this.tableUserInfo.getComponent("tableUserInfo");
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    moPaiFromServer: function moPaiFromServer(userOpenId) {},
    moPaiTest: function moPaiTest() {
        this.moPaiAction("15", "testUser2");
    },

    moPaiAction: function moPaiAction(paiNumber, userOpenId) {
        var paiList = tableActionScript.getSelfPaiList();
        var latstIndex = 0;
        if (paiList.length == 13) {
            latstIndex = 13;
        } else {
            latstIndex = paiList.length;
        }
        var paiNode = cc.instantiate(this.liPaiPrefab);
        var sprite = paiNode.getComponent(cc.Sprite);
        paiNode.name = "pai" + latstIndex + "_" + paiNumber;

        var index = tableUserInfoScript.getCurrectIndeOnSeflPai(paiNumber);
        sprite.spriteFrame = tableUserInfoScript.liPaiZiMian[index];
        this.user3PaiListNode.addChild(paiNode);
        paiNode.position = cc.p(-520 + latstIndex * 80, 0);
        //---data layer-----------------
        var userList = Global.userList;
        var user;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == userOpenId) {
                user = userList[i];
                break;
            }
        }
        user.userMoPai = paiNumber;
        this.updateUserListInGobal(user);
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);

        tableActionScript.enabledAllPai(parentNode, false);
    },

    updateUserListInGobal: function updateUserListInGobal(user) {
        var userList = Global.userList;

        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == user.openid) {
                userList[i] = user;
            }
        }
        Global.userList = userList;
    }

});

cc._RFpop();
},{}],"tableNetWork":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e15e652WSJJ+4yQ5yCC0PRa', 'tableNetWork');
// script/domainClass/tableNetWork.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"tablePaiAction":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ce6b2jbT71PzZaL7R+/rHKQ', 'tablePaiAction');
// script/ui/tablePaiAction.js


var paiListReOrderCount = "3";
var nodeMoveX = -1;
var nodeMoveY = -1;
var tableUserInfoScript;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        paiActionType: String,
        alertMessageNode: cc.Node,
        tableNode: cc.Node,
        selfChuPaiListNode: cc.Node,
        paiChuPaiNode: cc.Prefab,
        theMoveNode: cc.Node
    },

    //tableUserInfo:cc.Node,
    //paiListReOrderCount:cc.Integer,
    // use this for initialization
    //chuPaiActionType
    onLoad: function onLoad() {
        var tableUserInfo = cc.find("tableUserInfo");
        tableUserInfoScript = tableUserInfo.getComponent("tableUserInfo");
    },

    setPaiListReOrderCount: function setPaiListReOrderCount(number) {
        paiListReOrderCount = number;
    },
    //----------Data layer utils function---------------------------------
    getCorrectIndexByNumber: function getCorrectIndexByNumber(paiNumber, user) {

        var paiListArray = user.paiListArray;
        var index = -1;
        for (var i = 0; i < paiListArray.length; i++) {
            if (paiListArray[i] == paiNumber) {
                index = i;
            }
        }
        return index;
    },

    //----------Data layer utils function end---------------------------------

    //--------------------action layer utils function---------------------------

    addPaiIntoPaiListNode: function addPaiIntoPaiListNode(userChuPaiListNode, name, userPoint, paiNode) {
        var user = this.getCorrectUserByPoint(userPoint);
        var userPaiList = user.paiList;
        var x = user.chupaiListX;
        var y = user.chupaiListY;
        var paiPath = this.getChuPaiNameByNodeName(name, userPoint);
        cc.log("paiPath:" + paiPath);
        var pNode = cc.instantiate(this.paiChuPaiNode);

        if (userPoint == "3") {
            if (user.chuPaiCount >= paiListReOrderCount) {
                pNode.setLocalZOrder(10);
                pNode.zIndex = 10;
            } else {
                pNode.setLocalZOrder(20);
                pNode.zIndex = 20;
            }
        }

        if (userPoint == "4") {
            pNode.setLocalZOrder(100 - parseInt(user.chuPaiCount));
            pNode.zIndex = 100 - parseInt(user.chuPaiCount);
        }

        //let sprite = pNode.addComponent(cc.Sprite)
        pNode.name = "pai" + userPoint + "_" + name;
        pNode.active = false;
        pNode.position = cc.p(x, y);
        //pNode.width = 42;
        //pNode.height = 61;
        var sprite = pNode.getComponent(cc.Sprite);
        cc.loader.loadRes(paiPath, function (err, sp) {
            if (err) {
                //  cc.log("----" + err.message || err);
                return;
            }
            // cc.log("85");

            sprite.spriteFrame = new cc.SpriteFrame(sp);

            //  cc.log("99");
            // cc.log('Result should be a sprite frame: ' + (sp instanceof cc.SpriteFrame));
            // pNode.active = true;
        });
        userChuPaiListNode.addChild(pNode);
        var paiNodeArray = [];
        paiNodeArray.push(pNode);
        paiNodeArray.push(paiNode);
        paiNodeArray.push(paiNode.parent);
        paiNodeArray.push(userPaiList);
        paiNodeArray.push(user.openid);
        var finished = cc.callFunc(this.playSlefChuPaiAction_addChild, this, paiNodeArray);
        var moveToY = 0;

        if (userPoint == "3") {
            moveToY = y + 220;
        }
        if (userPoint == "1") {
            moveToY = y - 110;
        }
        cc.log("y:" + y);
        cc.log("moveToY:" + moveToY);
        var action = cc.sequence(cc.moveTo(0.15, x, moveToY), cc.scaleTo(0.15, 0.5), cc.removeSelf(), finished);
        //it is other user chupai ,get the first child element
        cc.log("127:" + paiNode.parent.childrenCount);
        paiNode.runAction(action);

        //user.chuPaiCount = user.chuPaiCount + 1;

        //remove paiNode from partnet
        cc.log("132:" + paiNode.parent.name);
        // paiNode.removeFromParent();
        //userChuPaiListNode.addChild(paiNode);

        return user;
    },
    //-------------------game action-------------------------------
    slefChuPaiAction: function slefChuPaiAction(paiNumber) {
        var paiNode = cc.find("user3Node", this.tableNode);
        var children = paiNode.children;
        var selfPaiList = this.getSelfPaiList();
        var userInfo = Global.userInfo;
        var openid = userInfo.openid;
        //---data layer start--------
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            var temp = childredName.split("_");
            var sType = temp[1].trim();
            var index = parseInt(temp[0].trim().replace("pai", ""));
            if (paiNumber == sType) {
                selfPaiList.splice(index, 1);
                this.setUserPaiList(openid, selfPaiList);

                break;
            }
        }
        //****fix the node name for the new pai list. */

        //----data layer end-----------
        //insert pai action comic action .
        // remove the pai from self list
        //move rest pai to correct point ,and keep the blank for 14 pai
        //insert the 14 pai into correct point .
    },
    testOtherChuPai: function testOtherChuPai() {
        this.playOtherChuPaiAction("22", "1");
        this.playOtherChuPaiAction("27", "2");
        this.playOtherChuPaiAction("27", "4");
        this.disableAllSlefPaiAfterQuePai();
    },
    /**
     * This method will execute the other chupai action 
     */
    playOtherChuPaiAction: function playOtherChuPaiAction(paiNumber, userPoint) {
        //var user = this.getCorrectUserByPoint(userPoint);
        var paiPath = this.getChuPaiNameByNodeName(paiNumber, userPoint);
        // var x = user.chupaiListX;
        //  var y = user.chupaiListY;
        var tableNode = cc.find("Canvas/tableNode");
        var userChuPaiListNode = cc.find("user" + userPoint + "ChuaPaiListNode", tableNode);
        var userPaiList = cc.find("user" + userPoint + "PaiList", tableNode);
        // cc.log("userPaiList:" + userPaiList.name);
        //    cc.log("userPaiList children:" + userPaiList.children.length);
        var paiNode = userPaiList.children[0];
        //   cc.log("paiNode:" + paiNode.name);
        var user = this.addPaiIntoPaiListNode(userChuPaiListNode, paiNumber, userPoint, paiNode);

        user = this.fixCurrentChuPaiPoint(user);
        this.updateUserListInGobal(user);
    },
    /**
     * This method will execute the anication of chupai in self pai list
     */
    playSlefChuPaiAction: function playSlefChuPaiAction(paiNode, userPoint) {
        // var user = this.getCorrectUserByPoint(userPoint);
        var name = paiNode.name;

        var tempArray = name.split("_");
        name = tempArray[1];

        // cc.log("user.chupaiListX:" + user.chupaiListX);

        // cc.log("x:" + x + "----" + "y:" + y);
        //, cc.removeSelf()

        //add the target pai into pai list.
        var parentNode = paiNode.parent.parent;
        //  cc.log("parentNode:" + parentNode.name);
        var userChuPaiListNode = cc.find("user" + userPoint + "ChuaPaiListNode", parentNode);
        //   cc.log("userChuPaiListNode:" + userChuPaiListNode);

        var user = this.addPaiIntoPaiListNode(userChuPaiListNode, name, userPoint, paiNode);
        user.chuPaiPointX = paiNode.x;
        user = this.fixCurrentChuPaiPoint(user);

        //Now, we need insert the 14 into correct point
        var chupaiIndex = parseInt(tempArray[0].replace("pai", ""));
        var mopaiInsertIndex = this.getPaiInsertIndexBy14();
        cc.log("mopaiInsertIndex:" + mopaiInsertIndex);
        cc.log("chupaiIndex:" + chupaiIndex);
        //move the other pai into correct point

        if (chupaiIndex != mopaiInsertIndex) {
            mopaiInsertIndex = this.moveOtherPaiIntoCorrectPoint(mopaiInsertIndex, chupaiIndex);
        }
        //move the 14 pai into correct point
        this.moveLastestPaiToPoint(mopaiInsertIndex);
        //datalayer -------------------------------------------

        var paiList = this.removeElementByNumberFromUser(paiNode, 1);
        cc.log("235:" + paiList);
        user.paiListArray = paiList;
        user = this.insertMoPaiIntoPaiList(user);
        user = this.synchronizationPaiList(user);
        user.userMoPai = "";
        cc.log("user openid:" + user.openid);
        this.updateUserListInGobal(user);
        cc.log("241:" + user.paiList);
        //this.fixUserSelfPaiPoinst();
        //this.removeAllNodeFromSelfPaiList();
        //tableUserInfoScript.intalSelfPaiList(user.paiList);

        //add pai to correct point 

        // pNode.active = true;
        //add it to curernt
        //  eval("this.user" + point + "PaiListNode.addChild(paiNode)");
    },

    /**
     * fix the point for self pai list
     */

    fixUserSelfPaiPoinst: function fixUserSelfPaiPoinst() {
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);
        var childrens = parentNode.children;
        var startPoint = -520;
        cc.log("264:" + childrens.length);
        for (var i = 0; i < childrens.length; i++) {
            var child = childrens[i];
            child.position = cc.p(startPoint + i * 79, 0);
            cc.log("ponit:" + i + ":" + (startPoint + i * 79) + "::" + child.name);
        }
    },

    playSlefInserterPaiAction: function playSlefInserterPaiAction(chupaiIndex, mopaiIndex) {
        //first we should decide if move the pai or not move
        if (chupaiIndex == mopaiIndex) {} else if (chupaiIndex > mopaiIndex) {} else {
            //chupaiIndex<mopaiIndex

        }
    },
    moveOtherPaiIntoCorrectPoint: function moveOtherPaiIntoCorrectPoint(mopaiInsertIndex, chuPaiIndex) {

        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);
        var children = parentNode.children;
        cc.log("288:" + children.length);
        cc.log("mopaiInsertIndex:" + mopaiInsertIndex);
        if (mopaiInsertIndex == -1) {
            mopaiInsertIndex = 0;
        }
        cc.log("chuPaiIndex:" + chuPaiIndex);
        for (var i = 0; i < children.length; i++) {
            var child = children[i];
            cc.log("288 name:" + child.name);
        }
        var user = this.getCorrectUserByPoint("3");
        var chuPaiPointX = user.chuPaiPointX;
        var moveDistance = 0;

        if (mopaiInsertIndex > chuPaiIndex) {
            cc.log(">>>>>:");

            for (var i = chuPaiIndex + 1; i < mopaiInsertIndex; i++) {
                var node = children[i];
                var action = cc.moveTo(0.1, node.x - 84, node.y);
                node.runAction(action);
            }
            mopaiInsertIndex--;
        } else {
            cc.log("<<<<<<:");
            for (var i = chuPaiIndex - 1; i > mopaiInsertIndex - 1; i--) {
                var node = children[i];
                var action = cc.moveTo(0.1, node.x + 84, node.y);
                node.runAction(action);
            }
        }

        return mopaiInsertIndex;
    },
    /**
     * Move the latest pai in to correct position 
     */
    moveLastestPaiToPoint: function moveLastestPaiToPoint(index) {
        index = parseInt(index);
        var latestPaiPoint = this.getPoinstByIndexFromSelfPaiList(13);
        var latestPaiX = latestPaiPoint.x;
        var chuPaiPoint = this.getPoinstByIndexFromSelfPaiList(index);
        var chuPaiX = chuPaiPoint.x;
        var painode = this.getPaiNodeByIndex(13);

        var contronalX = chuPaiX + Math.abs(latestPaiX - chuPaiX) / 2;
        chuPaiPoint.y = 0;

        var bezier = [latestPaiPoint, cc.p(contronalX, 30), chuPaiPoint];
        var bezierTo = cc.bezierTo(0.6, bezier);

        painode.runAction(bezierTo);
    },
    //------------------------------------------------------------------------

    playSlefChuPaiAction_addChild: function playSlefChuPaiAction_addChild(target, pNodeArray) {
        var pNode = pNodeArray[0];
        var paiNode = pNodeArray[1];
        var parent = pNodeArray[2];
        var paiList = pNodeArray[3];
        var userOpenId = pNodeArray[4];
        cc.log("playSlefChuPaiAction_addChild:" + paiNode.name);
        cc.log("playSlefChuPaiAction_addChild parent:" + parent.name);
        cc.log("playSlefChuPaiAction_addChild parent child count1:" + parent.childrenCount);
        pNode.active = true;

        var spriteFrame = paiNode.getComponent(cc.Sprite).spriteFrame;
        var deps = cc.loader.getDependsRecursively(spriteFrame);
        cc.loader.release(deps);
        paiNode.removeFromParent();
        cc.log("playSlefChuPaiAction_addChild parent child count2:" + parent.childrenCount);
        this.removeAllNodeFromSelfPaiList();
        cc.log("paiList:" + paiList);

        var user = this.getCorrectUserByOpenId(userOpenId);
        cc.log("374:" + user.paiList);
        tableUserInfoScript.intalSelfPaiList(user.paiList);

        this.disableAllSlefPai();
    },

    /**
     * 
     */

    updateUserListInGobal: function updateUserListInGobal(user) {
        var userList = Global.userList;

        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == user.openid) {
                userList[i] = user;
            }
        }
        Global.userList = userList;
    },
    /**
     * This method will  fix the pai in the chupai list point
     */

    fixCurrentChuPaiPoint: function fixCurrentChuPaiPoint(user) {
        // var user = this.getCorrectUserByPoint(userPoint);
        var userIndex = user.pointIndex;
        if (userIndex == "1") {

            if (user.chuPaiCount == paiListReOrderCount) {
                user.chupaiListY = -95;
                user.chupaiListX = 210;
            } else {
                user.chupaiListX = user.chupaiListX - 42;
            }
        }
        cc.log("this.paiListReOrderCount:" + paiListReOrderCount);
        if (userIndex == "2") {
            if (user.chuPaiCount == paiListReOrderCount) {
                user.chupaiListY = 120;
                user.chupaiListX = 226;
            } else {
                user.chupaiListY = user.chupaiListY - 35;
            }
        }
        if (userIndex == "3") {

            if (user.chuPaiCount == paiListReOrderCount) {
                user.chupaiListY = 3;
                user.chupaiListX = -210;
            } else {
                user.chupaiListX = user.chupaiListX + 42;
            }
        }
        if (userIndex == "4") {
            if (user.chuPaiCount == paiListReOrderCount) {
                user.chupaiListX = -225;
                user.chupaiListY = -120;
            } else {
                user.chupaiListY = user.chupaiListY + 35;
            }
        }

        user.chuPaiCount = user.chuPaiCount + 1;
        // cc.log("user.chupaiListX 200:"+user.chupaiListX);
        return user;
    },
    /**
     * This method will get the correct image path from image folder of resourecs
     */
    getChuPaiNameByNodeName: function getChuPaiNameByNodeName(paiName, userIndex) {
        var returnName = "";
        var backPrefix = "";
        var folderName = "user" + userIndex;
        var type = paiName[0];
        var number = paiName[1];
        var firstPrefix = "";
        var backPrefix2 = "";
        if (userIndex == "1") {
            backPrefix = "-u";
        }
        if (userIndex == "2") {
            backPrefix = "-l";
        }
        if (userIndex == "3") {
            backPrefix = "-d";
        }
        if (userIndex == "4") {
            backPrefix = "-r";
        }

        if (type == "1") {
            firstPrefix = "tong";
            backPrefix2 = "b";
        }
        if (type == "2") {
            firstPrefix = "tiao";
            backPrefix2 = "t";
        }
        if (type == "3") {
            firstPrefix = "wan";
            backPrefix2 = "w";
        }

        returnName = folderName + "/" + firstPrefix + backPrefix + "/" + number + backPrefix2;
        return returnName;
    },
    //-------------------game action end -------------------------------
    setUserPaiList: function setUserPaiList(openid, paiList) {
        var userList = Global.userList;
        var paiListStr = paiList.toString();
        paiListStr = paiListStr.replace("[", "");
        paiListStr = paiListStr.replace("]", "");
        //   var userInfo = Global.userInfo;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == openid) {
                userList[i].paiListArray = paiList;
                userList[i].paiList = paiListStr;
            }
        }

        Global.userList = userList;
    },
    getCorrectUserByOpenId: function getCorrectUserByOpenId(userOpenId) {

        var userList = Global.userList;
        var user;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == userOpenId) {
                user = userList[i];
            }
        }

        return user;
    },
    getCorrectUserByPoint: function getCorrectUserByPoint(pointIndex) {

        var userList = Global.userList;
        var user;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].pointIndex == pointIndex) {
                user = userList[i];
            }
        }

        return user;
    },
    getSelfPaiList: function getSelfPaiList() {

        var userList = Global.userList;
        var userInfo = Global.userInfo;
        var paiList;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == userInfo.openid) {
                paiList = userList[i].paiListArray;
            }
        }

        return paiList;
    },

    getQuePai: function getQuePai() {
        var quePai;
        var userList = Global.userList;
        var userInfo = Global.userInfo;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == userInfo.openid) {
                quePai = userList[i].quePai;
            }
        }

        return quePai;
    },

    chuPaiAction: function chuPaiAction(event) {

        var actionType = Global.chuPaiActionType;
        var gameMode = Global.gameMode;
        var huanSanZhangPaiList = Global.huanSanZhangPaiList;
        var node = event.target;
        var name = node.name;
        var temp = name.split("_");
        var paiNumTxt = temp[1];
        var chuPaiIndex = -1;
        chuPaiIndex = temp[0].replace("pai");

        //Fix the game mode aollow huansanzhang
        gameMode.huanSanZhang = "1";
        //************************************** */
        // var index = parseInt(name.substring(7));
        // cc.log("index:" + index);
        //var paiList = this.getSelfPaiList();
        cc.log("Global.chuPaiActionType:" + Global.chuPaiActionType);
        var parentNode = node.parent;
        if (node.y == 0) {
            //move out
            var action = cc.moveTo(0.1, node.x, node.y + 20);
            node.runAction(action);
            if (Global.chuPaiActionType == "huanSanZhang") {
                if (gameMode.huanSanZhang == "1") {
                    //cc.log("parentNode:" + parentNode.name);
                    if (huanSanZhangPaiList.length < 3) {
                        huanSanZhangPaiList.push(paiNumTxt);
                    }
                    //disable all other pai
                    this.disableAllSlefPaiExceptSelected(parentNode, node, huanSanZhangPaiList);
                    //}
                }
            } else {

                    this.putBackAllPaiExceptClickPai(parentNode, name);
                }
        } else {

            if (Global.chuPaiActionType == "huanSanZhang") {
                //huan sanzhang move back
                if (gameMode.huanSanZhang == "1") {
                    var action = cc.moveTo(0.1, node.x, 0);
                    node.runAction(action);
                    if (huanSanZhangPaiList == null || huanSanZhangPaiList == undefined) {
                        this.enabledAllSelfPai(parentNode);
                    } else {
                        huanSanZhangPaiList.splice(huanSanZhangPaiList.length - 1, 1);
                        if (huanSanZhangPaiList.length == 0) {
                            this.enabledAllSelfPai(parentNode);
                        } else {
                            if (huanSanZhangPaiList.length < 3) {
                                this.enabledSlefSelfPai(parentNode, huanSanZhangPaiList);
                            }
                        }
                    }
                }
            } else {
                //normal chupai
                //enable all pai after quepai clean
                this.playSlefChuPaiAction(node, "3");
            }
        }

        cc.log("huanSanZhangPaiList:" + huanSanZhangPaiList.toString());
    },

    getTypeByName: function getTypeByName(childredName) {
        var temp = childredName.split("_");
        var sType = temp[1];
        sType = sType.substring(0, 1);
        return sType;
    },

    putBackAllPaiExceptClickPai: function putBackAllPaiExceptClickPai(parentNode, clickPaiName) {
        var children = parentNode.children;

        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            if (childredName != clickPaiName) {
                if (children[i].y > 0) {
                    var action = cc.moveTo(0.1, children[i].x, 0);
                    children[i].runAction(action);
                }
            }
        }
    },
    onEnable: function onEnable() {
        cc.log("this node :" + this.node.name + "  enabled");
    },
    onDisable: function onDisable() {
        cc.log("this node :" + this.node.name + "  disabled");
    },
    throwActionForNode: function throwActionForNode(theNode) {
        cc.log(" throwActionForNode:");
        //  var sourceY;
        // var sourceX;
        theNode.on(cc.Node.EventType.TOUCH_START, function (event) {

            cc.log("touch start:" + theNode.name);
            this.sourceY = this.y;
            this.sourceX = this.x;
            cc.log("cc.Node.EventType.TOUCH_START:" + this.sourceY);
        }, theNode);
        theNode.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            cc.log("touch move :" + this.name);
            //var touches = event..getDeltaX();
            //var touchesLoc = touches[0].getLocation();
            //  cc.log(" touchesLoc:" + touchesLoc.toString());

            var x = event.getDeltaX();
            var y = event.getDeltaY();
            this.x += x;
            this.y += y;

            var btn = this.getComponent(cc.Button);
            if (btn != null && btn != undefined) {
                btn.interactable = false;
                btn.enableAutoGrayEffect = false;
            }

            // this.theMoveNode = theNode;
            // cc.log(" nodeMoveX:" + nodeMoveX);
            //   cc.log(" nodeMoveY:" + nodeMoveY);
            //var x = touches[0].getLocationX();
        }, theNode);
        theNode.on(cc.Node.EventType.TOUCH_END, function (event) {
            cc.log("cc.Node.EventType.TOUCH_END:" + theNode.sourceY);
            var endY = Math.floor(Math.abs(theNode.y - theNode.sourceY));
            cc.log("endY:" + endY);

            if (endY > 100) {
                var name = theNode.name;
                if (name.indexOf("_") > 0) {
                    var tempArray = name.split("_");
                    name = tempArray[1];
                };
                var partenName = theNode.parent.name;
                partenName = partenName.replace("PaiList", "");
                var userPoint = partenName.replace("user", "");
                var tableNode = cc.find("Canvas/tableNode");
                var userChuPaiListNode = cc.find(partenName + "ChuaPaiListNode", tableNode);
                cc.log("userChuPaiListNode:" + userChuPaiListNode.name);

                var user = this.addPaiIntoPaiListNode(userChuPaiListNode, name, userPoint, theNode);

                user = this.fixCurrentChuPaiPoint(user);
                this.updateUserListInGobal(user);
            } else {
                var btn = theNode.getComponent(cc.Button);
                btn.interactable = true;
                theNode.x = theNode.sourceX;
                theNode.y = theNode.sourceY;
            }

            //var x = touches[0].getLocationX();
        }, this);
    },
    /**
     * this.node.on('touchstart', function(event) {
    var touches = event.getTouches();
    var x = touches[0].getLocationX();
    }, this);
     */
    disableAllSlefPai: function disableAllSlefPai() {
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);
        var children = parentNode.children;
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            cc.log("throwActionForNode childredName:" + childredName);
            var btn = children[i].getComponent(cc.Button);
            if (btn != null && btn != undefined) {
                btn.enableAutoGrayEffect = false;
                btn.interactable = false;
                btn.disabledColor = new cc.Color(255, 255, 255);
                cc.log("disableAllSlefPai:" + btn.enableAutoGrayEffect);
            }
        }
    },
    //touchmove,'touchstart',touchend
    // when the mo pai action execute,it will disabled all other pai type ,if the que pai type in the pai list
    disableAllSlefPaiAfterQuePai: function disableAllSlefPaiAfterQuePai() {
        cc.log("throwActionForNode disableAllSlefPaiAfterQuePai:");
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);

        var existFlag = this.checkQuePaiInSelf();
        //if (existFlag) {
        var children = parentNode.children;
        cc.log("throwActionForNode children length:" + children.length);
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            cc.log("throwActionForNode childredName:" + childredName);
            var btn = children[i].getComponent(cc.Button);
            var sType = this.getTypeByName(childredName);
            //if (sType == que) {

            btn.interactable = true;

            this.throwActionForNode(children[i]);
            //} else {
            //   btn.interactable = false;
            //  }
        }
        //}
    },
    // after all que pai clean ,the all other pai should be enable
    enabledAllPaiAfterQuePai: function enabledAllPaiAfterQuePai(parentNode) {
        var existFlag = this.checkQuePaiInSelf();

        if (existFlag == false) {
            this.enabledAllPai(parentNode);
        } else {
            //disable other pai ,only enable the que pai

        }
    },
    enabledAllPai: function enabledAllPai(parentNode, autoGray) {
        var children = parentNode.children;
        for (var i = 0; i < children.length; ++i) {
            var btn = children[i].getComponent(cc.Button);
            if (autoGray != null && autoGray != undefined) {
                btn.enableAutoGrayEffect = autoGray;
            }

            btn.interactable = true;
        }
    },
    enabledSlefSelfPai: function enabledSlefSelfPai(parentNode, huanSanZhangPaiList) {
        var firstElement1 = (huanSanZhangPaiList[0] + "").trim();
        //cc.log("firstElement:" + firstElement1);
        var type = firstElement1[0];
        var children = parentNode.children;
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            var sType = this.getTypeByName(childredName);
            if (sType == type) {
                var btn = children[i].getComponent(cc.Button);
                btn.interactable = true;
            }
        }
    },
    enabledAllSelfPai: function enabledAllSelfPai(parentNode) {
        //  cc.log("enabledAllSelfPai");
        var v = this.getLess3NumberType(parentNode);
        var vstr = v.toString();
        //cc.log("vstr:" + vstr);
        var children = parentNode.children;
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            var sType = this.getTypeByName(childredName);
            if (vstr.indexOf(sType) >= 0) {} else {
                var btn = children[i].getComponent(cc.Button);
                btn.interactable = true;
            }
        }
    },
    getLess3NumberType: function getLess3NumberType(parentNode) {
        var v1 = 0;
        var v2 = 0;
        var v3 = 0;
        var children = parentNode.children;
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            var sType = this.getTypeByName(childredName);
            if (sType == "1") {
                v1++;
            }
            if (sType == "2") {
                v2++;
            }
            if (sType == "3") {
                v3++;
            }
        }

        var v = [];
        if (v1 < 3) {
            v.push("1");
        }
        if (v2 < 3) {
            v.push("2");
        }
        if (v3 < 3) {
            v.push("3");
        }
        return v;
    },
    disableAllSlefPaiExceptSelected: function disableAllSlefPaiExceptSelected(parentNode, node, huanSanZhangPaiList) {
        //cc.log("disableAllSlefPaiExceptSelected");
        var children = parentNode.children;
        var firstElement1 = (huanSanZhangPaiList[0] + "").trim();
        //cc.log("firstElement:" + firstElement1);
        var type = firstElement1[0];
        // cc.log("firstElement: " + "---" + type);
        for (var i = 0; i < children.length; ++i) {
            if (children[i].y == 0) {
                if (node.name != children[i].name) {
                    var childredName = children[i].name;
                    var sType = this.getTypeByName(childredName);
                    //  cc.log("sType:" + sType + "-----" + type);
                    if (sType != type) {
                        var btn = children[i].getComponent(cc.Button);
                        btn.interactable = false;
                    } else {
                        if (huanSanZhangPaiList.length == 3) {
                            if (node.y == 0) {
                                var btn = children[i].getComponent(cc.Button);
                                btn.interactable = false;
                            }
                        }
                    }
                }
            }
        }
    },
    //------------------------utils ------------------------------------------
    insertPaiIntoPaiListByPaiAndOpenId: function insertPaiIntoPaiListByPaiAndOpenId(paiNumber, userOpenId) {
        var currentUser = this.getCorrectUserByOpenId(userOpenId);
        var paiList = currentUser.paiListArray;
        if (paiNumber != null && paiNumber != undefined) {
            paiNumber = parseInt(paiNumber.trim());
        }
        if (paiList.length > 1) {
            var temp = [];
            var insertFlag = false;
            for (var i = 0; i < paiList.length; ++i) {
                var p = paiList[i] + "";
                var pai = parseInt(p.trim());
                cc.log("loop pai:" + pai);
                if (paiNumber < pai) {
                    if (insertFlag == false) {
                        cc.log("insertFlag pai:" + paiNumber);
                        temp.push(paiNumber);
                        insertFlag = true;
                    }
                }
                temp.push(pai);
            }
            user.paiListArray = temp;
        } else {
            paiList.push(paiNumber);
            user.paiListArray = paiList;
        }

        return user.paiListArray;
    },
    insertMoPaiIntoPaiList: function insertMoPaiIntoPaiList(user) {
        var moPai = user.userMoPai;
        if (moPai != null && moPai != undefined) {
            moPai = parseInt(moPai.trim());
            cc.log("moPai:" + moPai);
            var paiList = user.paiListArray;
            if (paiList.length > 1) {
                var temp = [];
                var insertFlag = false;
                for (var i = 0; i < paiList.length; ++i) {
                    var p = paiList[i] + "";
                    var pai = parseInt(p.trim());
                    cc.log("loop pai:" + pai);
                    if (moPai < pai) {
                        if (insertFlag == false) {
                            cc.log("insertFlag pai:" + moPai);
                            temp.push(moPai);
                            insertFlag = true;
                        }
                    }
                    temp.push(pai);
                }
                user.paiListArray = temp;
            } else {
                paiList.push(moPai);
                user.paiListArray = paiList;
            }
        }
        cc.log("user open:" + user.openid);
        cc.log("insertMoPaiIntoPaiList user.paiListArray:" + user.paiListArray.toString());
        return user;
    },
    insertHuPaiIntoPaiList: function insertHuPaiIntoPaiList(user) {
        var moPai = user.userMoPai;
        if (moPai != null && moPai != undefined) {
            moPai = parseInt(moPai.trim());
            cc.log("moPai:" + moPai);
            var paiList = user.paiListArray;
            if (paiList.length > 1) {
                var temp = [];
                var insertFlag = false;
                for (var i = 0; i < paiList.length; ++i) {
                    var p = paiList[i] + "";
                    var pai = parseInt(p.trim());
                    cc.log("loop pai:" + pai);
                    if (moPai < pai) {
                        if (insertFlag == false) {
                            cc.log("insertFlag pai:" + moPai);
                            temp.push(moPai);
                            insertFlag = true;
                        }
                    }
                    temp.push(pai);
                }
                user.paiListArray = temp;
            } else {
                paiList.push(moPai);
                user.paiListArray = paiList;
            }
        }
        cc.log("user open:" + user.openid);
        cc.log("insertMoPaiIntoPaiList user.paiListArray:" + user.paiListArray.toString());
        return user;
    },
    /**
     * Synchronization the pai list array into user pai string 
     */

    synchronizationPaiList: function synchronizationPaiList(user) {

        var paiList = user.paiListArray;
        var temp = "";
        for (var i = 0; i < paiList.length; ++i) {
            temp = temp + paiList[i] + ",";
        }
        if (temp.length > 0) {
            temp = temp.substring(0, temp.length - 1);
        }
        user.paiList = temp;
        return user;
    },
    removeElementByNumberByPaiListFromUser: function removeElementByNumberByPaiListFromUser(paiList, paiNumber, b) {
        var c = 0;
        // cc.log("1043:" + paiList.toString());
        while (this.contains(paiList, paiNumber) && c != b) {
            // cc.log("1044: c" +c+"---b:"+b);
            for (var i = 0; i < paiList.length; i++) {
                var temp = paiList[i] + "";
                temp = temp.trim();
                if (temp == paiNumber + "") {
                    paiList.splice(i, 1);
                    c++;
                    break;
                }
            }
        }

        //cc.log("1056:" + paiList.toString());
        return paiList;
    },
    contains: function contains(array, obj) {
        var i = array.length;
        while (i--) {
            if (array[i] === obj) {
                return true;
            }
        }
        return false;
    },
    /**
     * remove a element from paiList of user self
     * b---remove element number.
     */
    removeElementByNumberFromUser: function removeElementByNumberFromUser(node, b) {
        var number = node.name;
        var c = 0;
        var temp = number.split("_");
        number = temp[1];
        var paiList = this.getSelfPaiList();
        for (var i = 0; i < paiList.length; ++i) {
            var temp = paiList[i] + "";
            temp = temp.trim();
            if (temp == number) {
                paiList.splice(i, 1);
                c++;
                if (c == b) {
                    break;
                }
            }
        }

        return paiList;
    },
    /**
     * Get self pai node by index
     */
    getPaiNodeByIndex: function getPaiNodeByIndex(index) {
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);
        var children = parentNode.children;
        if (index >= children.length) {
            index = children.length - 1;
        }
        cc.log("getPaiNodeByIndex:" + index);
        var childredNode = children[index];
        return childredNode;
    },
    /**
     * Get the point from self pai list by index 
     *
     */

    getPoinstByIndexFromSelfPaiList: function getPoinstByIndexFromSelfPaiList(index) {
        cc.log("getPoinstByIndexFromSelfPaiList1:" + index);
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);
        var children = parentNode.children;
        cc.log("children.length:" + children.length);
        if (index >= children.length) {
            index = children.length - 1;
        }
        cc.log("getPoinstByIndexFromSelfPaiList2:" + index);
        var childredNode = children[index];

        var point = cc.p(childredNode.x, childredNode.y);
        return point;
    },
    /**
     * Check it que pai in the self pai list
     */

    checkQuePaiInSelf: function checkQuePaiInSelf() {
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3ChuaPaiListNode", tableNode);
        var que = this.getQuePai();
        var children = parentNode.children;
        var existFlag = false;
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            var sType = this.getTypeByName(childredName);
            if (sType == que) {
                existFlag == true;
            }
        }

        return existFlag;
    },
    removeAllNodeFromSelfPaiList: function removeAllNodeFromSelfPaiList() {
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);
        var count = parentNode.childrenCount;
        cc.log("parentNode: " + parentNode.name);
        cc.log("Node Children Count 1010: " + count);
        parentNode.removeAllChildren();
    },
    removeAllNodeFromOtherPaiList: function removeAllNodeFromOtherPaiList(point) {
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user" + point + "PaiList", tableNode);
        var count = parentNode.childrenCount;
        cc.log("parentNode: " + parentNode.name);
        cc.log("Node Children Count 1010: " + count);
        parentNode.removeAllChildren();
    },
    /**
     * Get the correct index by the 14 pai 
     */
    getPaiInsertIndexBy14: function getPaiInsertIndexBy14() {
        var index = -1;
        var tableNode = cc.find("Canvas/tableNode");
        var parentNode = cc.find("user3PaiList", tableNode);
        var user = this.getCorrectUserByPoint("3");
        var moPai = parseInt(user.userMoPai);
        var paiList = this.getSelfPaiList();
        if (paiList.length == 1) {

            index = 1;
        } else {
            var firstPai = paiList[0] + "";
            firstPai = firstPai.trim();
            var minPai = parseInt(firstPai);
            var maxIndex = paiList.length - 1;
            if (maxIndex == 13) {
                maxIndex = 12;
            }
            var lastPai = paiList[maxIndex] + "";
            lastPai = lastPai.trim();
            var maxPai = parseInt(lastPai);
            cc.log("moPai:" + moPai);
            cc.log("minPai:" + minPai);
            cc.log("maxPai:" + maxPai);
            if (moPai < minPai) {
                index = 0;
            } else if (moPai > maxPai) {
                index = paiList.length;
            } else {

                for (var i = 0; i < maxIndex; i++) {
                    var paiGet = paiList[i] + "";
                    paiGet = paiGet.trim();
                    var pai = parseInt(paiGet);
                    var nextI = i + 1;
                    if (nextI == paiList.length) {
                        nextI = i;
                    }

                    if (nextI == i) {
                        index = paiList.length;
                    } else {
                        var nextPaiStr = paiList[nextI] + "";
                        nextPaiStr = nextPaiStr.trim();
                        var nextPai = parseInt(nextPaiStr);
                        cc.log("pai:" + pai);
                        cc.log("nextPai:" + nextPai);
                        if (pai < moPai && moPai < nextPai) {
                            index = nextI;
                            break;
                        }
                    }
                }
            }
        }

        return index;
    },
    //---------------utils end----------------------------------------------------
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        // if (this.theMoveNode != null && this.theMoveNode != undefined) {
        //     cc.log("update this.theMoveNode.interactable:" + this.theMoveNode.interactable);
        //     if (this.theMoveNode.interactable == true || this.theMoveNode.interactable ==undefined) {
        //         cc.log("update:" + this.theMoveNode.name);
        //         if (nodeMoveX !=0 && nodeMoveY !=0) {

        //                   this.theMoveNode.setPosition(this.theMoveNode.x+nodeMoveX,this.theMoveNode.y+nodeMoveY);

        //         }

        //     }
        // }
    }
});

cc._RFpop();
},{}],"tableUserInfo":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'c59a7pYHjxMiq1GOYNT7EOn', 'tableUserInfo');
// script/controllers/tableUserInfo.js

var huanPaiScript;
cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        userInfo1: cc.Node,
        userInfo2: cc.Node,
        userInfo3: cc.Node,
        userInfo4: cc.Node,
        tableActionNode: cc.Node,
        tableNode: cc.Node,
        userReadyIconOk: cc.SpriteFrame,
        userReadyIconNotOk: cc.SpriteFrame,
        tableGameMode: cc.Node,
        tableHead: cc.Node,

        user1ReadNode: cc.Node,
        user2ReadNode: cc.Node,
        user3ReadNode: cc.Node,
        user4ReadNode: cc.Node,
        tableTitleNode: cc.Node,

        user1PaiListNode: cc.Node,
        user2PaiListNode: cc.Node,
        user4PaiListNode: cc.Node,
        user3PaiListNode: cc.Node,
        liPaiPrefab: cc.Prefab,
        backNode: cc.Prefab,

        liPaiZiMian: [cc.SpriteFrame],
        cePai: cc.SpriteFrame,
        cePaiLeft: cc.SpriteFrame,
        backPai: cc.SpriteFrame,

        quepaiNode: cc.Node,
        tableCenterPoint: cc.Node,
        huanPaiScriptNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        // this.userInfo1.active = false;
        // this.userInfo2.active = false;
        // this.userInfo3.active = false;
        // this.userInfo4.active = false;

        // this.initalUserPai();
        // this.disabledHuanSanZhangPai();
        huanPaiScript = this.huanPaiScriptNode.getComponent("huanPaiUI");
    },
    //this function only inital a gaobal user list for test
    /**
     * chuPaiCount
     * user 1 chupai list point :x -210,y -45 
     * user 2 chupai list point :x -210,y -45
     * 
     */
    testInitalUserList: function testInitalUserList() {
        var paiList = ["11, 11, 13, 14, 18, 21, 24, 32, 33, 34, 34, 35, 35, 35", "15, 17, 18, 22, 22, 23, 29, 29, 29, 33, 36, 37, 39", "16, 17, 19, 23, 23, 23, 24, 31, 32, 33, 33, 34, 36", "15, 15, 15, 18, 22, 22, 25, 26, 28, 28, 29, 34, 38"];
        var userList = [];
        for (var i = 0; i < 5; i++) {
            var o = new Object();
            o.id = i;
            o.nickName = "testUser" + i;
            o.headImageFileName = "testUser" + i + ".jpg";
            o.diamondsNumber = "30";
            o.country = "CN";
            o.openid = "testUser" + i;
            o.unionid = "testUser" + i;
            o.userCode = "testUser" + i;
            o.publicIp = "127.0.0.1";
            o.paiList = paiList[i];
            o.gameReadyStatu = "1";
            o.gameScoreCount = "1";
            o.pointIndex = i + 1;
            o.headImageFileName = "1";

            if (i == 0) {
                o.zhuang = "1";
            } else {
                o.zhuang = "0";
                if (i == 2) {
                    o.userMoPai = "22";
                }
            }

            userList.push(o);
        }
        var gameMode = require("gameMode").gameMode;
        var userInfo = require("userInfoDomain").userInfoDomain;
        userInfo.openid = "testUser2";
        gameMode.huanSanZhang = "1";
        Global.gameMode = gameMode;
        Global.userList = userList;
        Global.userInfo = userInfo;
        Global.chuPaiActionType = "normalChuPai";
    },
    //type:inital
    initalUserPai: function initalUserPai(initalType) {
        //inital the test data
        // this.testInitalUserList();
        // cc.log("Global.chuPaiActionType initalUserPai:"+Global.chuPaiActionType);
        //hide game mode
        this.tableGameMode.active = false;
        this.tableHead.active = true;

        //hide user ready icon
        this.user1ReadNode.active = false;
        this.user2ReadNode.active = false;
        this.user3ReadNode.active = false;
        this.user4ReadNode.active = false;
        //hide title
        this.tableTitleNode.active = false;
        //fix user point
        var userList = Global.userList;
        for (var i = 0; i < userList.length; i++) {
            var user = userList[i];
            //show current user node
            if (user.pointIndex != null && user.pointIndex != undefined) {
                cc.log(user.pointIndex);
                //fix user point
                if (user.pointIndex != "3") {
                    eval("this.userInfo" + user.pointIndex + ".active = true");
                    this.fixUserPointByIndex(user.pointIndex);
                } else {
                    eval("this.userInfo" + user.pointIndex + ".active = false");
                }

                var paiList = user.paiList;
                if (paiList != null && paiList != undefined) {
                    if (user.pointIndex + "" == "3") {
                        //inital self pai
                        Global.chuPaiActionType = "huanSanZhang";
                        Global.huanSanZhangPaiList = [];
                        user.paiListArray = this.intalSelfPaiList(paiList);
                        user.chupaiListX = -210;
                        user.chupaiListY = -45;
                        user.chuPaiCount = 0;
                    } else {
                        user.paiListArray = this.initalOtherPaiList(paiList, user.pointIndex, initalType);
                        user = this.initalOtherUserChuPaiPoint(user, user.pointIndex + "");
                        //intal other user pai
                    }
                }
            }
        }

        //put back the user list to gobal

        Global.userList = userList;
        //show huanPaiScript
        huanPaiScript.showHuanPaiNode();
    },

    //inital other user chupai start point
    initalOtherUserChuPaiPoint: function initalOtherUserChuPaiPoint(user, point) {

        if (point == "1") {
            user.chupaiListX = 210;
            user.chupaiListY = -45;
        } else if (point == "2") {
            user.chupaiListX = 170;
            user.chupaiListY = 120;
        } else if (point == "4") {
            user.chupaiListX = -170;
            user.chupaiListY = -120;
        }
        user.chuPaiCount = 0;
        return user;
    },
    /**
     * 
     */
    getMinLenPaiListFromPai: function getMinLenPaiListFromPai(paiList) {
        var v1 = [];
        var v2 = [];
        var v3 = [];

        for (var i = 0; i < paiList.length; ++i) {
            var pai = paiList[i];
            var sType = pai + "";
            var sType = sType.substring(0, 1);
            if (sType == "1") {
                v1.push(sType);
            }
            if (sType == "2") {
                v2.push(sType);
            }
            if (sType == "3") {
                v3.push(sType);
            }
        }

        var resultArray = [v1.length, v2.length, v3.length];
        var resultArray2 = [v1, v2, v3];
        resultArray.sort();
        var l = 0;
        for (var i = 0; i < 3; i++) {
            if (resultArray[i] >= 3) {
                l = resultArray[i];
                break;
            }
        }
        var returnArray;
        for (var i = 0; i < 3; i++) {
            if (resultArray2[i].length == l) {
                returnArray = resultArray2[i];
                break;
            }
        }

        for (var i = 0; i < 3; i++) {
            var paiName = "pai" + i + "_" + returnArray[i].trim();
            var paiNode = cc.find(paiName, this.user3PaiListNode);
            paiNode.y = 20;
            Global.huanSanZhangPaiList.push(returnArray[i]);
        }

        return returnArray;
    },

    getLess3NumberType: function getLess3NumberType(parentNode) {
        var v1 = 0;
        var v2 = 0;
        var v3 = 0;
        var children = parentNode.children;
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            var temp = childredName.split("_");
            var sType = temp[1];
            var sType = sType.substring(0, 1);
            if (sType == "1") {
                v1++;
            }
            if (sType == "2") {
                v2++;
            }
            if (sType == "3") {
                v3++;
            }
        }

        var v = [];
        if (v1 < 3) {
            v.push("1");
        }
        if (v2 < 3) {
            v.push("2");
        }
        if (v3 < 3) {
            v.push("3");
        }
        return v;
    },
    disableAllPai: function disableAllPai() {
        var children = this.user3PaiListNode.children;
        for (var i = 0; i < children.length; ++i) {
            var btn = children[i].getComponent(cc.Button);
            btn.interactable = false;
        }
    },
    disabledQuePai: function disabledQuePai() {
        var userList = Global.userList;
        var userInfo = Global.userInfo;
        var quePai = "";
        var paiList;
        var existFlag = false;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == userInfo.openid) {
                quePai = userList[i].quePai;
                paiList = userList[i].paiListArray;
            }
        }

        if (paiList != null) {
            if (quePai != null && quePai.length > 0) {
                for (var i = 0; i < paiList.length; ++i) {
                    var sType = paiList[i].trim() + "";
                    sType = sType.substring(0, 1);
                    if (sType == quePai) {
                        existFlag = true;
                    }
                }
            }
        }

        if (existFlag) {
            var children = this.user3PaiListNode.children;
            for (var i = 0; i < children.length; ++i) {
                var childredName = children[i].name;
                var temp = childredName.split("_");
                var sType = temp[1];
                sType = sType.substring(0, 1);
                if (sType != quePai) {
                    var btn = children[i].getComponent(cc.Button);
                    btn.interactable = false;
                }
            }
        }
    },

    getSlefUser: function getSlefUser() {
        var gobalUser = Global.userInfo;
        var userList = Global.userList;
        var user;
        for (var i = 0; i < userList.length; i++) {
            if (userList[i].openid == gobalUser.openid) {
                user = userList[i];
            }
        }

        return user;
    },
    //Force select san zhang pai after the timer end

    forceFillHuanSanZhangList: function forceFillHuanSanZhangList() {
        var paiList = this.getSlefUser().paiListArray;
        this.getMinLenPaiListFromPai(paiList);
    },

    //when huan san zhang work, this will disabled less 3 number pai
    disabledHuanSanZhangPai: function disabledHuanSanZhangPai() {

        var children = this.user3PaiListNode.children;
        var v = this.getLess3NumberType(this.user3PaiListNode);
        var vstr = v.toString();
        for (var i = 0; i < children.length; ++i) {
            var childredName = children[i].name;
            var temp = childredName.split("_");
            var sType = temp[1];
            sType = sType.substring(0, 1);
            if (vstr.indexOf(sType) >= 0) {
                var btn = children[i].getComponent(cc.Button);
                btn.interactable = false;
            }
        }
    },

    initalOtherPaiList: function initalOtherPaiList(paiList, point, iniType) {
        var paiArray = paiList.split(",");
        var startX = 0;
        var startY = 0;
        cc.log("********initalOtherPaiList:" + paiList + "----" + point);
        for (var i = 0; i < paiArray.length; i++) {
            if (paiArray[i] != null && paiArray[i] != undefined) {
                if (paiArray[i] != "") {
                    var paiNode;
                    var sprite;
                    paiNode = cc.instantiate(this.backNode);
                    paiNode.name = "pai" + i + "_" + paiArray[i].trim();
                    sprite = paiNode.getComponent(cc.Sprite);
                    if (point == "1") {

                        sprite.spriteFrame = this.backPai;
                        //this.user1PaiListNode.addChild(paiNode);
                    } else {

                            if (point == "2") {
                                sprite.spriteFrame = this.cePaiLeft;
                                //this.user2PaiListNode.addChild(paiNode);
                            } else {
                                    sprite.spriteFrame = this.cePai;
                                    // this.user4PaiListNode.addChild(paiNode);
                                }
                        }

                    eval("this.user" + point + "PaiListNode.addChild(paiNode)");
                    //fix the user 1
                    if (point == "1") {
                        startX = 380;
                        paiNode.rotation = 180;
                        paiNode.position = cc.p(startX - i * 55, 0);
                        //this.user1PaiListNode.addChild(paiNode);
                    }

                    if (point == "2") {
                        startX = 0;
                        if (iniType == "inital") {
                            startY = -210;
                        } else {
                            startY = -80;
                        }

                        paiNode.position = cc.p(startX, startY + i * 28);
                        if (i == 0) {
                            cc.log("337 startY:" + startY);
                        }
                        paiNode.zIndex = paiArray.length - i;
                        paiNode.width = 40;
                        paiNode.height = 85;
                        //parentNode
                    }

                    if (point == "4") {
                        startX = 0;
                        startY = -210;
                        paiNode.position = cc.p(startX, startY + i * 28);
                        paiNode.zIndex = paiArray.length - i;
                        paiNode.width = 40;
                        paiNode.height = 85;
                    }
                }
            }
        }

        return paiArray;
    },
    intalSelfPaiList: function intalSelfPaiList(paiList) {

        var startPoint = -520;
        var paiArray = paiList.split(",");
        for (var i = 0; i < paiArray.length; i++) {
            if (paiArray[i] != null && paiArray[i] != undefined) {
                var paiNode = cc.instantiate(this.liPaiPrefab);
                var btn = paiNode.getComponent(cc.Button);

                var sprite = paiNode.getComponent(cc.Sprite);
                paiNode.name = "pai" + i + "_" + paiArray[i].trim();
                //var imageUrl = "/img/9t";
                //var imageUrl = this.getCorrectNameOnSelfPai(paiArray[i]);
                //cc.log("img3:" + imageUrl);
                /*
                cc.loader.load(imageUrl, function (err, texture) {
                    if (err) {
                        cc.error(err.message || err);
                        return;
                    }
                    var frame = new cc.SpriteFrame(texture);
                    sprite.spriteFrame = frame;
                });*/
                var index = this.getCurrectIndeOnSeflPai(paiArray[i]);
                sprite.spriteFrame = this.liPaiZiMian[index];
                this.user3PaiListNode.addChild(paiNode);
                if (i == 13) {
                    paiNode.position = cc.p(startPoint + i * 80, 0);
                } else {
                    paiNode.position = cc.p(startPoint + i * 79, 0);
                }
            }
        }

        return paiArray;
    },

    getCurrectIndeOnSeflPai: function getCurrectIndeOnSeflPai(pai) {
        pai = (pai + "").trim();
        var type = (pai + "").substring(0, 1);
        var paiNum = (pai + "").substring(1);
        //tong 11-19
        //tiao 21-29
        //wan  31-39
        var index = -1;

        if (type == "1") {
            index = parseInt(paiNum) - 1;
        }

        if (type == "2") {
            index = parseInt(paiNum) + 8;
        }

        if (type == "3") {
            index = parseInt(paiNum) + 17;
        }

        return index;
    },

    getCorrectNameOnSelfPai: function getCorrectNameOnSelfPai(pai) {
        pai = (pai + "").trim();
        cc.log("img1:" + pai + "--" + pai.length);
        var type = (pai + "").substring(0, 1);
        var paiNum = (pai + "").substring(1);
        var prefix = "";
        var path = "";

        if (type == "1") {
            path = "image/table/pai/lipai/tong/";
            prefix = "b";
        }
        if (type == "2") {
            path = "image/table/pai/lipai/tiao/";
            prefix = "t";
        }
        if (type == "3") {
            path = "image/table/pai/lipai/wan/";
            prefix = "w";
        }

        var img = path + paiNum + prefix;
        cc.log("img2:" + img);
        return img;
    },

    fixUserPointByIndex: function fixUserPointByIndex(index) {
        if (index == "1") {
            var widget = this.userInfo1.getComponent(cc.Widget);
            widget.top = -20;
            // widget.isAlignRight = true;
            // widget.right = 210;
            //this.userInfo1.y=-20;
            cc.log("fixUserPointByIndex 1:" + this.userInfo1.y);
            //this.userInfo1.y =410;
            this.userInfo1.x = 457;
        }
        if (index == "2") {
            //var widget = this.userInfo2.getComponent(cc.Widget);
            //widget.left = 60;
            this.userInfo2.x = -607;
        }

        if (index == "4") {
            //var widget = this.userInfo4.getComponent(cc.Widget);
            //widget.right = 60;
            this.userInfo4.x = 607;
        }
    },
    intalUserInfoReadyIcon: function intalUserInfoReadyIcon() {

        var userList = Global.userList;
        for (var i = 0; i < userList.length; i++) {
            var user = userList[i];
            var userNodeName = "user" + user.pointIndex + "Node";
            cc.log("userNodeName:" + userNodeName);
            var userNode = cc.find(userNodeName, this.tableNode);
            var userInfoNode = cc.find("userInfoNode", userNode);
            //var userNickNameNode = cc.find("userNickNameBg", userInfoNode);
            var userReadyiconNode = cc.find("userReadyNode", userInfoNode);
            var userReadyBtnNode = cc.find("readyButton", userReadyiconNode);
            var s = userReadyBtnNode.getComponent(cc.Sprite);
            cc.log("user.gameReadyStatu:" + user.gameReadyStatu);
            if (user.gameReadyStatu == "1") {
                s.spriteFrame = this.userReadyIconOk;
            } else {
                s.spriteFrame = this.userReadyIconNotOk;
            }
        }
    },

    initalUserInfoFromGobalList: function initalUserInfoFromGobalList() {
        //hide  table  pai starting
        this.quepaiNode.active = false;
        this.tableCenterPoint.active = false;

        var numberOrder = [3, 4, 1, 2];
        var userList = Global.userList;
        var userInfo = Global.userInfo;
        var gameMode = Global.gameMode;
        var gamePeople = gameMode.gamePeopleNumber;
        var index = -1;
        if (userList != null && userList != undefined) {
            var tempList = [];
            //1.find the start index
            for (var i = 0; i < userList.length; i++) {
                var tableUserInfo = userList[i];
                if (index < 0) {
                    if (userInfo.openid == tableUserInfo.openid) {
                        tempList.push(tableUserInfo);
                        index = i;
                    }
                } else {
                    tempList.push(tableUserInfo);
                }
            }
            cc.log("index:" + index);
            if (index == 0) {
                if (gamePeople == "3") {
                    numberOrder = [3, 4, 2];
                }

                if (gamePeople == "2") {
                    numberOrder = [3, 1];
                }
            }
            if (index == 1) {
                if (gamePeople == "4") {
                    numberOrder = [2, 3, 4, 1];
                }
                if (gamePeople == "3") {
                    numberOrder = [2, 3, 4];
                }
                if (gamePeople == "2") {
                    numberOrder = [1, 3];
                }
            }
            if (index == 2) {
                if (gamePeople == "4") {
                    numberOrder = [1, 2, 3, 4];
                }
                if (gamePeople == "3") {
                    numberOrder = [4, 2, 3];
                }
            }
            if (index == 3) {
                if (gamePeople == "4") {
                    numberOrder = [4, 1, 2, 3];
                }
                if (gamePeople == "3") {
                    numberOrder = [4, 2, 3];
                }
            }

            // if (index > 0) {
            //     for (var i = 0; i < index; i++) {
            //         tempList.push(userList[i]);
            //     }
            // }

            //start fill the user info from index
            cc.log("numberOrder:" + numberOrder.toString());
            for (var i = 0; i < userList.length; i++) {
                var user = userList[i];
                user.pointIndex = numberOrder[i];
                userList[i] = user;
                var userNodeName = "user" + numberOrder[i] + "Node";
                //var testHeaImageurl = "http://wx.qlogo.cn/mmopen/Po9mkm3Z42tolYpxUVpY6mvCmqalibOpcJ2jG3Qza5qgtibO1NLFNUF7icwCibxPicbGmkoiciaqKEIdvvveIBfEQqal8vkiavHIeqFT/0";
                var serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;
                cc.log("headImageFileName:" + user.headImageFileName);
                var testHeaImageurl = serverUrl + "/webchatImage/" + userInfo.headImageFileName;
                cc.log("testHeaImageurl:" + testHeaImageurl);
                var userNode = cc.find(userNodeName, this.tableNode);
                var userInfoNode = cc.find("userInfoNode", userNode);
                var userNickNameNode = cc.find("userNickNameBg", userInfoNode);
                var userNickNameLableNode = cc.find("userNickName", userNickNameNode);
                cc.loader.load(testHeaImageurl, function (err, texture) {
                    var frame = new cc.SpriteFrame(texture);
                    userInfoNode.getComponent(cc.Sprite).spriteFrame = frame;
                });

                var userNickNameLable = userNickNameLableNode.getComponent(cc.Label);
                userNickNameLable.string = user.nickName;
                userNode.active = true;
            }
            Global.userList = userList;
            this.intalUserInfoReadyIcon();
        }
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{"gameMode":"gameMode","userInfoDomain":"userInfoDomain"}],"userInfoDomain":[function(require,module,exports){
"use strict";
cc._RFpush(module, '038b1LD8sdAoKFXcy5K0flN', 'userInfoDomain');
// script/domainClass/userInfoDomain.js

var userInfoDomain = { id: 25,
  agentLevel: 0,
  city: "",
  country: "",
  diamondsNumber: 0,
  gameCount: 0,
  headimgurl: "",
  nickName: "",
  openid: "",
  province: "",
  sex: 1,
  unionid: "",
  userCode: "",
  userType: "",
  winCount: 0,
  //userGameingStatu:"",
  publicIPAddress: "",
  roomNumber: "",
  paiList: "",
  gameReadyStatu: "",
  gameRoundScore: "",
  gameScoreCount: "",
  headImageFileName: ""
};
//gameingStatu:"",
module.exports = {
  userInfoDomain: userInfoDomain
};

cc._RFpop();
},{}],"webSokectMessage":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6e1ebTV0H1GkZpfFnVA900C', 'webSokectMessage');
// script/service/webSokectMessage.js

//var stomp=require('stomp');
var client;
var privateClient;
var userInfo;
var serverUrl;
var socket;
//Websokect only work on the sence ,when the switch sence ,the websokect will be lost,we should keep the websokect on one sence
cc.Class({
    "extends": cc.Component,
    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...http://cn.bing.com/
        testLabel: cc.Label,
        scriptNode: cc.Node,
        mainMenu: cc.Node,
        index: cc.Node,
        gameActionList: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {
        var self = this;
        self.gameStop();
        //cc.game.addPersistRootNode(self.scriptNode);

        serverUrl = Global.hostHttpProtocol + "://" + Global.hostServerIp + ":" + Global.hostServerPort;
        if (Global.userInfo == null || Global.userInfo == undefined) {
            var userInfo = require("userInfoDomain").userInfoDomain;
            //window.io = SocketIO.connect;
            //var p2psocket =  window.io.connect("");
            //var p2p = new P2P(p2psocket);
            // console.log("io instals");
            //var shaObj = new jsSHA("SHA-1", "TEXT");
            //shaObj.update("This is a test");
            // var hash = shaObj.getHash("HEX");
            // console.log("hash sha1:"+hash);
            //if (cc.sys.isNative) {
            socket = new SockJS(serverUrl + "/stomp");
            //} else {
            //  socket = new SockWebJS(serverUrl + "/stomp");
            //}
            //io.connect
            //var socket=window.io('http://localhost:8080/stomp');
            //var allowedOrigins = "http://localhost:* http://127.0.0.1:*";
            //var path = '/stomp';
            // var socket = window.io.connect('http://localhost:8080/stomp');
            console.log("conect to server");
            client = Stomp.over(socket);
            //open a chanle to list login message from server
            client.connect({}, function () {
                client.subscribe("/queue/pusmicGamePushLoginUserInfoChanle", function (message) {
                    var bodyStr = message.body;
                    var obj = JSON.parse(bodyStr);
                    if (obj != undefined && obj != null) {
                        for (var p in obj) {
                            userInfo[p] = obj[p];
                        }
                        console.log("userInfo.nickname:" + userInfo.nickName);
                        Global.userInfo = userInfo;
                        //update the user public ip from url call
                        self.updateUserIP(userInfo.id);
                        //
                        //self.initalPrivateChanleForUser(userInfo.roomNumber);

                        //user login success ,go to game main sence
                        //cc.director.loadScene('table');
                        this.index.active = false;
                        this.mainMenu.active = true;
                    } else {

                        console.log("No found correct user info return from server ,please check .");
                    }

                    //self.testLabel.string = message.body;
                    //$("#helloDiv").append(message.body);

                    //cc.director.loadScene('gameMain2');
                }, function () {
                    cc.log("websocket connect subscribe Error:233");
                    //client.disconnect();
                });
            }, function () {
                cc.log("websocket connect  Error:234");
                //client.disconnect();
            });

            //----------------
        } else {
                //Gobal userInfo already get the value ,drictly to to gameMain2
                cc.director.loadScene('table');
            }
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    sendWebSokectMessageToServer: function sendWebSokectMessageToServer() {
        var o = new Object();
        o.token = "test word";
        client.send("/app/resiveAllUserChanle", {}, JSON.stringify(o));
    },
    //send webchat opnunid to server to login user
    loginUserToServerByToken: function loginUserToServerByToken() {
        var o = new Object();
        o.token = "test word";
        client.send("/app/pusmicGameLoginUserChanle", {}, JSON.stringify(o));
    },
    //open user ip login url
    updateUserIP: function updateUserIP(id) {
        var xhr = new XMLHttpRequest();
        var url = serverUrl + "/user/getLoginUserIP?userId=" + id;
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
                var response = xhr.responseText;
                console.log(response);
                Global.userInfo.publicIPAddress = response;
                cc.director.loadScene('table');
            }
        };
        xhr.open("GET", url, true);
        xhr.send();
    },

    //-----------------------------------------------------------------------------
    onDestroy: function onDestroy() {
        //colse the websokect
        client.disconnect();
    },
    //----------------------inital private chanle----------------------------------
    // initalPrivateChanleForUser: function (roomNumber) {
    //     cc.log("roomNumber:"+roomNumber);
    //     privateClient = Stomp.over(socket);

    //         privateClient.connect({}, function () {
    //             privateClient.subscribe("/queue/privateRoomChanle" + roomNumber, function (message) {
    //                 var bodyStr = message.body;
    //                 cc.log("get meesge from private chanle:privateRoomChanle"+roomNumber);
    //             });
    //         },function(){
    //              cc.log("connect private chanle error !");
    //         });

    // privateClientChanle
    // },
    //----------------------game stop-----------------------------------------------
    gameStop: function gameStop() {
        cc.game.onStop = function () {
            cc.log("stopApp");
        };
    },
    //-----------------------websokect error callback--------------------------------
    error_callback: function error_callback(error) {
        // display the error's message header:
        cc.log("Self Error:" + error);
    }

});

cc._RFpop();
},{"userInfoDomain":"userInfoDomain"}]},{},["userInfoDomain","gameConfig","messageDomain","quepaiScript","normalTimerScript","gameConfigButtonListAction","publicMessageController","PersistRootNode","SwitchScene","paiAction","GameTableController","showGameMode","tableActionController","ButtonScaler","loginScript","gameStep","huanPaiUI","GameTableRoom","webSokectMessage","GameTableNetWork","HuPaiAction","GameModeOptionController","tableMoPaiAction","gameConfigSetting","Global","caCheScript","alertMessagePanle","gameMode","JoinRoomController","actionMesageDomain","gameConfigController","DataTime","onlineUserCheck","AudioMng","tableUserInfo","tablePaiAction","tableCenterPoint","InitalGameMain","tableNetWork","GameModeActionScript","gameUser","iniGameTable","iniIndex","PlayBgm"])

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL0FwcGxpY2F0aW9ucy9Db2Nvc0NyZWF0b3IuYXBwL0NvbnRlbnRzL1Jlc291cmNlcy9hcHAuYXNhci9ub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIiwiYXNzZXRzL3NjcmlwdC9hdWRpby9BdWRpb01uZy5qcyIsImFzc2V0cy9zY3JpcHQvdWkvQnV0dG9uU2NhbGVyLmpzIiwiYXNzZXRzL3NjcmlwdC91aS9EYXRhVGltZS5qcyIsImFzc2V0cy9zY3JpcHQvY29udHJvbGxlcnMvR2FtZU1vZGVBY3Rpb25TY3JpcHQuanMiLCJhc3NldHMvc2NyaXB0L2NvbnRyb2xsZXJzL0dhbWVNb2RlT3B0aW9uQ29udHJvbGxlci5qcyIsImFzc2V0cy9zY3JpcHQvY29udHJvbGxlcnMvR2FtZVRhYmxlQ29udHJvbGxlci5qcyIsImFzc2V0cy9zY3JpcHQvc2VydmljZS9HYW1lVGFibGVOZXRXb3JrLmpzIiwiYXNzZXRzL3NjcmlwdC9zZXJ2aWNlL0dhbWVUYWJsZVJvb20uanMiLCJhc3NldHMvc2NyaXB0L2RvbWFpbkNsYXNzL0dsb2JhbC5qcyIsImFzc2V0cy9zY3JpcHQvdWkvSHVQYWlBY3Rpb24uanMiLCJhc3NldHMvc2NyaXB0L2NvbnRyb2xsZXJzL0luaXRhbEdhbWVNYWluLmpzIiwiYXNzZXRzL3NjcmlwdC9jb250cm9sbGVycy9Kb2luUm9vbUNvbnRyb2xsZXIuanMiLCJhc3NldHMvc2NyaXB0L3NlcnZpY2UvUGVyc2lzdFJvb3ROb2RlLmpzIiwiYXNzZXRzL3NjcmlwdC9hdWRpby9QbGF5QmdtLmpzIiwiYXNzZXRzL3NjcmlwdC9jb250cm9sbGVycy9Td2l0Y2hTY2VuZS5qcyIsImFzc2V0cy9zY3JpcHQvZG9tYWluQ2xhc3MvYWN0aW9uTWVzYWdlRG9tYWluLmpzIiwiYXNzZXRzL3NjcmlwdC91aS9hbGVydE1lc3NhZ2VQYW5sZS5qcyIsImFzc2V0cy9zY3JpcHQvbGliL2NhQ2hlU2NyaXB0LmpzIiwiYXNzZXRzL3NjcmlwdC9jb250cm9sbGVycy9nYW1lQ29uZmlnQnV0dG9uTGlzdEFjdGlvbi5qcyIsImFzc2V0cy9zY3JpcHQvY29udHJvbGxlcnMvZ2FtZUNvbmZpZ0NvbnRyb2xsZXIuanMiLCJhc3NldHMvc2NyaXB0L2RvbWFpbkNsYXNzL2dhbWVDb25maWdTZXR0aW5nLmpzIiwiYXNzZXRzL3NjcmlwdC91aS9nYW1lQ29uZmlnLmpzIiwiYXNzZXRzL3NjcmlwdC9kb21haW5DbGFzcy9nYW1lTW9kZS5qcyIsImFzc2V0cy9zY3JpcHQvZG9tYWluQ2xhc3MvZ2FtZVN0ZXAuanMiLCJhc3NldHMvc2NyaXB0L2RvbWFpbkNsYXNzL2dhbWVVc2VyLmpzIiwiYXNzZXRzL3NjcmlwdC91aS9odWFuUGFpVUkuanMiLCJhc3NldHMvc2NyaXB0L3NlcnZpY2UvaW5pR2FtZVRhYmxlLmpzIiwiYXNzZXRzL3NjcmlwdC9zZXJ2aWNlL2luaUluZGV4LmpzIiwiYXNzZXRzL3NjcmlwdC9jb250cm9sbGVycy9sb2dpblNjcmlwdC5qcyIsImFzc2V0cy9zY3JpcHQvZG9tYWluQ2xhc3MvbWVzc2FnZURvbWFpbi5qcyIsImFzc2V0cy9zY3JpcHQvdWkvbm9ybWFsVGltZXJTY3JpcHQuanMiLCJhc3NldHMvc2NyaXB0L3NlcnZpY2Uvb25saW5lVXNlckNoZWNrLmpzIiwiYXNzZXRzL3NjcmlwdC91aS9wYWlBY3Rpb24uanMiLCJhc3NldHMvc2NyaXB0L2NvbnRyb2xsZXJzL3B1YmxpY01lc3NhZ2VDb250cm9sbGVyLmpzIiwiYXNzZXRzL3NjcmlwdC91aS9xdWVwYWlTY3JpcHQuanMiLCJhc3NldHMvc2NyaXB0L3VpL3Nob3dHYW1lTW9kZS5qcyIsImFzc2V0cy9zY3JpcHQvY29udHJvbGxlcnMvdGFibGVBY3Rpb25Db250cm9sbGVyLmpzIiwiYXNzZXRzL3NjcmlwdC91aS90YWJsZUNlbnRlclBvaW50LmpzIiwiYXNzZXRzL3NjcmlwdC91aS90YWJsZU1vUGFpQWN0aW9uLmpzIiwiYXNzZXRzL3NjcmlwdC9kb21haW5DbGFzcy90YWJsZU5ldFdvcmsuanMiLCJhc3NldHMvc2NyaXB0L3VpL3RhYmxlUGFpQWN0aW9uLmpzIiwiYXNzZXRzL3NjcmlwdC9jb250cm9sbGVycy90YWJsZVVzZXJJbmZvLmpzIiwiYXNzZXRzL3NjcmlwdC9kb21haW5DbGFzcy91c2VySW5mb0RvbWFpbi5qcyIsImFzc2V0cy9zY3JpcHQvc2VydmljZS93ZWJTb2tlY3RNZXNzYWdlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7OztBQ0FBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSTtBQUNJO0FBQ0E7QUFDWjtBQUNRO0FBQ0k7QUFDQTtBQUNaO0FBQ0E7QUFDUTtBQUNJO0FBQ0E7QUFDWjtBQUNBO0FBQ1E7QUFDSTtBQUNBO0FBQ1o7QUFDQTtBQUNRO0FBQ0k7QUFDQTtBQUNaO0FBQ0E7QUFDUTtBQUNJO0FBQ0E7QUFDWjtBQUNBO0FBQ1E7QUFDSTtBQUNBO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ1E7QUFDUjtBQUNRO0FBQ0k7QUFDWjtBQUNBO0FBR1E7QUFDSTtBQURaO0FBR1E7QUFEUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdJO0FBQ0s7QUFDRDtBQUNJO0FBRFo7QUFDQTtBQUlJO0FBQ0k7QUFGUjtBQUNBO0FBSUk7QUFDSTtBQUZSO0FBQ0E7QUFJSTtBQUNJO0FBRlI7QUFDQTtBQUlJO0FBQ0k7QUFGUjtBQUNBO0FBSUk7QUFDSTtBQUZSO0FBQ0E7QUFJSTtBQUNJO0FBRlI7QUFDQTtBQUlJO0FBQ0k7QUFGUjtBQUNBO0FBSUk7QUFDSTtBQUZSO0FBQ0E7QUFJSTtBQUNJO0FBRlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzR0E7QUFDSTtBQUNKO0FBQ0k7QUFDSTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNaO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNaO0FBQ1E7QUFDSTtBQUNBO0FBQ1o7QUFDUTtBQUNBO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3RDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ1o7QUFDWTtBQUNJO0FBQ2hCO0FBQ1k7QUFDSTtBQUNoQjtBQUNZO0FBQ1o7QUFDWTtBQUNBO0FBQ1o7QUFDQTtBQUNRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcERBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDWjtBQUVRO0FBQ0E7QUFBUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlJO0FBQ0k7QUFDQTtBQUZSO0FBSUk7QUFDSTtBQUNBO0FBRlI7QUFJSTtBQUNJO0FBQ0E7QUFGUjtBQUlJO0FBQ0k7QUFDQTtBQUZSO0FBQ0E7QUFDQTtBQUNBO0FBS0k7QUFDSTtBQUhSO0FBS1k7QUFDSTtBQUNBO0FBQ0k7QUFIcEI7QUFLZ0I7QUFDSTtBQUhwQjtBQUtnQjtBQUNJO0FBSHBCO0FBS2dCO0FBQ0k7QUFIcEI7QUFLZ0I7QUFDSTtBQUNJO0FBSHhCO0FBS29CO0FBQ0k7QUFIeEI7QUFLb0I7QUFDSTtBQUh4QjtBQUtvQjtBQUNJO0FBSHhCO0FBS29CO0FBQ0k7QUFIeEI7QUFDQTtBQUNBO0FBS2dCO0FBQ0k7QUFIcEI7QUFLZ0I7QUFDSTtBQUhwQjtBQUNBO0FBS2dCO0FBSGhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFLUTtBQUhSO0FBTUk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBSmhCO0FBT1k7QUFDSTtBQUxoQjtBQVFZO0FBQ0k7QUFOaEI7QUFTWTtBQUNJO0FBUGhCO0FBU1k7QUFDSTtBQVBoQjtBQVNZO0FBQ0k7QUFQaEI7QUFVWTtBQUNJO0FBUmhCO0FBV1k7QUFDSTtBQVRoQjtBQVlZO0FBQ0k7QUFWaEI7QUFhWTtBQUNJO0FBWGhCO0FBY1k7QUFDSTtBQVpoQjtBQWVZO0FBQ0k7QUFiaEI7QUFnQlk7QUFDSTtBQWRoQjtBQWlCWTtBQUNJO0FBZmhCO0FBa0JZO0FBaEJaO0FBQ0E7QUFDQTtBQXVCSTtBQUNJO0FBQ0k7QUFyQlo7QUF1Qlk7QUFyQlo7QUFDQTtBQXVCUTtBQUNJO0FBckJaO0FBdUJZO0FBckJaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBdUJRO0FBQ0k7QUFyQlo7QUF1Qlk7QUFyQlo7QUF1QlE7QUFDSTtBQXJCWjtBQXVCWTtBQXJCWjtBQXVCUTtBQUNJO0FBckJaO0FBdUJZO0FBckJaO0FBdUJRO0FBQ0k7QUFyQlo7QUF1Qlk7QUFyQlo7QUF1QlE7QUFDSTtBQXJCWjtBQXVCWTtBQXJCWjtBQXVCUTtBQUNJO0FBckJaO0FBdUJZO0FBckJaO0FBdUJRO0FBQ0E7QUFDSTtBQXJCWjtBQXVCWTtBQXJCWjtBQXVCUTtBQUNJO0FBckJaO0FBdUJZO0FBckJaO0FBdUJRO0FBQ0k7QUFyQlo7QUF1Qlk7QUFyQlo7QUF1QlE7QUFDSTtBQXJCWjtBQXVCWTtBQXJCWjtBQUNBO0FBQ0E7QUF3Qkk7QUF0Qko7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNLO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNUO0FBQ1M7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFPSztBQUxMO0FBQ0E7QUFPUTtBQUNBO0FBQ0E7QUFDRTtBQUNLO0FBQ0Q7QUFDQTtBQUNDO0FBTGY7QUFDQTtBQU9VO0FBQ0k7QUFDQTtBQUNBO0FBTGQ7QUFPYztBQUxkO0FBQ0E7QUFPVTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMVjtBQUNBO0FBT0k7QUFDSTtBQUxSO0FBT1E7QUFDQTtBQUxSO0FBQ0E7QUFPUTtBQUNBO0FBTFI7QUFTUTtBQUNBO0FBUFI7QUFTUTtBQUNBO0FBQ0Q7QUFDQztBQVBSO0FBU0k7QUFFQTtBQUVBO0FBRUE7QUFFQTtBQUVBO0FBRUE7QUFFQTtBQUVBO0FBRUE7QUFFQTtBQUVBO0FBRUE7QUFuQko7QUFDQTtBQXNCSTtBQUNFO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXBCZDtBQXNCYTtBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBcEJkO0FBQ0E7QUF1Qkk7QUFDTTtBQUNBO0FBckJWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF3Qkk7QUFHQTtBQUdBO0FBR0E7QUFHQTtBQTlCSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9KQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDWjtBQUNZO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUN4QjtBQUNBO0FBQ29CO0FBQ3BCO0FBQ0E7QUFDQTtBQUVZO0FBQ0k7QUFDSTtBQUFwQjtBQUNBO0FBQ0E7QUFDQTtBQUVZO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFBcEI7QUFFb0I7QUFBcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3RHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDUjtBQUNRO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUjtBQUNZO0FBQ1o7QUFDQTtBQUNRO0FBQ0E7QUFDUjtBQUNJO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNaO0FBQ0E7QUFDSTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDcEI7QUFDZ0I7QUFDaEI7QUFDZ0I7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2dCO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNwQztBQUNBO0FBQ0E7QUFDd0I7QUFDQTtBQUNBO0FBQ3hCO0FBQ3dCO0FBQ0E7QUFDeEI7QUFDQTtBQUNBO0FBRWdCO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFBNUI7QUFFd0I7QUFBeEI7QUFFd0I7QUFDQTtBQUF4QjtBQUV3QjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQTVCO0FBQ0E7QUFFd0I7QUFDQTtBQUF4QjtBQUV3QjtBQUNJO0FBQTVCO0FBRTRCO0FBQTVCO0FBQ0E7QUFHd0I7QUFDQTtBQUR4QjtBQUNBO0FBQ0E7QUFHZ0I7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFEaEM7QUFHZ0M7QUFDQTtBQUNBO0FBRGhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFLb0I7QUFIcEI7QUFDQTtBQUtvQjtBQUhwQjtBQUNBO0FBQ0E7QUFLZ0I7QUFIaEI7QUFNZ0I7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUo1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVVnQjtBQVJoQjtBQUNBO0FBV1k7QUFUWjtBQUNBO0FBQ0E7QUFXSTtBQUNJO0FBQ0k7QUFUWjtBQVdZO0FBVFo7QUFDQTtBQUNBO0FBWUk7QUFDSTtBQUNJO0FBQ0E7QUFWWjtBQUNBO0FBQ0E7QUFjSTtBQUNJO0FBQ0E7QUFaUjtBQUNBO0FBY1E7QUFDQTtBQUNBO0FBQ0E7QUFaUjtBQWNRO0FBQ0E7QUFaUjtBQUNBO0FBY0k7QUFDSTtBQUNBO0FBWlI7QUFDQTtBQUNBO0FBY1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFaUjtBQWNJO0FBWko7QUFnQkk7QUFkSjtBQWdCUTtBQUNBO0FBQ0E7QUFDSTtBQWRaO0FBZ0JRO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQWRaO0FBZ0JZO0FBQ0k7QUFDQTtBQWRoQjtBQWdCZ0I7QUFDQTtBQWRoQjtBQWdCWTtBQUNBO0FBQ0E7QUFkWjtBQWdCWTtBQUNBO0FBZFo7QUFnQlE7QUFkUjtBQWdCUTtBQWRSO0FBaUJJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQWZaO0FBQ0E7QUFrQkk7QUFDSTtBQUNBO0FBaEJSO0FBQ0E7QUFDQTtBQWtCSTtBQWhCSjtBQWtCUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFoQlI7QUFDQTtBQUNBO0FBQ0E7QUFtQkk7QUFDSTtBQUNBO0FBQ0k7QUFqQlo7QUFtQlE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBakJSO0FBQ0E7QUFvQkk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQWxCWjtBQW9CWTtBQWxCWjtBQW9CUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbEJSO0FBQ0E7QUFDQTtBQUNBO0FBcUJJO0FBbkJKO0FBcUJRO0FBbkJSO0FBQ0E7QUF1Qkk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQXJCUjtBQXVCUTtBQXJCUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF5Qkk7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQXZCcEI7QUFDQTtBQUNBO0FBeUJRO0FBQ0k7QUF2Qlo7QUF5QlE7QUF2QlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6WkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNSO0FBQ1E7QUFDQTtBQUNSO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFHUTtBQUNBO0FBQ0E7QUFDSTtBQURaO0FBR1k7QUFEWjtBQUNBO0FBR1E7QUFDQTtBQURSO0FBR1E7QUFDQTtBQUNBO0FBQ0E7QUFEUjtBQUdRO0FBRFI7QUFHUTtBQURSO0FBQ0E7QUFHUTtBQUNJO0FBRFo7QUFDQTtBQUNBO0FBQ0E7QUFLSTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhaO0FBS1k7QUFDQTtBQUNJO0FBSGhCO0FBQ0E7QUFDQTtBQUtnQjtBQUNBO0FBQ0E7QUFIaEI7QUFLZ0I7QUFDQTtBQUhoQjtBQUtnQjtBQUhoQjtBQUNBO0FBS2dCO0FBSGhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFPSTtBQUNJO0FBTFI7QUFDQTtBQUNBO0FBQ0E7QUFTSTtBQUNJO0FBQ0k7QUFQWjtBQVNRO0FBQ0E7QUFQUjtBQUNBO0FBVUk7QUFSSjtBQVdRO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFUWjtBQVlZO0FBVlo7QUFDQTtBQVlRO0FBVlI7QUFZUTtBQVZSO0FBWUk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVlI7QUFDQTtBQVlJO0FBVko7QUFDQTtBQVlRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZSO0FBWUk7QUFWSjtBQUNBO0FBYVE7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBWFo7QUFDQTtBQWFRO0FBQ0E7QUFDSTtBQVhaO0FBQ0E7QUFhUTtBQVhSO0FBZ0JJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFkUjtBQWdCUTtBQUNBO0FBQ0E7QUFkUjtBQUNBO0FBZ0JJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWRSO0FBQ0E7QUFpQkk7QUFmSjtBQWlCUTtBQUNBO0FBQ0E7QUFmUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFpQlE7QUFDSTtBQWZaO0FBaUJZO0FBZlo7QUFpQlE7QUFmUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQW1CSTtBQWpCSjtBQUNBO0FBcUJJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFuQlI7QUFxQlE7QUFDSTtBQW5CWjtBQXFCWTtBQW5CWjtBQXFCWTtBQW5CWjtBQUNBO0FBcUJRO0FBQ0E7QUFuQlI7QUFxQkk7QUFuQko7QUFDQTtBQXVCSTtBQUNJO0FBQ0E7QUFyQlI7QUF1QlE7QUFDQTtBQUNBO0FBckJSO0FBdUJRO0FBckJSO0FBQ0E7QUFDQTtBQUNBO0FBeUJJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF2QlI7QUF5QlE7QUFDSTtBQUNBO0FBdkJaO0FBeUJZO0FBQ0E7QUF2Qlo7QUFDQTtBQXlCSTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQXZCWjtBQUNBO0FBeUJRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXZCUjtBQXlCUTtBQUNBO0FBdkJSO0FBMEJJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXhCUjtBQUNBO0FBMEJJO0FBQ0k7QUF4QlI7QUEwQlE7QUFDQTtBQXhCUjtBQTBCUTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUF4QnhCO0FBQ0E7QUFDQTtBQTBCZ0I7QUFDSTtBQUNBO0FBeEJwQjtBQUNBO0FBMEJvQjtBQUNJO0FBQ0E7QUF4QnhCO0FBMEJ3QjtBQUNJO0FBQ0k7QUF4QmhDO0FBMEJvQztBQXhCcEM7QUFDQTtBQUNBO0FBQ0E7QUEwQndCO0FBQ0k7QUFDSTtBQUNJO0FBeEJwQztBQTBCd0M7QUFDQTtBQUNJO0FBeEI1QztBQTBCNEM7QUF4QjVDO0FBQ0E7QUEwQndDO0FBeEJ4QztBQUNBO0FBMEJ3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBeEJ4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBMkJnQjtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNJO0FBQ0k7QUFDQTtBQXpCcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBNEJnQjtBQTFCaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTRCb0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQTFCNUI7QUFDQTtBQUNBO0FBQ0E7QUFnQ2dCO0FBQ0k7QUFDQTtBQUNBO0FBOUJwQjtBQUNBO0FBZ0N3QjtBQUNJO0FBQ0k7QUE5QmhDO0FBZ0NnQztBQUNBO0FBOUJoQztBQWdDZ0M7QUFDQTtBQTlCaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWtDb0I7QUFDSTtBQUNBO0FBQ0E7QUFoQ3hCO0FBQ0E7QUFrQ29CO0FBaENwQjtBQUNBO0FBbUNZO0FBQ0k7QUFqQ2hCO0FBbUNZO0FBQ0k7QUFDQTtBQWpDaEI7QUFDQTtBQW1DWTtBQWpDWjtBQUNBO0FBQ0E7QUFxQ0k7QUFuQ0o7QUFDQTtBQXFDUTtBQW5DUjtBQUNBO0FBcUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBbkNoQjtBQUNBO0FBcUNRO0FBQ0E7QUFuQ1I7QUFxQ0k7QUFDSTtBQUNBO0FBbkNSO0FBcUNRO0FBQ0k7QUFDQTtBQW5DWjtBQXFDWTtBQW5DWjtBQXFDWTtBQW5DWjtBQXFDZ0I7QUFDQTtBQUNBO0FBbkNoQjtBQXFDb0I7QUFDSTtBQW5DeEI7QUFDQTtBQXFDb0I7QUFDQTtBQW5DcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFzQ29CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXBDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBc0NRO0FBQ0E7QUFwQ1I7QUFzQ0k7QUFDSTtBQUNBO0FBQ0E7QUFwQ1I7QUFzQ1E7QUFwQ1I7QUFDQTtBQUNBO0FBc0NJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXBDUjtBQUNBO0FBc0NJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXBDUjtBQXNDUTtBQXBDUjtBQUNBO0FBdUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXJDUjtBQUNBO0FBdUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXJDUjtBQUNBO0FBdUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXJDUjtBQXVDSTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFyQ1o7QUF1Q1k7QUFDSTtBQUNBO0FBQ0E7QUFyQ2hCO0FBdUNZO0FBQ0k7QUFDQTtBQUNBO0FBckNoQjtBQUNBO0FBQ0E7QUEyQ1E7QUFDQTtBQUNJO0FBekNaO0FBMkNRO0FBQ0k7QUF6Q1o7QUFDQTtBQTJDUTtBQXpDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BuQkE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3BCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUFSO0FBQ0E7QUFHSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFEWjtBQUdZO0FBRFo7QUFHUTtBQUNBO0FBRFI7QUFHUTtBQUNBO0FBQ0E7QUFEUjtBQUdRO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQURoQjtBQUdZO0FBQ0E7QUFDQTtBQURaO0FBR1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQURSO0FBR1E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBRGhCO0FBQ0E7QUFHUTtBQUNBO0FBQ0E7QUFDQTtBQURSO0FBQ0E7QUFJSTtBQUZKO0FBSVE7QUFDQTtBQUNBO0FBQ0k7QUFGWjtBQUNBO0FBSVk7QUFDSTtBQUNBO0FBQ0E7QUFGaEI7QUFDQTtBQUNBO0FBQ0E7QUFNSTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBSlo7QUFDQTtBQU9RO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFo7QUFRWTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBTmhCO0FBQ0E7QUFTWTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFQcEI7QUFDQTtBQUNBO0FBU1k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQVBoQjtBQVNvQjtBQVBwQjtBQUNBO0FBQ0E7QUFXUTtBQVRSO0FBQ0E7QUFDQTtBQVdRO0FBQ0k7QUFUWjtBQVdZO0FBVFo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFXUTtBQVRSO0FBWUk7QUFWSjtBQVlRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBVlo7QUFZWTtBQUNBO0FBVlo7QUFZWTtBQUNBO0FBVlo7QUFZUTtBQUNJO0FBVlo7QUFhWTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBWGhCO0FBY2dCO0FBQ0E7QUFDQTtBQUNJO0FBWnBCO0FBZW9CO0FBYnBCO0FBQ0E7QUFDQTtBQUNBO0FBaUJRO0FBQ0k7QUFDQTtBQUNBO0FBZlo7QUFDQTtBQWlCUTtBQWZSO0FBaUJJO0FBUUE7QUFDSTtBQUNBO0FBQ0k7QUF0Qlo7QUF3QlE7QUF0QlI7QUF3Qkk7QUFDSTtBQUNBO0FBQ0k7QUF0Qlo7QUFDQTtBQXdCUTtBQXRCUjtBQXlCSTtBQXZCSjtBQXlCUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQXZCaEI7QUFDQTtBQUNBO0FBeUJRO0FBdkJSO0FBeUJRO0FBQ0k7QUF2Qlo7QUF5Qlk7QUF2Qlo7QUFDQTtBQUNBO0FBeUJJO0FBdkJKO0FBeUJRO0FBdkJSO0FBeUJRO0FBQ0E7QUF2QlI7QUEyQkk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQXpCUjtBQTJCUTtBQUNFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0U7QUFDRjtBQUNBO0FBQ0E7QUFDRTtBQUNGO0FBQ0E7QUFDQTtBQXpCUjtBQUNBO0FBNEJJO0FBQ0k7QUFDSTtBQUNJO0FBMUJoQjtBQUNBO0FBQ0E7QUE2QlE7QUEzQlI7QUFDQTtBQThCSTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBNUJoQjtBQUNBO0FBQ0E7QUE4QlE7QUE1QlI7QUErQkk7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQTdCaEI7QUFDQTtBQStCUTtBQTdCUjtBQStCSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBN0JaO0FBK0JnQjtBQUNJO0FBN0JwQjtBQUNBO0FBK0JvQjtBQTdCcEI7QUFDQTtBQUNBO0FBK0JnQjtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTdCcEI7QUFDQTtBQUNBO0FBQ0E7QUFnQ2dCO0FBQ0k7QUFDSTtBQTlCeEI7QUFnQ3dCO0FBOUJ4QjtBQUNBO0FBQ0E7QUFrQ2dCO0FBQ0k7QUFDQTtBQUNBO0FBaENwQjtBQWtDb0I7QUFDQTtBQWhDcEI7QUFDQTtBQUNBO0FBa0NRO0FBQ0k7QUFoQ1o7QUFrQ1k7QUFoQ1o7QUFrQ1k7QUFDQTtBQUNBO0FBaENaO0FBa0NZO0FBaENaO0FBa0NZO0FBQ0E7QUFoQ1o7QUFrQ1E7QUFDQTtBQWhDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzFYQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDUjtBQUNRO0FBQ0E7QUFDUjtBQUNBO0FBQ1E7QUFDQTtBQUNSO0FBQ1E7QUFDQTtBQUNSO0FBQ1E7QUFDQTtBQUNSO0FBQ1E7QUFDSTtBQUNaO0FBQ1k7QUFDWjtBQUNBO0FBQ1k7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUVJO0FBQ0k7QUFDQTtBQUNBO0FBQVI7QUFFSTtBQUNJO0FBQ0E7QUFDQTtBQUFSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUk7QUFDSTtBQUNBO0FBQVI7QUFFUTtBQUNJO0FBQ0k7QUFDQTtBQUFoQjtBQUNBO0FBRVk7QUFBWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN4RkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVJO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBWjtBQUVRO0FBQVI7QUFFSTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQWhCO0FBQ0E7QUFDQTtBQUlJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFGUjtBQUtJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUhaO0FBQ0E7QUFLWTtBQUNJO0FBSGhCO0FBQ0E7QUFNUTtBQUpSO0FBQ0E7QUFNSTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBSmhCO0FBQ0E7QUFDQTtBQVFJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQU5aO0FBQ0E7QUFRWTtBQUNJO0FBTmhCO0FBUVk7QUFDQTtBQU5aO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hIQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xDQTtBQUNJO0FBQ0o7QUFDRztBQUNLO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDUjtBQUNBO0FBQ0k7QUFDSTtBQUNSO0FBQ0E7QUFDQTtBQUVJO0FBQUo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMUJBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0k7QUFDQTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUdBO0FBQ0k7QUFEUjtBQUdJO0FBQ0k7QUFEUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHSTtBQURKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzFDQTtBQUVFO0FBQ007QUFDQTtBQUNBO0FBQVI7QUFFQTtBQUNDO0FBQUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDZEE7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUk7QUFDSTtBQUNBO0FBQ0E7QUFBUjtBQUNBO0FBRUk7QUFDSTtBQUFSO0FBQ0E7QUFFSTtBQUNJO0FBQVI7QUFDQTtBQUVJO0FBQ0k7QUFBUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JEQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDckdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ1E7QUFDQTtBQUNBO0FBQ1I7QUFDUTtBQUNBO0FBQ0E7QUFDUjtBQUNRO0FBQ1I7QUFDUTtBQUNBO0FBQ0E7QUFDUjtBQUNBO0FBQ1E7QUFDUjtBQUNRO0FBQ0E7QUFDUjtBQUNRO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUjtBQUNRO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFFSTtBQUNJO0FBQ0E7QUFDQTtBQUFSO0FBR0k7QUFDSTtBQUNBO0FBQ0E7QUFEUjtBQUdJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFEWjtBQUdZO0FBQ0E7QUFEWjtBQUlRO0FBRlI7QUFJUTtBQUNBO0FBQ0E7QUFDQztBQUNXO0FBQ0E7QUFGcEI7QUFDQTtBQUNBO0FBQ0E7QUFJSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFGWjtBQUlZO0FBQ0E7QUFGWjtBQUNBO0FBSUk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUZSO0FBSUk7QUFDSTtBQUNJO0FBRlo7QUFDQTtBQUtRO0FBQ0E7QUFDQTtBQUhSO0FBS1E7QUFIUjtBQU1JO0FBQ0k7QUFDSTtBQUpaO0FBTVk7QUFDQTtBQUNBO0FBSlo7QUFDQTtBQVFJO0FBQ0k7QUFDQTtBQUNBO0FBTlI7QUFDQTtBQVFJO0FBQ0k7QUFOUjtBQUNBO0FBQ0E7QUFDQTtBQVFJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5SO0FBUVE7QUFDQTtBQU5SO0FBUVE7QUFDSTtBQU5aO0FBUVk7QUFOWjtBQUNBO0FBUVE7QUFOUjtBQVFRO0FBTlI7QUFRSTtBQUNJO0FBTlI7QUFRUTtBQUNBO0FBQ0E7QUFOUjtBQUNBO0FBU0k7QUFDSTtBQUNBO0FBR0E7QUFDQTtBQVRSO0FBWUk7QUFDSTtBQUNBO0FBVlI7QUFDQTtBQWFJO0FBQ0k7QUFDQTtBQVhSO0FBQ0E7QUFhSTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBWFo7QUFhWTtBQVhaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMU5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ1I7QUFDUTtBQUNSO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDSTtBQUNaO0FBQ1E7QUFDQTtBQUNBO0FBQ1I7QUFDUTtBQUNJO0FBQ0k7QUFDaEI7QUFDZ0I7QUFDaEI7QUFDQTtBQUNBO0FBRVE7QUFDSTtBQUNJO0FBQ0E7QUFBaEI7QUFFZ0I7QUFDQTtBQUFoQjtBQUNBO0FBQ0E7QUFFUTtBQUNJO0FBQ0k7QUFBaEI7QUFFZ0I7QUFBaEI7QUFDQTtBQUNBO0FBSVE7QUFGUjtBQUNBO0FBSUk7QUFGSjtBQUlRO0FBRlI7QUFDQTtBQUlRO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFGaEI7QUFLZ0I7QUFIaEI7QUFDQTtBQUNBO0FBTVE7QUFKUjtBQUNBO0FBT0k7QUFMSjtBQU9RO0FBTFI7QUFPUTtBQUNJO0FBTFo7QUFDQTtBQUNBO0FBT1E7QUFDQTtBQUNJO0FBTFo7QUFDQTtBQVFRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQU5aO0FBUVk7QUFOWjtBQUNBO0FBUVE7QUFDSTtBQU5aO0FBUVk7QUFOWjtBQUNBO0FBU1E7QUFDSTtBQVBaO0FBU1k7QUFQWjtBQVNRO0FBQ0E7QUFDSTtBQUNJO0FBUGhCO0FBQ0E7QUFTUTtBQVBSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlJQTtBQUVFO0FBQ007QUFDQTtBQUNBO0FBQVI7QUFFQTtBQUNDO0FBQUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDZEE7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ1I7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUdJO0FBQ0k7QUFDQTtBQUNDO0FBQ0Q7QUFEUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcENBO0FBRUU7QUFDQTtBQUNNO0FBQ0E7QUFDQTtBQUNOO0FBQ007QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBUjtBQUVBO0FBQ0M7QUFBRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3QkE7QUFFTTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQU47QUFDQTtBQUNBO0FBRUE7QUFDQztBQUFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pCQTtBQUVNO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQU47QUFFTTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQU47QUFFTTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQU47QUFFTTtBQUFOO0FBRU07QUFBTjtBQUNBO0FBRUE7QUFDQztBQUFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDUTtBQUNBO0FBQ0E7QUFDUjtBQUNRO0FBQ0E7QUFDUjtBQUNZO0FBQ0E7QUFDQTtBQUNBO0FBQ1o7QUFDWTtBQUNJO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBR0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQURSO0FBQ0E7QUFHSTtBQURKO0FBR1E7QUFDQTtBQURSO0FBQ0E7QUFJSTtBQUNJO0FBQ0E7QUFGUjtBQUNBO0FBSVE7QUFGUjtBQUNBO0FBQ0E7QUFDQTtBQUNTO0FBS0w7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUhaO0FBQ0E7QUFNWTtBQUNBO0FBQ0E7QUFDQTtBQUpaO0FBQ0E7QUFDQTtBQVVJO0FBQ007QUFSVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwR0E7QUFDQTtBQUVBO0FBQ0k7QUFBSjtBQUVJO0FBQUo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFSO0FBQ0E7QUFDQTtBQUVJO0FBQUo7QUFFUTtBQUFSO0FBQ0E7QUFDQTtBQUNBO0FBRVE7QUFBUjtBQUNBO0FBRVE7QUFDQTtBQUFSO0FBRVE7QUFDQTtBQUNBO0FBQ0E7QUFBUjtBQUNBO0FBQ0E7QUFFUTtBQUNJO0FBQVo7QUFFWTtBQUFaO0FBQ0E7QUFFWTtBQUFaO0FBQ0E7QUFFWTtBQUFaO0FBRVk7QUFDQTtBQUNBO0FBQVo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFRSTtBQUNJO0FBTlI7QUFDQTtBQUNBO0FBVUk7QUFSSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFVUTtBQUNBO0FBQ0E7QUFSUjtBQVVRO0FBQ0E7QUFDQTtBQVJSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWUk7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBVmhCO0FBQ0E7QUFZUTtBQUNBO0FBVlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3SEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBRHhCO0FBQ0E7QUFDQTtBQUNBO0FBR29CO0FBRHBCO0FBSXdCO0FBQ0E7QUFDQTtBQUZ4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUl3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRnhCO0FBQ0E7QUFDQTtBQUlvQjtBQUZwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlnQjtBQUZoQjtBQUNBO0FBQ0E7QUFJWTtBQUZaO0FBQ0E7QUFDQTtBQUNBO0FBSVE7QUFGUjtBQUlRO0FBQ0k7QUFGWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBT0k7QUFMSjtBQU9RO0FBQ0E7QUFMUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFPSTtBQUdBO0FBUEo7QUFTUTtBQUNBO0FBUFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0SkE7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdCQTtBQUVFO0FBQUY7QUFFRTtBQUNNO0FBQ0E7QUFBUjtBQUVBO0FBQ0M7QUFBRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNmQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ1o7QUFDWTtBQUNaO0FBQ1k7QUFDWjtBQUNBO0FBQ2tCO0FBQ0Y7QUFHQztBQURqQjtBQUNBO0FBT007QUFMTjtBQVFJO0FBTko7QUFRUTtBQUNBO0FBTlI7QUFRSTtBQUNJO0FBQ0E7QUFOUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzREE7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJSTtBQUZKO0FBSVE7QUFDSTtBQUZaO0FBSVk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUZoQjtBQUNBO0FBQ0E7QUFJUTtBQUZSO0FBQ0E7QUFJSTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFGWjtBQUNBO0FBTUk7QUFKSjtBQU1RO0FBSlI7QUFPSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBTFI7QUFPUTtBQUxSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbkVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNSO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDUjtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDUjtBQUNXO0FBQ1g7QUFDQTtBQUNJO0FBQ0o7QUFDUTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ2hCO0FBQ29CO0FBQ0E7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDUTtBQUNSO0FBQ0E7QUFDQTtBQUlJO0FBQ0k7QUFDQTtBQUZSO0FBSVE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFGWjtBQUlRO0FBQ0E7QUFGUjtBQUlRO0FBQ0E7QUFGUjtBQUNBO0FBSVE7QUFDQTtBQUNJO0FBQ0E7QUFGWjtBQUlZO0FBRlo7QUFJWTtBQUZaO0FBQ0E7QUFJUTtBQUZSO0FBT0k7QUFDSTtBQUNBO0FBTFI7QUFPUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUxaO0FBT1E7QUFDQTtBQUxSO0FBQ0E7QUFPUTtBQUNBO0FBTFI7QUFDQTtBQU9RO0FBQ0E7QUFDSTtBQUNBO0FBTFo7QUFPWTtBQUxaO0FBT1k7QUFMWjtBQUNBO0FBQ0E7QUFPUTtBQUxSO0FBQ0E7QUFZSTtBQVZKO0FBZUk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBYlo7QUFlWTtBQUNBO0FBQ0E7QUFiWjtBQWVZO0FBQ0E7QUFDQTtBQWJaO0FBZVk7QUFDQTtBQUNBO0FBYlo7QUFDQTtBQWdCUTtBQWRSO0FBQ0E7QUFrQkk7QUFoQko7QUFtQlE7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQWpCWjtBQW1CZ0I7QUFqQmhCO0FBbUJvQjtBQUNBO0FBQ0E7QUFqQnBCO0FBbUJnQjtBQUNBO0FBakJoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbUJnQjtBQUNBO0FBakJoQjtBQW1CZ0I7QUFDSTtBQUNJO0FBQ0E7QUFqQnhCO0FBQ0E7QUFvQm9CO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFsQjVCO0FBQ0E7QUFvQndCO0FBQ0k7QUFDQTtBQWxCNUI7QUFDQTtBQW9Cd0I7QUFDQTtBQUNBO0FBbEJ4QjtBQW9Cd0I7QUFDQTtBQUNBO0FBbEJ4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBeUJRO0FBQ0s7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBQ0k7QUFDQTtBQXZCeEI7QUFDQTtBQTBCb0I7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBeEI1QjtBQUNBO0FBMEJ3QjtBQUNJO0FBQ0E7QUF4QjVCO0FBQ0E7QUEwQndCO0FBQ0E7QUFDQTtBQXhCeEI7QUEwQndCO0FBQ0E7QUFDQTtBQXhCeEI7QUFDQTtBQUNBO0FBMkJ3QjtBQUNBO0FBQ0k7QUF6QjVCO0FBMkI0QjtBQXpCNUI7QUEyQjRCO0FBekI1QjtBQTJCNEI7QUF6QjVCO0FBQ0E7QUEyQndCO0FBQ0E7QUF6QnhCO0FBMkJ3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXpCeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTZCSTtBQUNJO0FBQ0E7QUFDSTtBQTNCWjtBQUNBO0FBNkJZO0FBM0JaO0FBQ0E7QUE4Qlk7QUE1Qlo7QUE4Qlk7QUE1Qlo7QUFDQTtBQThCUTtBQUNBO0FBQ0E7QUE1QlI7QUFDQTtBQUNBO0FBQ0E7QUErQkk7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQTdCcEI7QUErQm9CO0FBN0JwQjtBQUNBO0FBZ0NZO0FBOUJaO0FBQ0E7QUFnQ1E7QUE5QlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xXQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDUjtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0k7QUFDWjtBQUNTO0FBQ0k7QUFDYjtBQUNBO0FBRVE7QUFDQTtBQU1BO0FBTFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNSO0FBQ1E7QUFDQTtBQUNSO0FBQ0E7QUFFSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFBWjtBQUVRO0FBQ0k7QUFBWjtBQUVRO0FBQ0k7QUFBWjtBQUNBO0FBRVE7QUFDQTtBQUFSO0FBRVE7QUFDSTtBQUNJO0FBQ0E7QUFBaEI7QUFDQTtBQUVRO0FBQVI7QUFFUTtBQUNBO0FBQVI7QUFFUTtBQUFSO0FBQ0E7QUFJSTtBQUNJO0FBRlI7QUFDQTtBQUlJO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFGWjtBQUNBO0FBS1k7QUFDQTtBQUNBO0FBQ0E7QUFIWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlGQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFJSTtBQUNHO0FBQ0E7QUFDQTtBQUNFO0FBRlQ7QUFDQTtBQUlTO0FBQ0E7QUFDSTtBQUZiO0FBSVU7QUFDRztBQUZiO0FBSVc7QUFDRTtBQUZiO0FBSVc7QUFDRTtBQUZiO0FBSVc7QUFDRTtBQUZiO0FBSVc7QUFDRTtBQUZiO0FBSVc7QUFDRTtBQUZiO0FBSVc7QUFDRTtBQUZiO0FBSVc7QUFDRTtBQUZiO0FBQ0E7QUFJVztBQUNFO0FBRmI7QUFDQTtBQUlXO0FBQ0U7QUFGYjtBQUlXO0FBQ0U7QUFGYjtBQUlXO0FBQ0U7QUFGYjtBQUlXO0FBQ0U7QUFGYjtBQUlXO0FBQ0U7QUFGYjtBQUNBO0FBS1M7QUFDQTtBQUNBO0FBQ0E7QUFIVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3RkE7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFHSTtBQURKO0FBR1E7QUFDQTtBQUNJO0FBRFo7QUFHWTtBQURaO0FBR1E7QUFEUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUVZO0FBQ0E7QUFBWjtBQUVZO0FBQ0k7QUFBaEI7QUFDQTtBQUNBO0FBR1E7QUFDSTtBQUNBO0FBQ0k7QUFEaEI7QUFHWTtBQUNJO0FBRGhCO0FBR1k7QUFDSTtBQURoQjtBQUdZO0FBQ0k7QUFEaEI7QUFDQTtBQUdZO0FBQ0k7QUFEaEI7QUFHZ0I7QUFEaEI7QUFDQTtBQUNBO0FBSVE7QUFDQTtBQUZSO0FBS0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFIWjtBQUtZO0FBQ0E7QUFIWjtBQUNBO0FBS1E7QUFDSTtBQUhaO0FBS1E7QUFDSTtBQUhaO0FBQ0E7QUFLUTtBQUNBO0FBSFI7QUFLUTtBQUNBO0FBSFI7QUFDQTtBQUtJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFIUjtBQUNBO0FBS0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSFI7QUFDQTtBQUtJO0FBSEo7QUFLUTtBQUNBO0FBQ0E7QUFIUjtBQUtJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFIUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3SUE7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBR0k7QUFDSTtBQUNBO0FBRFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0k7QUFHQTtBQUNJO0FBSFI7QUFDQTtBQUtJO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFIWjtBQUtZO0FBSFo7QUFLUTtBQUNBO0FBQ0E7QUFIUjtBQUtRO0FBQ0E7QUFDQTtBQUNBO0FBSFI7QUFLUTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFIaEI7QUFDQTtBQUtRO0FBQ0E7QUFDQTtBQUNBO0FBSFI7QUFLUTtBQUhSO0FBQ0E7QUFNSTtBQUNJO0FBSlI7QUFNUTtBQUNJO0FBQ0k7QUFKaEI7QUFDQTtBQU9RO0FBTFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hGQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0o7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ1I7QUFDQTtBQUdJO0FBQ0k7QUFEUjtBQUNBO0FBR0k7QUFESjtBQUdRO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFEaEI7QUFDQTtBQUdRO0FBRFI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTUk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpSO0FBT1E7QUFDSTtBQUNJO0FBQ0E7QUFMaEI7QUFPZ0I7QUFDQTtBQUxoQjtBQUNBO0FBQ0E7QUFRUTtBQUNJO0FBQ0E7QUFOWjtBQUNBO0FBQ0E7QUFRUTtBQUNBO0FBQ0E7QUFOUjtBQUNBO0FBUVE7QUFDQTtBQUNJO0FBTlo7QUFRZ0I7QUFOaEI7QUFDQTtBQUNBO0FBU1k7QUFQWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVVE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUlI7QUFVUTtBQUNJO0FBUlo7QUFVUTtBQUNJO0FBUlo7QUFVUTtBQUNBO0FBQ0E7QUFSUjtBQVVRO0FBQ0E7QUFSUjtBQUNBO0FBQ0E7QUFDQTtBQVVRO0FBUlI7QUFDQTtBQUNBO0FBVVE7QUFSUjtBQUNBO0FBV0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVFI7QUFXUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBVGhCO0FBWWdCO0FBVmhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZUk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQWJSO0FBQ0E7QUFDQTtBQUNBO0FBZUk7QUFiSjtBQWVRO0FBYlI7QUFDQTtBQWVRO0FBQ0E7QUFDQTtBQWJSO0FBQ0E7QUFlUTtBQWJSO0FBZVE7QUFiUjtBQWVRO0FBQ0E7QUFiUjtBQUNBO0FBQ0E7QUFDQTtBQWdCSTtBQWRKO0FBZ0JRO0FBZFI7QUFnQlE7QUFDQTtBQWRSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBa0JRO0FBaEJSO0FBa0JRO0FBaEJSO0FBQ0E7QUFrQlE7QUFDQTtBQUNBO0FBaEJSO0FBQ0E7QUFrQlE7QUFDQTtBQUNBO0FBQ0E7QUFoQlI7QUFDQTtBQW1CUTtBQUNJO0FBakJaO0FBQ0E7QUFtQlE7QUFqQlI7QUFDQTtBQW1CUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFqQlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBb0JJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBbEJaO0FBQ0E7QUFDQTtBQXFCSTtBQW5CSjtBQXFCUTtBQW5CUjtBQUNBO0FBQ0E7QUFDQTtBQXlCSTtBQXZCSjtBQXlCUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQXZCWjtBQXlCUTtBQUNBO0FBQ0k7QUFDQTtBQXZCWjtBQXlCUTtBQUNBO0FBQ0E7QUF2QlI7QUF5QlE7QUFDSTtBQXZCWjtBQXlCWTtBQUNJO0FBQ0E7QUFDQTtBQXZCaEI7QUEwQlk7QUF4Qlo7QUEwQlk7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQXhCaEI7QUFDQTtBQUNBO0FBNEJRO0FBMUJSO0FBQ0E7QUFDQTtBQUNBO0FBNkJJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBM0JSO0FBNkJRO0FBQ0E7QUEzQlI7QUE2QlE7QUFDQTtBQTNCUjtBQThCUTtBQTVCUjtBQUNBO0FBQ0E7QUE4Qkk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE1QlI7QUE4QlE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE1QlI7QUE4QlE7QUFDQTtBQUNBO0FBNUJSO0FBOEJRO0FBNUJSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWdDSTtBQUNJO0FBOUJSO0FBZ0NRO0FBQ0k7QUFDSTtBQTlCaEI7QUFDQTtBQWlDUTtBQS9CUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBa0NJO0FBaENKO0FBa0NRO0FBQ0E7QUFoQ1I7QUFtQ1k7QUFDSTtBQUNBO0FBakNoQjtBQW9DZ0I7QUFsQ2hCO0FBQ0E7QUF3Q1E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQXRDaEI7QUF5Q2dCO0FBdkNoQjtBQUNBO0FBMENRO0FBeENSO0FBMENZO0FBQ0k7QUFDQTtBQXhDaEI7QUEyQ2dCO0FBekNoQjtBQUNBO0FBMkNRO0FBQ0k7QUFDSTtBQUNBO0FBekNoQjtBQTZDZ0I7QUEzQ2hCO0FBQ0E7QUFDQTtBQThDUTtBQTVDUjtBQThDUTtBQTVDUjtBQUNBO0FBQ0E7QUFDQTtBQStDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQTdDWjtBQStDUTtBQUNJO0FBN0NaO0FBK0NRO0FBQ0k7QUE3Q1o7QUErQ1E7QUFDSTtBQTdDWjtBQUNBO0FBK0NRO0FBQ0k7QUFDQTtBQTdDWjtBQStDUTtBQUNJO0FBQ0E7QUE3Q1o7QUErQ1E7QUFDSTtBQUNBO0FBN0NaO0FBQ0E7QUErQ1E7QUFDQTtBQTdDUjtBQUNBO0FBZ0RJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUE5Q1I7QUFnRFE7QUFDSTtBQUNJO0FBQ0E7QUE5Q2hCO0FBQ0E7QUFDQTtBQWdEUTtBQTlDUjtBQWlESTtBQS9DSjtBQWlEUTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBL0NoQjtBQUNBO0FBQ0E7QUFpRFE7QUEvQ1I7QUFrREk7QUFoREo7QUFrRFE7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQWhEaEI7QUFDQTtBQUNBO0FBa0RRO0FBaERSO0FBbURJO0FBakRKO0FBbURRO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQWpEaEI7QUFDQTtBQUNBO0FBbURRO0FBakRSO0FBQ0E7QUFvREk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFsRGhCO0FBQ0E7QUFDQTtBQW9EUTtBQWxEUjtBQUNBO0FBc0RJO0FBcERKO0FBc0RRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXBEUjtBQUNBO0FBc0RRO0FBcERSO0FBQ0E7QUFDQTtBQUNBO0FBc0RRO0FBQ0E7QUFDQTtBQXBEUjtBQXNEWTtBQUNBO0FBQ0E7QUFDSTtBQXBEaEI7QUFzRG9CO0FBQ0k7QUFwRHhCO0FBQ0E7QUFzRG9CO0FBcERwQjtBQUNBO0FBQ0E7QUFDQTtBQXVEZ0I7QUFyRGhCO0FBQ0E7QUFDQTtBQXlEWTtBQXZEWjtBQXlEZ0I7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQXZEeEI7QUF5RHdCO0FBQ0E7QUFDSTtBQXZENUI7QUF5RDRCO0FBQ0k7QUF2RGhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBeURnQjtBQXZEaEI7QUFDQTtBQUNBO0FBMkRRO0FBekRSO0FBQ0E7QUE0REk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQTFEUjtBQUNBO0FBNERJO0FBQ0k7QUExRFI7QUE2RFE7QUFDSTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBM0RwQjtBQUNBO0FBQ0E7QUFDQTtBQStESTtBQUNJO0FBN0RSO0FBK0RJO0FBQ0k7QUE3RFI7QUErREk7QUFDSTtBQTdEUjtBQUNBO0FBK0RRO0FBN0RSO0FBK0RZO0FBQ0E7QUFDQTtBQUNBO0FBN0RaO0FBK0RRO0FBQ0k7QUE3RFo7QUFDQTtBQUNBO0FBQ0E7QUErRFk7QUFDQTtBQUNBO0FBQ0E7QUE3RFo7QUErRFk7QUFDQTtBQUNJO0FBQ0E7QUE3RGhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZ0VRO0FBQ0k7QUFDQTtBQUNBO0FBOURaO0FBZ0VZO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUE5RHBCO0FBZ0VnQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE5RGhCO0FBZ0VnQjtBQTlEaEI7QUFnRWdCO0FBQ0E7QUE5RGhCO0FBaUVnQjtBQUNBO0FBQ0E7QUFDQTtBQS9EaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWtFSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQWhFaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWtFSTtBQUNJO0FBQ0E7QUFDQTtBQWhFUjtBQWtFUTtBQWhFUjtBQWtFUTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQWhFWjtBQUNBO0FBa0VZO0FBaEVaO0FBa0VZO0FBaEVaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBbUVJO0FBQ0k7QUFqRVI7QUFtRVE7QUFDSTtBQWpFWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBb0VJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQWxFaEI7QUFDQTtBQW9FWTtBQWxFWjtBQUNBO0FBb0VJO0FBQ0k7QUFsRVI7QUFvRVE7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQWxFaEI7QUFDQTtBQUNBO0FBcUVJO0FBbkVKO0FBcUVRO0FBQ0E7QUFuRVI7QUFxRVE7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUdJO0FBQ0E7QUFyRWhCO0FBQ0E7QUFDQTtBQXlFSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQXZFaEI7QUF5RVk7QUFDSTtBQXZFaEI7QUF5RVk7QUFDSTtBQXZFaEI7QUFDQTtBQUNBO0FBMEVRO0FBQ0E7QUFDSTtBQXhFWjtBQTBFUTtBQUNJO0FBeEVaO0FBMEVRO0FBQ0k7QUF4RVo7QUEwRVE7QUF4RVI7QUEwRUk7QUF4RUo7QUEwRVE7QUFDQTtBQXhFUjtBQTBFUTtBQXhFUjtBQTBFUTtBQUNJO0FBQ0k7QUFDSTtBQUNBO0FBeEVwQjtBQTBFb0I7QUFDSTtBQUNBO0FBeEV4QjtBQTBFd0I7QUFDSTtBQUNJO0FBQ0E7QUF4RWhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUErRUk7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQTdFWjtBQStFUTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUE3RXhCO0FBQ0E7QUFnRmdCO0FBOUVoQjtBQWtGWTtBQWhGWjtBQWtGWTtBQUNBO0FBaEZaO0FBQ0E7QUFrRlE7QUFoRlI7QUFrRkk7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBaEY1QjtBQUNBO0FBbUZvQjtBQWpGcEI7QUFxRmdCO0FBbkZoQjtBQXFGZ0I7QUFDQTtBQW5GaEI7QUFDQTtBQXNGUTtBQUNBO0FBQ0E7QUFwRlI7QUF1Rkk7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBckY1QjtBQUNBO0FBd0ZvQjtBQXRGcEI7QUEwRmdCO0FBeEZoQjtBQTBGZ0I7QUFDQTtBQXhGaEI7QUFDQTtBQTJGUTtBQUNBO0FBQ0E7QUF6RlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTRGSTtBQTFGSjtBQTRGUTtBQUNBO0FBQ0E7QUFDSTtBQTFGWjtBQTRGUTtBQUNJO0FBMUZaO0FBNEZRO0FBQ0E7QUExRlI7QUE0Rkk7QUFDSTtBQTFGUjtBQTRGUTtBQTFGUjtBQTRGWTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQTFGcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTRGUTtBQTFGUjtBQTRGSTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBMUZoQjtBQUNBO0FBNEZRO0FBMUZSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUE0Rkk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQTFGcEI7QUFDQTtBQUNBO0FBQ0E7QUE4RlE7QUE1RlI7QUFDQTtBQUNBO0FBQ0E7QUErRkk7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBN0ZaO0FBK0ZRO0FBQ0E7QUFDQTtBQTdGUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFnR0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQTlGWjtBQWdHUTtBQUNBO0FBOUZSO0FBZ0dRO0FBQ0E7QUE5RlI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWlHSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBL0ZoQjtBQUNBO0FBQ0E7QUFpR1E7QUEvRlI7QUFrR0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFoR1I7QUFrR0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFoR1I7QUFDQTtBQUNBO0FBQ0E7QUFrR0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWhHUjtBQWtHWTtBQWhHWjtBQW1HWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFqR2hCO0FBbUdZO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFqR2hCO0FBbUdnQjtBQWpHaEI7QUFDQTtBQW9HZ0I7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFsR3hCO0FBQ0E7QUFvR29CO0FBQ0k7QUFsR3hCO0FBb0d3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBbEc1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF3R1E7QUF0R1I7QUFDQTtBQUNBO0FBeUdJO0FBdkdKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdG9DQTtBQUNBO0FBQ0k7QUFDSjtBQUNJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDUjtBQUNRO0FBQ0E7QUFDQTtBQUNBO0FBQ1I7QUFDUTtBQUNBO0FBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUk7QUFDSTtBQUtBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKWjtBQU1ZO0FBQ0k7QUFKaEI7QUFNZ0I7QUFDQTtBQUNJO0FBSnBCO0FBQ0E7QUFDQTtBQU1ZO0FBSlo7QUFPUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTFI7QUFDQTtBQVFJO0FBTko7QUFDQTtBQUNBO0FBQ0E7QUFRUTtBQUNBO0FBTlI7QUFDQTtBQVFRO0FBQ0E7QUFDQTtBQUNBO0FBTlI7QUFRUTtBQU5SO0FBUVE7QUFDQTtBQUNJO0FBTlo7QUFRWTtBQUNJO0FBTmhCO0FBUWdCO0FBQ0k7QUFDQTtBQU5wQjtBQVNvQjtBQVBwQjtBQUNBO0FBU2dCO0FBQ0E7QUFDSTtBQVBwQjtBQVN3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFQeEI7QUFTd0I7QUFDQTtBQVB4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYVE7QUFYUjtBQWFRO0FBWFI7QUFDQTtBQUNBO0FBZUk7QUFiSjtBQWVRO0FBQ0k7QUFDQTtBQWJaO0FBZ0JZO0FBQ0E7QUFkWjtBQWlCWTtBQUNBO0FBZlo7QUFrQlE7QUFDQTtBQWhCUjtBQUNBO0FBQ0E7QUFDQTtBQW1CSTtBQUNJO0FBQ0E7QUFDQTtBQWpCUjtBQW1CUTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFqQmhCO0FBb0JZO0FBQ0k7QUFsQmhCO0FBcUJZO0FBQ0k7QUFuQmhCO0FBQ0E7QUFDQTtBQXVCUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBckJoQjtBQUNBO0FBdUJRO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFyQmhCO0FBQ0E7QUFDQTtBQTJCVTtBQUNLO0FBQ0E7QUFDQTtBQUNBO0FBekJmO0FBQ0E7QUE4QlE7QUE1QlI7QUFDQTtBQThCSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUE1QmhCO0FBOEJZO0FBQ0k7QUE1QmhCO0FBOEJZO0FBQ0k7QUE1QmhCO0FBQ0E7QUFDQTtBQStCUTtBQUNBO0FBQ0k7QUE3Qlo7QUErQlE7QUFDSTtBQTdCWjtBQStCUTtBQUNJO0FBN0JaO0FBK0JRO0FBN0JSO0FBK0JJO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUE3Qlo7QUFDQTtBQStCSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQTdCaEI7QUFDQTtBQUNBO0FBK0JRO0FBQ0k7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBN0J4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBaUNRO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBL0JwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBa0NJO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNJO0FBaENoQjtBQUNBO0FBQ0E7QUFrQ1E7QUFoQ1I7QUFDQTtBQUNBO0FBbUNJO0FBQ0k7QUFDQTtBQWpDUjtBQUNBO0FBQ0E7QUFvQ0k7QUFsQ0o7QUFvQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQWxDaEI7QUFDQTtBQUNBO0FBQ0E7QUFxQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQW5DcEI7QUFxQ3dCO0FBbkN4QjtBQUNBO0FBQ0E7QUFzQ3dCO0FBQ0k7QUFwQzVCO0FBQ0E7QUFzQzRCO0FBcEM1QjtBQUNBO0FBQ0E7QUFDQTtBQXdDb0I7QUF0Q3BCO0FBd0NvQjtBQUNJO0FBQ0E7QUFDQTtBQXRDeEI7QUFDQTtBQUNBO0FBd0NvQjtBQUNJO0FBQ0E7QUFDSTtBQXRDNUI7QUF3QzRCO0FBdEM1QjtBQUNBO0FBd0N3QjtBQUNBO0FBQ0k7QUF0QzVCO0FBd0N3QjtBQUNBO0FBQ0E7QUF0Q3hCO0FBQ0E7QUFDQTtBQXlDb0I7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUF2Q3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUEwQ1E7QUF4Q1I7QUEwQ0k7QUF4Q0o7QUEwQ1E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBeENoQjtBQTBDZ0I7QUFDQTtBQXhDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBMENnQjtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBeENwQjtBQTBDb0I7QUF4Q3BCO0FBQ0E7QUFDQTtBQUNBO0FBMkNRO0FBekNSO0FBQ0E7QUE0Q0k7QUFDSTtBQUNBO0FBQ0E7QUExQ1I7QUFDQTtBQUNBO0FBNENRO0FBMUNSO0FBNENRO0FBQ0k7QUExQ1o7QUFDQTtBQTRDUTtBQUNJO0FBMUNaO0FBQ0E7QUE0Q1E7QUFDSTtBQTFDWjtBQUNBO0FBNENRO0FBMUNSO0FBQ0E7QUE2Q0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUEzQ1I7QUE2Q1E7QUFDSTtBQUNBO0FBM0NaO0FBNkNRO0FBQ0k7QUFDQTtBQTNDWjtBQTZDUTtBQUNJO0FBQ0E7QUEzQ1o7QUFDQTtBQTZDUTtBQUNBO0FBQ0E7QUEzQ1I7QUFDQTtBQThDSTtBQUNJO0FBQ0k7QUFDQTtBQTVDWjtBQUNBO0FBQ0E7QUE4Q1k7QUE1Q1o7QUE4Q1k7QUE1Q1o7QUErQ1E7QUE3Q1I7QUFDQTtBQStDWTtBQTdDWjtBQUNBO0FBK0NRO0FBN0NSO0FBQ0E7QUErQ1k7QUE3Q1o7QUFDQTtBQStDSTtBQTdDSjtBQStDUTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTdDWjtBQStDWTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUE3Q2hCO0FBK0NnQjtBQTdDaEI7QUFDQTtBQUNBO0FBQ0E7QUFnREk7QUE5Q0o7QUFnRFE7QUFDQTtBQTlDUjtBQWdEUTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBOUNaO0FBZ0RZO0FBQ0k7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQTlDeEI7QUFDQTtBQWdEb0I7QUE5Q3BCO0FBQ0E7QUFpRFk7QUFDQTtBQUNJO0FBQ0k7QUEvQ3BCO0FBQ0E7QUFpRGdCO0FBQ0k7QUEvQ3BCO0FBQ0E7QUFpRFk7QUFDSTtBQUNJO0FBL0NwQjtBQWlEZ0I7QUFDSTtBQS9DcEI7QUFpRGdCO0FBQ0k7QUEvQ3BCO0FBQ0E7QUFrRFk7QUFDSTtBQUNJO0FBaERwQjtBQWtEZ0I7QUFDSTtBQWhEcEI7QUFDQTtBQW1EWTtBQUNJO0FBQ0k7QUFqRHBCO0FBbURnQjtBQUNJO0FBakRwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQW1EWTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFqRGhCO0FBbURnQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBakRwQjtBQUNBO0FBbURnQjtBQUNBO0FBQ0E7QUFqRGhCO0FBbURZO0FBQ0E7QUFqRFo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNucEJBO0FBRU07QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFOO0FBRU07QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBTjtBQUNBO0FBRUE7QUFDQztBQUFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ1I7QUFDQTtBQUNRO0FBQ0E7QUFDSTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ1k7QUFDQTtBQUNaO0FBQ1k7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0k7QUFDNUI7QUFDd0I7QUFDQTtBQUN4QjtBQUN3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ3dCO0FBQ0E7QUFDeEI7QUFDQTtBQUN3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNvQjtBQUNwQjtBQUNBO0FBQ0E7QUFDZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBS1k7QUFIWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVFJO0FBQ0k7QUFDQTtBQUNBO0FBTlI7QUFDQTtBQVFJO0FBQ0k7QUFDQTtBQUNBO0FBTlI7QUFDQTtBQVNJO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQVBoQjtBQUNBO0FBU1E7QUFDQTtBQVBSO0FBQ0E7QUFDQTtBQVNJO0FBUEo7QUFTUTtBQVBSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVNJO0FBQ0k7QUFDSTtBQVBaO0FBQ0E7QUFDQTtBQVNJO0FBUEo7QUFTUTtBQVBSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdjM2Q4NjhvcG05QkI0TEgrVllLcXNxYycsICdBdWRpb01uZycpO1xuLy8gc2NyaXB0L2F1ZGlvL0F1ZGlvTW5nLmpzXG5cbnZhciBnYW1lQ29uZmlnU2V0dGluZztcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBnYW1lU3RhcnRBdWRpbzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuICAgICAgICB3aW5BdWRpbzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuXG4gICAgICAgIGxvc2VBdWRpbzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuXG4gICAgICAgIGNhcmRBdWRpbzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuXG4gICAgICAgIGJ1dHRvbkF1ZGlvOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHVybDogY2MuQXVkaW9DbGlwXG4gICAgICAgIH0sXG5cbiAgICAgICAgY2hpcHNBdWRpbzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuXG4gICAgICAgIGJnbToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9XG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuXG4gICAgICAgIHZhciBvID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiZ2FtZUNvbmZpZ1wiKTtcblxuICAgICAgICBpZiAobyAhPSBudWxsICYmIG8gIT0gdW5kZWZpbmVkICYmIG8gIT0gXCJcIiAmJiBvICE9IFwiXFxcIlxcXCJcIikge1xuICAgICAgICAgICAgR2xvYmFsLmdhbWVDb25maWdTZXR0aW5nID0gSlNPTi5wYXJzZShvKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmcgPT0gbnVsbCB8fCBHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmcgPT0gdW5kZWZpbmVkIHx8IEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZyA9PSBcIlwiKSB7XG4gICAgICAgICAgICBHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmcgPSByZXF1aXJlKFwiZ2FtZUNvbmZpZ1NldHRpbmdcIikuZ2FtZUNvbmZpZ1NldHRpbmc7XG4gICAgICAgIH1cbiAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcgPSBHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmc7XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG5cbiAgICBwbGF5TXVzaWM6IGZ1bmN0aW9uIHBsYXlNdXNpYygpIHtcbiAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcgPSBHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmc7XG4gICAgICAgIGlmIChnYW1lQ29uZmlnU2V0dGluZy5tdXNpYyA9PSBcIjFcIikge1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheU11c2ljKHRoaXMuYmdtLCB0cnVlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgc3RvcE11c2ljOiBmdW5jdGlvbiBzdG9wTXVzaWMoKSB7XG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnN0b3BNdXNpYygpO1xuICAgIH0sXG5cbiAgICBwYXVzZU11c2ljOiBmdW5jdGlvbiBwYXVzZU11c2ljKCkge1xuICAgICAgICBjYy5hdWRpb0VuZ2luZS5wYXVzZU11c2ljKCk7XG4gICAgfSxcblxuICAgIHJlc3VtZU11c2ljOiBmdW5jdGlvbiByZXN1bWVNdXNpYygpIHtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucmVzdW1lTXVzaWMoKTtcbiAgICB9LFxuXG4gICAgX3BsYXlTRlg6IGZ1bmN0aW9uIF9wbGF5U0ZYKGNsaXApIHtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdChjbGlwLCBmYWxzZSk7XG4gICAgfSxcblxuICAgIHBsYXlXaW46IGZ1bmN0aW9uIHBsYXlXaW4oKSB7XG4gICAgICAgIHRoaXMuX3BsYXlTRlgodGhpcy53aW5BdWRpbyk7XG4gICAgfSxcblxuICAgIHBsYXlMb3NlOiBmdW5jdGlvbiBwbGF5TG9zZSgpIHtcbiAgICAgICAgdGhpcy5fcGxheVNGWCh0aGlzLmxvc2VBdWRpbyk7XG4gICAgfSxcblxuICAgIHBsYXlDYXJkOiBmdW5jdGlvbiBwbGF5Q2FyZCgpIHtcbiAgICAgICAgdGhpcy5fcGxheVNGWCh0aGlzLmNhcmRBdWRpbyk7XG4gICAgfSxcblxuICAgIHBsYXlDaGlwczogZnVuY3Rpb24gcGxheUNoaXBzKCkge1xuICAgICAgICB0aGlzLl9wbGF5U0ZYKHRoaXMuY2hpcHNBdWRpbyk7XG4gICAgfSxcblxuICAgIHBsYXlCdXR0b246IGZ1bmN0aW9uIHBsYXlCdXR0b24oKSB7XG4gICAgICAgIHRoaXMuX3BsYXlTRlgodGhpcy5idXR0b25BdWRpbyk7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc1NjE5NEg2RnhsTjRwaWd1dVRsWW81SicsICdCdXR0b25TY2FsZXInKTtcbi8vIHNjcmlwdC91aS9CdXR0b25TY2FsZXIuanNcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBwcmVzc2VkU2NhbGU6IDEsXG4gICAgICAgIHRyYW5zRHVyYXRpb246IDBcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgdmFyIGF1ZGlvTW5nID0gY2MuZmluZCgnU2NyaXB0UGxheUJnbS9BdWRpb01uZycpIHx8IGNjLmZpbmQoJ1NjcmlwdC9BdWRpb01uZycpO1xuICAgICAgICBpZiAoYXVkaW9NbmcpIHtcbiAgICAgICAgICAgIGF1ZGlvTW5nID0gYXVkaW9NbmcuZ2V0Q29tcG9uZW50KCdBdWRpb01uZycpO1xuICAgICAgICB9XG4gICAgICAgIHNlbGYuaW5pdFNjYWxlID0gdGhpcy5ub2RlLnNjYWxlO1xuICAgICAgICBzZWxmLmJ1dHRvbiA9IHNlbGYuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgIHNlbGYuc2NhbGVEb3duQWN0aW9uID0gY2Muc2NhbGVUbyhzZWxmLnRyYW5zRHVyYXRpb24sIHNlbGYucHJlc3NlZFNjYWxlKTtcbiAgICAgICAgc2VsZi5zY2FsZVVwQWN0aW9uID0gY2Muc2NhbGVUbyhzZWxmLnRyYW5zRHVyYXRpb24sIHNlbGYuaW5pdFNjYWxlKTtcbiAgICAgICAgZnVuY3Rpb24gb25Ub3VjaERvd24oZXZlbnQpIHtcbiAgICAgICAgICAgIHRoaXMuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgICAgIGlmIChhdWRpb01uZykgYXVkaW9NbmcucGxheUJ1dHRvbigpO1xuICAgICAgICAgICAgdGhpcy5ydW5BY3Rpb24oc2VsZi5zY2FsZURvd25BY3Rpb24pO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG9uVG91Y2hVcChldmVudCkge1xuICAgICAgICAgICAgdGhpcy5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICAgICAgdGhpcy5ydW5BY3Rpb24oc2VsZi5zY2FsZVVwQWN0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm5vZGUub24oJ3RvdWNoc3RhcnQnLCBvblRvdWNoRG93biwgdGhpcy5ub2RlKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKCd0b3VjaGVuZCcsIG9uVG91Y2hVcCwgdGhpcy5ub2RlKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKCd0b3VjaGNhbmNlbCcsIG9uVG91Y2hVcCwgdGhpcy5ub2RlKTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2JkMmRmaUdrZnhDRWJncm5rVWxZV2kwJywgJ0RhdGFUaW1lJyk7XG4vLyBzY3JpcHQvdWkvRGF0YVRpbWUuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG5cbiAgICAgICAgdGltZUxhYmxlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICAvL3Nob3cgdGltZVxuICAgICAgICB2YXIgZGF0ZVRpbWVVcHRlID0gZnVuY3Rpb24gZGF0ZVRpbWVVcHRlKCkge1xuICAgICAgICAgICAgdmFyIGN1cnJlbnRkYXRlID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgIHZhciBob3VyID0gY3VycmVudGRhdGUuZ2V0SG91cnMoKSArIFwiOlwiO1xuICAgICAgICAgICAgdmFyIG1pbiA9IGN1cnJlbnRkYXRlLmdldE1pbnV0ZXMoKSArIFwiXCI7XG4gICAgICAgICAgICB2YXIgc2Vjb25kID0gY3VycmVudGRhdGUuZ2V0U2Vjb25kcygpICsgXCJcIjtcblxuICAgICAgICAgICAgaWYgKG1pbi5sZW5ndGggPT0gMSkge1xuICAgICAgICAgICAgICAgIG1pbiA9IFwiMFwiICsgbWluO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNlY29uZC5sZW5ndGggPT0gMSkge1xuICAgICAgICAgICAgICAgIHNlY29uZCA9IFwiMFwiICsgc2Vjb25kO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIGN1cnJlbnRUaWVtID0gaG91ciArIG1pbjtcblxuICAgICAgICAgICAgdmFyIGxhYmxlID0gdGhpcy50aW1lTGFibGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgICAgIGxhYmxlLnN0cmluZyA9IGN1cnJlbnRUaWVtO1xuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZGF0ZVRpbWVVcHRlLCAxKTtcbiAgICB9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdlODg3OHVlWExKTFVZMUxacFVQWmRFUycsICdHYW1lTW9kZUFjdGlvblNjcmlwdCcpO1xuLy8gc2NyaXB0L2NvbnRyb2xsZXJzL0dhbWVNb2RlQWN0aW9uU2NyaXB0LmpzXG5cbnZhciBpbmZvVGV4dE5vZGU7XG52YXIgZ2FtZU1vZGU7XG52YXIgZmFuQXJyYXkgPSBbXTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBtb2RlSW5mb1JpZ2h0UmljaFRleHQ6IGNjLk5vZGUsXG4gICAgICAgIHppTW9KaWFEaTogY2MuTm9kZSxcbiAgICAgICAgemlNb0ppYUZhbjogY2MuTm9kZSxcbiAgICAgICAgemlNb0h1OiBjYy5Ob2RlLFxuICAgICAgICBkaWFuUGFvSHU6IGNjLk5vZGUsXG4gICAgICAgIGh1YW5TYW5aaGFuZzogY2MuTm9kZSxcbiAgICAgICAgZGlhbkdhbmdIdWFfZGlhblBhbzogY2MuTm9kZSxcbiAgICAgICAgZGlhbkdhbmdIdWFfemlNbzogY2MuTm9kZSxcbiAgICAgICAgZGFpMTlKaWFuZ0R1aTogY2MuTm9kZSxcbiAgICAgICAgbWVuZ1FpbmdaaG9uZ1poYW5nOiBjYy5Ob2RlLFxuICAgICAgICB0aWFuRGlIdTogY2MuTm9kZSxcbiAgICAgICAgZmFuMjogY2MuTm9kZSxcbiAgICAgICAgZmFuMzogY2MuTm9kZSxcbiAgICAgICAgZmFuNDogY2MuTm9kZSxcbiAgICAgICAgZmFuNjogY2MuTm9kZSxcbiAgICAgICAgcm91bmRDb3VudDQ6IGNjLk5vZGUsXG4gICAgICAgIHJvdW5kQ291bnQ4OiBjYy5Ob2RlLFxuICAgICAgICBnYW1lUGVvcGxlTnVtYmVyOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICBmYW5BcnJheSA9IFsyLCAzLCA0LCA2XTtcbiAgICAgICAgaW5mb1RleHROb2RlID0gdGhpcy5tb2RlSW5mb1JpZ2h0UmljaFRleHQuZ2V0Q29tcG9uZW50KGNjLlJpY2hUZXh0KTtcbiAgICAgICAgZ2FtZU1vZGUgPSByZXF1aXJlKFwiZ2FtZU1vZGVcIikuZ2FtZU1vZGU7XG4gICAgICAgIGlmIChHbG9iYWwuZ2FtZU1vZGUgIT0gbnVsbCkge1xuICAgICAgICAgICAgZ2FtZU1vZGUgPSBHbG9iYWwuZ2FtZU1vZGU7XG4gICAgICAgIH1cbiAgICAgICAgZ2FtZU1vZGUuZ2FtZVBlb3BsZU51bWJlciA9IDQ7XG4gICAgICAgIHRoaXMuaW5pdGFsR2FtZU1vZGVVSUJ5TW9kZURhdGEoKTtcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcblxuICAgIHh1ZVpoYW5EYW9EaTogZnVuY3Rpb24geHVlWmhhbkRhb0RpKCkge1xuICAgICAgICBpbmZvVGV4dE5vZGUuc3RyaW5nID0gXCLooYDmiJjliLDlupXvvJrooYDmiJjpurvlsIbljbPmjIfigJzooYDmiJjliLDlupXigJ3njqnms5XvvIzmjIcx5a626IOh5LqG5bm25LiN57uT5p2f6K+l5bGA77yM6ICM5piv5pyq6IOh55qE546p5a6257un57ut5omT77yM55u05Yiw5pyJM+WutumDveiDoeaIluiAheS9meS4i+eahOeOqeWutua1geWxgOOAglwiO1xuICAgICAgICBnYW1lTW9kZS5nYW1lUGVvcGxlTnVtYmVyID0gXCI0XCI7XG4gICAgfSxcbiAgICB4dWVMaXVDaGVuZ0hlOiBmdW5jdGlvbiB4dWVMaXVDaGVuZ0hlKCkge1xuICAgICAgICBpbmZvVGV4dE5vZGUuc3RyaW5nID0gXCLooYDmtYHmiJDmsrPvvJrmraTop4TliJnlkozooYDmiJjln7rmnKzkuIDmoLfvvIzkuI3lhYHorrjlpKnog6HvvIzlv4XpobvmjaLkuInlvKDjgIJcIjtcbiAgICAgICAgZ2FtZU1vZGUuZ2FtZVBlb3BsZU51bWJlciA9IFwiNFwiO1xuICAgIH0sXG4gICAgc2FuUmVuTWFoSm9uZzogZnVuY3Rpb24gc2FuUmVuTWFoSm9uZygpIHtcbiAgICAgICAgaW5mb1RleHROb2RlLnN0cmluZyA9IFwi5LiJ5Lq66bq75bCG77ya5q2k6KeE5YiZ5ZKM6KGA5oiY5Z+65pys5LiA5qC377yM5Y+q5piv5Lq65pWw5Li65LiJ5Lq65Y2z5Y+v5byA5aeL44CCXCI7XG4gICAgICAgIGdhbWVNb2RlLmdhbWVQZW9wbGVOdW1iZXIgPSBcIjNcIjtcbiAgICB9LFxuICAgIGVyUmVuTWFoSm9uZzogZnVuY3Rpb24gZXJSZW5NYWhKb25nKCkge1xuICAgICAgICBpbmZvVGV4dE5vZGUuc3RyaW5nID0gXCLkuozkurrpurvlsIbvvJrmraTop4TliJnlkozooYDmiJjln7rmnKzkuIDmoLfvvIzlj6rmmK/kurrmlbDkuLrkuozkurrljbPlj6/lvIDlp4vjgIJcIjtcbiAgICAgICAgZ2FtZU1vZGUuZ2FtZVBlb3BsZU51bWJlciA9IFwiMlwiO1xuICAgIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tb3B0aW9uIHNlbGVjdCBmdW5jdGlvbi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vemlNb0ppYWRpVG9nZ2xlLHppTW9KaWFkaVRvZ2dsZSx6aU1vSmlhZGlUb2dnbGUsZGFpWWFvaml1VG9nZ2xlLG1lblFpbmdUb2dnbGUsdGlhbkRpSHVUb2dnbGUsZmFuMlRvZ2dsZSxmYW4zVG9nZ2xlLGZhbjRUb2dnbGUsZmFuNlRvZ2dsZVxuICAgIC8vanU4VG9nZ2xlLGp1NFRvZ2dsZSxcbiAgICBzZXRHYW1lTW9kZTogZnVuY3Rpb24gc2V0R2FtZU1vZGUocG9ycGVydGl0ZXNOYW1lLCB0b2cpIHtcbiAgICAgICAgaWYgKHRvZyAhPSBudWxsKSB7XG4gICAgICAgICAgICAvLyBpZiAocG9ycGVydGl0ZXNOYW1lID09IFwiemlNb0ppYWRpVG9nZ2xlXCIpIHtcbiAgICAgICAgICAgIGlmICh0b2cuaXNDaGVja2VkKSB7XG4gICAgICAgICAgICAgICAgZXZhbChcImdhbWVNb2RlLlwiICsgcG9ycGVydGl0ZXNOYW1lICsgXCIgPSAnMSdcIik7XG4gICAgICAgICAgICAgICAgaWYgKHBvcnBlcnRpdGVzTmFtZSA9PSBcInppTW9KaWFEaVwiKSB7XG4gICAgICAgICAgICAgICAgICAgIGV2YWwoXCJnYW1lTW9kZS56aU1vSmlhRmFuID0gJzAnXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocG9ycGVydGl0ZXNOYW1lID09IFwiemlNb0ppYUZhblwiKSB7XG4gICAgICAgICAgICAgICAgICAgIGV2YWwoXCJnYW1lTW9kZS56aU1vSmlhRGkgPSAnMCdcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwb3JwZXJ0aXRlc05hbWUgPT0gXCJkaWFuR2FuZ0h1YV9kaWFuUGFvXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZhbChcImdhbWVNb2RlLmRpYW5HYW5nSHVhX3ppTW8gPSAnMCdcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwb3JwZXJ0aXRlc05hbWUgPT0gXCJkaWFuR2FuZ0h1YV96aU1vXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZhbChcImdhbWVNb2RlLmRpYW5HYW5nSHVhX2RpYW5QYW8gPSAnMCdcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwb3JwZXJ0aXRlc05hbWUuaW5kZXhPZihcImZhblwiKSA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwb3JwZXJ0aXRlc05hbWUgPT0gXCJmYW4yXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhbkFycmF5LnNwbGljZSgwLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAocG9ycGVydGl0ZXNOYW1lID09IFwiZmFuM1wiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmYW5BcnJheS5zcGxpY2UoMSwgMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHBvcnBlcnRpdGVzTmFtZSA9PSBcImZhbjRcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmFuQXJyYXkuc3BsaWNlKDIsIDEpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChwb3JwZXJ0aXRlc05hbWUgPT0gXCJmYW42XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhbkFycmF5LnNwbGljZSgzLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGZhbkFycmF5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBldmFsKFwiZ2FtZU1vZGUuZmFuXCIgKyBmYW5BcnJheVtpXSArIFwiID0gJzAnXCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHBvcnBlcnRpdGVzTmFtZSA9PSBcInJvdW5kQ291bnQ0XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZhbChcImdhbWVNb2RlLnJvdW5kQ291bnQ4ID0gJzAnXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocG9ycGVydGl0ZXNOYW1lID09IFwicm91bmRDb3VudDhcIikge1xuICAgICAgICAgICAgICAgICAgICBldmFsKFwiZ2FtZU1vZGUucm91bmRDb3VudDQgPSAnMCdcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBldmFsKFwiZ2FtZU1vZGUuXCIgKyBwb3JwZXJ0aXRlc05hbWUgKyBcIiA9ICcwJ1wiKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy99XG4gICAgICAgIH1cblxuICAgICAgICBHbG9iYWwuZ2FtZU1vZGUgPSBnYW1lTW9kZTtcbiAgICB9LFxuICAgIG9wdGlvblNlbGVjdEZ1bmN0aW9uOiBmdW5jdGlvbiBvcHRpb25TZWxlY3RGdW5jdGlvbihldmVudCkge1xuICAgICAgICB2YXIgbm9kZSA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgY2MubG9nKG5vZGUubmFtZSk7XG4gICAgICAgIHZhciBwYXJ0ZW50Tm9kZSA9IG5vZGUucGFyZW50O1xuICAgICAgICB2YXIgdG9nID0gcGFydGVudE5vZGUuZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSk7XG4gICAgICAgIGlmICh0b2cgIT0gbnVsbCkge1xuICAgICAgICAgICAgY2MubG9nKFwicGFydGVudE5vZGU6XCIgKyBwYXJ0ZW50Tm9kZS5uYW1lICsgXCItXCIgKyB0b2cuaXNDaGVja2VkKTtcbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwiemlNb0ppYWRpVG9nZ2xlXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVNb2RlKFwiemlNb0ppYURpXCIsIHRvZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocGFydGVudE5vZGUubmFtZSA9PSBcInppTW9KaWFGYW5Ub2dnbGVcIikge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0R2FtZU1vZGUoXCJ6aU1vSmlhRmFuXCIsIHRvZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocGFydGVudE5vZGUubmFtZSA9PSBcImRpYW5HYW5nRGlhblBhb1RvZ2dsZVwiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRHYW1lTW9kZShcImRpYW5HYW5nSHVhX2RpYW5QYW9cIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwiaHVhblNhblpoYW5nVG9nZ2xlXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVNb2RlKFwiaHVhblNhblpoYW5nXCIsIHRvZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocGFydGVudE5vZGUubmFtZSA9PSBcImRpYW5HYW5nWmlNb1RvZ2dsZVwiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRHYW1lTW9kZShcImRpYW5HYW5nSHVhX3ppTW9cIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwiZGFpWWFvaml1VG9nZ2xlXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVNb2RlKFwiZGFpMTlKaWFuZ0R1aVwiLCB0b2cpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHBhcnRlbnROb2RlLm5hbWUgPT0gXCJtZW5RaW5nVG9nZ2xlXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVNb2RlKFwibWVuZ1FpbmdaaG9uZ1poYW5nXCIsIHRvZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocGFydGVudE5vZGUubmFtZSA9PSBcInRpYW5EaUh1VG9nZ2xlXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVNb2RlKFwidGlhbkRpSHVcIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwiZmFuMlRvZ2dsZVwiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRHYW1lTW9kZShcImZhbjJcIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwiZmFuM1RvZ2dsZVwiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRHYW1lTW9kZShcImZhbjNcIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwiZmFuNFRvZ2dsZVwiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRHYW1lTW9kZShcImZhbjRcIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwiZmFuNlRvZ2dsZVwiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRHYW1lTW9kZShcImZhbjZcIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwianU0VG9nZ2xlXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVNb2RlKFwicm91bmRDb3VudDRcIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwYXJ0ZW50Tm9kZS5uYW1lID09IFwianU4VG9nZ2xlXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldEdhbWVNb2RlKFwicm91bmRDb3VudDhcIiwgdG9nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuaW5pdGFsR2FtZU1vZGVVSUJ5TW9kZURhdGEoKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBpbml0YWxHYW1lTW9kZVVJQnlNb2RlRGF0YTogZnVuY3Rpb24gaW5pdGFsR2FtZU1vZGVVSUJ5TW9kZURhdGEoKSB7XG4gICAgICAgIGlmIChnYW1lTW9kZS56aU1vSmlhRGkgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICAgICAgICB0aGlzLnppTW9KaWFEaS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy56aU1vSmlhRGkuZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSkuaXNDaGVja2VkID0gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZ2FtZU1vZGUuemlNb0ppYUZhbiArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHRoaXMuemlNb0ppYUZhbi5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy56aU1vSmlhRmFuLmdldENvbXBvbmVudChjYy5Ub2dnbGUpLmlzQ2hlY2tlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIC8vIGlmIChnYW1lTW9kZS56aU1vSHUgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICAgIC8vICAgICB0aGlzLnppTW9IdS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlXG4gICAgICAgIC8vIH0gZWxzZSB7XG4gICAgICAgIC8vICAgICB0aGlzLnppTW9IdS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSBmYWxzZVxuICAgICAgICAvLyB9XG4gICAgICAgIC8vIGlmIChnYW1lTW9kZS5kaWFuUGFvSHUgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICAgIC8vICAgICB0aGlzLmRpYW5QYW9IdS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlXG4gICAgICAgIC8vIH0gZWxzZSB7XG4gICAgICAgIC8vICAgICB0aGlzLmRpYW5QYW9IdS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSBmYWxzZVxuICAgICAgICAvLyB9XG4gICAgICAgIC8vIGlmIChnYW1lTW9kZS5odWFuU2FuWmhhbmcgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICAgIC8vICAgICB0aGlzLmh1YW5TYW5aaGFuZy5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlXG4gICAgICAgIC8vIH0gZWxzZSB7XG4gICAgICAgIC8vICAgICB0aGlzLmh1YW5TYW5aaGFuZy5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSBmYWxzZVxuICAgICAgICAvLyB9XG4gICAgICAgIGlmIChnYW1lTW9kZS5kaWFuR2FuZ0h1YV9kaWFuUGFvICsgXCJcIiA9PSBcIjFcIikge1xuICAgICAgICAgICAgdGhpcy5kaWFuR2FuZ0h1YV9kaWFuUGFvLmdldENvbXBvbmVudChjYy5Ub2dnbGUpLmlzQ2hlY2tlZCA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmRpYW5HYW5nSHVhX2RpYW5QYW8uZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSkuaXNDaGVja2VkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGdhbWVNb2RlLmRpYW5HYW5nSHVhX3ppTW8gKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICAgICAgICB0aGlzLmRpYW5HYW5nSHVhX3ppTW8uZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSkuaXNDaGVja2VkID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuZGlhbkdhbmdIdWFfemlNby5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZ2FtZU1vZGUuZGFpMTlKaWFuZ0R1aSArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHRoaXMuZGFpMTlKaWFuZ0R1aS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5kYWkxOUppYW5nRHVpLmdldENvbXBvbmVudChjYy5Ub2dnbGUpLmlzQ2hlY2tlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChnYW1lTW9kZS5tZW5nUWluZ1pob25nWmhhbmcgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICAgICAgICB0aGlzLm1lbmdRaW5nWmhvbmdaaGFuZy5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5tZW5nUWluZ1pob25nWmhhbmcuZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSkuaXNDaGVja2VkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGdhbWVNb2RlLnRpYW5EaUh1ICsgXCJcIiA9PSBcIjFcIikge1xuICAgICAgICAgICAgdGhpcy50aWFuRGlIdS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy50aWFuRGlIdS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZ2FtZU1vZGUuZmFuMiArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHRoaXMuZmFuMi5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5mYW4yLmdldENvbXBvbmVudChjYy5Ub2dnbGUpLmlzQ2hlY2tlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNjLmxvZyhcImdhbWVNb2RlLmZhbjM6XCIgKyBnYW1lTW9kZS5mYW4zKTtcbiAgICAgICAgaWYgKGdhbWVNb2RlLmZhbjMgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICAgICAgICB0aGlzLmZhbjMuZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSkuaXNDaGVja2VkID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuZmFuMy5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZ2FtZU1vZGUuZmFuNCArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHRoaXMuZmFuNC5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5mYW40LmdldENvbXBvbmVudChjYy5Ub2dnbGUpLmlzQ2hlY2tlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChnYW1lTW9kZS5yb3VuZENvdW50NCArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHRoaXMucm91bmRDb3VudDQuZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSkuaXNDaGVja2VkID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucm91bmRDb3VudDQuZ2V0Q29tcG9uZW50KGNjLlRvZ2dsZSkuaXNDaGVja2VkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGdhbWVNb2RlLnJvdW5kQ291bnQ4ICsgXCJcIiA9PSBcIjFcIikge1xuICAgICAgICAgICAgdGhpcy5yb3VuZENvdW50OC5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5yb3VuZENvdW50OC5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKS5pc0NoZWNrZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gc2V0dGluZyBhbGwgdmFsdWVzIGludG8gIGdvYmFsIG1vZGUgb2JqZWN0IGFuZCBzd3RpY2ggdG8gdGFibGUgc2VuY2UuXG4gICAgYnVpbGROZXdSb29tOiBmdW5jdGlvbiBidWlsZE5ld1Jvb20oKSB7XG4gICAgICAgIC8vR2xvYmFsLmdhbWVNb2RlID0gZ2FtZU1vZGU7XG4gICAgICAgIC8vY2MuZGlyZWN0b3IubG9hZFNjZW5lKCd0YWJsZScpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnODU3ZjBmZXlWdEFpNnhTVXROR1RGQ1gnLCAnR2FtZU1vZGVPcHRpb25Db250cm9sbGVyJyk7XG4vLyBzY3JpcHQvY29udHJvbGxlcnMvR2FtZU1vZGVPcHRpb25Db250cm9sbGVyLmpzXG5cbnZhciBnYW1lTW9kZU1vZGVsID0gcmVxdWlyZSgnZ2FtZU1vZGUnKS5nYW1lTW9kZTtcbnZhciBjaGVja0xhYmxlQ29sb3IgPSBuZXcgY2MuQ29sb3IoMjMxLCAyOCwgNzcpO1xudmFyIG5vQ2hlY2tMYWJsZUNvbG9yID0gbmV3IGNjLkNvbG9yKDEyMSwgODEsIDQ0KTtcbnZhciBnYW1lTW9kZUxheWVyO1xudmFyIGJ0bkxpc3RMYXllcjtcbnZhciB0b3BJbmZvTGF5ZXI7XG5jYy5DbGFzcyh7XG4gIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgcHJvcGVydGllczoge1xuICAgIC8vIGZvbzoge1xuICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgIC8vIH0sXG4gICAgLy8gLi4uXG4gICAgbm9DaGVja0JveEJnOiBjYy5TcHJpdGVGcmFtZSxcbiAgICBDaGVja0JveEJnOiBjYy5TcHJpdGVGcmFtZVxuICB9LFxuXG4gIC8vIGdhbWVNb2RlTW9kZWw6Y2Muc2NyaXB0XG4gIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICBnYW1lTW9kZUxheWVyID0gY2MuZmluZChcIkNhbnZhcy9nYW1lTW9kZVNlbGVjdExheWVyL21haW5TZWxlY3RNb2RlL21haW5Nb2RlT3B0aW9uL0dhbWVNb2RlT3B0aW9uMS9MaXN0TGF5b3V0XCIpO1xuICAgIGJ0bkxpc3RMYXllciA9IGNjLmZpbmQoXCJDYW52YXMvZ2FtZU1vZGVTZWxlY3RMYXllci9tYWluU2VsZWN0TW9kZS9CdG5MaXN0XCIpO1xuICAgIHRvcEluZm9MYXllciA9IGNjLmZpbmQoXCJDYW52YXMvdG9wSW5mb0xheWVyXCIpO1xuICAgIGdhbWVNb2RlTW9kZWwuemlNb0ppYURpID0gMTtcbiAgICBnYW1lTW9kZU1vZGVsLnppTW9IdSA9IDA7XG4gICAgZ2FtZU1vZGVNb2RlbC5odWFuU2FuWmhhbmcgPSAwO1xuICAgIGdhbWVNb2RlTW9kZWwuemlNb0ppYUZhbiA9IDA7XG4gICAgZ2FtZU1vZGVNb2RlbC5kaWFuUGFvSHUgPSAwO1xuICAgIGdhbWVNb2RlTW9kZWwuZGlhbkdhbmdIdWFfZGlhblBhbyA9IDA7XG4gICAgZ2FtZU1vZGVNb2RlbC5kaWFuR2FuZ0h1YV96aU1vID0gMDtcbiAgICBnYW1lTW9kZU1vZGVsLmRhaTE5SmlhbmdEdWkgPSAwO1xuICAgIGdhbWVNb2RlTW9kZWwubWVuZ1FpbmdaaG9uZ1poYW5nID0gMDtcbiAgICBnYW1lTW9kZU1vZGVsLnRpYW5EaUh1ID0gMDtcbiAgICBnYW1lTW9kZU1vZGVsLmZhbjIgPSAwO1xuICAgIGdhbWVNb2RlTW9kZWwuZmFuMyA9IDA7XG4gICAgZ2FtZU1vZGVNb2RlbC5mYW40ID0gMDtcbiAgICBnYW1lTW9kZU1vZGVsLnJvdW5kQ291bnQ0ID0gMDtcbiAgICBnYW1lTW9kZU1vZGVsLnJvdW5kQ291bnQ4ID0gMDtcbiAgICAvL1xuICAgIHRoaXMuaW5pdGxaaU1vSmlhRGkoKTtcbiAgfSxcblxuICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gIC8vIH0sXG4gIC8qXG4gIG5vcm1hbFNwcml0ZSBTcHJpdGVGcmFtZVxuICDmma7pgJrnirbmgIHkuIvmjInpkq7miYDmmL7npLrnmoQgU3ByaXRlIOOAglxuICBwcmVzc2VkU3ByaXRlIFNwcml0ZUZyYW1lXG4gIOaMieS4i+eKtuaAgeaXtuaMiemSruaJgOaYvuekuueahCBTcHJpdGUg44CCXG4gIGhvdmVyU3ByaXRlIFNwcml0ZUZyYW1lXG4gIOaCrOWBnOeKtuaAgeS4i+aMiemSruaJgOaYvuekuueahCBTcHJpdGUg44CCXG4gIGRpc2FibGVkU3ByaXRlIFNwcml0ZUZyYW1lXG4gICAgKi9cbiAgaW5pdGxaaU1vSmlhRGk6IGZ1bmN0aW9uIGluaXRsWmlNb0ppYURpKCkge1xuXG4gICAgLy92YXIgYnRuPSBnYW1lTW9kZUxheWVyLmdldENoaWxkQnlOYW1lKFwiemlib2ppYWRpQnRuXCIpO1xuICAgIHZhciBidG4gPSBjYy5maW5kKFwicm93T3B0aW9uMS96aWJvamlhZGlCdG5cIiwgZ2FtZU1vZGVMYXllcik7XG4gICAgdmFyIGJ0bkJ0biA9IGJ0bi5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICB2YXIgYnRuTGFibGUgPSBjYy5maW5kKFwicm93T3B0aW9uMS96aU1vSmlhRGlMYWJlbFwiLCBnYW1lTW9kZUxheWVyKTtcbiAgICBpZiAoZ2FtZU1vZGVNb2RlbC56aU1vSmlhRGkgPT0gMSkge1xuICAgICAgYnRuQnRuLm5vcm1hbFNwcml0ZSA9IHRoaXMuQ2hlY2tCb3hCZztcbiAgICAgIGJ0bkJ0bi5wcmVzc2VkU3ByaXRlID0gdGhpcy5DaGVja0JveEJnO1xuICAgICAgYnRuQnRuLmhvdmVyU3ByaXRlID0gdGhpcy5DaGVja0JveEJnO1xuICAgICAgYnRuTGFibGUuY29sb3IgPSBjaGVja0xhYmxlQ29sb3I7XG4gICAgfTtcblxuICAgIGZvciAodmFyIGkgPSAyOyBpIDwgNjsgaSsrKSB7XG4gICAgICB2YXIgYnRuTGF5ZXJOYW1lID0gXCJCdG5MYXlcIiArIGk7XG4gICAgICB2YXIgYXJyb3dOYW1lID0gXCJBcnJvd1wiICsgaTtcbiAgICAgIHZhciBhcnJvdyA9IGNjLmZpbmQoXCJcIiArIGJ0bkxheWVyTmFtZSArIFwiL1wiICsgYXJyb3dOYW1lLCBidG5MaXN0TGF5ZXIpO1xuICAgICAgLy9jb25zb2xlLmxvZyhcImFycm93OlwiK1wiQ2FudmFzL2dhbWVNb2RlU2VsZWN0TGF5ZXIvbWFpblNlbGVjdE1vZGUvQnRuTGlzdC9cIitidG5MYXllck5hbWUrXCIvXCIrYXJyb3dOYW1lKTtcbiAgICAgIGFycm93LmFjdGl2ZSA9IGZhbHNlO1xuICAgIH1cbiAgICAvL2Rpc2FibGUgZGlhblBhb0h1XG4gICAgdmFyIGRpYW5QYW9IdWJ0biA9IGNjLmZpbmQoXCJyb3dPcHRpb24xL2RpYW5QYW9IdUJ0blwiLCBnYW1lTW9kZUxheWVyKTtcbiAgICB2YXIgZGlhblBhb0h1TGFibGUgPSBjYy5maW5kKFwicm93T3B0aW9uMS9kaWFuUGFvSHVMYWJlbFwiLCBnYW1lTW9kZUxheWVyKTtcbiAgICB0aGlzLmRpc2FibGVCdG5BbmRMYWJsZShkaWFuUGFvSHVidG4sIGRpYW5QYW9IdUxhYmxlKTtcbiAgICBkaWFuUGFvSHVidG4gPSBjYy5maW5kKFwicm93T3B0aW9uMi96aU1vSHVCdG5cIiwgZ2FtZU1vZGVMYXllcik7XG4gICAgZGlhblBhb0h1TGFibGUgPSBjYy5maW5kKFwicm93T3B0aW9uMi96aU1vSHVMYWJlbFwiLCBnYW1lTW9kZUxheWVyKTtcbiAgICB0aGlzLmRpc2FibGVCdG5BbmRMYWJsZShkaWFuUGFvSHVidG4sIGRpYW5QYW9IdUxhYmxlKTtcbiAgfSxcbiAgLy/oh6rmkbjliqDlupUgb3B0aW9uXG4gIHVwZGF0ZVppTW9KaWFEaTogZnVuY3Rpb24gdXBkYXRlWmlNb0ppYURpKCkge1xuICAgIGNvbnNvbGUubG9nKFwiZ2FtZU1vZGVNb2RlbDpcIiArIGdhbWVNb2RlTW9kZWwuemlNb0ppYURpKTtcbiAgICAvL2NjLmxvZyhjb21wLnV1aWQpO1xuICAgIHZhciBidG4gPSBjYy5maW5kKFwicm93T3B0aW9uMS96aWJvamlhZGlCdG5cIiwgZ2FtZU1vZGVMYXllcik7XG4gICAgdmFyIGJ0bkJ0biA9IGJ0bi5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcblxuICAgIC8vIHZhciBwYXJlbnQ9YnRuLmdldHBhXG4gICAgdmFyIGJ0bkxhYmxlID0gY2MuZmluZChcInJvd09wdGlvbjEvemlNb0ppYURpTGFiZWxcIiwgZ2FtZU1vZGVMYXllcik7XG4gICAgZ2FtZU1vZGVNb2RlbC56aU1vSmlhRGkgPSB0aGlzLnVwZGF0ZVV0aWxzQnRuQW5kTGFibGUoYnRuQnRuLCBidG5MYWJsZSwgZ2FtZU1vZGVNb2RlbC56aU1vSmlhRGkpO1xuICB9LFxuICB1cGRhdGVaaU1vSmlhRmFuOiBmdW5jdGlvbiB1cGRhdGVaaU1vSmlhRmFuKCkge1xuICAgIGNvbnNvbGUubG9nKFwiZ2FtZU1vZGVNb2RlbDpcIiArIGdhbWVNb2RlTW9kZWwuemlNb0ppYUZhbik7XG4gICAgLy9jYy5sb2coY29tcC51dWlkKTtcbiAgICB2YXIgYnRuID0gY2MuZmluZChcInJvd09wdGlvbjEvemlib2ppYWZhbkJ0blwiLCBnYW1lTW9kZUxheWVyKTtcbiAgICB2YXIgYnRuQnRuID0gYnRuLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgIHZhciBidG5MYWJsZSA9IGNjLmZpbmQoXCJyb3dPcHRpb24xL3ppTW9KaWFGYW5MYWJlbFwiLCBnYW1lTW9kZUxheWVyKTtcbiAgICBnYW1lTW9kZU1vZGVsLnppTW9KaWFGYW4gPSB0aGlzLnVwZGF0ZVV0aWxzQnRuQW5kTGFibGUoYnRuQnRuLCBidG5MYWJsZSwgZ2FtZU1vZGVNb2RlbC56aU1vSmlhRmFuKTtcbiAgfSxcbiAgdXBkYXRlRGlhbkdhbmdIdWFfZGlhblBhbzogZnVuY3Rpb24gdXBkYXRlRGlhbkdhbmdIdWFfZGlhblBhbygpIHt9LFxuICB1cGRhdGVEaWFuR2FuZ0h1YV96aU1vOiBmdW5jdGlvbiB1cGRhdGVEaWFuR2FuZ0h1YV96aU1vKCkge30sXG4gIHVwZGF0ZURhaTE5SmlhbmdEdWk6IGZ1bmN0aW9uIHVwZGF0ZURhaTE5SmlhbmdEdWkoKSB7fSxcbiAgdXBkYXRlTWVuZ1FpbmdaaG9uZ1poYW5nOiBmdW5jdGlvbiB1cGRhdGVNZW5nUWluZ1pob25nWmhhbmcoKSB7fSxcbiAgdXBkYXRlVGlhbkRpSHU6IGZ1bmN0aW9uIHVwZGF0ZVRpYW5EaUh1KCkge30sXG4gIHVwZGF0ZUZhbjI6IGZ1bmN0aW9uIHVwZGF0ZUZhbjIoKSB7fSxcbiAgdXBkYXRlRmFuMzogZnVuY3Rpb24gdXBkYXRlRmFuMygpIHt9LFxuICB1cGRhdGVGYW40OiBmdW5jdGlvbiB1cGRhdGVGYW40KCkge30sXG4gIHVwZGF0ZVJvdW5kQ291bnQ0OiBmdW5jdGlvbiB1cGRhdGVSb3VuZENvdW50NCgpIHt9LFxuICB1cGRhdGVSb3VuZENvdW50ODogZnVuY3Rpb24gdXBkYXRlUm91bmRDb3VudDgoKSB7fSxcbiAgdXBkYXRlSHVhblNhblpoYW5nOiBmdW5jdGlvbiB1cGRhdGVIdWFuU2FuWmhhbmcoKSB7fSxcbiAgdXBkYXRlWmlNb0h1OiBmdW5jdGlvbiB1cGRhdGVaaU1vSHUoKSB7fSxcbiAgdXBkYXRlRGlhblBhb0h1OiBmdW5jdGlvbiB1cGRhdGVEaWFuUGFvSHUoKSB7fSxcblxuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1VdGlscyBmdW5jdGlvbi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIHVwZGF0ZVV0aWxzQnRuQW5kTGFibGU6IGZ1bmN0aW9uIHVwZGF0ZVV0aWxzQnRuQW5kTGFibGUoYnRuQnRuLCBidG5MYWJsZSwgY29uZlZhbHVlKSB7XG4gICAgaWYgKGNvbmZWYWx1ZSA9PSAxKSB7XG4gICAgICBidG5CdG4ubm9ybWFsU3ByaXRlID0gdGhpcy5ub0NoZWNrQm94Qmc7XG4gICAgICBidG5CdG4ucHJlc3NlZFNwcml0ZSA9IHRoaXMubm9DaGVja0JveEJnO1xuICAgICAgYnRuQnRuLmhvdmVyU3ByaXRlID0gdGhpcy5ub0NoZWNrQm94Qmc7XG4gICAgICBidG5MYWJsZS5jb2xvciA9IG5vQ2hlY2tMYWJsZUNvbG9yO1xuICAgICAgcmV0dXJuIDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIGJ0bkJ0bi5ub3JtYWxTcHJpdGUgPSB0aGlzLkNoZWNrQm94Qmc7XG4gICAgICBidG5CdG4ucHJlc3NlZFNwcml0ZSA9IHRoaXMuQ2hlY2tCb3hCZztcbiAgICAgIGJ0bkJ0bi5ob3ZlclNwcml0ZSA9IHRoaXMuQ2hlY2tCb3hCZztcbiAgICAgIGJ0bkxhYmxlLmNvbG9yID0gY2hlY2tMYWJsZUNvbG9yO1xuICAgICAgcmV0dXJuIDE7XG4gICAgfVxuICB9LFxuICBkaXNhYmxlQnRuQW5kTGFibGU6IGZ1bmN0aW9uIGRpc2FibGVCdG5BbmRMYWJsZShidG5CdG4sIGJ0bkxhYmxlKSB7XG4gICAgYnRuQnRuLmFjdGl2ZSA9IGZhbHNlO1xuICAgIGJ0bkxhYmxlLmFjdGl2ZSA9IGZhbHNlO1xuICB9LFxuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1VdGlscyBmdW5jdGlvbiBlbmQtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvL0xlZnQgYnV0dG9uIG1vZGUgY2xpY2sgZnVuY3Rpb24uLi4uLi4uLi4uLlxuICAvL3ppYm9qaWFkaUJ0bix6aU1vSmlhRGlMYWJlbCx6aWJvamlhZmFuQnRuLHppTW9KaWFGYW5MYWJlbCxkaWFuUGFvSHVCdG4sZGlhblBhb0h1TGFiZWxcbiAgLy9kaWFuR2FuZ0h1YURpYW5QYW9CdG4sZGlhbkdhbmdIdWFEaWFuUGFvTGFiZWxcbiAgeHVlWmhhbkRhb0RpQnV0dG9uQ2xpY2s6IGZ1bmN0aW9uIHh1ZVpoYW5EYW9EaUJ1dHRvbkNsaWNrKCkge30sXG4gIHh1ZUxpdUNoZW5nSGVCdXR0b25DbGljazogZnVuY3Rpb24geHVlTGl1Q2hlbmdIZUJ1dHRvbkNsaWNrKCkge30sXG4gIERhb0Rhb0h1QnV0dG9uQ2xpY2s6IGZ1bmN0aW9uIERhb0Rhb0h1QnV0dG9uQ2xpY2soKSB7fSxcbiAgTmVpSmlhbmdNYUppYW5nQnV0dG9uQ2xpY2s6IGZ1bmN0aW9uIE5laUppYW5nTWFKaWFuZ0J1dHRvbkNsaWNrKCkge30sXG4gIFNhblJlbkxpYW5nRmFuZ0J1dHRvbkNsaWNrOiBmdW5jdGlvbiBTYW5SZW5MaWFuZ0ZhbmdCdXR0b25DbGljaygpIHt9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnM2U5ZjVnakVMSkJncHowNVRoVUtuOU8nLCAnR2FtZVRhYmxlQ29udHJvbGxlcicpO1xuLy8gc2NyaXB0L2NvbnRyb2xsZXJzL0dhbWVUYWJsZUNvbnRyb2xsZXIuanNcblxudmFyIGdhbWVNb2RlO1xudmFyIHVzZXJJbmZvO1xudmFyIHNlcnZlclVybDtcbnZhciBzb2NrZXQ7XG52YXIgcm9vbU51bWJlcjtcbnZhciBtZXNzYWdlRG9tYWluO1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG5cbiAgICAgICAgdGFibGVOb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyMU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHVzZXIyTm9kZTogY2MuTm9kZSxcbiAgICAgICAgdXNlcjNOb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyNE5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJSZWFkeU9LOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgdXNlclJlYWR5Tm90T2s6IGNjLlNwcml0ZUZyYW1lXG5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMudXNlcjFOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnVzZXIyTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy51c2VyM05vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcjROb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH0sXG5cbiAgICBzaG93VXNlckluZm86IGZ1bmN0aW9uIHNob3dVc2VySW5mbygpIHtcbiAgICAgICAgdmFyIHVzZXJMaXN0ID0gR2xvYmFsLnVzZXJMaXN0O1xuICAgICAgICBpZiAodXNlckxpc3QgIT0gbnVsbCAmJiB1c2VyTGlzdCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdXNlckxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgdXNlciA9IHVzZXJMaXN0W2ldO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIGluaXRhbFVzZXJJbmZvRnJvbUdvYmFsTGlzdDogZnVuY3Rpb24gaW5pdGFsVXNlckluZm9Gcm9tR29iYWxMaXN0KCkge1xuICAgICAgICB2YXIgbnVtYmVyT3JkZXIgPSBbMywgNCwgMSwgMl07XG4gICAgICAgIHZhciB1c2VyTGlzdCA9IEdsb2JhbC51c2VyTGlzdDtcbiAgICAgICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICB2YXIgaW5kZXggPSAtMTtcbiAgICAgICAgaWYgKHVzZXJMaXN0ICE9IG51bGwgJiYgdXNlckxpc3QgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB2YXIgdGVtcExpc3QgPSBbXTtcbiAgICAgICAgICAgIC8vMS5maW5kIHRoZSBzdGFydCBpbmRleFxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1c2VyTGlzdC5sZW5ndGgoKTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIHRhYmxlVXNlckluZm8gPSB1c2VyTGlzdFtpXTtcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggPCAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh1c2VySW5mby5vcGVuaWQgPT0gdGFibGVVc2VySW5mby5vcGVuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBMaXN0LnB1c2godGFibGVVc2VySW5mbyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbmRleCA9IGk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0ZW1wTGlzdC5wdXNoKHRhYmxlVXNlckluZm8pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGluZGV4ID4gMCkge1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgaW5kZXg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB0ZW1wTGlzdC5wdXNoKHVzZXJMaXN0W2ldKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vc3RhcnQgZmlsbCB0aGUgdXNlciBpbmZvIGZyb20gaW5kZXhcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGVtcExpc3QubGVuZ3RoKCk7IGkrKykge1xuICAgICAgICAgICAgICAgIHZhciBnYW1lVXNlciA9IHRlbXBMaXN0W2ldO1xuICAgICAgICAgICAgICAgIHZhciB1c2VyTm9kZU5hbWUgPSBcInVzZXJcIiArIG51bWJlck9yZGVyW2ldICsgXCJOb2RlXCI7XG4gICAgICAgICAgICAgICAgdmFyIHVzZXJOb2RlID0gY2MuZmluZCh1c2VyTm9kZU5hbWUsIHRoaXMudGFibGVOb2RlKTtcbiAgICAgICAgICAgICAgICB1c2VyTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHZhciB1c2VySW5mb05vZGUgPSBjYy5maW5kKFwidXNlckluZm9Ob2RlXCIsIHVzZXJOb2RlKTtcbiAgICAgICAgICAgICAgICB2YXIgdXNlclJlYWR5Tm9kZSA9IGNjLmZpbmQoXCJ1c2VyUmVhZHlOb2RlXCIsIHVzZXJJbmZvTm9kZSk7XG4gICAgICAgICAgICAgICAgdmFyIHJlYWR5QnV0dG9uID0gY2MuZmluZChcInJlYWR5QnV0dG9uXCIsIHVzZXJSZWFkeU5vZGUpO1xuICAgICAgICAgICAgICAgIHZhciBzID0gcmVhZHlCdXR0b24uZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgICAgICAgICAgaWYgKGdhbWVVc2VyLmdhbWVSZWFkeVN0YXR1ID09IFwiMVwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHMuc3ByaXRlRnJhbWUgPSB0aGlzLnVzZXJSZWFkeU9LO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHMuc3ByaXRlRnJhbWUgPSB0aGlzLnVzZXJSZWFkeU5vdE9rO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc3NmVlYXVpWDRkT3dwNUV5S1BGTjVsTCcsICdHYW1lVGFibGVOZXRXb3JrJyk7XG4vLyBzY3JpcHQvc2VydmljZS9HYW1lVGFibGVOZXRXb3JrLmpzXG5cbnZhciBjbGllbnQ7XG52YXIgcm9vbU51bWJlcjtcbnZhciB1c2VySW5mbztcbnZhciBhY3Rpb25VSVNjcmlwdE5vZGU7XG52YXIgYWxlcnRNZXNzYWdlVUk7XG52YXIgc2VydmVyVXJsO1xudmFyIHNvY2tldDtcbnZhciBtZXNzYWdlRG9tYWluO1xudmFyIGNvbm5lY3RfY2FsbGJhY2s7XG52YXIgdXNlckluZm9TY3JpcHQ7XG52YXIgaHVhblNhblpoYW5nU2NyaXB0O1xudmFyIHF1ZVBhaVNjcmlwdDtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuXG4gICAgICAgIGFjdGlvbk5vZGVTY3JpcHQ6IGNjLk5vZGUsXG4gICAgICAgIGFsZXJ0TWVzc2FnZU5vZGVTY2lycHQ6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJJbmZvU2NyaXB0Tm9kZTogY2MuTm9kZSxcblxuICAgICAgICBodWFuU2FuWmhhbmdOb2RlOiBjYy5Ob2RlLFxuICAgICAgICBxdWVQYWlTY3JpcHROb2RlOiBjYy5Ob2RlXG5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgYWN0aW9uVUlTY3JpcHROb2RlID0gc2VsZi5hY3Rpb25Ob2RlU2NyaXB0LmdldENvbXBvbmVudChcImdhbWVDb25maWdCdXR0b25MaXN0QWN0aW9uXCIpO1xuICAgICAgICBhbGVydE1lc3NhZ2VVSSA9IHNlbGYuYWxlcnRNZXNzYWdlTm9kZVNjaXJwdC5nZXRDb21wb25lbnQoXCJhbGVydE1lc3NhZ2VQYW5sZVwiKTtcbiAgICAgICAgdXNlckluZm9TY3JpcHQgPSBzZWxmLnVzZXJJbmZvU2NyaXB0Tm9kZS5nZXRDb21wb25lbnQoXCJ0YWJsZVVzZXJJbmZvXCIpO1xuICAgICAgICBtZXNzYWdlRG9tYWluID0gcmVxdWlyZShcIm1lc3NhZ2VEb21haW5cIikubWVzc2FnZURvbWFpbjtcbiAgICAgICAgR2xvYmFsLnN1YmlkID0gMDtcbiAgICAgICAgY29ubmVjdF9jYWxsYmFjayA9IGZ1bmN0aW9uIChlcnJvcikge1xuICAgICAgICAgICAgLy8gZGlzcGxheSB0aGUgZXJyb3IncyBtZXNzYWdlIGhlYWRlcjpcbiAgICAgICAgICAgIGFsZXJ0KGVycm9yLmhlYWRlcnMubWVzc2FnZSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgaHVhblNhblpoYW5nU2NyaXB0ID0gc2VsZi5odWFuU2FuWmhhbmdOb2RlLmdldENvbXBvbmVudChcImh1YW5QYWlVSVwiKTtcbiAgICAgICAgcXVlUGFpU2NyaXB0ID0gc2VsZi5xdWVQYWlTY3JpcHROb2RlLmdldENvbXBvbmVudChcInF1ZXBhaVNjcmlwdFwiKTtcbiAgICB9LFxuICAgIGNvbm5lY3RCeVByaXZhdGVDaGFuZWw6IGZ1bmN0aW9uIGNvbm5lY3RCeVByaXZhdGVDaGFuZWwoKSB7XG4gICAgICAgIGlmIChjbGllbnQgPT0gbnVsbCB8fCBjbGllbnQgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB1c2VySW5mbyA9IHJlcXVpcmUoXCJ1c2VySW5mb0RvbWFpblwiKS51c2VySW5mb0RvbWFpbjtcbiAgICAgICAgICAgIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICAgICAgcm9vbU51bWJlciA9IHVzZXJJbmZvLnJvb21OdW1iZXI7XG4gICAgICAgICAgICBzZXJ2ZXJVcmwgPSBHbG9iYWwuaG9zdEh0dHBQcm90b2NvbCArIFwiOi8vXCIgKyBHbG9iYWwuaG9zdFNlcnZlcklwICsgXCI6XCIgKyBHbG9iYWwuaG9zdFNlcnZlclBvcnQ7XG4gICAgICAgICAgICBzb2NrZXQgPSBuZXcgU29ja0pTKHNlcnZlclVybCArIFwiL3N0b21wXCIpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJjb25lY3QgdG8gc2VydmVyXCIpO1xuICAgICAgICAgICAgY2xpZW50ID0gU3RvbXAub3Zlcihzb2NrZXQpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBzdWJzY3JpYmVUb1ByaXZhdGVDaGFuZWxOb0Nvbm5ldEFnYWluOiBmdW5jdGlvbiBzdWJzY3JpYmVUb1ByaXZhdGVDaGFuZWxOb0Nvbm5ldEFnYWluKHRoaXNSb29OdW1iZXIpIHtcbiAgICAgICAgY2xpZW50LnN1YnNjcmliZShcIi9xdWV1ZS9wcml2YXRlVXNlckNoYW5lbFwiICsgdGhpc1Jvb051bWJlciwgKGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICB2YXIgYm9keVN0ciA9IG1lc3NhZ2UuYm9keTtcbiAgICAgICAgICAgIGNjLmxvZyhcIiMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcIik7XG4gICAgICAgICAgICBjYy5sb2coYm9keVN0cik7XG4gICAgICAgICAgICB2YXIgb2JqID0gSlNPTi5wYXJzZShib2R5U3RyKTtcbiAgICAgICAgICAgIGlmIChvYmogIT0gdW5kZWZpbmVkICYmIG9iaiAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBvYmopIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZURvbWFpbltwXSA9IG9ialtwXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYWN0aW9uVUlTY3JpcHROb2RlLmNsb3NlTG9hZGluZ0ljb24oKTtcbiAgICAgICAgICAgICAgICAvLyBhY3Rpb25VSVNjcmlwdE5vZGUuc2hvd0dhbWVUYWxiZSgpO1xuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlRG9tYWluLm1lc3NhZ2VBY3Rpb24gPT0gXCJidWlsZE5ld1JvdW5kTHVuXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKG1lc3NhZ2VEb21haW4ubWVzc2FnZUJvZHkpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgdXNlck9iaiA9IEpTT04ucGFyc2UobWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciB1c2VyTGlzdCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICB1c2VyT2JqLnBvaW50SW5kZXggPSBcIjNcIjtcbiAgICAgICAgICAgICAgICAgICAgdXNlck9iai56aHVhbmcgPSBcIjFcIjtcbiAgICAgICAgICAgICAgICAgICAgdXNlckxpc3QucHVzaCh1c2VyT2JqKTtcbiAgICAgICAgICAgICAgICAgICAgR2xvYmFsLnVzZXJMaXN0ID0gdXNlckxpc3Q7XG4gICAgICAgICAgICAgICAgICAgIGFjdGlvblVJU2NyaXB0Tm9kZS5zaG93R2FtZVRhbGJlKFwiMVwiKTtcbiAgICAgICAgICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVzZXJJbmZvLm9wZW5pZD09dXNlck9iai5vcGVuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgLy9pbml0YWwgdGhlIGdvYmFsIHVzZXIgbGlzdCBieSBzZWxmIHVzZXIgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgIGFsZXJ0TWVzc2FnZVVJLnRleHQgPSBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5O1xuICAgICAgICAgICAgICAgICAgICAgICBhbGVydE1lc3NhZ2VVSS5zZXRUZXh0T2ZQYW5lbCgpO1xuICAgICAgICAgICAgICAgICAgICB9Ki9cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvL2ludGFsVXNlckluZm9SZWFkeUljb25cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZURvbWFpbi5tZXNzYWdlQWN0aW9uID09IFwidXNlclJlYWR5U3RhdHVDaGFuZ2VcIikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgT2JqID0gSlNPTi5wYXJzZShtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iai5tZXNzYWdlRXhlY3V0ZUZsYWcgPT0gXCJzdWNjZXNzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB1c2VyTGlzdCA9IEdsb2JhbC51c2VyTGlzdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBnYW1lVXNlckxpc3QgPSBKU09OLnBhcnNlKE9iai5tZXNzYWdlRXhlY3V0ZVJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCIlJSUlJSVPYmo6XCIgKyBPYmoubWVzc2FnZUV4ZWN1dGVSZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBnYW1lVXNlckxpc3QubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZ2FtZVVzZXIgPSBnYW1lVXNlckxpc3Rbal07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1c2VyTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdXNlciA9IHVzZXJMaXN0W2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXNlci5vcGVuaWQgPT0gZ2FtZVVzZXIub3BlbmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyLmdhbWVSZWFkeVN0YXR1ID0gZ2FtZVVzZXIuZ2FtZVJlYWR5U3RhdHU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBHbG9iYWwudXNlckxpc3QgPSB1c2VyTGlzdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIkdsb2JhbC51c2VyTGlzdDpcIiArIEdsb2JhbC51c2VyTGlzdC50b1N0cmluZygpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJJbmZvU2NyaXB0LmludGFsVXNlckluZm9SZWFkeUljb24oKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsZXJ0TWVzc2FnZVVJLnRleHQgPSBPYmoubWVzc2FnZUV4ZWN1dGVSZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbGVydE1lc3NhZ2VVSS5zZXRUZXh0T2ZQYW5lbCgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2VEb21haW4ubWVzc2FnZUFjdGlvbiA9PSBcImpvaW5Sb29tXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIE9iaiA9IEpTT04ucGFyc2UobWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keSk7XG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIiUlJSUlJU9iai5tZXNzYWdlRXhlY3V0ZUZsYWc6XCIgKyBPYmoubWVzc2FnZUV4ZWN1dGVGbGFnKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iai5tZXNzYWdlRXhlY3V0ZUZsYWcgPT0gXCJzdWNjZXNzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIEdsb2JhbC5qb2luUm9vbU51bWJlciA9IG1lc3NhZ2VEb21haW4ubWVzc2FnZUJlbG9uZ3NUb1ByaXZhdGVDaGFubGVOdW1iZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgam9pblJvb21Kc29uID0gSlNPTi5wYXJzZShPYmoubWVzc2FnZUV4ZWN1dGVSZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGdhbWVVc2VyTGlzdCA9IEpTT04ucGFyc2Uoam9pblJvb21Kc29uLnVzZXJMaXN0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBqb2luTW9kZSA9IEpTT04ucGFyc2Uoam9pblJvb21Kc29uLmdhbWVNb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChqb2luTW9kZSAhPSBudWxsICYmIGpvaW5Nb2RlICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdsb2JhbC5nYW1lTW9kZSA9IGpvaW5Nb2RlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcImpvaW5Nb2RlOlwiICsgR2xvYmFsLmdhbWVNb2RlLnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGV4aXN0RmxhZyA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCIlJSUlJSVPYmo6XCIgKyBPYmoubWVzc2FnZUV4ZWN1dGVSZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiJSUlJSUlZ2FtZVVzZXJMaXN0OlwiICsgZ2FtZVVzZXJMaXN0Lmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjYy5sb2coXCIlJSUlJSVnYW1lVXNlcjpcIitnYW1lVXNlci50b1N0cmluZygpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB1c2VyTGlzdCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBnYW1lVXNlckxpc3QubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZ2V0VXNlciA9IGdhbWVVc2VyTGlzdFtqXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCIlJSUlJSVnYW1lZ2V0VXNlcjpcIiArIGdldFVzZXIub3BlbmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTGlzdC5wdXNoKGdldFVzZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJ1c2VyTGlzdCAxOlwiICsgdXNlckxpc3QudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBHbG9iYWwudXNlckxpc3QgPSB1c2VyTGlzdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vc2hvdyBnYW1lIHRhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoR2xvYmFsLmpvaW5Sb29tTnVtYmVyID09IEdsb2JhbC51c2VySW5mby5yb29tTnVtYmVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uVUlTY3JpcHROb2RlLnNob3dHYW1lVGFsYmUoXCIxXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25VSVNjcmlwdE5vZGUuc2hvd0dhbWVUYWxiZShcIjBcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbGVydE1lc3NhZ2VVSS50ZXh0ID0gT2JqLm1lc3NhZ2VFeGVjdXRlUmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxlcnRNZXNzYWdlVUkuc2V0VGV4dE9mUGFuZWwoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlRG9tYWluLm1lc3NhZ2VBY3Rpb24gPT0gXCJmYVBhaVwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBnYW1lVXNlckxpc3QgPSBKU09OLnBhcnNlKG1lc3NhZ2VEb21haW4ubWVzc2FnZUJvZHkpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgdXNlckxpc3QyID0gR2xvYmFsLnVzZXJMaXN0O1xuICAgICAgICAgICAgICAgICAgICB2YXIgdXNlckluZm8gPSBHbG9iYWwudXNlckluZm87XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgZ2FtZVVzZXJMaXN0Lmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZ2FtZVVzZXIgPSBnYW1lVXNlckxpc3Rbal07XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Mi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB1c2VyID0gdXNlckxpc3QyW2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1c2VyLm9wZW5pZCA9PSBnYW1lVXNlci5vcGVuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBhaUxpc3RTdHJpbmcgPSBnYW1lVXNlci5wYWlMaXN0O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhaUxpc3RTdHJpbmcgPSB0aGlzLmNoYW5nZUpzb25MaXN0U3RyaW5nVG9BcnJheVN0cmluZyhwYWlMaXN0U3RyaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiZ2FtZVVzZXIucGFpTGlzdDpcIiArIHBhaUxpc3RTdHJpbmcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyLnBhaUxpc3QgPSBwYWlMaXN0U3RyaW5nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgaWYgKHVzZXIub3BlbmlkID09IHVzZXJJbmZvLm9wZW5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgIGNjLmxvZyhcImZvdW5kIDM6XCIrdXNlci5vcGVuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICB1c2VyLnBvaW50SW5kZXggPTNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBHbG9iYWwudXNlckxpc3QgPSB1c2VyTGlzdDI7XG4gICAgICAgICAgICAgICAgICAgIC8vdGFibGUgdXNlciBpbmZvXG5cbiAgICAgICAgICAgICAgICAgICAgdXNlckluZm9TY3JpcHQuaW5pdGFsVXNlclBhaShcImluaXRhbFwiKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvL2h1YW4gc2FuemhhbmdcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZURvbWFpbi5tZXNzYWdlQWN0aW9uID09IFwiaHVhblNhblpoYW5nRmFQYWlcIikge31cbiAgICAgICAgICAgICAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tR2FtZSBBY3Rpb24gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2VEb21haW4ubWVzc2FnZUFjdGlvbiA9PSBcImdhbWVBY3Rpb25cIikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgdXNlckxpc3QgPSBHbG9iYWwudXNlckxpc3Q7XG4gICAgICAgICAgICAgICAgICAgIHZhciB1c2VySW5mbyA9IEdsb2JhbC51c2VySW5mbztcbiAgICAgICAgICAgICAgICAgICAgdmFyIG9iaiA9IEpTT04ucGFyc2UobWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBmcm9tVXNlck9wZW5pZCA9IG9iai5mcm9tVXNlck9wZW5pZDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iai5hY3Rpb25OYW1lID09IFwiY2h1UGFpXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdXNlckxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXJJbmZvLm9wZW5pZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL3BsYXkgY2h1cGFpIGFjdGlvbiBvbiBzZWxmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vcGxheSBjaHVwYWkgYWN0aW9uIG9uIG90aGVyIHNpZGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy8gaWYgKG1lc3NhZ2VEb21haW4ubWVzc2FnZUFjdGlvbiA9PSBcInVzZXJSZWFkeVN0YXR1Q2hhbmdlXCIpIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgaWYgKG1lc3NhZ2VEb21haW4ubWVzc2FnZUJvZHkuaW5kZXhPZihcInN1Y2Nlc3NcIikgPj0gMCkge1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgdmFyIHRlbXAgPSBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5LnNwbGl0KFwiOlwiKTtcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHZhciBvcGVuaWQgPSB0ZW1wWzFdO1xuICAgICAgICAgICAgICAgIC8vICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vICAgICAgICAgYWxlcnRNZXNzYWdlVUkudGV4dCA9IG1lc3NhZ2VEb21haW4ubWVzc2FnZUJvZHk7XG4gICAgICAgICAgICAgICAgLy8gICAgICAgICBhbGVydE1lc3NhZ2VVSS5zZXRUZXh0T2ZQYW5lbCgpO1xuICAgICAgICAgICAgICAgIC8vICAgICB9XG4gICAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgfSBlbHNlIHtcblxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIk5vIGZvdW5kIGNvcnJlY3QgdXNlciBpbmZvIHJldHVybiBmcm9tIHNlcnZlciAscGxlYXNlIGNoZWNrIC5cIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICB9KS5iaW5kKHRoaXMpLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjYy5sb2coXCJ3ZWJzb2NrZXQgY29ubmVjdCBzdWJzY3JpYmUgRXJyb3I6MjMzXCIpO1xuICAgICAgICAgICAgLy9jbGllbnQuZGlzY29ubmVjdCgpO1xuICAgICAgICB9KTtcbiAgICB9LFxuICAgIHN1YnNjcmliZVRvUHJpdmF0ZUNoYW5lbDogZnVuY3Rpb24gc3Vic2NyaWJlVG9Qcml2YXRlQ2hhbmVsKHRoaXNSb29OdW1iZXIpIHtcbiAgICAgICAgY2xpZW50LmNvbm5lY3Qoe30sIChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLnN1YnNjcmliZVRvUHJpdmF0ZUNoYW5lbE5vQ29ubmV0QWdhaW4odGhpc1Jvb051bWJlcik7XG4gICAgICAgIH0pLmJpbmQodGhpcyksIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNjLmxvZyhcIndlYnNvY2tldCBjb25uZWN0ICBFcnJvcjoyMzRcIik7XG4gICAgICAgICAgICAvL2NsaWVudC5kaXNjb25uZWN0KCk7XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgaW5pdGFsQ2xpZW50OiBmdW5jdGlvbiBpbml0YWxDbGllbnQoKSB7XG4gICAgICAgIGlmIChjbGllbnQgPT0gbnVsbCB8fCBjbGllbnQgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLmNvbm5lY3RCeVByaXZhdGVDaGFuZWwoKTtcbiAgICAgICAgICAgIHRoaXMuc3Vic2NyaWJlVG9Qcml2YXRlQ2hhbmVsKHJvb21OdW1iZXIpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1jaHUgcGFpIGFjdGlvbi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGNodVBhaUFjdGlvbjogZnVuY3Rpb24gY2h1UGFpQWN0aW9uKHVzZXJPcGVuSWQsIHBhaU51bWJlcikge1xuICAgICAgICB2YXIgam9pblJvb21OdW1iZXIgPSBHbG9iYWwuam9pblJvb21OdW1iZXI7XG4gICAgICAgIHZhciBvID0gbmV3IE9iamVjdCgpO1xuICAgICAgICAvL3ZhciBnYW1lU3RlcCA9IHJlcXVpcmUoXCJnYW1lU3RlcFwiKS5nYW1lU3RlcDtcblxuICAgICAgICBvLmZyb21Vc2VyT3BlbmlkID0gdXNlck9wZW5JZDtcbiAgICAgICAgby5hY3Rpb25OYW1lID0gXCJjaHVQYWlcIjtcbiAgICAgICAgby5wYWlOdW1iZXIgPSBwYWlOdW1iZXI7XG4gICAgICAgIG8udG9Vc2VyT3BlbmlkID0gdXNlck9wZW5JZDtcblxuICAgICAgICB2YXIgbWVzc2FnZU9iaiA9IHRoaXMuYnVpbGRTZW5kTWVzc2FnZShKU09OLnN0cmluZ2lmeShvKSwgam9pblJvb21OdW1iZXIsIFwiZ2FtZUFjdGlvblwiKTtcbiAgICAgICAgdGhpcy5zZW5kTWVzc2FnZVRvU2VydmVyKG1lc3NhZ2VPYmopO1xuICAgIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGpvaW5Sb29tOiBmdW5jdGlvbiBqb2luUm9vbShqb2luUm9vbU51bWJlcikge1xuICAgICAgICBHbG9iYWwuam9pblJvb21OdW1iZXIgPSBqb2luUm9vbU51bWJlcjtcbiAgICAgICAgY2xpZW50LnVuc3Vic2NyaWJlKFwic3ViLVwiICsgR2xvYmFsLnN1YmlkKTtcblxuICAgICAgICAvL2NsaWVudC5kaXNjb25uZWN0KCk7XG4gICAgICAgIC8vdGhpcy5jb25uZWN0QnlQcml2YXRlQ2hhbmVsKCk7XG4gICAgICAgIHRoaXMuc3Vic2NyaWJlVG9Qcml2YXRlQ2hhbmVsTm9Db25uZXRBZ2Fpbihqb2luUm9vbU51bWJlcik7XG4gICAgICAgIEdsb2JhbC5zdWJpZCA9IEdsb2JhbC5zdWJpZCArIDE7XG4gICAgICAgIGNjLmxvZyhcIkdsb2JhbC5zdWJpZDpcIiArIEdsb2JhbC5zdWJpZCk7XG4gICAgICAgIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICB2YXIgb3BlbklkID0gdXNlckluZm8ub3BlbmlkO1xuICAgICAgICB2YXIgbWVzc2FnZU9iaiA9IHRoaXMuYnVpbGRTZW5kTWVzc2FnZShvcGVuSWQsIGpvaW5Sb29tTnVtYmVyLCBcImpvaW5Sb29tXCIpO1xuICAgICAgICB0aGlzLnNlbmRNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZU9iaik7XG4gICAgfSxcbiAgICBjaGVja1Jvb21OdW1iZXI6IGZ1bmN0aW9uIGNoZWNrUm9vbU51bWJlcigpIHt9LFxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBidWlsZE5ld0dhbWVSb3VuZDogZnVuY3Rpb24gYnVpbGROZXdHYW1lUm91bmQoKSB7XG4gICAgICAgIC8vIHRoaXMuaW5pdGFsQ2xpZW50KCk7XG4gICAgICAgIGNjLmxvZyhcImJ1aWxkTmV3R2FtZVJvdW5kLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cIik7XG4gICAgICAgIHZhciBnYW1lTW9kZSA9IEdsb2JhbC5nYW1lTW9kZTtcbiAgICAgICAgaWYgKGdhbWVNb2RlID09IG51bGwpIHtcbiAgICAgICAgICAgIGdhbWVNb2RlID0gcmVxdWlyZShcImdhbWVNb2RlXCIpLmdhbWVNb2RlO1xuICAgICAgICB9XG4gICAgICAgIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICBHbG9iYWwuam9pblJvb21OdW1iZXIgPSB1c2VySW5mby5yb29tTnVtYmVyO1xuICAgICAgICBpZiAoZ2FtZU1vZGUgIT0gbnVsbCkge1xuICAgICAgICAgICAgcm9vbU51bWJlciA9IHVzZXJJbmZvLnJvb21OdW1iZXI7XG4gICAgICAgICAgICB2YXIgbyA9IG5ldyBPYmplY3QoKTtcbiAgICAgICAgICAgIG8udXNlck9wZW5JZCA9IHVzZXJJbmZvLm9wZW5pZDtcbiAgICAgICAgICAgIC8vYWRkIGxpbWl0IGZvciBtb2RlXG4gICAgICAgICAgICBpZiAoR2xvYmFsLmdhbWVDb25maWdTZXR0aW5nICE9IG51bGwgJiYgR2xvYmFsLmdhbWVDb25maWdTZXR0aW5nICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGdhbWVNb2RlLnB1YmxpY0lwTGltaXQgPSBHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmcucHVibGljSXBMaW1pdDtcbiAgICAgICAgICAgICAgICBnYW1lTW9kZS5ncHNMaW1pdCA9IEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZy5ncHNMaW1pdDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZ2FtZU1vZGUucHVibGljSXBMaW1pdCA9IFwiMFwiO1xuICAgICAgICAgICAgICAgIGdhbWVNb2RlLmdwc0xpbWl0ID0gXCIwXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvLmdhbWVNb2RlID0gZ2FtZU1vZGU7XG4gICAgICAgICAgICBjYy5sb2coXCJidWlsZE5ld0dhbWVSb3VuZDItLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVwiKTtcbiAgICAgICAgICAgIHZhciBtZXNzYWdlT2JqID0gdGhpcy5idWlsZFNlbmRNZXNzYWdlKEpTT04uc3RyaW5naWZ5KG8pLCByb29tTnVtYmVyLCBcImJ1aWxkTmV3Um91bmRMdW5cIik7XG5cbiAgICAgICAgICAgIHRoaXMuc2VuZE1lc3NhZ2VUb1NlcnZlcihtZXNzYWdlT2JqKTtcbiAgICAgICAgICAgIGNjLmxvZyhcImJ1aWxkTmV3R2FtZVJvdW5kMy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXCIpO1xuICAgICAgICB9XG4gICAgICAgIEdsb2JhbC5nYW1lTW9kZSA9IGdhbWVNb2RlO1xuXG4gICAgICAgIGFjdGlvblVJU2NyaXB0Tm9kZS5zaG93TG9hZGluZ0ljb24oKTtcbiAgICB9LFxuICAgIGNsb3NlR2FtZVJvdW5kTHVuOiBmdW5jdGlvbiBjbG9zZUdhbWVSb3VuZEx1bigpIHtcbiAgICAgICAgdXNlckluZm8gPSBHbG9iYWwudXNlckluZm87XG4gICAgICAgIGlmICh1c2VySW5mbyAhPSBudWxsKSB7XG4gICAgICAgICAgICByb29tTnVtYmVyID0gdXNlckluZm8ucm9vbU51bWJlcjtcbiAgICAgICAgICAgIHZhciBtZXNzYWdlT2JqID0gdGhpcy5idWlsZFNlbmRNZXNzYWdlKHJvb21OdW1iZXIsIHJvb21OdW1iZXIsIFwiY2xvc2VHYW1lUm91bmRMdW5cIik7XG4gICAgICAgICAgICB0aGlzLnNlbmRNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZU9iaik7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGdldEZhUGFpOiBmdW5jdGlvbiBnZXRGYVBhaSgpIHtcbiAgICAgICAgdmFyIG1lc3NhZ2VPYmogPSB0aGlzLmJ1aWxkU2VuZE1lc3NhZ2UoXCJcIiwgcm9vbU51bWJlciwgXCJmYVBhaVwiKTtcbiAgICAgICAgdGhpcy5zZW5kTWVzc2FnZVRvU2VydmVyKG1lc3NhZ2VPYmopO1xuICAgIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tc2VuZCBodWFuIHNhbnpoYW5nIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy9HbG9iYWwuaHVhblNhblpoYW5nUGFpTGlzdFxuICAgIHNlbmRRdWVQYWk6IGZ1bmN0aW9uIHNlbmRRdWVQYWkoKSB7XG5cbiAgICAgICAgdXNlckluZm8gPSBHbG9iYWwudXNlckluZm87XG4gICAgICAgIHZhciBxdWUgPSB1c2VySW5mby5xdWVQYWk7XG4gICAgICAgIHZhciB1c2VyT3BlbklkID0gdXNlckluZm8ub3BlbmlkO1xuICAgICAgICB2YXIgam9pblJvb21OdW1iZXIgPSBHbG9iYWwuam9pblJvb21OdW1iZXI7XG4gICAgICAgIHZhciBvID0gbmV3IE9iamVjdCgpO1xuICAgICAgICBvLmh1YW5TYW5aaGFuZ1BhaUxpc3QgPSBwYWlMaXN0O1xuICAgICAgICBvLm9wZW5pZCA9IHVzZXJPcGVuSWQ7XG4gICAgICAgIHZhciBtZXNzYWdlT2JqID0gdGhpcy5idWlsZFNlbmRNZXNzYWdlKEpTT04uc3RyaW5naWZ5KG8pLCBqb2luUm9vbU51bWJlciwgXCJ1c2VySHVhblNhblpoYW5nXCIpO1xuICAgICAgICB0aGlzLnNlbmRNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZU9iaik7XG4gICAgfSxcblxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLXNlbmQgaHVhbiBzYW56aGFuZyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vR2xvYmFsLmh1YW5TYW5aaGFuZ1BhaUxpc3RcbiAgICBzZW5kSHVhblNhblpoYW5nOiBmdW5jdGlvbiBzZW5kSHVhblNhblpoYW5nKCkge1xuICAgICAgICB2YXIgcGFpTGlzdCA9IFwiXCI7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMzsgaSsrKSB7XG4gICAgICAgICAgICBwYWlMaXN0ID0gcGFpTGlzdCArIEdsb2JhbC5odWFuU2FuWmhhbmdQYWlMaXN0W2ldICsgXCIsXCI7XG4gICAgICAgIH1cbiAgICAgICAgcGFpTGlzdCA9IHBhaUxpc3Quc3Vic3RyaW5nKDAsIHBhaUxpc3QubGVuZ3RoIC0gMSk7XG4gICAgICAgIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICB2YXIgdXNlck9wZW5JZCA9IHVzZXJJbmZvLm9wZW5pZDtcbiAgICAgICAgdmFyIGpvaW5Sb29tTnVtYmVyID0gR2xvYmFsLmpvaW5Sb29tTnVtYmVyO1xuICAgICAgICB2YXIgbyA9IG5ldyBPYmplY3QoKTtcbiAgICAgICAgby5odWFuU2FuWmhhbmdQYWlMaXN0ID0gcGFpTGlzdDtcbiAgICAgICAgby5vcGVuaWQgPSB1c2VyT3BlbklkO1xuICAgICAgICB2YXIgbWVzc2FnZU9iaiA9IHRoaXMuYnVpbGRTZW5kTWVzc2FnZShKU09OLnN0cmluZ2lmeShvKSwgam9pblJvb21OdW1iZXIsIFwidXNlckh1YW5TYW5aaGFuZ1wiKTtcbiAgICAgICAgdGhpcy5zZW5kTWVzc2FnZVRvU2VydmVyKG1lc3NhZ2VPYmopO1xuICAgIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tVXNlciByZWFkeSBhY3Rpb24tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgc2VuZFVzZXJSZWFkeVRvU2VydmVyOiBmdW5jdGlvbiBzZW5kVXNlclJlYWR5VG9TZXJ2ZXIoZXZlbnQpIHtcbiAgICAgICAgdmFyIG5vZGUgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIHZhciByZWFkeVN0YXR1ID0gXCIwXCI7XG4gICAgICAgIGNjLmxvZyhcIm5vZGU6XCIgKyBub2RlLm5hbWUpO1xuICAgICAgICB2YXIgcyA9IG5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIGNjLmxvZyhcInM6XCIgKyBzLnNwcml0ZUZyYW1lLm5hbWUpO1xuICAgICAgICBpZiAocy5zcHJpdGVGcmFtZS5uYW1lID09IFwiMjZcIikge1xuICAgICAgICAgICAgcmVhZHlTdGF0dSA9IFwiMVwiO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVhZHlTdGF0dSA9IFwiMFwiO1xuICAgICAgICB9XG4gICAgICAgIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICB2YXIgdXNlck9wZW5JZCA9IHVzZXJJbmZvLm9wZW5pZDtcbiAgICAgICAgdmFyIGpvaW5Sb29tTnVtYmVyID0gR2xvYmFsLmpvaW5Sb29tTnVtYmVyO1xuICAgICAgICB2YXIgbyA9IG5ldyBPYmplY3QoKTtcbiAgICAgICAgby51c2VyUmVhZHlTdGF0dSA9IHJlYWR5U3RhdHU7XG4gICAgICAgIG8ub3BlbmlkID0gdXNlck9wZW5JZDtcbiAgICAgICAgdmFyIG1lc3NhZ2VPYmogPSB0aGlzLmJ1aWxkU2VuZE1lc3NhZ2UoSlNPTi5zdHJpbmdpZnkobyksIGpvaW5Sb29tTnVtYmVyLCBcInVzZXJSZWFkeVN0YXR1Q2hhbmdlXCIpO1xuICAgICAgICB0aGlzLnNlbmRNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZU9iaik7XG4gICAgfSxcblxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgIHNlbmRNZXNzYWdlVG9TZXJ2ZXI6IGZ1bmN0aW9uIHNlbmRNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZU9iaikge1xuXG4gICAgICAgIGNsaWVudC5zZW5kKFwiL2FwcC91c2VyX3ByaXZhdGVfbWVzc2FnZVwiLCB7fSwgSlNPTi5zdHJpbmdpZnkobWVzc2FnZU9iaikpO1xuICAgIH0sXG5cbiAgICBidWlsZFNlbmRNZXNzYWdlOiBmdW5jdGlvbiBidWlsZFNlbmRNZXNzYWdlKG1lc3NhZ2VCb2R5LCByb29tTnVtLCBhY3Rpb24pIHtcbiAgICAgICAgdmFyIG1lc3NhZ2VEb21haW4gPSByZXF1aXJlKFwibWVzc2FnZURvbWFpblwiKS5tZXNzYWdlRG9tYWluO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCZWxvbmdzVG9Qcml2YXRlQ2hhbmxlTnVtYmVyID0gcm9vbU51bTtcbiAgICAgICAgbWVzc2FnZURvbWFpbi5tZXNzYWdlQWN0aW9uID0gYWN0aW9uO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5ID0gbWVzc2FnZUJvZHk7XG5cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2VEb21haW47XG4gICAgfSxcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLXVudGlscy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBjaGFuZ2VKc29uTGlzdFN0cmluZ1RvQXJyYXlTdHJpbmc6IGZ1bmN0aW9uIGNoYW5nZUpzb25MaXN0U3RyaW5nVG9BcnJheVN0cmluZyh0ZW1wU3RyaW5nKSB7XG4gICAgICAgIHZhciBzdHIgPSBcIlwiO1xuICAgICAgICBpZiAodGVtcFN0cmluZyAhPSBudWxsICYmIHRlbXBTdHJpbmcgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0ZW1wU3RyaW5nID0gdGVtcFN0cmluZy5yZXBsYWNlKFwiW1wiLCBcIlwiKTtcbiAgICAgICAgICAgIHRlbXBTdHJpbmcgPSB0ZW1wU3RyaW5nLnJlcGxhY2UoXCJdXCIsIFwiXCIpO1xuICAgICAgICAgICAgdmFyIGxpc3QgPSB0ZW1wU3RyaW5nLnNwbGl0KFwiLFwiKTtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGlmIChsaXN0W2ldICE9IG51bGwgJiYgbGlzdFtpXSAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHMgPSBsaXN0W2ldICsgXCJcIjtcbiAgICAgICAgICAgICAgICAgICAgcyA9IHMudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICBzdHIgPSBzdHIgKyBzICsgXCIsXCI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChzdHIuc3Vic3RyaW5nKHN0ci5sZW5ndGggLSAxKSA9PSBcIixcIikge1xuICAgICAgICAgICAgc3RyID0gc3RyLnN1YnN0cmluZygwLCBzdHIubGVuZ3RoIC0gMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0cjtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzY2NDRidXJFR1JOV3A1MGJPaGtvYTZhJywgJ0dhbWVUYWJsZVJvb20nKTtcbi8vIHNjcmlwdC9zZXJ2aWNlL0dhbWVUYWJsZVJvb20uanNcblxudmFyIHVzZXJMaXN0QXJyYXk7XG52YXIgcHJpdmF0ZUNsaWVudDtcbnZhciBzZXJ2ZXJVcmw7XG52YXIgc29ja2V0O1xudmFyIHBhaUxpc3RBcnJheTtcbnZhciBnYW1lTW9kZU1vZGVsID0gcmVxdWlyZSgnZ2FtZU1vZGUnKS5nYW1lTW9kZTtcbnZhciBwcmVSb29tTnVtYmVyO1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIGNyZWF0ZVJvb21CdG46IGNjLk5vZGUsXG4gICAgICAgIGJhY2tSb29tQnRuOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIGdhbWVNb2RlTm9kZTogY2MuTm9kZSxcbiAgICAgICAgZ2FtZU1haW5NZW51OiBjYy5Ob2RlLFxuICAgICAgICByb29tTnVtYmVyTGF5ZXI6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJSZWFkeUxheWVyOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyUmVhZHkxTm9kZTogY2MuTm9kZSxcbiAgICAgICAgdXNlclJlYWR5Mk5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJSZWFkeTNOb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyUmVhZHk0Tm9kZTogY2MuTm9kZSxcbiAgICAgICAgY2hhbmdlVXNlclN0YXR1c1llc0J0bkltYWdlOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgY2hhbmdlVXNlclN0YXR1c05vQnRuSW1hZ2U6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB1c2VyU3RhdHVzWWVzSW1hZ2U6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB1c2VyU3RhdHVzTm9JbWFnZTogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHF1ZVBhaU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIGh1YW5QYWlOb2RlOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZUNlbnRlck5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHcxOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgdzI6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB3MzogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHc0OiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgdzU6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB3NjogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHc3OiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgdzg6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB3OTogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHQxOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgdDI6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB0MzogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHQ0OiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgdDU6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB0NjogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHQ3OiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgdDg6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICB0OTogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIGExOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgYTI6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICBhMzogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIGE0OiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgYTU6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICBhNjogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIGE3OiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgYTg6IGNjLlNwcml0ZUZyYW1lLFxuICAgICAgICBhOTogY2MuU3ByaXRlRnJhbWVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIGNjLmxvZyhcIioqKioqKioqKioqOlwiICsgdGhpcy5uYW1lKTtcbiAgICAgICAgLy9pbml0YWwgdGhlIHdlYnNva2VjdCBwdWJsaWMgdmFyXG4gICAgICAgIHNlcnZlclVybCA9IEdsb2JhbC5ob3N0SHR0cFByb3RvY29sICsgXCI6Ly9cIiArIEdsb2JhbC5ob3N0U2VydmVySXAgKyBcIjpcIiArIEdsb2JhbC5ob3N0U2VydmVyUG9ydDtcbiAgICAgICAgc29ja2V0ID0gbmV3IFNvY2tKUyhzZXJ2ZXJVcmwgKyBcIi9zdG9tcFwiKTtcblxuICAgICAgICAvL2hpZGUgdGhlIGpvaW4gcm9vbSBsYXllclxuICAgICAgICB0aGlzLnJvb21OdW1iZXJMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy51c2VyUmVhZHlMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5iYWNrUm9vbUJ0bi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5jcmVhdGVSb29tQnRuLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIC8vdGhpcy51c2VyUmVhZHkxTm9kZS5hY3RpdmVcblxuICAgICAgICB1c2VyTGlzdEFycmF5ID0gbmV3IEFycmF5KCk7XG4gICAgICAgIHBhaUxpc3RBcnJheSA9IG5ldyBBcnJheSgpO1xuICAgICAgICBpZiAoR2xvYmFsLnVzZXJJbmZvID09IHVuZGVmaW5lZCB8fCBHbG9iYWwudXNlckluZm8gPT0gbnVsbCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJFcnJvcjogbm8gZm91bmQgY29ycmVjdCB1c2VyICxwbGVhc2UgY2hlY2sgc2VydmVyIG9yIG5ldHdvcmsuXCIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICB9XG4gICAgICAgIC8vaW50YWwgdGhlIHVzZXJMaXN0IGJ5IHNlbGYgcG9pbnQgM1xuICAgICAgICB1c2VyTGlzdEFycmF5WzBdID0gbnVsbDtcbiAgICAgICAgdXNlckxpc3RBcnJheVsxXSA9IG51bGw7XG4gICAgICAgIC8vc3RhdHVzIDAtb2ZmbGluZSAsMS1vbmxpbmUgLDItbm90IHJlYWR5LCAzLXJlYWR5LDQtZ2FtZWluZyw1LW90aGVyXG4gICAgICAgIHVzZXJJbmZvLmdhbWVpbmdTdGF0dSA9IFwiMVwiO1xuICAgICAgICB1c2VySW5mby56aHVhbmdTdGF0dSA9IFwiMFwiO1xuICAgICAgICB1c2VyTGlzdEFycmF5WzJdID0gdXNlckluZm87XG4gICAgICAgIHVzZXJMaXN0QXJyYXlbM10gPSBudWxsO1xuICAgICAgICAvL2luaXRhbCB0aGUgdXNlciByZWFkeSBpY29uXG4gICAgICAgIHRoaXMuaW5pdGFsVXNlclJlYWR5TGF5ZXIoKTtcbiAgICAgICAgLy9pbnRhbCB0aGUgd2Vic29rZWN0XG4gICAgICAgIHRoaXMuaW5pdGFsUHJpdmF0ZUNoYW5sZUZvclVzZXIodXNlckluZm8ucm9vbU51bWJlciwgXCJcIik7XG5cbiAgICAgICAgLy9pbml0YWwgdGhlIGdhbWUgbW9kZSBkb21haW4gXG4gICAgICAgIGlmIChnYW1lTW9kZU1vZGVsLmdhbWVQZW9wbGVOdW1iZXIgPT0gMCkge1xuICAgICAgICAgICAgZ2FtZU1vZGVNb2RlbC5nYW1lUGVvcGxlTnVtYmVyID0gNDtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tR2FtZSBUYWJsZSBGdW5jdGlvbiBTdGFydGluZy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBjcmVhdGVSb29tX2NsZWFyVGFibGVJbml0YWxVc2VySW5mbzogZnVuY3Rpb24gY3JlYXRlUm9vbV9jbGVhclRhYmxlSW5pdGFsVXNlckluZm8oKSB7XG4gICAgICAgIGNjLmxvZyhcImNyZWF0ZVJvb21fY2xlYXJUYWJsZUluaXRhbFVzZXJJbmZvIHN0YXJ0aW5nLi4uLi4uXCIpO1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IDU7IGkrKykge1xuICAgICAgICAgICAgY2MubG9nKFwiaTpcIiArIGkpO1xuICAgICAgICAgICAgdmFyIHVzZXIxUGFpTGlzdExheWVyTm9kZSA9IHRoaXMudGFibGVOb2RlLmdldENoaWxkQnlOYW1lKFwidXNlclwiICsgaSArIFwiUGFpTGlzdExheWVyXCIpO1xuICAgICAgICAgICAgdXNlcjFQYWlMaXN0TGF5ZXJOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgdmFyIHVzZXIxSGlkZVBhaUxheWVyTm9kZSA9IHRoaXMudGFibGVOb2RlLmdldENoaWxkQnlOYW1lKFwidXNlclwiICsgaSArIFwiSGlkZVBhaUxheWVyXCIpO1xuICAgICAgICAgICAgdXNlcjFIaWRlUGFpTGF5ZXJOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgdmFyIHVzZXIxQ2h1UGFpTGF5ZXJOb2RlID0gdGhpcy50YWJsZU5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyXCIgKyBpICsgXCJDaHVQYWlMYXllclwiKTtcbiAgICAgICAgICAgIHVzZXIxQ2h1UGFpTGF5ZXJOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgLy9oaWRlIG90aGVyIHVlciBpbmZvIGljb24sdW50aWwgb3RoZXIgdXNlciBqb2luIHRoaXMgcm9vbVxuICAgICAgICAgICAgdmFyIHVzZXJJbmZvID0gdGhpcy50YWJsZU5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyXCIgKyBpICsgXCJMYXllclwiKTtcbiAgICAgICAgICAgIGlmIChpICE9IDMpIHtcbiAgICAgICAgICAgICAgICB1c2VySW5mby5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy9pbml0YWwgdGhlIHVzZXIgc2VsZiB0byBjZW50ZXIgb2YgdGhlIHggcG9pbnRcbiAgICAgICAgICAgICAgICAvL3ggNjAyLHkgLTE2NSx0b3AgNDkwXG4gICAgICAgICAgICAgICAgdXNlckluZm8ueCA9IDA7XG4gICAgICAgICAgICAgICAgdmFyIHVzZXJXaWdldCA9IHVzZXJJbmZvLmdldENvbXBvbmVudChjYy5XaWRnZXQpO1xuICAgICAgICAgICAgICAgIHVzZXJXaWdldC50b3AgPSA2MDA7XG4gICAgICAgICAgICAgICAgLy91c2VyV2lnZXQucmlnaHQgPSA2MTc7XG4gICAgICAgICAgICAgICAgdXNlcldpZ2V0LmlzQWxpZ25Ib3Jpem9udGFsQ2VudGVyID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB1c2VyV2lnZXQuaG9yaXpvbnRhbENlbnRlciA9IDA7XG4gICAgICAgICAgICAgICAgLy9pbml0YWwgc2VsZiB1c2VyIGluZm9cbiAgICAgICAgICAgICAgICB0aGlzLmluaXRhbFVzZXJJbmZvTGF5ZXIodXNlckluZm8pO1xuICAgICAgICAgICAgICAgIC8vaW5pdGFsIHNlbGYgdXNlciBpY29uXG5cbiAgICAgICAgICAgICAgICB0aGlzLnVzZXJSZWFkeTNOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG4gICAgLy9lbmQgdGhlIHJvb21cbiAgICBlbmRUb1Jvb206IGZ1bmN0aW9uIGVuZFRvUm9vbSgpIHtcbiAgICAgICAgdGhpcy5iYWNrUm9vbUJ0bi5hY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgLy9idWlsZCByZW1vdmUgYWxsIG9ubGluZSByb29tIGZyb20gc2VydmVyXG4gICAgICAgIC8vIHRoaXMuYnVpbGRDYW5sZVVzZXJNZXNzYWdlQW5kU2VuZEl0KHVzZXJMaXN0QXJyYXlbMl0ucm9vbU51bWJlcik7XG4gICAgfSxcbiAgICAvL2JhY2sgdG8gcm9vbSBieSBwcmVSb29tTnVtYmVyXG4gICAgYmFja1RvUm9vbTogZnVuY3Rpb24gYmFja1RvUm9vbSgpIHtcbiAgICAgICAgaWYgKHByaXZhdGVDbGllbnQgIT0gbnVsbCB8fCBwcml2YXRlQ2xpZW50ICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcHJpdmF0ZUNsaWVudC51bnN1YnNjcmliZSgpO1xuICAgICAgICB9XG4gICAgICAgIHNvY2tldCA9IG5ldyBTb2NrSlMoc2VydmVyVXJsICsgXCIvc3RvbXBcIik7XG4gICAgICAgIHRoaXMuaW5pdGFsUHJpdmF0ZUNoYW5sZUZvclVzZXIocHJlUm9vbU51bWJlciwgXCJzZW5kXCIpO1xuICAgIH0sXG4gICAgLy9jcmVhdGUgYSBuZXcgcm9vbVxuICAgIGNyZWF0ZVJvb21BbmRFbnRlclRhYmxlOiBmdW5jdGlvbiBjcmVhdGVSb29tQW5kRW50ZXJUYWJsZSgpIHtcblxuICAgICAgICBpZiAocHJpdmF0ZUNsaWVudCA9PSBudWxsIHx8IHByaXZhdGVDbGllbnQgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB2YXIgdXNlckluZm8gPSBHbG9iYWwudXNlckluZm87XG4gICAgICAgICAgICBzb2NrZXQgPSBuZXcgU29ja0pTKHNlcnZlclVybCArIFwiL3N0b21wXCIpO1xuICAgICAgICAgICAgdXNlckxpc3RBcnJheVsyXSA9IHVzZXJJbmZvO1xuICAgICAgICAgICAgdGhpcy5pbml0YWxQcml2YXRlQ2hhbmxlRm9yVXNlcih1c2VySW5mby5yb29tTnVtYmVyLCBcInVwZGF0ZVwiKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYnVpbGRHYW1lTW9kZU1lc3NhZ2VBbmRTZW5kSXQodXNlckxpc3RBcnJheVsyXS5yb29tTnVtYmVyKTtcbiAgICAgICAgfVxuICAgICAgICAvL2NyZWF0ZSBhIG5ldyByb29tICx3aWxsIGRlZmF1bHQgYXMgemh1YW5nXG4gICAgICAgIHVzZXJMaXN0QXJyYXlbMl0uemh1YW5nU3RhdHUgPSBcIjFcIjtcblxuICAgICAgICB0aGlzLnNob3dHYW1lVGFibGUoKTtcbiAgICB9LFxuICAgIGNsb3NlUm9vbU51bWJlckxheWVyOiBmdW5jdGlvbiBjbG9zZVJvb21OdW1iZXJMYXllcigpIHtcbiAgICAgICAgdmFyIGxpc3RCdXR0b24gPSB0aGlzLmdhbWVNYWluTWVudS5nZXRDaGlsZEJ5TmFtZShcIkxpc3RCdXR0b25cIik7XG4gICAgICAgIHZhciB0b3BJbmZvVXNlciA9IHRoaXMuZ2FtZU1haW5NZW51LmdldENoaWxkQnlOYW1lKFwidG9wSW5mb1VzZXJMYXllclwiKTtcbiAgICAgICAgbGlzdEJ1dHRvbi5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0b3BJbmZvVXNlci5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLnJvb21OdW1iZXJMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgLy90aGlzLnJvb21OdW1iZXJMYXllci5vcGFjaXR5ID0gMjU1O1xuICAgIH0sXG4gICAgc2hvd1Jvb21OdW1iZXJMYXllcjogZnVuY3Rpb24gc2hvd1Jvb21OdW1iZXJMYXllcigpIHtcbiAgICAgICAgLy90aGlzLnNob3dHYW1lVGFibGUoKTtcbiAgICAgICAgLy9jbG9zZSB0aGUgcHJpdmF0ZSB3ZXNva2VjdFxuICAgICAgICB2YXIgbGlzdEJ1dHRvbiA9IHRoaXMuZ2FtZU1haW5NZW51LmdldENoaWxkQnlOYW1lKFwiTGlzdEJ1dHRvblwiKTtcbiAgICAgICAgdmFyIHRvcEluZm9Vc2VyID0gdGhpcy5nYW1lTWFpbk1lbnUuZ2V0Q2hpbGRCeU5hbWUoXCJ0b3BJbmZvVXNlckxheWVyXCIpO1xuICAgICAgICBsaXN0QnV0dG9uLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0b3BJbmZvVXNlci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5yb29tTnVtYmVyTGF5ZXIuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5yb29tTnVtYmVyTGF5ZXIub3BhY2l0eSA9IDI1NTtcbiAgICB9LFxuICAgIGpvaW5Sb29tQW5kRW50ZXJUYWJsZTogZnVuY3Rpb24gam9pblJvb21BbmRFbnRlclRhYmxlKCkge1xuXG4gICAgICAgIC8vMS4gZ2V0IG90aGVyIHJvb20gbnVtYmVyXG4gICAgICAgIHZhciByb29tTnVtYmVyID0gXCJcIjtcbiAgICAgICAgdmFyIHJvb21MYXlvdXQgPSB0aGlzLnJvb21OdW1iZXJMYXllci5nZXRDaGlsZEJ5TmFtZShcInJvb21OdW1iZXJMYXlvdXRcIik7XG4gICAgICAgIGZvciAodmFyIGkgPSAxOyBpIDwgNzsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgcm9vbU51bU5vZGUgPSByb29tTGF5b3V0LmdldENoaWxkQnlOYW1lKFwiTnVtXCIgKyBpKTtcbiAgICAgICAgICAgIHZhciByb29tTnVtRWRpdEJveCA9IHJvb21OdW1Ob2RlLmdldENvbXBvbmVudChjYy5FZGl0Qm94KTtcbiAgICAgICAgICAgIHJvb21OdW1iZXIgPSByb29tTnVtYmVyICsgcm9vbU51bUVkaXRCb3guc3RyaW5nO1xuICAgICAgICB9XG5cbiAgICAgICAgY2MubG9nKFwibmV3IHJvb21OdW1Ob2RlOlwiICsgcm9vbU51bWJlcik7XG4gICAgICAgIGlmIChyb29tTnVtYmVyLmxlbmd0aCAhPSA2KSB7XG4gICAgICAgICAgICBjYy5sb2coXCJHZXQgcm9vbSBudW1iZXIgZXJyb3JcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8zLiBjaGVjayB0aGUgcm9vbSBudW1iZXJcbiAgICAgICAgdGhpcy5jaGVja09ubGluZVJvb21OdW1iZXIocm9vbU51bWJlciwgdGhpcyk7XG4gICAgfSxcbiAgICBzaG93R2FtZVRhYmxlOiBmdW5jdGlvbiBzaG93R2FtZVRhYmxlKCkge1xuICAgICAgICB0aGlzLmdhbWVNYWluTWVudS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5nYW1lTW9kZU5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudGFibGVOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMudGFibGVOb2RlLm9wYWNpdHkgPSAyNTU7XG4gICAgICAgIC8vaGlkZSBvdGhlciBVSSAuXG4gICAgICAgIHRoaXMucXVlUGFpTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy50YWJsZUNlbnRlck5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMuY3JlYXRlUm9vbV9jbGVhclRhYmxlSW5pdGFsVXNlckluZm8oKTtcbiAgICAgICAgLy90aGlzLmluaXRhbFVzZXJSZWFkeUxheWVyKCk7XG4gICAgfSxcbiAgICBzaG93R2FtZU1lbnU6IGZ1bmN0aW9uIHNob3dHYW1lTWVudSgpIHtcbiAgICAgICAgdGhpcy5nYW1lTWFpbk1lbnUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5nYW1lTW9kZU5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudGFibGVOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnJvb21OdW1iZXJMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy51c2VyUmVhZHlMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuICAgIC8vVE9ET1xuICAgIHVzZXJCYWNrVG9NYWluTWVhdTogZnVuY3Rpb24gdXNlckJhY2tUb01haW5NZWF1KCkge1xuICAgICAgICAvLy5wcmUgc2V0dXBcbiAgICAgICAgdGhpcy5zaG93R2FtZU1lbnUoKTtcbiAgICAgICAgdGhpcy5jcmVhdGVSb29tQnRuLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLmJhY2tSb29tQnRuLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIC8vMC4gdGhpcy5pbml0YWxQcml2YXRlQ2hhbmxlRm9yVXNlcih1c2VySW5mby5yb29tTnVtYmVyLCBcIlwiKTtcblxuICAgICAgICAvLzEuIGNsaWVudCBzZW5kIHRoZSB1c2VyIG9wZW5pZCB0byBzZXJ2ZXJcblxuICAgICAgICAvLzIuIHNlcnZlciBnZXQgdGhlIG5ldyBvcGVuaWQgYW5kIG9sZCBvcGVuaWQsIHNldCB0aGUgdXNlciByb29tIG51bWJlciBhcyBuZXcgb3BlbmlkXG4gICAgICAgIC8vMy4gcHVibGljIHRoZSBhbGwgdXNlcnMgdG8gb2xkIHByaXZhdGUgY2hhbmxlICx0byB1cGRhdGUgdGhlIHVzZXIgbGlzdFxuICAgICAgICBpZiAodXNlckxpc3RBcnJheVsyXS56aHVhbmdTdGF0dSA9PSBcIjFcIikge1xuICAgICAgICAgICAgcHJlUm9vbU51bWJlciA9IHVzZXJMaXN0QXJyYXlbMl0ucm9vbU51bWJlcjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHByZVJvb21OdW1iZXIgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYnVpbGRDYW5sZVVzZXJNZXNzYWdlQW5kU2VuZEl0KHVzZXJMaXN0QXJyYXlbMl0ucm9vbU51bWJlcik7XG5cbiAgICAgICAgLy9wcmVSb29tTnVtYmVyXG4gICAgICAgIC8vNC4gaGlkZSB0aGUgcmVhZHkgaWNvbiBmb3IgZW1wcnkgdXNlclxuICAgIH0sXG4gICAgLy9UaGlzIGZ1bmN0aW9uIHdpbGwgY29tbWl0IGEgcHJpdmF0ZSByb29tIG51bWJlciB0byBzZXJ2ZXJcbiAgICAvL1NlcnZlciBwdWJsaWMgYSBtZXNzYWdlIHRvIHRoZSBwcml2YXRlIGNoYW5sZSAsYW55IGFjdGl2ZSBjbGllbnQgd2lsbCBzZW5kIGJhY2sgYWN0aXZlIG1lc3NhZ2UgYW5kIGtleSB0byBzZXJ2ZXJcbiAgICAvL1NlcnZlciBwdWJsaWMgdGhlIGFjdGl2ZSBjbGllbnQgaW4gdGhlIHByaXZhdGUgY2hhbmxlIGFnYWluICxjbGllbnQgZ2V0IHdoaWNoIGNsaWVudCBpcyBhY3RpdmVcbiAgICBjaGVja09ubGluZVVzZXJJblRoZVByaXZhdGVDaGFubGU6IGZ1bmN0aW9uIGNoZWNrT25saW5lVXNlckluVGhlUHJpdmF0ZUNoYW5sZSgpIHt9LFxuXG4gICAgLy9jaGFuZ2UgdXNlciBzdGF0dSB0byByZWFkeSBvciBjYW5sZSB0aGUgcmVhZHlcbiAgICBjaGFuZ2VVc2VyU3RhdHU6IGZ1bmN0aW9uIGNoYW5nZVVzZXJTdGF0dSgpIHtcbiAgICAgICAgdmFyIHVzZXJvcGVuaWQgPSB1c2VyTGlzdEFycmF5WzJdLm9wZW5pZDtcbiAgICAgICAgdmFyIHJvb21OdW1iZXIgPSB1c2VyTGlzdEFycmF5WzJdLnJvb21OdW1iZXI7XG4gICAgICAgIHZhciBzdGF0dXMgPSBwYXJzZUludCh1c2VyTGlzdEFycmF5WzJdLmdhbWVpbmdTdGF0dSk7XG4gICAgICAgIGNjLmxvZyhcInNlbmQgc3RhdHVzMTpcIiArIHN0YXR1cyk7XG4gICAgICAgIC8vc3RhdHVzIDAtb2ZmbGluZSAsMS1vbmxpbmUgLDItbm90IHJlYWR5LCAzLXJlYWR5LDQtZ2FtZWluZyw1LW90aGVyXG4gICAgICAgIGlmIChzdGF0dXMgPT0gMSkge1xuICAgICAgICAgICAgc3RhdHVzID0gMztcbiAgICAgICAgfSBlbHNlIGlmIChzdGF0dXMgPT0gMikge1xuICAgICAgICAgICAgc3RhdHVzID0gMztcbiAgICAgICAgfSBlbHNlIGlmIChzdGF0dXMgPT0gMykge1xuICAgICAgICAgICAgc3RhdHVzID0gMjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmxvZyhcInNlbmQgc3RhdHVzMjpcIiArIHN0YXR1cyk7XG4gICAgICAgIHRoaXMuYnVpbGRDaGFuZ2VVc2VyU3RhdHVzTWVzc2FnZUFuZFNlbmRJdCh1c2Vyb3BlbmlkLCByb29tTnVtYmVyLCBzdGF0dXMpO1xuICAgIH0sXG4gICAgY2hlY2tVc2VyU3RhdHU6IGZ1bmN0aW9uIGNoZWNrVXNlclN0YXR1KCkge30sXG5cbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1HYW1lIFRhYmxlIGZ1bmN0aW9uIEVuZC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgc2hvd0dhbWVNb2RlOiBmdW5jdGlvbiBzaG93R2FtZU1vZGUoKSB7XG4gICAgICAgIGNjLmxvZyhcImNyZWF0ZVJvb21fY2xlYXJUYWJsZUluaXRhbFVzZXJJbmZvIHN0YXJ0aW5nLi4uLi4uXCIpO1xuICAgICAgICB0aGlzLmdhbWVNYWluTWVudS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgLy9zZWxmLmdhbWVNYWluTWVudS5vcGFjaXR5PTA7XG4gICAgICAgIHRoaXMuZ2FtZU1vZGVOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuZ2FtZU1vZGVOb2RlLm9wYWNpdHkgPSAwO1xuICAgICAgICB0aGlzLnRhYmxlTm9kZS5hY3RpdmUgPSBmYWxzZTtcblxuICAgICAgICB0aGlzLmdhbWVNb2RlTm9kZS5vcGFjaXR5ID0gMjU1O1xuICAgIH0sXG5cbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvL2luaXRhbCB1ZXIgaW5mbyBsYXllciBieSBnb2JhbCB1c2VyaW5mbyBvYmplY3QsIHRoZSBzZWxmIHVzZXIgb25seSB1c2VyMyAuXG4gICAgaW5pdGFsVXNlckluZm9MYXllcjogZnVuY3Rpb24gaW5pdGFsVXNlckluZm9MYXllcih1c2VySW5mb05vZGUpIHtcbiAgICAgICAgY2MubG9nKFwiaW5pdGFsVXNlckluZm9MYXllciBzdGFydGluZy4uLi4uLlwiKTtcbiAgICAgICAgdmFyIHVzZXJMYXlvdXQgPSB1c2VySW5mb05vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyM0xheW91dExheWVyXCIpO1xuICAgICAgICB2YXIgdXNlclRleHRJbmZvTGF5ZXIgPSB1c2VyTGF5b3V0LmdldENoaWxkQnlOYW1lKFwidXNlcmluZm9GcmFtZUJnXCIpO1xuICAgICAgICB2YXIgdXNlck5hbWVMYWJsZU5vZGUgPSB1c2VyVGV4dEluZm9MYXllci5nZXRDaGlsZEJ5TmFtZShcInVzZXJOaWNrTmFtZUxhYmVsXCIpO1xuICAgICAgICB2YXIgdXNlclNjb3J0TGFibGVOb2RlID0gdXNlclRleHRJbmZvTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoXCJzY29ydExhYmVsXCIpO1xuICAgICAgICB2YXIgdXNlck5pY2tOYW1lTGFibGUgPSB1c2VyTmFtZUxhYmxlTm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xuICAgICAgICB2YXIgdXNlclNjb3J0TGFibGUgPSB1c2VyU2NvcnRMYWJsZU5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcblxuICAgICAgICBpZiAoR2xvYmFsLnVzZXJJbmZvICE9IG51bGwpIHtcbiAgICAgICAgICAgIHVzZXJOaWNrTmFtZUxhYmxlLnN0cmluZyA9IEdsb2JhbC51c2VySW5mby5uaWNrTmFtZTtcbiAgICAgICAgICAgIHVzZXJTY29ydExhYmxlLnN0cmluZyA9IEdsb2JhbC51c2VySW5mby5kaWFtb25kc051bWJlcjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHVzZXJOaWNrTmFtZUxhYmxlLnN0cmluZyA9ICd0ZXN0MTIzJztcbiAgICAgICAgICAgIHVzZXJTY29ydExhYmxlLnN0cmluZyA9ICcyMzIxJztcbiAgICAgICAgfVxuICAgIH0sXG4gICAgaW5pdGFsVXNlckluZm9MYXllckJ5SWQ6IGZ1bmN0aW9uIGluaXRhbFVzZXJJbmZvTGF5ZXJCeUlkKHVzZXJJbmZvTm9kZSwgaWQpIHtcbiAgICAgICAgdmFyIHVzZXJJbmZvID0gdGhpcy50YWJsZU5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyXCIgKyBpZCArIFwiTGF5ZXJcIik7XG4gICAgICAgIHVzZXJJbmZvLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGlmIChpZCA9PSAxKSB7XG4gICAgICAgICAgICB2YXIgdXNlcldpZGdldCA9IHVzZXJJbmZvLmdldENvbXBvbmVudChjYy5XaWRnZXQpO1xuICAgICAgICAgICAgdXNlcldpZGdldC5pc0FsaWduSG9yaXpvbnRhbENlbnRlciA9IHRydWU7XG4gICAgICAgICAgICB1c2VyV2lkZ2V0Lmhvcml6b250YWxDZW50ZXIgPSAwO1xuICAgICAgICAgICAgLy8gdXNlckluZm8ueD0wO1xuICAgICAgICB9XG4gICAgICAgIHZhciB1c2VyTGF5b3V0ID0gdXNlckluZm8uZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyXCIgKyBpZCArIFwiTGF5b3V0TGF5ZXJcIik7XG4gICAgICAgIHZhciB1c2VyVGV4dEluZm9MYXllciA9IHVzZXJMYXlvdXQuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyaW5mb0ZyYW1lQmdcIik7XG4gICAgICAgIHZhciB1c2VyTmFtZUxhYmxlTm9kZSA9IHVzZXJUZXh0SW5mb0xheWVyLmdldENoaWxkQnlOYW1lKFwidXNlck5pY2tOYW1lTGFiZWxcIik7XG4gICAgICAgIHZhciB1c2VyU2NvcnRMYWJsZU5vZGUgPSB1c2VyVGV4dEluZm9MYXllci5nZXRDaGlsZEJ5TmFtZShcInNjb3J0TGFiZWxcIik7XG4gICAgICAgIHZhciB1c2VyTmlja05hbWVMYWJsZSA9IHVzZXJOYW1lTGFibGVOb2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XG4gICAgICAgIHZhciB1c2VyU2NvcnRMYWJsZSA9IHVzZXJTY29ydExhYmxlTm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xuXG4gICAgICAgIHVzZXJOaWNrTmFtZUxhYmxlLnN0cmluZyA9IHVzZXJJbmZvTm9kZS5uaWNrTmFtZTtcbiAgICAgICAgdXNlclNjb3J0TGFibGUuc3RyaW5nID0gdXNlckluZm9Ob2RlLmRpYW1vbmRzTnVtYmVyO1xuICAgIH0sXG4gICAgaW5pdGFsVXNlclJlYWR5TGF5ZXI6IGZ1bmN0aW9uIGluaXRhbFVzZXJSZWFkeUxheWVyKCkge1xuICAgICAgICB0aGlzLnVzZXJSZWFkeUxheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMudXNlclJlYWR5MU5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlclJlYWR5Mk5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlclJlYWR5M05vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlclJlYWR5NE5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS13ZWIgc29rZWMgY29ubmVjdCBhbmQgc3Vic2NyaWJlIGFuZCBoYW5kbGUgcmVzaXZlIG1lc3NhZ2UtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBpbml0YWxQcml2YXRlQ2hhbmxlRm9yVXNlcjogZnVuY3Rpb24gaW5pdGFsUHJpdmF0ZUNoYW5sZUZvclVzZXIocm9vbU51bWJlciwgYWN0aW9uKSB7XG4gICAgICAgIGNjLmxvZyhcImluaXRhbFByaXZhdGVDaGFubGVGb3JVc2VyIHJvb21OdW1iZXI6XCIgKyByb29tTnVtYmVyKTtcbiAgICAgICAgLy9yZXNldCB0aGUgcm9vbSBmb3IgdXNlciBMaXN0XG4gICAgICAgIHVzZXJMaXN0QXJyYXlbMl0ucm9vbU51bWJlciA9IHJvb21OdW1iZXI7XG4gICAgICAgIHByaXZhdGVDbGllbnQgPSBTdG9tcC5vdmVyKHNvY2tldCk7XG4gICAgICAgIC8vIHZhciBtZXNzYWdlRG9tYWluID0gcmVxdWlyZShcIm1lc3NhZ2VEb21haW5cIikubWVzc2FnZURvbWFpbjtcbiAgICAgICAgcHJpdmF0ZUNsaWVudC5jb25uZWN0KHt9LCAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcHJpdmF0ZUNsaWVudC5zdWJzY3JpYmUoXCIvcXVldWUvcHJpdmF0ZVJvb21DaGFubGVcIiArIHJvb21OdW1iZXIsIChmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgICAgICAgICAgICAgIHZhciBib2R5U3RyID0gbWVzc2FnZS5ib2R5O1xuICAgICAgICAgICAgICAgIGNjLmxvZyhcImdldCBtZWVzZ2UgZnJvbSBwcml2YXRlIGNoYW5sZTpwcml2YXRlUm9vbUNoYW5sZVwiICsgcm9vbU51bWJlcik7XG4gICAgICAgICAgICAgICAgdmFyIG1lc3NhZ2VEb21haW4gPSByZXF1aXJlKFwibWVzc2FnZURvbWFpblwiKS5tZXNzYWdlRG9tYWluO1xuICAgICAgICAgICAgICAgIHZhciBvYmogPSBKU09OLnBhcnNlKGJvZHlTdHIpO1xuICAgICAgICAgICAgICAgIGlmIChvYmogIT0gdW5kZWZpbmVkICYmIG9iaiAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIHAgaW4gb2JqKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlRG9tYWluW3BdID0gb2JqW3BdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vMS4gam9pbiBuZXcgdXNlciB0byByb29tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlRG9tYWluLm1lc3NhZ2VBY3Rpb24gPT0gXCJhZGROZXdVc2VyVG9Qcml2YXRlQ2hhbmxlXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHVzZXJMaXN0SnNvblN0ciA9IG1lc3NhZ2VEb21haW4ubWVzc2FnZUJvZHk7XG4gICAgICAgICAgICAgICAgICAgIHZhciB1c2VyTGlzdCA9IEpTT04ucGFyc2UodXNlckxpc3RKc29uU3RyKTtcbiAgICAgICAgICAgICAgICAgICAgLy9nYW1laW5nU3RhdHVcblxuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdSA9IHVzZXJMaXN0W2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGV4aXN0RmxhZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9jaGVjayB0aGUgdXNlciBpZiBhbHJlYWR5IGV4aXN0IGluIHRoZSB1c2VyIGxpc3RcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgdXNlckxpc3RBcnJheS5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1c2VyTGlzdEFycmF5W2pdICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHUub3BlbmlkID09IHVzZXJMaXN0QXJyYXlbal0ub3BlbmlkKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0RmxhZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZXhpc3RGbGFnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCB1c2VyTGlzdEFycmF5Lmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZXhpc3RGbGFnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXNlckxpc3RBcnJheVtqXSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy9zdGF0dXMgMC1vZmZsaW5lICwxLW9ubGluZSAsMi1ub3QgcmVhZHksIDMtcmVhZHksNC1nYW1laW5nLDUtb3RoZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJpbml0YWwgdXNlciBnYW1lIHVzZXIgdS5nYW1laW5nU3RhdHU6XCIgKyB1LmdhbWVpbmdTdGF0dSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHUuZ2FtZWluZ1N0YXR1ID09IG51bGwgfHwgdS5nYW1laW5nU3RhdHUgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHUuZ2FtZWluZ1N0YXR1ID0gXCIyXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChwYXJzZUludCh1LmdhbWVpbmdTdGF0dSkgPT0gMCB8fCBwYXJzZUludCh1LmdhbWVpbmdTdGF0dSkgPT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1LmdhbWVpbmdTdGF0dSA9IFwiMlwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJMaXN0QXJyYXlbal0gPSB1O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy91c2VyTGlzdEFycmF5W2pdLmdhbWVpbmdTdGF0dSA9IDI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRVc2VyU3RhdXRzQW5kSW1hZ2UoaiwgdXNlckxpc3RBcnJheVtqXS5nYW1laW5nU3RhdHUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB1c2VyUmVhZE5vZGUgPSB0aGlzLnVzZXJSZWFkeUxheWVyLmdldENoaWxkQnlOYW1lKFwidXNlclwiICsgKGogKyAxKSArIFwiUmVhZHlOb2RlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJSZWFkTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5pdGFsVXNlckluZm9MYXllckJ5SWQodSwgaiArIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0RmxhZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvL3VzZXJMaXN0QXJyYXlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLzIuIENIQU5HRSB1c2VyIHN0YXR1cy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2VEb21haW4ubWVzc2FnZUFjdGlvbiA9PSBcImNoYW5nZVVzZXJTdGF0dXNJblByaXZhdGVDaGFubGVcIikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgbyA9IEpTT04ucGFyc2UobWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciB1c2Vyb3BlbmlkID0gby5vcGVuaWQ7XG4gICAgICAgICAgICAgICAgICAgIHZhciB1c2VyU3RhdHVzID0gby5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgIGlmICh1c2Vyb3BlbmlkICE9IG51bGwgJiYgdXNlcm9wZW5pZCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgdXNlckxpc3RBcnJheS5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1c2VyTGlzdEFycmF5W2pdICE9IG51bGwgJiYgdXNlckxpc3RBcnJheVtqXSAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVzZXJvcGVuaWQgPT0gdXNlckxpc3RBcnJheVtqXS5vcGVuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJMaXN0QXJyYXlbal0uZ2FtZWluZ1N0YXR1ID0gdXNlclN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0VXNlclN0YXV0c0FuZEltYWdlKGosIHVzZXJTdGF0dXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vMy4gZ2V0IGFsbCBwYWkgZnJvbSBzZXJ2ZXItLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZURvbWFpbi5tZXNzYWdlQWN0aW9uID09IFwicHVibGljQWxsUGFpXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgLy92YXIgcGFpU3RyID0gbWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keTtcbiAgICAgICAgICAgICAgICAgICAgLy9pbml0YWwgdGhlIHBhaSBsaXN0XG4gICAgICAgICAgICAgICAgICAgIC8vcGFpTGlzdEFycmF5ID0gcGFpU3RyLnNwbGl0KFwiLFwiKTtcblxuICAgICAgICAgICAgICAgICAgICAvL3JlbW92ZSB0aGUgYWxsIHVzZXIgcmVhZHkgaWNvblxuICAgICAgICAgICAgICAgICAgICB0aGlzLnVzZXJSZWFkeUxheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB2YXIgb2JqID0gSlNPTi5wYXJzZShtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5KTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBhaVN0ciA9IG9iai5wYWlSZXN0TGlzdDtcbiAgICAgICAgICAgICAgICAgICAgcGFpTGlzdEFycmF5ID0gcGFpU3RyLnNwbGl0KFwiLFwiKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHVzZXJQYWlMaXN0ID0gb2JqLnVzZXJQYWlMaXN0O1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJQYWlMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHVzZXJMaXN0QXJyYXkubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXNlclBhaUxpc3RbaV0ub3BlbmlkID09IHVzZXJMaXN0QXJyYXlbal0ub3BlbmlkKSB7fVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vNC4gY2FuY2xlIHRoZSB1c2VyIGZyb20gdGhlIHJvb20tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZURvbWFpbi5tZXNzYWdlQWN0aW9uID09IFwidXNlckNhbmxlUm9vbVwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBjYW5jbGVVc2VyT3BlbklkID0gbWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keTtcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiY2FuY2xlVXNlck9wZW5JZCBjYW5sZSEhXCIgKyBjYW5jbGVVc2VyT3BlbklkKTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCB1c2VyTGlzdEFycmF5Lmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMgaXMgb3RoZXIgdXNlclxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodXNlckxpc3RBcnJheVtqXSAhPSBudWxsICYmIHVzZXJMaXN0QXJyYXlbal0gIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNhbmNsZVVzZXJPcGVuSWQgPT0gdXNlckxpc3RBcnJheVtqXS5vcGVuaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlckxpc3RBcnJheVtqXSA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vaGlkZSB0aGUgdXNlciByZWFkeSBpY29uIExhcnllclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdXNlclJlYWROb2RlID0gdGhpcy51c2VyUmVhZHlMYXllci5nZXRDaGlsZEJ5TmFtZShcInVzZXJcIiArIChqICsgMSkgKyBcIlJlYWR5Tm9kZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlclJlYWROb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL2hpZGUgdGhlIHVzZXIgaW5mbyBsYXllclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdXNlckluZm8gPSB0aGlzLnRhYmxlTm9kZS5nZXRDaGlsZEJ5TmFtZShcInVzZXJcIiArIChqICsgMSkgKyBcIkxheWVyXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VySW5mby5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvL2Rpc2Nvbm5lY3QgdGhlIGNvbm5lY3QgZnJvbSByb29tXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcml2YXRlQ2xpZW50ICE9IG51bGwgJiYgcHJpdmF0ZUNsaWVudCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGVDbGllbnQudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaXZhdGVDbGllbnQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwicHJpdmF0ZUNsaWVudCBjYW5sZSEhXCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwicHJpdmF0ZUNsaWVudCBjYW5sZSAxMTEhIVwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KS5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIGlmIChhY3Rpb24gPT0gXCJzZW5kXCIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmJ1aWxkQWRkTmV3VXNlck1lc3NhZ2VBbmRTZW5kSXQocm9vbU51bWJlcik7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKGFjdGlvbiA9PSBcInVwZGF0ZVwiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5idWlsZFVwZGF0ZVJvb21OdW1iZXJPZk9ubGluZVVzZXJNZXNzYWdlKHVzZXJMaXN0QXJyYXlbMl0ucm9vbU51bWJlciwgdXNlckxpc3RBcnJheVsyXS5vcGVuaWQpO1xuICAgICAgICAgICAgICAgIHRoaXMuYnVpbGRHYW1lTW9kZU1lc3NhZ2VBbmRTZW5kSXQodXNlckxpc3RBcnJheVsyXS5yb29tTnVtYmVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkuYmluZCh0aGlzKSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY2MubG9nKFwiY29ubmVjdCBwcml2YXRlIGNoYW5sZSBlcnJvciAhXCIpO1xuICAgICAgICB9KTtcbiAgICB9LFxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLXNlbmQgbWVzc2FnZSB0byBzZXJ2ZXItLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgc2VuZFdlYlNva2VjdE1lc3NhZ2VUb1NlcnZlcjogZnVuY3Rpb24gc2VuZFdlYlNva2VjdE1lc3NhZ2VUb1NlcnZlcihtZXNzYWdlT2JqKSB7XG4gICAgICAgIC8vIHZhciBvID0gbmV3IE9iamVjdCgpO1xuICAgICAgICAvLyBvLnRva2VuID0gXCJ0ZXN0IHdvcmRcIlxuICAgICAgICBwcml2YXRlQ2xpZW50LnNlbmQoXCIvYXBwL3Jlc2l2ZUFsbFVzZXJDaGFubGVQdXNtaWNHYW1lXCIsIHt9LCBKU09OLnN0cmluZ2lmeShtZXNzYWdlT2JqKSk7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgcmVtb3ZlT25saW5lVXNlckJ5SWQ6IGZ1bmN0aW9uIHJlbW92ZU9ubGluZVVzZXJCeUlkKCkge1xuICAgICAgICB2YXIgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHZhciB1cmwgPSBzZXJ2ZXJVcmwgKyBcIi91c2VyL3JlbW92ZU9ubGluVXNlckJ5SWQ/dXNlcklkPVwiICsgR2xvYmFsLnVzZXJJbmZvLmlkO1xuICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlID09IDQgJiYgeGhyLnN0YXR1cyA+PSAyMDAgJiYgeGhyLnN0YXR1cyA8IDQwMCkge1xuICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IHhoci5yZXNwb25zZVRleHQ7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB4aHIub3BlbihcIkdFVFwiLCB1cmwsIHRydWUpO1xuICAgICAgICB4aHIuc2VuZCgpO1xuICAgIH0sXG4gICAgY2hlY2tPbmxpbmVSb29tTnVtYmVyOiBmdW5jdGlvbiBjaGVja09ubGluZVJvb21OdW1iZXIocm9vbU51bWJlciwgc2VsZikge1xuICAgICAgICB2YXIgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHZhciB1cmwgPSBzZXJ2ZXJVcmwgKyBcIi9yb29tL2NoZWNrT25saW5lUm9vbU51bWJlckNvcnJlY3Q/cm9vbU51bWJlcj1cIiArIHJvb21OdW1iZXIgKyBcIiZvcGVudW5pZD1cIiArIEdsb2JhbC51c2VySW5mby5vcGVuaWQ7XG4gICAgICAgIC8vdXJsID0gc2VydmVyVXJsICsgXCIvdXNlci9nZXRMb2dpblVzZXJJUFwiO1xuICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNjLmxvZyhcInhoci5zdGF0dXM6XCIgKyB4aHIuc3RhdHVzKTtcbiAgICAgICAgICAgIGNjLmxvZyhcInhoci5yZWFkeVN0YXRlOlwiICsgeGhyLnJlYWR5U3RhdGUpO1xuXG4gICAgICAgICAgICBjYy5sb2coXCItLS0tLS0tLS0tLVwiKTtcblxuICAgICAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlID09IDQgJiYgeGhyLnN0YXR1cyA+PSAyMDAgJiYgeGhyLnN0YXR1cyA8IDQwMCkge1xuICAgICAgICAgICAgICAgIC8vbGV0IHNlbGY9dGhpcztcbiAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSB4aHIucmVzcG9uc2VUZXh0O1xuICAgICAgICAgICAgICAgIGNjLmxvZyhyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlID09IFwiY29ycmVjdFwiKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vMS4gY2xvc2UgcHJpdmF0ZSBjaGFubGVcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByaXZhdGVDbGllbnQgIT0gbnVsbCAmJiBwcml2YXRlQ2xpZW50ICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcHJpdmF0ZUNsaWVudC51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vMi4gY29ubmVjdCB0byBuZXcgcHJpdmF0ZSBjaGFubGVcbiAgICAgICAgICAgICAgICAgICAgc29ja2V0ID0gbmV3IFNvY2tKUyhzZXJ2ZXJVcmwgKyBcIi9zdG9tcFwiKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbml0YWxQcml2YXRlQ2hhbmxlRm9yVXNlcihyb29tTnVtYmVyLCBcInNlbmRcIik7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8zLiBidWlsZCBhIG1lc3NhZ2UgZm9yIGFkZCBuZXcgdXNlciBmb3IgYWxsIGluIHRoZSBwcml2YXRlIGNoYW5sZVxuXG4gICAgICAgICAgICAgICAgICAgIC8vNC4gc2VuZCBhIG1lc3NhZ2UgdG8gc2VydmVyIGZvciBwdWJsaWMgdGhlIG5ldyBqb2luIHVzZXIgLlxuXG4gICAgICAgICAgICAgICAgICAgIC8vNS4gc2hvdyBnYW1lIHRhYmxlIHNlbmNlXG5cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nYW1lTWFpbk1lbnUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2FtZU1vZGVOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRhYmxlTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRhYmxlTm9kZS5vcGFjaXR5ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jcmVhdGVSb29tX2NsZWFyVGFibGVJbml0YWxVc2VySW5mbygpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnRhYmxlTm9kZS5vcGFjaXR5ID0gMjU1O1xuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuaW5pdGFsVXNlclJlYWR5TGF5ZXIoKTtcbiAgICAgICAgICAgICAgICAgICAgLy9tZXNzYWdlRG9tYWluID0gcmVxdWlyZShcIm1lc3NhZ2VEb21haW5cIikubWVzc2FnZURvbWFpbjtcbiAgICAgICAgICAgICAgICAgICAgLy9tZXNzYWdlRG9tYWluLm1lc3NhZ2VCZWxvbmdzVG9Qcml2YXRlQ2hhbmxlTnVtYmVyID0gcm9vbU51bWJlcjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9mdWxsIC0tLSByb29tIGFscmVkeSBmdWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzaG93IHRoZSBpcyBhIGluY29yZXJjdCByb29tIG51bWJlclxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAvLyBzaG93IG5ldCB3b3JrIGlzc3VlXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICB9KS5iaW5kKHRoaXMpO1xuICAgICAgICAvL3hoci5zZXRSZXF1ZXN0SGVhZGVyKCdDb250ZW50LVR5cGUnLCAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkOyBjaGFyc2V0PVVURi04Jyk7XG4gICAgICAgIHhoci5vcGVuKFwiR0VUXCIsIHVybCwgdHJ1ZSk7XG4gICAgICAgIHhoci5zZW5kKCk7XG4gICAgfSxcbiAgICBvbkRlc3Ryb3k6IGZ1bmN0aW9uIG9uRGVzdHJveSgpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLnJlbW92ZU9ubGluZVVzZXJCeUlkKCk7XG4gICAgICAgIGNjLmxvZyhcInJlbW92ZSBzdWNjZXNzXCIpO1xuICAgICAgICAvL2NvbHNlIHRoZSB3ZWJzb2tlY3RcbiAgICAgICAgcHJpdmF0ZUNsaWVudC5kaXNjb25uZWN0KCk7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLXVudGlsIGZ1bmN0aW9uIGluIHRoaXMgY2xhc3NzLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy9hZGQgdGhlIG5ldyB1c2VyIHRvIHByaXZhdGUgY2hhbmxlXG4gICAgYnVpbGRBZGROZXdVc2VyTWVzc2FnZUFuZFNlbmRJdDogZnVuY3Rpb24gYnVpbGRBZGROZXdVc2VyTWVzc2FnZUFuZFNlbmRJdChyb29tTnVtYmVyKSB7XG4gICAgICAgIHZhciBtZXNzYWdlRG9tYWluID0gcmVxdWlyZShcIm1lc3NhZ2VEb21haW5cIikubWVzc2FnZURvbWFpbjtcbiAgICAgICAgbWVzc2FnZURvbWFpbi5tZXNzYWdlQmVsb25nc1RvUHJpdmF0ZUNoYW5sZU51bWJlciA9IHJvb21OdW1iZXI7XG4gICAgICAgIG1lc3NhZ2VEb21haW4ubWVzc2FnZUFjdGlvbiA9IFwiYWRkTmV3VXNlclRvUHJpdmF0ZUNoYW5sZVwiO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5ID0gXCJcIjtcbiAgICAgICAgdGhpcy5zZW5kV2ViU29rZWN0TWVzc2FnZVRvU2VydmVyKG1lc3NhZ2VEb21haW4pO1xuICAgIH0sXG4gICAgLy9jaGFuZ2UgdGhlIHVzZXIgc3RhdHVzXG4gICAgYnVpbGRDaGFuZ2VVc2VyU3RhdHVzTWVzc2FnZUFuZFNlbmRJdDogZnVuY3Rpb24gYnVpbGRDaGFuZ2VVc2VyU3RhdHVzTWVzc2FnZUFuZFNlbmRJdCh1c2Vyb3BlbmlkLCByb29tTnVtYmVyLCBzdGF1dHMpIHtcbiAgICAgICAgdmFyIG1lc3NhZ2VEb21haW4gPSByZXF1aXJlKFwibWVzc2FnZURvbWFpblwiKS5tZXNzYWdlRG9tYWluO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCZWxvbmdzVG9Qcml2YXRlQ2hhbmxlTnVtYmVyID0gcm9vbU51bWJlcjtcbiAgICAgICAgbWVzc2FnZURvbWFpbi5tZXNzYWdlQWN0aW9uID0gXCJjaGFuZ2VVc2VyU3RhdHVzSW5Qcml2YXRlQ2hhbmxlXCI7XG4gICAgICAgIHZhciBvID0gbmV3IE9iamVjdCgpO1xuICAgICAgICBvLm9wZW5pZCA9IHVzZXJvcGVuaWQ7XG4gICAgICAgIG8uc3RhdHVzID0gc3RhdXRzO1xuICAgICAgICB2YXIgYm9keVN0ciA9IEpTT04uc3RyaW5naWZ5KG8pO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5ID0gYm9keVN0cjtcblxuICAgICAgICB0aGlzLnNlbmRXZWJTb2tlY3RNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZURvbWFpbik7XG4gICAgfSxcbiAgICAvL3NlbmQgZ2FtZSBtb2RlIHRvIHNlcnZlclxuICAgIGJ1aWxkR2FtZU1vZGVNZXNzYWdlQW5kU2VuZEl0OiBmdW5jdGlvbiBidWlsZEdhbWVNb2RlTWVzc2FnZUFuZFNlbmRJdChyb29tTnVtYmVyKSB7XG4gICAgICAgIHZhciBtZXNzYWdlRG9tYWluID0gcmVxdWlyZShcIm1lc3NhZ2VEb21haW5cIikubWVzc2FnZURvbWFpbjtcbiAgICAgICAgbWVzc2FnZURvbWFpbi5tZXNzYWdlQmVsb25nc1RvUHJpdmF0ZUNoYW5sZU51bWJlciA9IHJvb21OdW1iZXI7XG4gICAgICAgIG1lc3NhZ2VEb21haW4ubWVzc2FnZUFjdGlvbiA9IFwicHVibGljR2FtZU1vZGVcIjtcbiAgICAgICAgbWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keSA9IEpTT04uc3RyaW5naWZ5KGdhbWVNb2RlTW9kZWwpO1xuICAgICAgICB0aGlzLnNlbmRXZWJTb2tlY3RNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZURvbWFpbik7XG4gICAgfSxcbiAgICAvL3NlbmQgdGhlIGNhbmxlIHVzZXIgb3BlbmlkIHRvIHNlcnZlciBhbmQgcHVibGljIHRvIG90aGVyXG4gICAgYnVpbGRDYW5sZVVzZXJNZXNzYWdlQW5kU2VuZEl0OiBmdW5jdGlvbiBidWlsZENhbmxlVXNlck1lc3NhZ2VBbmRTZW5kSXQocm9vbU51bWJlcikge1xuICAgICAgICB2YXIgbWVzc2FnZURvbWFpbiA9IHJlcXVpcmUoXCJtZXNzYWdlRG9tYWluXCIpLm1lc3NhZ2VEb21haW47XG4gICAgICAgIG1lc3NhZ2VEb21haW4ubWVzc2FnZUJlbG9uZ3NUb1ByaXZhdGVDaGFubGVOdW1iZXIgPSByb29tTnVtYmVyO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VBY3Rpb24gPSBcInVzZXJDYW5sZVJvb21cIjtcbiAgICAgICAgbWVzc2FnZURvbWFpbi5tZXNzYWdlQm9keSA9IHVzZXJMaXN0QXJyYXlbMl0ub3BlbmlkO1xuICAgICAgICB0aGlzLnNlbmRXZWJTb2tlY3RNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZURvbWFpbik7XG4gICAgfSxcbiAgICAvL2J1aWxkIHVwZGF0ZSByb29tIG51bWJlciBmb3IgdXNlciBtZXNzYWdlXG4gICAgYnVpbGRVcGRhdGVSb29tTnVtYmVyT2ZPbmxpbmVVc2VyTWVzc2FnZTogZnVuY3Rpb24gYnVpbGRVcGRhdGVSb29tTnVtYmVyT2ZPbmxpbmVVc2VyTWVzc2FnZShyb29tTnVtYmVyLCBteW9wZW5pZCkge1xuICAgICAgICB2YXIgbWVzc2FnZURvbWFpbiA9IHJlcXVpcmUoXCJtZXNzYWdlRG9tYWluXCIpLm1lc3NhZ2VEb21haW47XG4gICAgICAgIG1lc3NhZ2VEb21haW4ubWVzc2FnZUJlbG9uZ3NUb1ByaXZhdGVDaGFubGVOdW1iZXIgPSByb29tTnVtYmVyO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VBY3Rpb24gPSBcInVwZGF0ZU9ubGluZVVzZXJSb29tTnVtYmVyXCI7XG4gICAgICAgIG1lc3NhZ2VEb21haW4ubWVzc2FnZUJvZHkgPSBteW9wZW5pZDtcbiAgICAgICAgdGhpcy5zZW5kV2ViU29rZWN0TWVzc2FnZVRvU2VydmVyKG1lc3NhZ2VEb21haW4pO1xuICAgIH0sXG4gICAgc2V0VXNlclN0YXV0c0FuZEltYWdlOiBmdW5jdGlvbiBzZXRVc2VyU3RhdXRzQW5kSW1hZ2UoaSwgdXNlclN0YXR1cykge1xuICAgICAgICBjYy5sb2coXCJzZXRVc2VyU3RhdXRzQW5kSW1hZ2U6XCIgKyBpICsgXCItXCIgKyB1c2VyU3RhdHVzKTtcbiAgICAgICAgdmFyIHVzZXJSZWFkTm9kZSA9IHRoaXMudXNlclJlYWR5TGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyXCIgKyAoaSArIDEpICsgXCJSZWFkeU5vZGVcIik7XG4gICAgICAgIGlmIChpID09IDIpIHtcbiAgICAgICAgICAgIHZhciB1c2VyQnRuID0gdXNlclJlYWROb2RlLmdldENoaWxkQnlOYW1lKFwidXNlclJlYWR5QnRuXCIpO1xuICAgICAgICAgICAgdXNlclJlYWROb2RlID0gdXNlclJlYWROb2RlLmdldENoaWxkQnlOYW1lKFwidXNlclN0YXR1SW1hZ2VcIik7XG5cbiAgICAgICAgICAgIGlmICh1c2VyU3RhdHVzID09IDIpIHtcbiAgICAgICAgICAgICAgICB1c2VyQnRuLm5vcm1hbFNwcml0ZSA9IHRoaXMuY2hhbmdlVXNlclN0YXR1c05vQnRuSW1hZ2U7XG4gICAgICAgICAgICAgICAgdXNlckJ0bi5wcmVzc2VkU3ByaXRlID0gdGhpcy5jaGFuZ2VVc2VyU3RhdHVzTm9CdG5JbWFnZTtcbiAgICAgICAgICAgICAgICB1c2VyQnRuLmhvdmVyU3ByaXRlID0gdGhpcy5jaGFuZ2VVc2VyU3RhdHVzTm9CdG5JbWFnZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh1c2VyU3RhdHVzID09IDMpIHtcbiAgICAgICAgICAgICAgICB1c2VyQnRuLm5vcm1hbFNwcml0ZSA9IHRoaXMuY2hhbmdlVXNlclN0YXR1c1llc0J0bkltYWdlO1xuICAgICAgICAgICAgICAgIHVzZXJCdG4ucHJlc3NlZFNwcml0ZSA9IHRoaXMuY2hhbmdlVXNlclN0YXR1c1llc0J0bkltYWdlO1xuICAgICAgICAgICAgICAgIHVzZXJCdG4uaG92ZXJTcHJpdGUgPSB0aGlzLmNoYW5nZVVzZXJTdGF0dXNZZXNCdG5JbWFnZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHt9XG5cbiAgICAgICAgdmFyIHMgPSB1c2VyUmVhZE5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIGlmICh1c2VyU3RhdHVzID09IDIpIHtcbiAgICAgICAgICAgIHMuc3ByaXRlRnJhbWUgPSB0aGlzLnVzZXJTdGF0dXNOb0ltYWdlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh1c2VyU3RhdHVzID09IDMpIHtcbiAgICAgICAgICAgIHMuc3ByaXRlRnJhbWUgPSB0aGlzLnVzZXJTdGF0dXNZZXNJbWFnZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHVzZXJMaXN0QXJyYXlbaV0uZ2FtZWluZ1N0YXR1ID0gdXNlclN0YXR1cztcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzhkZjIxTGJDN1ZBOTdDby85MEJPTnl4JywgJ0dsb2JhbCcpO1xuLy8gc2NyaXB0L2RvbWFpbkNsYXNzL0dsb2JhbC5qc1xuXG53aW5kb3cuR2xvYmFsID0ge1xuICAgIHVzZXJJbmZvOiBudWxsLFxuICAgIGdhbWVDb25maWc6IG51bGwsXG4gICAgZ2FtZUNvbmZpZ1NldHRpbmc6IG51bGwsXG4gICAgZ2FtZU1vZGU6IG51bGwsXG4gICAgaG9zdFNlcnZlcklwOiBcIjEyNy4wLjAuMVwiLFxuICAgIGhvc3RTZXJ2ZXJQb3J0OiBcIjkwMDFcIixcbiAgICBob3N0SHR0cFByb3RvY29sOiBcImh0dHBcIixcbiAgICBwcml2YXRlQ2xpZW50Q2hhbmxlOiBudWxsLFxuICAgIGpvaW5Sb29tTnVtYmVyOiBudWxsLFxuICAgIHVzZXJMaXN0OiBbXSxcbiAgICBzdWJpZDogMCxcbiAgICBjaHVQYWlBY3Rpb25UeXBlOiBcIlwiLFxuICAgIGh1YW5TYW5aaGFuZ1BhaUxpc3Q6IFtdXG59O1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnN2U5ZDdNRnZybENBNUkrQVpRVnVucXYnLCAnSHVQYWlBY3Rpb24nKTtcbi8vIHNjcmlwdC91aS9IdVBhaUFjdGlvbi5qc1xuXG52YXIgdGFibGVBY3Rpb25TY3JpcHQ7XG52YXIgdGFibGVVc2VySW5mb1NjcmlwdDtcbnZhciB0YWJsZU1vUGFpQWN0aW9uU2NyaXB0O1xudmFyIHNvdXJjZVBhaUxpc3Q7XG52YXIgc291cmNlUGFpQ291bnQ7XG52YXIgaHVGbGFnID0gZmFsc2U7XG52YXIgamlhbmdGbGFnID0gZmFsc2U7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cblxuICAgICAgICB0YWJsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHRhYmxlQWN0aW9uOiBjYy5Ob2RlLFxuICAgICAgICBtb1BhaVByZWZhYjogY2MuUHJlZmFiLFxuICAgICAgICB1c2VyM1BhaUxpc3ROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZVVzZXJJbmZvOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZU1vUGFpTm9kZTogY2MuTm9kZVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGFibGVBY3Rpb25TY3JpcHQgPSB0aGlzLnRhYmxlQWN0aW9uLmdldENvbXBvbmVudChcInRhYmxlUGFpQWN0aW9uXCIpO1xuICAgICAgICB0YWJsZVVzZXJJbmZvU2NyaXB0ID0gdGhpcy50YWJsZVVzZXJJbmZvLmdldENvbXBvbmVudChcInRhYmxlVXNlckluZm9cIik7XG4gICAgICAgIHRhYmxlTW9QYWlBY3Rpb25TY3JpcHQgPSB0aGlzLnRhYmxlTW9QYWlOb2RlLmdldENvbXBvbmVudChcInRhYmxlTW9QYWlBY3Rpb25cIik7XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG4gICAgdGVzdEh1UGFpOiBmdW5jdGlvbiB0ZXN0SHVQYWkoKSB7XG4gICAgICAgIHRoaXMuaHVQYWlBY3Rpb24oXCIxOVwiLCBcInRlc3RVc2VyMlwiKTtcbiAgICAgICAgdGhpcy5odVBhaUFjdGlvbihcIjE5XCIsIFwidGVzdFVzZXIwXCIpO1xuICAgICAgICB0aGlzLmh1UGFpQWN0aW9uKFwiMTlcIiwgXCJ0ZXN0VXNlcjFcIik7XG4gICAgICAgIHRoaXMuaHVQYWlBY3Rpb24oXCIxOVwiLCBcInRlc3RVc2VyM1wiKTtcbiAgICB9LFxuXG4gICAgaHVQYWlBY3Rpb246IGZ1bmN0aW9uIGh1UGFpQWN0aW9uKHBhaU51bWJlciwgdXNlck9wZW5JZCkge1xuICAgICAgICB2YXIgY3VycmVudFVzZXIgPSB0YWJsZUFjdGlvblNjcmlwdC5nZXRDb3JyZWN0VXNlckJ5T3BlbklkKHVzZXJPcGVuSWQpO1xuICAgICAgICB2YXIgcGFpTGlzdCA9IGN1cnJlbnRVc2VyLnBhaUxpc3RBcnJheTtcbiAgICAgICAgdmFyIGxhdHN0SW5kZXggPSAwO1xuICAgICAgICBpZiAocGFpTGlzdC5sZW5ndGggPT0gMTMpIHtcbiAgICAgICAgICAgIGxhdHN0SW5kZXggPSAxMztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxhdHN0SW5kZXggPSBwYWlMaXN0Lmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICB2YXIgdXNlclBvaW50ID0gY3VycmVudFVzZXIucG9pbnRJbmRleDtcbiAgICAgICAgdmFyIHBhaVBhdGggPSB0YWJsZUFjdGlvblNjcmlwdC5nZXRDaHVQYWlOYW1lQnlOb2RlTmFtZShwYWlOdW1iZXIsIHVzZXJQb2ludCk7XG5cbiAgICAgICAgdmFyIHBhaU5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLm1vUGFpUHJlZmFiKTtcbiAgICAgICAgdmFyIHNwcml0ZSA9IHBhaU5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIHBhaU5vZGUubmFtZSA9IFwicGFpXCIgKyBsYXRzdEluZGV4ICsgXCJfXCIgKyBwYWlOdW1iZXI7XG4gICAgICAgIC8vcGFpTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdmFyIHNwcml0ZSA9IHBhaU5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKHBhaVBhdGgsIGZ1bmN0aW9uIChlcnIsIHNwKSB7XG4gICAgICAgICAgICBjYy5sb2coXCI2MTpcIiArIHBhaVBhdGgpO1xuICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgIGNjLmxvZyhcIkVycm9yOlwiICsgZXJyKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYy5sb2coXCI2NTpcIik7XG4gICAgICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUoc3ApO1xuICAgICAgICAgICAgcGFpTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB9KTtcbiAgICAgICAgcGFpTm9kZSA9IHRoaXMuZ2V0Q3VyZWVudFBvc3Rpb25Gcm9tVXNlclBvaW50QW5kUGFpTGlzdChwYWlMaXN0LCB1c2VyUG9pbnQsIHBhaU5vZGUpO1xuICAgICAgICB2YXIgdXNlck5vZGVOYW1lID0gXCJ1c2VyXCIgKyB1c2VyUG9pbnQgKyBcIlBlbmdQYWlMaXN0Tm9kZVwiO1xuICAgICAgICBjYy5sb2coXCJ1c2VyTm9kZU5hbWU6XCIgKyB1c2VyTm9kZU5hbWUpO1xuICAgICAgICB2YXIgdXNlck5vZGVQYWlMaXN0ID0gY2MuZmluZCh1c2VyTm9kZU5hbWUsIHRoaXMudGFibGVOb2RlKTtcbiAgICAgICAgdXNlck5vZGVQYWlMaXN0LmFkZENoaWxkKHBhaU5vZGUpO1xuICAgICAgICAvLy0tLWRhdGEgbGF5ZXItLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICB2YXIgdXNlckxpc3QgPSBHbG9iYWwudXNlckxpc3Q7XG4gICAgICAgIHZhciB1c2VyO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXJPcGVuSWQpIHtcbiAgICAgICAgICAgICAgICB1c2VyID0gdXNlckxpc3RbaV07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdXNlci51c2VyTW9QYWkgPSBwYWlOdW1iZXI7XG4gICAgICAgIHRhYmxlQWN0aW9uU2NyaXB0Lmluc2VydE1vUGFpSW50b1BhaUxpc3QodXNlcik7XG4gICAgICAgIHRhYmxlTW9QYWlBY3Rpb25TY3JpcHQudXBkYXRlVXNlckxpc3RJbkdvYmFsKHVzZXIpO1xuICAgICAgICB0YWJsZUFjdGlvblNjcmlwdC5kaXNhYmxlQWxsU2xlZlBhaSgpO1xuICAgIH0sXG4gICAgLy9kZWNpZGUgdGhlIHBhaW51bWJlciBpZiBodSBvciBub3QgaHUgLlxuICAgIGh1cGFpTG9naWM6IGZ1bmN0aW9uIGh1cGFpTG9naWMocGFpTnVtYmVyLCB1c2VyT3BlbklkKSB7XG4gICAgICAgIC8vdmFyIGN1cnJlbnRVc2VyID0gdGFibGVBY3Rpb25TY3JpcHQuZ2V0Q29ycmVjdFVzZXJCeU9wZW5JZCh1c2VyT3BlbklkKTtcbiAgICAgICAgdmFyIGh1RmxhZ0RldGFpbHMgPSBmYWxzZTtcbiAgICAgICAgdmFyIHBhaUxpc3QgPSB0YWJsZUFjdGlvblNjcmlwdC5pbnNlcnRQYWlJbnRvUGFpTGlzdEJ5UGFpQW5kT3BlbklkKHBhaU51bWJlciwgdXNlck9wZW5JZCk7XG4gICAgICAgIGlmICh0aGlzLmNoZWNrUWlhb1FpRHVpKHBhaUxpc3QpKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcblxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgcGFpTGlzdC5zcGxpY2UoaSwgMSk7XG4gICAgICAgICAgICAgICAgaSA9IDA7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwiaHVwYWlMb2dpYyBwYWlMaXN0OlwiICsgcGFpTGlzdCk7XG4gICAgICAgICAgICAgICAgLy9odUZsYWdEZXRhaWxzID0gdGhpcy5zdGFydERlY2lkZUh1KHBhaUxpc3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBzdGFydERlY2lkZUh1OiBmdW5jdGlvbiBzdGFydERlY2lkZUh1KHBhaUxpc3QpIHtcbiAgICAgICAgY2MubG9nKFwiMTA2IHBhaUxpc3Q6XCIgKyBwYWlMaXN0LnRvU3RyaW5nKCkpO1xuICAgICAgICBpZiAoc291cmNlUGFpQ291bnQgPT0gMCkge1xuICAgICAgICAgICAgc291cmNlUGFpTGlzdCA9IFtdO1xuICAgICAgICAgICAgc291cmNlUGFpTGlzdCA9IHRoaXMuZGVlcENvcHlBcnJheShwYWlMaXN0LCBzb3VyY2VQYWlMaXN0KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHNvdXJjZVBhaUNvdW50Kys7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFpTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIHBhaSA9IHBhaUxpc3RbaV07XG4gICAgICAgICAgICB2YXIgY291bnQgPSB0aGlzLmNvdW50RWxlbWVudEFjY291bnQocGFpLCBwYWlMaXN0KTtcbiAgICAgICAgICAgIHZhciBvbGRMZW4gPSBwYWlMaXN0Lmxlbmd0aDtcbiAgICAgICAgICAgIHZhciBvbGRQYWlMaXN0ID0gW107XG4gICAgICAgICAgICBvbGRQYWlMaXN0ID0gdGhpcy5kZWVwQ29weUFycmF5KHBhaUxpc3QsIG9sZFBhaUxpc3QpO1xuXG4gICAgICAgICAgICBwYWlMaXN0ID0gdGhpcy5jaGVja0xpYW5TYW5aaGFuKHBhaSwgcGFpTGlzdCk7XG4gICAgICAgICAgICB2YXIgbmV3TGVuID0gcGFpTGlzdC5sZW5ndGg7XG4gICAgICAgICAgICBjYy5sb2coXCIxMTY6XCIgKyBwYWlMaXN0LnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgaWYgKG9sZExlbiAhPSBuZXdMZW4pIHtcbiAgICAgICAgICAgICAgICBodUZsYWcgPSB0aGlzLnN0YXJ0RGVjaWRlSHUocGFpTGlzdCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChjb3VudCA+PSAyKSB7XG4gICAgICAgICAgICAgICAgdmFyIG9sZFBhaUxpc3QyID0gW107XG4gICAgICAgICAgICAgICAgb2xkUGFpTGlzdDIgPSB0aGlzLmRlZXBDb3B5QXJyYXkob2xkUGFpTGlzdCwgb2xkUGFpTGlzdDIpO1xuICAgICAgICAgICAgICAgIG9sZExlbiA9IG9sZFBhaUxpc3QubGVuZ3RoO1xuICAgICAgICAgICAgICAgIG9sZFBhaUxpc3QgPSB0aGlzLmxpYW5nWmhhbmcocGFpLCBvbGRQYWlMaXN0KTtcbiAgICAgICAgICAgICAgICBuZXdMZW4gPSBvbGRQYWlMaXN0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICBpZiAob2xkTGVuICE9IG5ld0xlbikge1xuICAgICAgICAgICAgICAgICAgICBqaWFuZ0ZsYWcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICBodUZsYWcgPSB0aGlzLnN0YXJ0RGVjaWRlSHUob2xkUGFpTGlzdCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoY291bnQgPj0gMykge1xuICAgICAgICAgICAgICAgIG9sZExlbiA9IG9sZFBhaUxpc3QubGVuZ3RoO1xuICAgICAgICAgICAgICAgIG9sZFBhaUxpc3QgPSB0aGlzLmNoZWNrU2FuWmhhbmcocGFpLCBvbGRQYWlMaXN0KTtcbiAgICAgICAgICAgICAgICBuZXdMZW4gPSBvbGRQYWlMaXN0Lmxlbmd0aDtcbiAgICAgICAgICAgICAgICBpZiAob2xkTGVuICE9IG5ld0xlbikge1xuXG4gICAgICAgICAgICAgICAgICAgIGh1RmxhZyA9IHRoaXMuc3RhcnREZWNpZGVIdShvbGRQYWlMaXN0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2MubG9nKFwicGFpTGlzdDpcIiArIHBhaUxpc3QudG9TdHJpbmcoKSk7XG5cbiAgICAgICAgLy9jYy5sb2coXCJvbGRQYWlMaXN0OlwiICsgb2xkUGFpTGlzdC50b1N0cmluZygpKTtcblxuICAgICAgICBpZiAocGFpTGlzdC5sZW5ndGggPT0gMiAmJiBwYWlMaXN0WzBdID09IHBhaUxpc3RbMV0pIHtcbiAgICAgICAgICAgIGh1RmxhZyA9IHRydWU7XG4gICAgICAgIH0gZWxzZSBpZiAoamlhbmdGbGFnID09IHRydWUgJiYgcGFpTGlzdC5sZW5ndGggPT0gMCkge1xuICAgICAgICAgICAgaHVGbGFnID0gdHJ1ZTtcbiAgICAgICAgICAgIC8vIHZhciBsaXN0ID0gW107XG4gICAgICAgICAgICAvLyBsaXN0ID0gdGhpcy5kZWVwQ29weUFycmF5KHNvdXJjZVBhaUxpc3QsIGxpc3QpO1xuICAgICAgICAgICAgLy8gbGlzdC5zcGxpY2UoMCwgMSk7XG4gICAgICAgICAgICAvLyBzb3VyY2VQYWlDb3VudCA9IDA7XG4gICAgICAgICAgICAvLyBodUZsYWcgPSB0aGlzLnN0YXJ0RGVjaWRlSHUobGlzdCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gaHVGbGFnO1xuICAgIH0sXG4gICAgY2hlY2tMaWFuU2FuWmhhbjogZnVuY3Rpb24gY2hlY2tMaWFuU2FuWmhhbihwYWksIHBhaUxpc3QpIHtcblxuICAgICAgICB2YXIgcGFpTnVtYmVyID0gcGFpWzFdO1xuICAgICAgICB2YXIgcHJlUGFpID0gLTE7XG4gICAgICAgIHZhciBuZXh0UGFpID0gLTE7XG4gICAgICAgIHZhciBleGVjdXRlRmxhZyA9IGZhbHNlO1xuICAgICAgICBpZiAocGFpTnVtYmVyICsgXCJcIiA9PSBcIjFcIikge1xuICAgICAgICAgICAgcHJlUGFpID0gcGFpICsgMTtcbiAgICAgICAgICAgIG5leHRQYWkgPSBwYWkgKyAyO1xuICAgICAgICB9IGVsc2UgaWYgKHBhaU51bWJlciArIFwiXCIgPT0gXCI5XCIpIHtcbiAgICAgICAgICAgIHByZVBhaSA9IHBhaSAtIDE7XG4gICAgICAgICAgICBuZXh0UGFpID0gcGFpIC0gMjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHByZVBhaSA9IHBhaSAtIDE7XG4gICAgICAgICAgICBuZXh0UGFpID0gcGFpICsgMTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5jb250YWlucyhwYWlMaXN0LCBwcmVQYWkpICYmIHRoaXMuY29udGFpbnMocGFpTGlzdCwgbmV4dFBhaSkpIHtcbiAgICAgICAgICAgIGV4ZWN1dGVGbGFnID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHByZVBhaSA9IHBhaSArIDE7XG4gICAgICAgICAgICBuZXh0UGFpID0gcGFpICsgMjtcbiAgICAgICAgICAgIGNjLmxvZyhcInByZVBhaTpcIiArIHByZVBhaSArIFwiLS1cIiArIFwibmV4dFBhaTpcIiArIG5leHRQYWkpO1xuICAgICAgICAgICAgaWYgKHRoaXMuY29udGFpbnMocGFpTGlzdCwgcHJlUGFpKSAmJiB0aGlzLmNvbnRhaW5zKHBhaUxpc3QsIG5leHRQYWkpKSB7XG4gICAgICAgICAgICAgICAgZXhlY3V0ZUZsYWcgPSB0cnVlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwcmVQYWkgPSBwYWkgLSAxO1xuICAgICAgICAgICAgICAgIG5leHRQYWkgPSBwYWkgLSAyO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbnRhaW5zKHBhaUxpc3QsIHByZVBhaSkgJiYgdGhpcy5jb250YWlucyhwYWlMaXN0LCBuZXh0UGFpKSkge1xuICAgICAgICAgICAgICAgICAgICBleGVjdXRlRmxhZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZXhlY3V0ZUZsYWcgPSBmYWxzZTs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGV4ZWN1dGVGbGFnKSB7XG4gICAgICAgICAgICBwYWlMaXN0ID0gdGFibGVBY3Rpb25TY3JpcHQucmVtb3ZlRWxlbWVudEJ5TnVtYmVyQnlQYWlMaXN0RnJvbVVzZXIocGFpTGlzdCwgcHJlUGFpLCAxKTtcbiAgICAgICAgICAgIHBhaUxpc3QgPSB0YWJsZUFjdGlvblNjcmlwdC5yZW1vdmVFbGVtZW50QnlOdW1iZXJCeVBhaUxpc3RGcm9tVXNlcihwYWlMaXN0LCBuZXh0UGFpLCAxKTtcbiAgICAgICAgICAgIHBhaUxpc3QgPSB0YWJsZUFjdGlvblNjcmlwdC5yZW1vdmVFbGVtZW50QnlOdW1iZXJCeVBhaUxpc3RGcm9tVXNlcihwYWlMaXN0LCBwYWksIDEpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHBhaUxpc3Q7XG4gICAgfSxcbiAgICByZW1vdmVMaWFuU2FuWmhhbmc6IGZ1bmN0aW9uIHJlbW92ZUxpYW5TYW5aaGFuZyhwYWksIHBhaUxpc3QpIHt9LFxuICAgIGxpYW5nWmhhbmc6IGZ1bmN0aW9uIGxpYW5nWmhhbmcocGFpLCBwYWlMaXN0KSB7XG4gICAgICAgIHZhciBjb3VudCA9IHRoaXMuY291bnRFbGVtZW50QWNjb3VudChwYWksIHBhaUxpc3QpO1xuICAgICAgICBpZiAoY291bnQgPT0gMiB8fCBjb3VudCA9PSA0KSB7XG4gICAgICAgICAgICBwYWlMaXN0ID0gdGFibGVBY3Rpb25TY3JpcHQucmVtb3ZlRWxlbWVudEJ5TnVtYmVyQnlQYWlMaXN0RnJvbVVzZXIocGFpTGlzdCwgcGFpLCAyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcGFpTGlzdDtcbiAgICB9LFxuICAgIGNoZWNrU2FuWmhhbmc6IGZ1bmN0aW9uIGNoZWNrU2FuWmhhbmcocGFpLCBwYWlMaXN0KSB7XG4gICAgICAgIHZhciBjb3VudCA9IHRoaXMuY291bnRFbGVtZW50QWNjb3VudChwYWksIHBhaUxpc3QpO1xuICAgICAgICBpZiAoY291bnQgPj0gMykge1xuICAgICAgICAgICAgcGFpTGlzdCA9IHRhYmxlQWN0aW9uU2NyaXB0LnJlbW92ZUVsZW1lbnRCeU51bWJlckJ5UGFpTGlzdEZyb21Vc2VyKHBhaUxpc3QsIHBhaSwgMyk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcGFpTGlzdDtcbiAgICB9LFxuICAgIGNoZWNrUWlhb1FpRHVpOiBmdW5jdGlvbiBjaGVja1FpYW9RaUR1aShwYWlMaXN0KSB7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgc291cmNlTGVuID0gcGFpTGlzdC5sZW5ndGg7XG4gICAgICAgICAgICBwYWlMaXN0ID0gdGhpcy5saWFuZ1poYW5nKHBhaUxpc3RbaV0sIHBhaUxpc3QpO1xuICAgICAgICAgICAgY2MubG9nKFwicGFpTGlzdDpcIiArIHBhaUxpc3QpO1xuICAgICAgICAgICAgdmFyIG9sZExlbiA9IHBhaUxpc3QubGVuZ3RoO1xuICAgICAgICAgICAgaWYgKHNvdXJjZUxlbiAhPSBvbGRMZW4pIHtcbiAgICAgICAgICAgICAgICBpID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmxvZyhcInBhaUxpc3Q6XCIgKyBwYWlMaXN0LnRvU3RyaW5nKCkpO1xuXG4gICAgICAgIGlmIChwYWlMaXN0Lmxlbmd0aCA9PSAwKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICB0ZXN0UWlhb1FpRHVpOiBmdW5jdGlvbiB0ZXN0UWlhb1FpRHVpKCkge1xuXG4gICAgICAgIHZhciBwYWlMaXN0ID0gWzE1LCAxNSwgMTgsIDE4LCAyMiwgMjIsIDI1LCAyNSwgMjUsIDI1LCAyOSwgMjksIDM4LCAzOF07XG5cbiAgICAgICAgdmFyIGYgPSB0aGlzLmNoZWNrUWlhb1FpRHVpKHBhaUxpc3QpO1xuICAgICAgICBjYy5sb2coXCJjaGVjayBxaWFvcWlkdWk6XCIgKyBmKTtcbiAgICB9LFxuICAgIHRlc3RIdTogZnVuY3Rpb24gdGVzdEh1KCkge1xuICAgICAgICB2YXIgcGFpTGlzdCA9IFsxNSwgMTUsIDE2LCAxNiwgMTcsIDE3LCAxOCwgMTgsIDE4LCAzNiwgMzZdO1xuICAgICAgICBzb3VyY2VQYWlDb3VudCA9IDA7XG4gICAgICAgIGh1RmxhZyA9IGZhbHNlO1xuICAgICAgICBqaWFuZ0ZsYWcgPSBmYWxzZTtcblxuICAgICAgICBjYy5sb2coXCJ0ZXN0SFUgMTpcIiArIHRoaXMuc3RhcnREZWNpZGVIdShwYWlMaXN0KSk7XG4gICAgICAgIGh1RmxhZyA9IGZhbHNlO1xuICAgICAgICBqaWFuZ0ZsYWcgPSBmYWxzZTtcbiAgICAgICAgcGFpTGlzdCA9IFsxNSwgMTYsIDE3LCAxOSwgMTksIDE5LCAyMywgMjMsIDM1LCAzNiwgMzddO1xuICAgICAgICBjYy5sb2coXCJ0ZXN0SFUgMjpcIiArIHRoaXMuc3RhcnREZWNpZGVIdShwYWlMaXN0KSk7XG4gICAgICAgIGh1RmxhZyA9IGZhbHNlO1xuICAgICAgICBqaWFuZ0ZsYWcgPSBmYWxzZTtcbiAgICAgICAgcGFpTGlzdCA9IFsxMSwgMTEsIDE3LCAxNywgMTcsIDE4LCAxOSwgMjAsIDM1LCAzNiwgMzddO1xuICAgICAgICBjYy5sb2coXCJ0ZXN0SFUgMzpcIiArIHRoaXMuc3RhcnREZWNpZGVIdShwYWlMaXN0KSk7XG4gICAgICAgIGh1RmxhZyA9IGZhbHNlO1xuICAgICAgICBqaWFuZ0ZsYWcgPSBmYWxzZTtcbiAgICAgICAgcGFpTGlzdCA9IFsxNSwgMTYsIDE3LCAxNywgMTcsIDE4LCAxOSwgMjAsIDIxLCAzNiwgMzZdO1xuICAgICAgICBjYy5sb2coXCJ0ZXN0SFUgNDpcIiArIHRoaXMuc3RhcnREZWNpZGVIdShwYWlMaXN0KSk7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVVudGlscy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBkZWVwQ29weUFycmF5OiBmdW5jdGlvbiBkZWVwQ29weUFycmF5KHNvdXJlQXJyYXksIGRlc2NBcnJheSkge1xuICAgICAgICBpZiAoc291cmVBcnJheSAhPSBudWxsICYmIHNvdXJlQXJyYXkubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzb3VyZUFycmF5Lmxlbmd0aCArIDE7IGkrKykge1xuICAgICAgICAgICAgICAgIGlmIChzb3VyZUFycmF5W2ldICE9IG51bGwgJiYgc291cmVBcnJheVtpXSAhPSB1bmRlZmluZWQpIGRlc2NBcnJheS5wdXNoKHNvdXJlQXJyYXlbaV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGRlc2NBcnJheTtcbiAgICB9LFxuXG4gICAgY291bnRFbGVtZW50QWNjb3VudDogZnVuY3Rpb24gY291bnRFbGVtZW50QWNjb3VudChwYWksIHBhaUxpc3QpIHtcbiAgICAgICAgdmFyIGNvdW50ID0gMDtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0Lmxlbmd0aCArIDE7IGkrKykge1xuICAgICAgICAgICAgaWYgKHBhaUxpc3RbaV0gPT0gcGFpKSB7XG4gICAgICAgICAgICAgICAgY291bnQrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBjb3VudDtcbiAgICB9LFxuICAgIGNvbnRhaW5zOiBmdW5jdGlvbiBjb250YWlucyhhcnJheSwgb2JqKSB7XG4gICAgICAgIHZhciBpID0gYXJyYXkubGVuZ3RoO1xuICAgICAgICB3aGlsZSAoaS0tKSB7XG4gICAgICAgICAgICBpZiAoYXJyYXlbaV0gKyBcIlwiID09PSBvYmogKyBcIlwiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgZ2V0Q3VyZWVudFBvc3Rpb25Gcm9tVXNlclBvaW50QW5kUGFpTGlzdDogZnVuY3Rpb24gZ2V0Q3VyZWVudFBvc3Rpb25Gcm9tVXNlclBvaW50QW5kUGFpTGlzdChwYWlBcnJheSwgcG9pbnQsIHBhaU5vZGUpIHtcbiAgICAgICAgdmFyIHN0YXJ0WCA9IDA7XG4gICAgICAgIHZhciBzdGFydFkgPSAwO1xuICAgICAgICB2YXIgbGF0ZXN0WCA9IDA7XG4gICAgICAgIHZhciBsYXRlc3RZID0gMDtcbiAgICAgICAgdmFyIHN0YXJ0UG9pbnQgPSAtNTIwO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhaUFycmF5Lmxlbmd0aCArIDE7IGkrKykge1xuICAgICAgICAgICAgaWYgKHBhaUFycmF5W2ldICE9IG51bGwgJiYgcGFpQXJyYXlbaV0gIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgLy9maXggdGhlIHVzZXIgMVxuICAgICAgICAgICAgICAgIGlmIChwb2ludCA9PSBcIjFcIikge1xuICAgICAgICAgICAgICAgICAgICBzdGFydFggPSAzODA7XG4gICAgICAgICAgICAgICAgICAgIC8vIGxhdGVzdFg9c3RhcnRYIC0gaSAqIDU1O1xuICAgICAgICAgICAgICAgICAgICAvLyBsYXRlc3RZPTBcbiAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAoc3RhcnRYIC0gaSAqIDU1LCAwKTtcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLnVzZXIxUGFpTGlzdE5vZGUuYWRkQ2hpbGQocGFpTm9kZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHBvaW50ID09IFwiMlwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXJ0WCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIHN0YXJ0WSA9IC00MDA7XG4gICAgICAgICAgICAgICAgICAgIHBhaU5vZGUucG9zaXRpb24gPSBjYy5wKHN0YXJ0WCwgc3RhcnRZICsgaSAqIDI4KTtcbiAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS56SW5kZXggPSBwYWlBcnJheS5sZW5ndGggLSBpO1xuICAgICAgICAgICAgICAgICAgICBwYWlOb2RlLndpZHRoID0gNDA7XG4gICAgICAgICAgICAgICAgICAgIHBhaU5vZGUuaGVpZ2h0ID0gODU7XG4gICAgICAgICAgICAgICAgICAgIC8vcGFpTm9kZS5zZXRMb2NhbFpPcmRlcigxMDAwKTtcbiAgICAgICAgICAgICAgICAgICAgLy9wYWlOb2RlLnpJbmRleCA9IDEwMDA7XG4gICAgICAgICAgICAgICAgICAgIC8vcGFyZW50Tm9kZVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocG9pbnQgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGkgPT0gMTMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhaU5vZGUucG9zaXRpb24gPSBjYy5wKHN0YXJ0UG9pbnQgKyBpICogODAsIDApO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAoc3RhcnRQb2ludCArIGkgKiA3OSwgMCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAocG9pbnQgPT0gXCI0XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgc3RhcnRYID0gMDtcbiAgICAgICAgICAgICAgICAgICAgc3RhcnRZID0gLTIwMDtcbiAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAoc3RhcnRYLCBzdGFydFkgKyBpICogMjgpO1xuXG4gICAgICAgICAgICAgICAgICAgIHBhaU5vZGUud2lkdGggPSA0MDtcbiAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5oZWlnaHQgPSA4NTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBvaW50ID09IFwiMVwiKSB7XG4gICAgICAgICAgICBwYWlOb2RlLnBvc2l0aW9uID0gY2MucChwYWlOb2RlLnBvc2l0aW9uLnggKyA4NSwgcGFpTm9kZS5wb3NpdGlvbi55KTtcbiAgICAgICAgfSBlbHNlIGlmIChwb2ludCA9PSBcIjJcIikge1xuICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAocGFpTm9kZS5wb3NpdGlvbi54LCBwYWlOb2RlLnBvc2l0aW9uLnkgLSAyNSk7XG4gICAgICAgIH0gZWxzZSBpZiAocG9pbnQgPT0gXCI0XCIpIHtcbiAgICAgICAgICAgIHBhaU5vZGUucG9zaXRpb24gPSBjYy5wKHBhaU5vZGUucG9zaXRpb24ueCwgcGFpTm9kZS5wb3NpdGlvbi55IC0gODUpO1xuICAgICAgICAgICAgcGFpTm9kZS5zZXRMb2NhbFpPcmRlcigxMDAwKTtcbiAgICAgICAgICAgIHBhaU5vZGUuekluZGV4ID0gMTAwMDtcbiAgICAgICAgfSBlbHNlIGlmIChwb2ludCA9PSBcIjNcIikge1xuICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAocGFpTm9kZS5wb3NpdGlvbi54IC0gOTAsIHBhaU5vZGUucG9zaXRpb24ueSArIDEwKTtcblxuICAgICAgICAgICAgcGFpTm9kZS53aWR0aCA9IDc1O1xuICAgICAgICAgICAgcGFpTm9kZS5oZWlnaHQgPSAxMTA7XG4gICAgICAgIH1cbiAgICAgICAgY2MubG9nKFwicGFpTm9kZSBwb3NpdGlvbjpcIiArIHBhaU5vZGUucG9zaXRpb24pO1xuICAgICAgICByZXR1cm4gcGFpTm9kZTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2UwZGJmQ0hXdFpMdUpJTitmUlBQc004JywgJ0luaXRhbEdhbWVNYWluJyk7XG4vLyBzY3JpcHQvY29udHJvbGxlcnMvSW5pdGFsR2FtZU1haW4uanNcblxudmFyIHVzZXJJbmZvO1xudmFyIHVzZXJJbmZvTGF5ZXI7XG52YXIgZ2FtZU1vZGVMYXllcjtcbnZhciB0b3BJbmZvTGF5ZXI7XG52YXIgbWFpbkxpc3RCdXR0b25MYXllcjtcbnZhciBzZXJ2ZXJVcmw7XG52YXIgc29ja2V0O1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIGF1ZGlvTW5nOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICAgICAgc2VydmVyVXJsID0gR2xvYmFsLmhvc3RIdHRwUHJvdG9jb2wgKyBcIjovL1wiICsgR2xvYmFsLmhvc3RTZXJ2ZXJJcCArIFwiOlwiICsgR2xvYmFsLmhvc3RTZXJ2ZXJQb3J0O1xuICAgICAgICBzb2NrZXQgPSBuZXcgU29ja0pTKHNlcnZlclVybCArIFwiL3N0b21wXCIpO1xuXG4gICAgICAgIC8vcGxheSBiZ21cbiAgICAgICAgdGhpcy5hdWRpb01uZyA9IHRoaXMuYXVkaW9NbmcuZ2V0Q29tcG9uZW50KCdBdWRpb01uZycpO1xuICAgICAgICB0aGlzLmF1ZGlvTW5nLnBsYXlNdXNpYygpO1xuICAgICAgICAvL2hpZGUgdGhlIGdhbWUgbW9kZVxuICAgICAgICBnYW1lTW9kZUxheWVyID0gY2MuZmluZChcIkNhbnZhcy9HYW1lTW9kZVNlbGVjdFwiKTtcbiAgICAgICAgZ2FtZU1vZGVMYXllci5hY3RpdmUgPSBmYWxzZTtcblxuICAgICAgICB0b3BJbmZvTGF5ZXIgPSBjYy5maW5kKFwiQ2FudmFzL3RvcEluZm9Vc2VyTGF5ZXJcIik7XG4gICAgICAgIG1haW5MaXN0QnV0dG9uTGF5ZXIgPSBjYy5maW5kKFwiQ2FudmFzL0xpc3RCdXR0b25cIik7XG4gICAgICAgIC8vaW5pdGFsIHVzZXIgaW5mbyBpbiB0aGUgZ2FtZU1haW4gc2VuY2VcbiAgICAgICAgaWYgKEdsb2JhbC51c2VySW5mbyA9PSB1bmRlZmluZWQgfHwgR2xvYmFsLnVzZXJJbmZvID09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3I6IG5vIGZvdW5kIGNvcnJlY3QgdXNlciAscGxlYXNlIGNoZWNrIHNlcnZlciBvciBuZXR3b3JrLlwiKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICAgICAgLy9pbnRhbCB0aGUgdXNlciBpbmZvIHRleHRcbiAgICAgICAgICAgIC8vdXNlckluZm9MYXllciA9IGNjLmZpbmQoXCJDYW52YXMvdG9wSW5mb0xheWVyL3VzZXJJbmZvTGF5b3V0L3VzZXJJbmZvVHh0TGF5b3V0XCIpO1xuICAgICAgICAgICAgc2VsZi5pbml0YWxQcml2YXRlQ2hhbmxlRm9yVXNlcih1c2VySW5mby5yb29tTnVtYmVyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vXG4gICAgfSxcbiAgICBzaG93R2FtZU1vZGVOb2RlOiBmdW5jdGlvbiBzaG93R2FtZU1vZGVOb2RlKCkge1xuICAgICAgICBnYW1lTW9kZUxheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRvcEluZm9MYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgbWFpbkxpc3RCdXR0b25MYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuICAgIGhpZGVHYW1lTW9kZU5vZGU6IGZ1bmN0aW9uIGhpZGVHYW1lTW9kZU5vZGUoKSB7XG4gICAgICAgIGdhbWVNb2RlTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRvcEluZm9MYXllci5hY3RpdmUgPSB0cnVlO1xuICAgICAgICBtYWluTGlzdEJ1dHRvbkxheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG5cbiAgICBpbml0YWxQcml2YXRlQ2hhbmxlRm9yVXNlcjogZnVuY3Rpb24gaW5pdGFsUHJpdmF0ZUNoYW5sZUZvclVzZXIocm9vbU51bWJlcikge1xuICAgICAgICBjYy5sb2coXCJyb29tTnVtYmVyOlwiICsgcm9vbU51bWJlcik7XG4gICAgICAgIHZhciBwcml2YXRlQ2xpZW50ID0gU3RvbXAub3Zlcihzb2NrZXQpO1xuXG4gICAgICAgIHByaXZhdGVDbGllbnQuY29ubmVjdCh7fSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcHJpdmF0ZUNsaWVudC5zdWJzY3JpYmUoXCIvcXVldWUvcHJpdmF0ZVJvb21DaGFubGVcIiArIHJvb21OdW1iZXIsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgdmFyIGJvZHlTdHIgPSBtZXNzYWdlLmJvZHk7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwiZ2V0IG1lZXNnZSBmcm9tIHByaXZhdGUgY2hhbmxlOnByaXZhdGVSb29tQ2hhbmxlXCIgKyByb29tTnVtYmVyKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjYy5sb2coXCJjb25uZWN0IHByaXZhdGUgY2hhbmxlIGVycm9yICFcIik7XG4gICAgICAgIH0pO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc5YmNkM2hQR0dsSzM1dUNFaXVORU9KcScsICdKb2luUm9vbUNvbnRyb2xsZXInKTtcbi8vIHNjcmlwdC9jb250cm9sbGVycy9Kb2luUm9vbUNvbnRyb2xsZXIuanNcblxudmFyIHJvb21OdW1iZXJMYWJsZUxpc3QgPSBbXTtcbnZhciBnYW1lQWN0aW9uO1xudmFyIHRhYmxlTmV0V29yaztcbnZhciBhbGVydE1lc3NhZ2VVSTtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICByb29tSW5wdXRMYWJsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIGtleUJvYXJkTm9kZTogY2MuTm9kZSxcbiAgICAgICAgbG9hZGluZ0ljb25Ob2RlOiBjYy5Ob2RlLFxuICAgICAgICBnYW1lb0NvbmZpZ1NjcmlwdE5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHRhYmxlTmV0d29ya05vZGU6IGNjLk5vZGUsXG4gICAgICAgIGFsZXJ0TWVzc2FnZU5vZGVTY2lycHQ6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIGdhbWVBY3Rpb24gPSB0aGlzLmdhbWVvQ29uZmlnU2NyaXB0Tm9kZS5nZXRDb21wb25lbnQoXCJnYW1lQ29uZmlnQnV0dG9uTGlzdEFjdGlvblwiKTtcbiAgICAgICAgdGFibGVOZXRXb3JrID0gdGhpcy50YWJsZU5ldHdvcmtOb2RlLmdldENvbXBvbmVudChcIkdhbWVUYWJsZU5ldFdvcmtcIik7XG4gICAgICAgIGFsZXJ0TWVzc2FnZVVJID0gdGhpcy5hbGVydE1lc3NhZ2VOb2RlU2NpcnB0LmdldENvbXBvbmVudChcImFsZXJ0TWVzc2FnZVBhbmxlXCIpO1xuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxuXG4gICAga2V5Qm9yYWRDbGlja0V2ZW50OiBmdW5jdGlvbiBrZXlCb3JhZENsaWNrRXZlbnQoZXZlbnQpIHtcbiAgICAgICAgaWYgKHJvb21OdW1iZXJMYWJsZUxpc3QubGVuZ3RoIDw9IDUpIHtcbiAgICAgICAgICAgIHZhciBub2RlID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICAgICAgdmFyIG5hbWUgPSBub2RlLm5hbWU7XG4gICAgICAgICAgICBuYW1lID0gbmFtZS5yZXBsYWNlKFwiTnVtXCIsIFwiXCIpO1xuICAgICAgICAgICAgbmFtZSA9IG5hbWUucmVwbGFjZShcIk5vZGVcIiwgXCJcIik7XG4gICAgICAgICAgICByb29tTnVtYmVyTGFibGVMaXN0LnB1c2gobmFtZSk7XG4gICAgICAgICAgICB0aGlzLmludGFsVGhlTnVtYmVyTGFibGVCeUxpc3QoKTtcbiAgICAgICAgfVxuICAgICAgICBjYy5sb2cocm9vbU51bWJlckxhYmxlTGlzdC50b1N0cmluZygpKTtcbiAgICB9LFxuICAgIGludGFsVGhlTnVtYmVyTGFibGVCeUxpc3Q6IGZ1bmN0aW9uIGludGFsVGhlTnVtYmVyTGFibGVCeUxpc3QoKSB7XG4gICAgICAgIHZhciBub2RlID0gdGhpcy5yb29tSW5wdXRMYWJsZU5vZGU7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcm9vbU51bWJlckxhYmxlTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIGxhYmxlTmFtZSA9IFwiaW5wdXRcIiArIChpICsgMSkgKyBcIk5vZGVcIjtcbiAgICAgICAgICAgIHZhciBsYWJsZU5vZGUgPSBjYy5maW5kKGxhYmxlTmFtZSwgbm9kZSk7XG4gICAgICAgICAgICBpZiAobGFibGVOb2RlICE9IG51bGwgJiYgbGFibGVOb2RlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB2YXIgbGFibGUgPSBsYWJsZU5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgICAgICAgICBsYWJsZS5zdHJpbmcgPSByb29tTnVtYmVyTGFibGVMaXN0W2ldO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBkZWxldGVOdW1iZXI6IGZ1bmN0aW9uIGRlbGV0ZU51bWJlcigpIHtcbiAgICAgICAgcm9vbU51bWJlckxhYmxlTGlzdC5zcGxpY2UoLTEsIDEpO1xuICAgICAgICBjYy5sb2cocm9vbU51bWJlckxhYmxlTGlzdC50b1N0cmluZygpKTtcbiAgICAgICAgdGhpcy5jbGVhbkxhYmxlKCk7XG4gICAgICAgIHRoaXMuaW50YWxUaGVOdW1iZXJMYWJsZUJ5TGlzdCgpO1xuICAgIH0sXG4gICAgZ2V0Um9vbU51bWJlcjogZnVuY3Rpb24gZ2V0Um9vbU51bWJlcigpIHtcbiAgICAgICAgdmFyIHJvb21OdW1iZXIgPSBcIlwiO1xuICAgICAgICBpZiAocm9vbU51bWJlckxhYmxlTGlzdC5sZW5ndGggPCA2KSB7XG4gICAgICAgICAgICBhbGVydE1lc3NhZ2VVSS50ZXh0ID0gXCLkvaDlv4XpobvovpPlhaU25L2N5pWw55qE5oi/6Ze05Y+377yBXCI7XG4gICAgICAgICAgICBhbGVydE1lc3NhZ2VVSS5zZXRUZXh0T2ZQYW5lbCgpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHJvb21OdW1iZXJMYWJsZUxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICByb29tTnVtYmVyID0gcm9vbU51bWJlciArIHJvb21OdW1iZXJMYWJsZUxpc3RbaV07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJvb21OdW1iZXI7XG4gICAgfSxcblxuICAgIGNsZWFuTGFibGU6IGZ1bmN0aW9uIGNsZWFuTGFibGUoKSB7XG4gICAgICAgIHZhciBub2RlID0gdGhpcy5yb29tSW5wdXRMYWJsZU5vZGU7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgNjsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgbGFibGVOYW1lID0gXCJpbnB1dFwiICsgKGkgKyAxKSArIFwiTm9kZVwiO1xuICAgICAgICAgICAgdmFyIGxhYmxlTm9kZSA9IGNjLmZpbmQobGFibGVOYW1lLCBub2RlKTtcbiAgICAgICAgICAgIGlmIChsYWJsZU5vZGUgIT0gbnVsbCAmJiBsYWJsZU5vZGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHZhciBsYWJsZSA9IGxhYmxlTm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xuICAgICAgICAgICAgICAgIGxhYmxlLnN0cmluZyA9IFwiXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGpvaW5Sb29tQWN0aW9uOiBmdW5jdGlvbiBqb2luUm9vbUFjdGlvbigpIHtcbiAgICAgICAgdmFyIHJvb21OdW1iZXIgPSBcIlwiO1xuICAgICAgICBpZiAocm9vbU51bWJlckxhYmxlTGlzdC5sZW5ndGggPCA2KSB7XG4gICAgICAgICAgICBhbGVydE1lc3NhZ2VVSS50ZXh0ID0gXCLkvaDlv4XpobvovpPlhaU25L2N5pWw55qE5oi/6Ze05Y+377yBXCI7XG4gICAgICAgICAgICBhbGVydE1lc3NhZ2VVSS5zZXRUZXh0T2ZQYW5lbCgpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHJvb21OdW1iZXJMYWJsZUxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICByb29tTnVtYmVyID0gcm9vbU51bWJlciArIHJvb21OdW1iZXJMYWJsZUxpc3RbaV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBnYW1lQWN0aW9uLnNob3dMb2FkaW5nSWNvbigpO1xuICAgICAgICAgICAgdGFibGVOZXRXb3JrLmpvaW5Sb29tKHJvb21OdW1iZXIpO1xuICAgICAgICB9XG4gICAgICAgIC8qXG4gICAgICAgIGlmIChyb29tTnVtYmVyID09IFwiXCIpIHtcbiAgICAgICAgICAgIGFsZXJ0TWVzc2FnZVVJLnRleHQgPSBcIuS9oOW/hemhu+i+k+WFpTbkvY3mlbDnmoTmiL/pl7Tlj7fvvIFcIjtcbiAgICAgICAgICAgIGFsZXJ0TWVzc2FnZVVJLnNldFRleHRPZlBhbmVsKCk7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgfSovXG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzJkNWY3VjRpblpJYnBFS0VnV1BHdWJTJywgJ1BlcnNpc3RSb290Tm9kZScpO1xuLy8gc2NyaXB0L3NlcnZpY2UvUGVyc2lzdFJvb3ROb2RlLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuXG4gICAgICAgIHNjcmlwdE5vZGU6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgY2MuZ2FtZS5hZGRQZXJzaXN0Um9vdE5vZGUoc2VsZi5zY3JpcHROb2RlKTtcbiAgICB9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdmYzNlZk00eU5CTVJKbXdLQXluRS9mVScsICdQbGF5QmdtJyk7XG4vLyBzY3JpcHQvYXVkaW8vUGxheUJnbS5qc1xuXG5jYy5DbGFzcyh7XG4gICAgJ2V4dGVuZHMnOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGF1ZGlvTW5nOiBjYy5Ob2RlLFxuICAgICAgICBhbGVydE1lc3NhZ2U6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMuYXVkaW9NbmcgPSB0aGlzLmF1ZGlvTW5nLmdldENvbXBvbmVudCgnQXVkaW9NbmcnKTtcbiAgICAgICAgdGhpcy5hdWRpb01uZy5wbGF5TXVzaWMoKTtcbiAgICB9LFxuXG4gICAgcGxheUdhbWU6IGZ1bmN0aW9uIHBsYXlHYW1lKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ3RhYmxlJyk7XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZVxuICAgIHVwZGF0ZTogZnVuY3Rpb24gdXBkYXRlKGR0KSB7fVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICcyZjAxZGd1czd0S3dibnRqV0Rsd1M5aCcsICdTd2l0Y2hTY2VuZScpO1xuLy8gc2NyaXB0L2NvbnRyb2xsZXJzL1N3aXRjaFNjZW5lLmpzXG5cbmNjLkNsYXNzKHtcbiAgICAnZXh0ZW5kcyc6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cblxuICAgICAgICBzY2VuZToge1xuICAgICAgICAgICAgJ2RlZmF1bHQnOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuU2NlbmVcbiAgICAgICAgfVxuXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG4gICAgZ290b0dhbWVDZW50ZXI6IGZ1bmN0aW9uIGdvdG9HYW1lQ2VudGVyKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ2dhbWVDZW50ZXInKTtcbiAgICB9LFxuICAgIGdvdG9HYW1lTWFpbjogZnVuY3Rpb24gZ290b0dhbWVNYWluKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ2dhbWVNYWluMicpO1xuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxuICAgIGdvdG9HYW1lQ2VudGVyU2NlbmU6IGZ1bmN0aW9uIGdvdG9HYW1lQ2VudGVyU2NlbmUoKSB7fVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdiODAxNkF2LzlaTjU0ellyME5SV01zdycsICdhY3Rpb25NZXNhZ2VEb21haW4nKTtcbi8vIHNjcmlwdC9kb21haW5DbGFzcy9hY3Rpb25NZXNhZ2VEb21haW4uanNcblxudmFyIGFjdGlvbk1lc3NhZ2VEb21haW4gPSB7XG5cdG1lc3NhZ2VBY3Rpb246IFwiXCIsXG5cdG1lc3NhZ2VFeGVjdXRlRmxhZzogXCJcIixcblx0bWVzc2FnZUV4ZWN1dGVSZXN1bHQ6IFwiXCIsXG5cdHVzZXJvcGVuaWQ6IFwiXCJcbn07XG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0YWN0aW9uTWVzc2FnZURvbWFpbjogYWN0aW9uTWVzc2FnZURvbWFpblxufTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzkzMTE3OU1BYk5CenIvTzROZm5tUmpPJywgJ2FsZXJ0TWVzc2FnZVBhbmxlJyk7XG4vLyBzY3JpcHQvdWkvYWxlcnRNZXNzYWdlUGFubGUuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIHRleHQ6IFN0cmluZyxcbiAgICAgICAgYWxlcnRQYW5lbE5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHRleHROb2RlOiBjYy5Ob2RlLFxuICAgICAgICBidXR0b25Ob2RlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLmFsZXJ0UGFuZWxOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxuXG4gICAgc2V0VGV4dE9mUGFuZWw6IGZ1bmN0aW9uIHNldFRleHRPZlBhbmVsKCkge1xuICAgICAgICB0aGlzLmFsZXJ0UGFuZWxOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHZhciByID0gdGhpcy50ZXh0Tm9kZS5nZXRDb21wb25lbnQoY2MuUmljaFRleHQpO1xuICAgICAgICByLnN0cmluZyA9IHRoaXMudGV4dDtcbiAgICB9LFxuXG4gICAgY2xvc2VQYW5lbDogZnVuY3Rpb24gY2xvc2VQYW5lbCgpIHtcbiAgICAgICAgdGhpcy5hbGVydFBhbmVsTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgY2xvc2VCdXR0b246IGZ1bmN0aW9uIGNsb3NlQnV0dG9uKCkge1xuICAgICAgICB0aGlzLmJ1dHRvbk5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgfSxcblxuICAgIHNob3dCdXR0b246IGZ1bmN0aW9uIHNob3dCdXR0b24oKSB7XG4gICAgICAgIHRoaXMuYnV0dG9uTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnOTI4YzJnN29BQkMzNmVmelBLVmtPa2cnLCAnY2FDaGVTY3JpcHQnKTtcbi8vIHNjcmlwdC9saWIvY2FDaGVTY3JpcHQuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge31cblxufSk7XG5cbi8qKlxuICog5Yqo5oCB5Yqg6L295Zu+54mH5ZCO6YeK5pS+XG4gKiBcbiAqIHZhciBzcHJpdGVGcmFtZSA9IG5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU7XG52YXIgZGVwcyA9IGNjLmxvYWRlci5nZXREZXBlbmRzUmVjdXJzaXZlbHkoc3ByaXRlRnJhbWUpO1xuY2MubG9hZGVyLnJlbGVhc2UoZGVwcyk7XG4gKiBcbiAqL1xuXG4vKipcbiAqIFxuICogbG9hZE5hdGl2ZSA9IGZ1bmN0aW9uKHVybCwgY2FsbGJhY2spe1xuICAgIHZhciBkaXJwYXRoID0gIGpzYi5maWxlVXRpbHMuZ2V0V3JpdGFibGVQYXRoKCkgKyAnaW1nLyc7XG4gICAgdmFyIGZpbGVwYXRoID0gZGlycGF0aCArIE1ENSh1cmwpICsgJy5wbmcnO1xuXG4gICAgZnVuY3Rpb24gbG9hZEVuZCgpe1xuICAgICAgICBjYy5sb2FkZXIubG9hZChmaWxlcGF0aCwgZnVuY3Rpb24oZXJyLCB0ZXgpe1xuICAgICAgICAgICAgaWYoIGVyciApe1xuICAgICAgICAgICAgICAgIGNjLmVycm9yKGVycik7XG4gICAgICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUodGV4KTtcbiAgICAgICAgICAgICAgICBpZiggc3ByaXRlRnJhbWUgKXtcbiAgICAgICAgICAgICAgICAgICAgc3ByaXRlRnJhbWUucmV0YWluKCk7XG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKHNwcml0ZUZyYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgfVxuXG4gICAgaWYoIGpzYi5maWxlVXRpbHMuaXNGaWxlRXhpc3QoZmlsZXBhdGgpICl7XG4gICAgICAgIGNjLmxvZygnUmVtb3RlIGlzIGZpbmQnICsgZmlsZXBhdGgpO1xuICAgICAgICBsb2FkRW5kKCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB2YXIgc2F2ZUZpbGUgPSBmdW5jdGlvbihkYXRhKXtcbiAgICAgICAgaWYoIHR5cGVvZiBkYXRhICE9PSAndW5kZWZpbmVkJyApe1xuICAgICAgICAgICAgaWYoICFqc2IuZmlsZVV0aWxzLmlzRGlyZWN0b3J5RXhpc3QoZGlycGF0aCkgKXtcbiAgICAgICAgICAgICAgICBqc2IuZmlsZVV0aWxzLmNyZWF0ZURpcmVjdG9yeShkaXJwYXRoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYoIGpzYi5maWxlVXRpbHMud3JpdGVEYXRhVG9GaWxlKCAgbmV3IFVpbnQ4QXJyYXkoZGF0YSkgLCBmaWxlcGF0aCkgKXtcbiAgICAgICAgICAgICAgICBjYy5sb2coJ1JlbW90ZSB3cml0ZSBmaWxlIHN1Y2NlZWQuJyk7XG4gICAgICAgICAgICAgICAgbG9hZEVuZCgpO1xuICAgICAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAgICAgY2MubG9nKCdSZW1vdGUgd3JpdGUgZmlsZSBmYWlsZWQuJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgY2MubG9nKCdSZW1vdGUgZG93bmxvYWQgZmlsZSBmYWlsZWQuJyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFxuICAgIHZhciB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcblxuICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNjLmxvZyhcInhoci5yZWFkeVN0YXRlICBcIiAreGhyLnJlYWR5U3RhdGUpO1xuICAgICAgICBjYy5sb2coXCJ4aHIuc3RhdHVzICBcIiAreGhyLnN0YXR1cyk7XG4gICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA9PT0gNCApIHtcbiAgICAgICAgICAgIGlmKHhoci5zdGF0dXMgPT09IDIwMCl7XG4gICAgICAgICAgICAgICAgeGhyLnJlc3BvbnNlVHlwZSA9ICdhcnJheWJ1ZmZlcic7XG4gICAgICAgICAgICAgICAgc2F2ZUZpbGUoeGhyLnJlc3BvbnNlKTtcbiAgICAgICAgICAgIH1lbHNle1xuICAgICAgICAgICAgICAgIHNhdmVGaWxlKG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfS5iaW5kKHRoaXMpO1xuICAgIHhoci5vcGVuKFwiR0VUXCIsIHVybCwgdHJ1ZSk7XG4gICAgeGhyLnNlbmQoKTtcbn07XG4gKi9cbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMWE4NDFmcTJGNUw4cTNLVUFhUVMrd2knLCAnZ2FtZUNvbmZpZ0J1dHRvbkxpc3RBY3Rpb24nKTtcbi8vIHNjcmlwdC9jb250cm9sbGVycy9nYW1lQ29uZmlnQnV0dG9uTGlzdEFjdGlvbi5qc1xuXG5cbnZhciBib3lCdG4gPSBudWxsO1xudmFyIGdyaWxCdG4gPSBudWxsO1xudmFyIHRhYmxlTmV0V29yayA9IG51bGw7XG52YXIgc2hvd0dhbWVNb2RlID0gbnVsbDtcbnZhciBnYW1lQ29uZmlnU2NyaXB0ID0gbnVsbDtcbnZhciB0YWJsZVVzZXJJbmZvID0gbnVsbDtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuXG4gICAgICAgIGluZGV4Tm9kZTogY2MuTm9kZSxcbiAgICAgICAgbWFpbk1lbnVOb2RlOiBjYy5Ob2RlLFxuICAgICAgICBtYWluTWVudUdyYWlsQnRuOiBjYy5Ob2RlLFxuICAgICAgICBtYWluTWVudUJveUJ0bjogY2MuTm9kZSxcbiAgICAgICAgZ2FtZU1vZGVOb2RlOiBjYy5Ob2RlLFxuICAgICAgICBqb2luUm9vbU51bWJlclVJTm9kZTogY2MuTm9kZSxcbiAgICAgICAgZ2FtZUNvbmZpZ05vZGU6IGNjLk5vZGUsXG4gICAgICAgIGFsZXJ0TWVzc2FnZU5vZGU6IGNjLk5vZGUsXG5cbiAgICAgICAgZ2FtZVRhYmxlOiBjYy5Ob2RlLFxuICAgICAgICBnYW1lVGFibGVIZWFkOiBjYy5Ob2RlLFxuICAgICAgICBnYW1lVGFibGVNb2RlQmFyTm9kZTogY2MuTm9kZSxcblxuICAgICAgICB1c2VyTmlja05hbWVOb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyQ29kZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJJbWFnZU5vZGU6IGNjLk5vZGUsXG5cbiAgICAgICAgdGFibGVOZXRXb3JrTm9kZTogY2MuTm9kZSxcblxuICAgICAgICBsb2FkaW5nTm9kZTogY2MuTm9kZSxcbiAgICAgICAgbG9hZEljb25Ob2RlOiBjYy5Ob2RlLFxuICAgICAgICBzaG93R2FtZU1vZGVTY3JpcHQ6IGNjLk5vZGUsXG5cbiAgICAgICAgLy90YWJsZSByb29tXG4gICAgICAgIGNsb3NlUm9vbUJ0bjogY2MuTm9kZSxcbiAgICAgICAgLy9tYWluTWVudVxuICAgICAgICBiYWNrUm9vbUJ0bjogY2MuTm9kZSxcbiAgICAgICAgbmV3Um9vbUJ0bjogY2MuTm9kZSxcblxuICAgICAgICBnYW1lQ29uZmlnU2V0dGluZ1NjcmlwdDogY2MuTm9kZSxcbiAgICAgICAgdGFibGVVc2VySW5mb1NjcmlwdDogY2MuTm9kZVxuXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuXG4gICAgICAgIGdyaWxCdG4gPSB0aGlzLm1haW5NZW51R3JhaWxCdG4uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgIGJveUJ0biA9IHRoaXMubWFpbk1lbnVCb3lCdG4uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgIHRhYmxlTmV0V29yayA9IHRoaXMudGFibGVOZXRXb3JrTm9kZS5nZXRDb21wb25lbnQoXCJHYW1lVGFibGVOZXRXb3JrXCIpO1xuICAgICAgICB0aGlzLmxvYWRpbmdOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLmJhY2tSb29tQnRuLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5ld1Jvb21CdG4uYWN0aXZlID0gdHJ1ZTtcblxuICAgICAgICBzaG93R2FtZU1vZGUgPSB0aGlzLnNob3dHYW1lTW9kZVNjcmlwdC5nZXRDb21wb25lbnQoXCJzaG93R2FtZU1vZGVcIik7XG4gICAgICAgIGdhbWVDb25maWdTY3JpcHQgPSB0aGlzLmdhbWVDb25maWdTZXR0aW5nU2NyaXB0LmdldENvbXBvbmVudChcImdhbWVDb25maWdDb250cm9sbGVyXCIpO1xuICAgICAgICB0YWJsZVVzZXJJbmZvID0gdGhpcy50YWJsZVVzZXJJbmZvU2NyaXB0LmdldENvbXBvbmVudChcInRhYmxlVXNlckluZm9cIik7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS1Kb2luIHJvb20tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHNob3dKb2luUm9vbU5vZGU6IGZ1bmN0aW9uIHNob3dKb2luUm9vbU5vZGUoKSB7XG4gICAgICAgIHRoaXMuam9pblJvb21OdW1iZXJVSU5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgYm95QnRuLmVuYWJsZWQgPSBmYWxzZTtcbiAgICAgICAgZ3JpbEJ0bi5lbmFibGVkID0gZmFsc2U7XG4gICAgfSxcbiAgICBjbG9zZUpvZW5Sb29tTm9kZTogZnVuY3Rpb24gY2xvc2VKb2VuUm9vbU5vZGUoKSB7XG4gICAgICAgIHRoaXMuam9pblJvb21OdW1iZXJVSU5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIGJveUJ0bi5lbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgZ3JpbEJ0bi5lbmFibGVkID0gdHJ1ZTtcbiAgICB9LFxuICAgIHNob3dVc2VyTmlja05hbWVBbmRDb2RlOiBmdW5jdGlvbiBzaG93VXNlck5pY2tOYW1lQW5kQ29kZSgpIHtcbiAgICAgICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICBpZiAodXNlckluZm8gIT0gbnVsbCAmJiB1c2VySW5mbyAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHZhciB1c2VyTmlja25hbWUgPSB0aGlzLnVzZXJOaWNrTmFtZU5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgICAgIHZhciB1c2VyQ29kZSA9IHRoaXMudXNlckNvZGVOb2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XG5cbiAgICAgICAgICAgIHVzZXJOaWNrbmFtZS5zdHJpbmcgPSB1c2VySW5mby5uaWNrTmFtZTtcbiAgICAgICAgICAgIHVzZXJDb2RlLnN0cmluZyA9IHVzZXJJbmZvLnVzZXJDb2RlO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzZXJ2ZXJVcmwgPSBHbG9iYWwuaG9zdEh0dHBQcm90b2NvbCArIFwiOi8vXCIgKyBHbG9iYWwuaG9zdFNlcnZlcklwICsgXCI6XCIgKyBHbG9iYWwuaG9zdFNlcnZlclBvcnQ7XG5cbiAgICAgICAgdmFyIHRlc3RIZWFJbWFnZXVybCA9IHNlcnZlclVybCArIFwiL3dlYmNoYXRJbWFnZS9cIiArIHVzZXJJbmZvLmhlYWRJbWFnZUZpbGVOYW1lO1xuICAgICAgICBjYy5sb2coXCJ0ZXN0SGVhSW1hZ2V1cmw6XCIgKyB0ZXN0SGVhSW1hZ2V1cmwpO1xuICAgICAgICB2YXIgdXNlckltYWdlID0gdGhpcy51c2VySW1hZ2VOb2RlLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICBjYy5sb2FkZXIubG9hZCh0ZXN0SGVhSW1hZ2V1cmwsIGZ1bmN0aW9uIChlcnIsIHRleHR1cmUpIHtcbiAgICAgICAgICAgIHZhciBmcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcbiAgICAgICAgICAgIHVzZXJJbWFnZS5zcHJpdGVGcmFtZSA9IGZyYW1lO1xuICAgICAgICB9KTtcbiAgICB9LFxuXG4gICAgLy8gYWN0aW9uIDEsYnVpbGQgYSAgbmV3IHJvb20gLDAsIGJhY2sgdG8gcm9vbVxuICAgIGVudGVyTWFpbkVudHJ5OiBmdW5jdGlvbiBlbnRlck1haW5FbnRyeShhY3Rpb24pIHtcbiAgICAgICAgdGFibGVOZXRXb3JrLmluaXRhbENsaWVudCgpO1xuICAgICAgICB0aGlzLmluZGV4Tm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5tYWluTWVudU5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgZ3JpbEJ0bi5lbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgYm95QnRuLmVuYWJsZWQgPSB0cnVlO1xuICAgICAgICBpZiAoYWN0aW9uID09IFwiMVwiKSB7XG4gICAgICAgICAgICB0aGlzLmJhY2tSb29tQnRuLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5uZXdSb29tQnRuLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmJhY2tSb29tQnRuLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLm5ld1Jvb21CdG4uYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIHNob3dHYW1lQ29uZmlnOiBmdW5jdGlvbiBzaG93R2FtZUNvbmZpZygpIHtcbiAgICAgICAgdGhpcy5nYW1lQ29uZmlnTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICBnYW1lQ29uZmlnU2NyaXB0LmluaXRhbEdhbWVDb25maWcoKTtcbiAgICAgICAgYm95QnRuLmVuYWJsZWQgPSBmYWxzZTtcbiAgICAgICAgZ3JpbEJ0bi5lbmFibGVkID0gZmFsc2U7XG4gICAgfSxcbiAgICBjbG9zZUdhbWVDb25maWc6IGZ1bmN0aW9uIGNsb3NlR2FtZUNvbmZpZygpIHtcbiAgICAgICAgaWYgKEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZyAhPSBudWxsICYmIEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZyAhPSB1bmRlZmluZWQgJiYgR2xvYmFsLmdhbWVDb25maWdTZXR0aW5nICE9IFwiXCIpIHtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZ2FtZUNvbmZpZycsIEpTT04uc3RyaW5naWZ5KEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZykpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5nYW1lQ29uZmlnTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgYm95QnRuLmVuYWJsZWQgPSB0cnVlO1xuICAgICAgICBncmlsQnRuLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgIGNjLmxvZyhcImNsb3NlR2FtZUNvbmZpZzpcIiArIEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZyk7XG4gICAgfSxcbiAgICBzaG93R2FtZU1vZGVQYW5lbDogZnVuY3Rpb24gc2hvd0dhbWVNb2RlUGFuZWwoKSB7XG4gICAgICAgIGlmICh0aGlzLmJhY2tSb29tQnRuLmFjdGl2ZSA9PSB0cnVlKSB7XG4gICAgICAgICAgICB0aGlzLmJhY2tUYWJsZUFjdGlvbigpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5nYW1lTW9kZU5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIGJveUJ0bi5lbmFibGVkID0gZmFsc2U7XG4gICAgICAgICAgICBncmlsQnRuLmVuYWJsZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgY2xvc2VHYW1lTW9kZVBhbmVsOiBmdW5jdGlvbiBjbG9zZUdhbWVNb2RlUGFuZWwoKSB7XG4gICAgICAgIHRoaXMuZ2FtZU1vZGVOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICBib3lCdG4uZW5hYmxlZCA9IHRydWU7XG4gICAgICAgIGdyaWxCdG4uZW5hYmxlZCA9IHRydWU7XG4gICAgfSxcblxuICAgIGV4aXN0R2FtZTogZnVuY3Rpb24gZXhpc3RHYW1lKCkge1xuICAgICAgICBjYy5nYW1lLmVuZCgpO1xuICAgIH0sXG5cbiAgICAvL3JlYWQgdGhlIGdhbWUgdXNlciBmcm9tIEdvYmFsIHVzZXIgbGlzdCBhbmQgaW5pdGFsIHRoZSB1c2VyXG5cbiAgICBzaG93R2FtZVRhbGJlOiBmdW5jdGlvbiBzaG93R2FtZVRhbGJlKHJvb21Pd25lcikge1xuICAgICAgICB0aGlzLmdhbWVUYWJsZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLmpvaW5Sb29tTnVtYmVyVUlOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLmdhbWVNb2RlTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5pbmRleE5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMubWFpbk1lbnVOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuXG4gICAgICAgIHRoaXMuZ2FtZVRhYmxlSGVhZC5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5nYW1lVGFibGVNb2RlQmFyTm9kZS5hY3RpdmUgPSB0cnVlO1xuXG4gICAgICAgIGlmIChyb29tT3duZXIgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIHRoaXMuY2xvc2VSb29tQnRuLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmNsb3NlUm9vbUJ0bi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHNob3dHYW1lTW9kZS5zaG93R2FtZU1vZGUoKTtcbiAgICAgICAgLy9ub3cgd2UgbmVlZCBpbnN0YWwgdGhlIHVzZXIgaW5mbyBmb3IgZWFjaCB1c2VyXG4gICAgICAgIHRhYmxlVXNlckluZm8uaW5pdGFsVXNlckluZm9Gcm9tR29iYWxMaXN0KCk7XG4gICAgfSxcbiAgICBjbG9zZUdhbWVUYWJsZTogZnVuY3Rpb24gY2xvc2VHYW1lVGFibGUoKSB7XG4gICAgICAgIHRoaXMuZ2FtZVRhYmxlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAvL3RoaXMubWFpbk1lbnVOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRhYmxlTmV0V29yay5jbG9zZUdhbWVSb3VuZEx1bigpO1xuICAgICAgICBHbG9iYWwuam9pblJvb21OdW1iZXIgPSBcIlwiO1xuICAgICAgICB0aGlzLmVudGVyTWFpbkVudHJ5KFwiMVwiKTtcbiAgICB9LFxuXG4gICAgc2hvd0xvYWRpbmdJY29uOiBmdW5jdGlvbiBzaG93TG9hZGluZ0ljb24oKSB7XG4gICAgICAgIHRoaXMubG9hZGluZ05vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdmFyIHNlcSA9IGNjLnJlcGVhdEZvcmV2ZXIoY2Mucm90YXRlQnkoMywgMzYwKSk7XG4gICAgICAgIHRoaXMubG9hZEljb25Ob2RlLnJ1bkFjdGlvbihzZXEpO1xuICAgICAgICBjYy5sb2coXCJzaG93TG9hZGluZ0ljb25cIik7XG4gICAgfSxcbiAgICBjbG9zZUxvYWRpbmdJY29uOiBmdW5jdGlvbiBjbG9zZUxvYWRpbmdJY29uKCkge1xuICAgICAgICB0aGlzLmxvYWRJY29uTm9kZS5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICB0aGlzLmxvYWRpbmdOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH0sXG5cbiAgICBiYWNrUm9vbUFjdGlvbjogZnVuY3Rpb24gYmFja1Jvb21BY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuZ2FtZVRhYmxlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLmVudGVyTWFpbkVudHJ5KFwiMFwiKTtcbiAgICB9LFxuXG4gICAgYmFja1RhYmxlQWN0aW9uOiBmdW5jdGlvbiBiYWNrVGFibGVBY3Rpb24oKSB7XG4gICAgICAgIHZhciB1c2VySW5mbyA9IEdsb2JhbC51c2VySW5mbztcbiAgICAgICAgdmFyIHJvb21OdW1iZXIgPSB1c2VySW5mby5yb29tTnVtYmVyO1xuICAgICAgICBpZiAoR2xvYmFsLmpvaW5Sb29tTnVtYmVyID09IHJvb21OdW1iZXIpIHtcbiAgICAgICAgICAgIHRoaXMuc2hvd0dhbWVUYWxiZShcIjFcIik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnNob3dHYW1lVGFsYmUoXCIwXCIpO1xuICAgICAgICB9XG4gICAgfVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYmJiZjI2YnJUcElFSXhVT1hYQi9SV0wnLCAnZ2FtZUNvbmZpZ0NvbnRyb2xsZXInKTtcbi8vIHNjcmlwdC9jb250cm9sbGVycy9nYW1lQ29uZmlnQ29udHJvbGxlci5qc1xuXG52YXIgZ2FtZUNvbmZpZ1NldHRpbmc7XG52YXIgYWxlcnRNZXNzYWdlVUk7XG52YXIgbXVzaWNTY3JpcHQ7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgbXVzaWNUb2dnbGU6IGNjLk5vZGUsXG4gICAgICAgIG11c2ljRWZmZWN0VG9nZ2xlOiBjYy5Ob2RlLFxuICAgICAgICBwdWJsaWNJcExpbWl0VG9nZ2VsZTogY2MuTm9kZSxcbiAgICAgICAgZ3BzTGltaXROb2RlOiBjYy5Ob2RlLFxuICAgICAgICBhbGVydE1lc3NhZ2VOb2RlOiBjYy5Ob2RlLFxuICAgICAgICBtdXNpY05vZGU6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIGFsZXJ0TWVzc2FnZVVJID0gdGhpcy5hbGVydE1lc3NhZ2VOb2RlLmdldENvbXBvbmVudChcImFsZXJ0TWVzc2FnZVBhbmxlXCIpO1xuICAgICAgICAvL3RoaXMuaW5pdGFsR2FtZUNvbmZpZygpO1xuICAgICAgICBtdXNpY1NjcmlwdCA9IHRoaXMubXVzaWNOb2RlLmdldENvbXBvbmVudChcIkF1ZGlvTW5nXCIpO1xuICAgIH0sXG5cbiAgICB0b2dnbGVyQ2xpY2s6IGZ1bmN0aW9uIHRvZ2dsZXJDbGljayhldmVudCkge1xuICAgICAgICBnYW1lQ29uZmlnU2V0dGluZyA9IEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZztcbiAgICAgICAgaWYgKGdhbWVDb25maWdTZXR0aW5nID09IG51bGwgfHwgZ2FtZUNvbmZpZ1NldHRpbmcgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBnYW1lQ29uZmlnU2V0dGluZyA9IHJlcXVpcmUoXCJnYW1lQ29uZmlnU2V0dGluZ1wiKS5nYW1lQ29uZmlnU2V0dGluZztcbiAgICAgICAgfVxuICAgICAgICB2YXIgbm9kZSA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgdmFyIHBhcmVudCA9IG5vZGUucGFyZW50O1xuICAgICAgICB2YXIgdG9nZ2xlID0gcGFyZW50LmdldENvbXBvbmVudChjYy5Ub2dnbGUpO1xuICAgICAgICAvL211c2ljRWZmZWN0VG9nZ2xlLG11c2ljVG9nZ2xlLHB1YmxpY0lwVG9nZ2xlXG4gICAgICAgIGlmIChwYXJlbnQubmFtZSA9PSBcIm11c2ljRWZmZWN0VG9nZ2xlXCIpIHtcbiAgICAgICAgICAgIGlmICh0b2dnbGUuaXNDaGVja2VkKSB7XG4gICAgICAgICAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcubXVzaWNFZmZlY3QgPSBcIjFcIjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcubXVzaWNFZmZlY3QgPSBcIjBcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwYXJlbnQubmFtZSA9PSBcIm11c2ljVG9nZ2xlXCIpIHtcbiAgICAgICAgICAgIGlmICh0b2dnbGUuaXNDaGVja2VkKSB7XG4gICAgICAgICAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcubXVzaWMgPSBcIjFcIjtcbiAgICAgICAgICAgICAgICBtdXNpY1NjcmlwdC5wbGF5TXVzaWMoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcubXVzaWMgPSBcIjBcIjtcbiAgICAgICAgICAgICAgICBtdXNpY1NjcmlwdC5zdG9wTXVzaWMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwYXJlbnQubmFtZSA9PSBcInB1YmxpY0lwVG9nZ2xlXCIpIHtcbiAgICAgICAgICAgIGlmICh0b2dnbGUuaXNDaGVja2VkKSB7XG4gICAgICAgICAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcucHVibGljSXBMaW1pdCA9IFwiMVwiO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBnYW1lQ29uZmlnU2V0dGluZy5wdWJsaWNJcExpbWl0ID0gXCIwXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjYy5sb2coSlNPTi5zdHJpbmdpZnkoR2xvYmFsLmdhbWVDb25maWdTZXR0aW5nKSk7XG4gICAgfSxcblxuICAgIGVkaXRCb3hDaGFuZ2U6IGZ1bmN0aW9uIGVkaXRCb3hDaGFuZ2UoKSB7XG5cbiAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcgPSBHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmc7XG4gICAgICAgIC8vdmFyIG5vZGUgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIC8vY2MubG9nKFwiZWRpdEJveENoYW5nZSBuYW1lOlwiICsgbm9kZS5uYW1lKTtcbiAgICAgICAgdmFyIGVkaXQgPSB0aGlzLmdwc0xpbWl0Tm9kZS5nZXRDb21wb25lbnQoY2MuRWRpdEJveCk7XG4gICAgICAgIGlmIChlZGl0LnN0cmluZy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBpZiAoaXNOYU4oZWRpdC5zdHJpbmcpKSB7XG4gICAgICAgICAgICAgICAgYWxlcnRNZXNzYWdlVUkudGV4dCA9IFwi5L2g5b+F6aG75ZyoR1BT6Led56a76ZmQ5Yi25Lit6L6T5YWl5pWw5a2X77yM6K+35qOA5p+l5ZCO6YeN5paw6L6T5YWl77yBXCI7XG4gICAgICAgICAgICAgICAgYWxlcnRNZXNzYWdlVUkuc2V0VGV4dE9mUGFuZWwoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcuZ3BzTGltaXQgPSBlZGl0LnN0cmluZztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZyA9IGdhbWVDb25maWdTZXR0aW5nO1xuICAgIH0sXG5cbiAgICBpbml0YWxHYW1lQ29uZmlnOiBmdW5jdGlvbiBpbml0YWxHYW1lQ29uZmlnKCkge1xuICAgICAgICAvL2NjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZ2FtZUNvbmZpZycsIG51bGwpO1xuICAgICAgICB2YXIgbyA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImdhbWVDb25maWdcIik7XG4gICAgICAgIC8vY2MubG9nKFwiaW5pdGFsR2FtZUNvbmZpZyBvOlwiICsgKG8pICsgXCI6XCIpO1xuICAgICAgICBpZiAobyAhPSBudWxsICYmIG8gIT0gdW5kZWZpbmVkICYmIG8gIT0gXCJcIiAmJiBvICE9IFwiXFxcIlxcXCJcIikge1xuICAgICAgICAgICAgR2xvYmFsLmdhbWVDb25maWdTZXR0aW5nID0gSlNPTi5wYXJzZShvKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBKU09OLnBhcnNlKGJvZHlTdHIpXG5cbiAgICAgICAgZ2FtZUNvbmZpZ1NldHRpbmcgPSBHbG9iYWwuZ2FtZUNvbmZpZ1NldHRpbmc7XG4gICAgICAgIGlmIChnYW1lQ29uZmlnU2V0dGluZyA9PSBudWxsIHx8IGdhbWVDb25maWdTZXR0aW5nID09IHVuZGVmaW5lZCB8fCBnYW1lQ29uZmlnU2V0dGluZyA9PSBcIlwiKSB7XG4gICAgICAgICAgICBnYW1lQ29uZmlnU2V0dGluZyA9IHJlcXVpcmUoXCJnYW1lQ29uZmlnU2V0dGluZ1wiKS5nYW1lQ29uZmlnU2V0dGluZztcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmxvZyhcImluaXRhbEdhbWVDb25maWc6XCIgKyBnYW1lQ29uZmlnU2V0dGluZyArIFwiOlwiKTtcbiAgICAgICAgdmFyIG11c2ljdG9nZ2xlID0gdGhpcy5tdXNpY1RvZ2dsZS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKTtcbiAgICAgICAgdmFyIG11c2NpRWZmZWN0VG9nZ2xlID0gdGhpcy5tdXNpY0VmZmVjdFRvZ2dsZS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKTtcbiAgICAgICAgdmFyIHB1YmxpY0lwVG9nZ2xlID0gdGhpcy5wdWJsaWNJcExpbWl0VG9nZ2VsZS5nZXRDb21wb25lbnQoY2MuVG9nZ2xlKTtcbiAgICAgICAgaWYgKGdhbWVDb25maWdTZXR0aW5nLm11c2ljID09IFwiMVwiKSB7XG4gICAgICAgICAgICBtdXNpY3RvZ2dsZS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbXVzaWN0b2dnbGUuaXNDaGVja2VkID0gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZ2FtZUNvbmZpZ1NldHRpbmcubXVzaWNFZmZlY3QgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgIG11c2NpRWZmZWN0VG9nZ2xlLmlzQ2hlY2tlZCA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBtdXNjaUVmZmVjdFRvZ2dsZS5pc0NoZWNrZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChnYW1lQ29uZmlnU2V0dGluZy5wdWJsaWNJcExpbWl0ID09IFwiMVwiKSB7XG4gICAgICAgICAgICBwdWJsaWNJcFRvZ2dsZS5pc0NoZWNrZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHVibGljSXBUb2dnbGUuaXNDaGVja2VkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGVkaXQgPSB0aGlzLmdwc0xpbWl0Tm9kZS5nZXRDb21wb25lbnQoY2MuRWRpdEJveCk7XG4gICAgICAgIGlmIChnYW1lQ29uZmlnU2V0dGluZy5ncHNMaW1pdCAhPSB1bmRlZmluZWQgJiYgZ2FtZUNvbmZpZ1NldHRpbmcuZ3BzTGltaXQgIT0gbnVsbCkge1xuICAgICAgICAgICAgaWYgKGdhbWVDb25maWdTZXR0aW5nLmdwc0xpbWl0ICE9IFwiMFwiICYmIGdhbWVDb25maWdTZXR0aW5nLmdwc0xpbWl0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBlZGl0LnN0cmluZyA9IGdhbWVDb25maWdTZXR0aW5nLmdwc0xpbWl0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIEdsb2JhbC5nYW1lQ29uZmlnU2V0dGluZyA9IGdhbWVDb25maWdTZXR0aW5nO1xuICAgIH1cblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzg5ZGZiUzVpaFpISVptWjBJWTYyNXdHJywgJ2dhbWVDb25maWdTZXR0aW5nJyk7XG4vLyBzY3JpcHQvZG9tYWluQ2xhc3MvZ2FtZUNvbmZpZ1NldHRpbmcuanNcblxudmFyIGdhbWVDb25maWdTZXR0aW5nID0ge1xuXHRtdXNpYzogXCIxXCIsXG5cdG11c2ljRWZmZWN0OiBcIjFcIixcblx0cHVibGljSXBMaW1pdDogXCIwXCIsXG5cdGdwc0xpbWl0OiBcIjBcIlxufTtcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRnYW1lQ29uZmlnU2V0dGluZzogZ2FtZUNvbmZpZ1NldHRpbmdcbn07XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICcwNGMzYzloTDIxQmZwY1ltZUpLNkttUCcsICdnYW1lQ29uZmlnJyk7XG4vLyBzY3JpcHQvdWkvZ2FtZUNvbmZpZy5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgYWxlcnRNZXNzYWdlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG5cbiAgICBoZWxwQnV0bjogZnVuY3Rpb24gaGVscEJ1dG4oKSB7XG4gICAgICAgIHRoaXMuYWxlcnRNZXNzYWdlID0gdGhpcy5hbGVydE1lc3NhZ2UuZ2V0Q29tcG9uZW50KFwiYWxlcnRNZXNzYWdlUGFubGVcIik7XG4gICAgICAgIHRoaXMuYWxlcnRNZXNzYWdlLnRleHQgPSBcIiAgR1BT6Led56a76ZmQ5Yi25oyH55qE5piv5L2g5Y+v5Lul6K6+572u5LiA5Liq5pWw5a2X77yM6L+Z5Liq5pWw5a2X5Luj6KGo5LqG546p5a625LmL6Ze055qER1BT6Led56a777yM5aaC5p6c6K+l6Led56a75bCP5LqO5L2g6K6+5a6a55qE5YC877yM6YKj5LmI5bCG5ouS57ud546p5a625Yqg5YWl5L2g5Yib5bu655qE5oi/6Ze044CCPGJyLz5cIjtcbiAgICAgICAgdGhpcy5hbGVydE1lc3NhZ2UudGV4dCA9IHRoaXMuYWxlcnRNZXNzYWdlLnRleHQgKyBcIiAg5q+P5Liq5paw546p5a625Yqg5YWl5q2k5oi/6Ze05bCG5qC55o2uR1BT6Ieq5Yqo5rWL566X5LiO5oi/6Ze05Lit5bey5pyJ546p5a625LmL6Ze055qE5a6e6ZmF6Led56a777yM5aaC5p6c6Led56a75bCP5LqO5L2g6K6+572u55qE5YC877yM5bCG5ouS57ud6K+l546p5a625Yqg5YWl77yBXCI7XG4gICAgICAgIHRoaXMuYWxlcnRNZXNzYWdlLnNldFRleHRPZlBhbmVsKCk7XG4gICAgfVxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzkzZTVkc3hydWxQdVk2NnkwQzh5aTE3JywgJ2dhbWVNb2RlJyk7XG4vLyBzY3JpcHQvZG9tYWluQ2xhc3MvZ2FtZU1vZGUuanNcblxudmFyIGdhbWVNb2RlID0ge1xuICB6aU1vSmlhRGk6IDEsXG4gIHppTW9KaWFGYW46IDAsXG4gIHppTW9IdTogMSxcbiAgZGlhblBhb0h1OiAwLFxuICBodWFuU2FuWmhhbmc6IDEsXG4gIGRpYW5HYW5nSHVhX2RpYW5QYW86IDEsXG4gIGRpYW5HYW5nSHVhX3ppTW86IDAsXG4gIGRhaTE5SmlhbmdEdWk6IDEsXG4gIG1lbmdRaW5nWmhvbmdaaGFuZzogMCxcbiAgdGlhbkRpSHU6IDAsXG4gIGZhbjI6IDAsXG4gIGZhbjM6IDEsXG4gIGZhbjQ6IDAsXG4gIGZhbjY6IDAsXG4gIHJvdW5kQ291bnQ0OiAxLFxuICByb3VuZENvdW50ODogMCxcbiAgZ2FtZVBlb3BsZU51bWJlcjogMCxcbiAgcHVibGljSXBMaW1pdDogMCxcbiAgZ3BzTGltaXQ6IDBcbn07XG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgZ2FtZU1vZGU6IGdhbWVNb2RlXG59O1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNWUxMTU2Szl3MURSSlJjVEVRUVh0eDAnLCAnZ2FtZVN0ZXAnKTtcbi8vIHNjcmlwdC9kb21haW5DbGFzcy9nYW1lU3RlcC5qc1xuXG52YXIgZ2FtZVN0ZXAgPSB7IGlkOiAwLFxuICBmcm9tVXNlck9wZW5pZDogXCJcIixcbiAgYWN0aW9uTmFtZTogXCJcIixcbiAgcGFpTnVtYmVyOiBcIlwiLFxuICB0b1VzZXJPcGVuaWQ6IFwiXCIsXG4gIGpvaW5Sb29tTnVtYmVyOiBcIlwiXG5cbn07XG4vL2dhbWVpbmdTdGF0dTpcIlwiLFxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGdhbWVTdGVwOiBnYW1lU3RlcFxufTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2U5NTFkcmNwMmxJL3FGbUp6a3ZEQW9TJywgJ2dhbWVVc2VyJyk7XG4vLyBzY3JpcHQvZG9tYWluQ2xhc3MvZ2FtZVVzZXIuanNcblxudmFyIGdhbWVVc2VyID0geyBpZDogMCxcbiAgbmlja05hbWU6IFwiXCIsXG4gIGhlYWRpbWd1cmw6IFwiXCIsXG4gIGNvdW50cnk6IFwiXCIsXG4gIGRpYW1vbmRzTnVtYmVyOiAwLFxuICBvcGVuaWQ6IFwiXCIsXG4gIHVuaW9uaWQ6IFwiXCIsXG4gIHVzZXJDb2RlOiBcIlwiLFxuICAvL3VzZXJHYW1laW5nU3RhdHU6XCJcIixcbiAgcHVibGljSXA6IFwiXCIsXG4gIHBhaUxpc3Q6IFwiXCIsXG4gIGdhbWVSZWFkeVN0YXR1OiBcIlwiLFxuICBnYW1lUm91bmRTY29yZTogXCJcIixcbiAgZ2FtZVNjb3JlQ291bnQ6IFwiXCIsXG4gIHBvaW50SW5kZXg6IFwiXCIsXG4gIGhlYWRJbWFnZUZpbGVOYW1lOiBcIlwiLFxuICB6aHVhbmc6IFwiXCIsXG4gIC8vZm9sbG93IHByb3BlcnRpdHkgb25seSB3b3JrIG9uIGNsaWVudFxuICBwYWlMaXN0QXJyYXk6IFtdLFxuICBodWFuU2FuWmhhbmdQYWlMaXN0OiBbXSxcbiAgcGVuZ1BhaUxpc3Q6IFtdLFxuICBnYW5nUGFpTGlzdDogW10sXG4gIHBlbmdHYW5nUGFpUG9pbnQ6IDAsXG4gIHF1ZVBhaTogXCJcIixcbiAgY2h1cGFpTGlzdFg6IDAsXG4gIGNodXBhaUxpc3RZOiAwLFxuICBjaHVQYWlDb3VudDogMCxcbiAgY2h1UGFpUG9pbnRYOiAwLFxuICB1c2VyTW9QYWk6IFwiXCIsXG4gIC8vaHVwYWkgXG4gIGh1UGFpOiBcIlwiLFxuICAvL3ppTW8sbm9ybWFsSHUsZ2FuZ1NoYW5nSHVhLGdhbmdTaGFuZ1BhbyAsaGFpRGksdGlhbkh1LGRpSHVcbiAgaHVQYWlUeXBlOiBcIlwiXG59O1xuLy9nYW1laW5nU3RhdHU6XCJcIixcbm1vZHVsZS5leHBvcnRzID0ge1xuICBnYW1lVXNlcjogZ2FtZVVzZXJcbn07XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc1ZjhiM2k0ZThsR2xZdTFkVVM1aGhXMicsICdodWFuUGFpVUknKTtcbi8vIHNjcmlwdC91aS9odWFuUGFpVUkuanNcblxudmFyIHRpbWVyVXBhdGU7XG52YXIgdGltZUNvdW50O1xudmFyIHRhYmxlVXNlckluZm87XG52YXIgYWxlck1lc3NhZ2U7XG52YXIgZ2FtZVRhYmxlTmV0V29yaztcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBodWFuUGFpTm9kZTogY2MuTm9kZSxcbiAgICAgICAgaHVhblBhaVRpbWVMYWJsZTogY2MuTm9kZSxcbiAgICAgICAgdGFibGVVc2VySW5mb05vZGU6IGNjLk5vZGUsXG4gICAgICAgIGFsZXJ0TWVzc2FnZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIGdhbWVUYWJsZU5ldFdvcmtOb2RlOiBjYy5Ob2RlLFxuICAgICAgICB3YWl0UGFubGVOb2RlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuXG4gICAgICAgIHRhYmxlVXNlckluZm8gPSB0aGlzLnRhYmxlVXNlckluZm9Ob2RlLmdldENvbXBvbmVudChcInRhYmxlVXNlckluZm9cIik7XG4gICAgICAgIGFsZXJNZXNzYWdlID0gdGhpcy5hbGVydE1lc3NhZ2VOb2RlLmdldENvbXBvbmVudChcImFsZXJ0TWVzc2FnZVBhbmxlXCIpO1xuICAgICAgICBnYW1lVGFibGVOZXRXb3JrID0gdGhpcy5nYW1lVGFibGVOZXRXb3JrTm9kZS5nZXRDb21wb25lbnQoXCJHYW1lVGFibGVOZXRXb3JrXCIpO1xuXG4gICAgICAgIHRpbWVDb3VudCA9IDE0O1xuICAgICAgICB0aW1lclVwYXRlID0gZnVuY3Rpb24gKCkge1xuXG4gICAgICAgICAgICB2YXIgc2hvd1RpbWVyU3RyID0gXCIoXCIgKyB0aW1lQ291bnQgKyBcIilcIjtcbiAgICAgICAgICAgIHZhciBsYWJsZSA9IHRoaXMuaHVhblBhaVRpbWVMYWJsZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xuICAgICAgICAgICAgbGFibGUuc3RyaW5nID0gc2hvd1RpbWVyU3RyO1xuICAgICAgICAgICAgdGltZUNvdW50LS07XG5cbiAgICAgICAgICAgIGlmICh0aW1lQ291bnQgPT0gLTEpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmVuZFRpbWVyKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSxcblxuICAgIHNob3dIdWFuUGFpTm9kZTogZnVuY3Rpb24gc2hvd0h1YW5QYWlOb2RlKCkge1xuICAgICAgICB0aGlzLmh1YW5QYWlOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuc3RyYXRUaW1lcigpO1xuICAgICAgICB0YWJsZVVzZXJJbmZvLmRpc2FibGVkSHVhblNhblpoYW5nUGFpKCk7XG4gICAgICAgIEdsb2JhbC5jaHVQYWlBY3Rpb25UeXBlID0gXCJodWFuU2FuWmhhbmdcIjtcbiAgICB9LFxuXG4gICAgc3RyYXRUaW1lcjogZnVuY3Rpb24gc3RyYXRUaW1lcigpIHtcbiAgICAgICAgLy90aW1lQ291bnQgPSAxMDtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLnNjaGVkdWxlKHRpbWVyVXBhdGUsIDEpO1xuICAgICAgICAvL1xuICAgIH0sXG4gICAgZW5kVGltZXI6IGZ1bmN0aW9uIGVuZFRpbWVyKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYudW5zY2hlZHVsZSh0aW1lclVwYXRlKTtcbiAgICAgICAgLy8gR2xvYmFsLmNodVBhaUFjdGlvblR5cGUgPSBcIlwiXG4gICAgICAgIC8vYXV0byBzZWxlY3QgbGF0ZXN0IHBhaVxuICAgICAgICBpZiAoR2xvYmFsLmh1YW5TYW5aaGFuZ1BhaUxpc3QubGVuZ3RoIDwgMykge31cbiAgICAgICAgLy90YWJsZVVzZXJJbmZvLmZvcmNlRmlsbEh1YW5TYW5aaGFuZ0xpc3QoKVxuXG4gICAgICAgIC8vXG4gICAgfSxcblxuICAgIHNlbmRIdWFuU2FuWmhhbmc6IGZ1bmN0aW9uIHNlbmRIdWFuU2FuWmhhbmcoKSB7XG4gICAgICAgIGlmIChHbG9iYWwuaHVhblNhblpoYW5nUGFpTGlzdC5sZW5ndGggPCAzKSB7XG4gICAgICAgICAgICBhbGVyTWVzc2FnZS50ZXh0ID0gXCLkvaDlv4XpobvpgInmi6nkuInlvKDniYzvvIFcIjtcbiAgICAgICAgICAgIGFsZXJNZXNzYWdlLnNldFRleHRPZlBhbmVsKCk7XG4gICAgICAgICAgICBhbGVyTWVzc2FnZS5hbGVydFBhbmVsTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy9HbG9iYWwuY2h1UGFpQWN0aW9uVHlwZSA9IFwiXCJcbiAgICAgICAgICAgIHRoaXMud2FpdFBhbmxlTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgZ2FtZVRhYmxlTmV0V29yay5zZW5kSHVhblNhblpoYW5nKCk7XG4gICAgICAgICAgICB0YWJsZVVzZXJJbmZvLmRpc2FibGVBbGxQYWkoKTtcbiAgICAgICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aW1lclVwYXRlKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBjbG9zZVdhaXRQYW5sZTogZnVuY3Rpb24gY2xvc2VXYWl0UGFubGUoKSB7XG4gICAgICAgIHRoaXMud2FpdFBhbmxlTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdlYTUyMGczRGFWQ05JRXVlWDRPSG0ybicsICdpbmlHYW1lVGFibGUnKTtcbi8vIHNjcmlwdC9zZXJ2aWNlL2luaUdhbWVUYWJsZS5qc1xuXG5cblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIGF1ZGlvTW5nOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIGdhbWVNb2RlTm9kZTogY2MuTm9kZSxcbiAgICAgICAgZ2FtZU1haW5NZW51OiBjYy5Ob2RlLFxuICAgICAgICB1c2VyTmlja05hbWVMYWJsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJDb2RlTGFibGU6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJEZW1vbmROdW1iZXJMYWJsZTogY2MuTm9kZVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcblxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICAgICAgLy9zZXJ2ZXJVcmwgPSBHbG9iYWwuaG9zdEh0dHBQcm90b2NvbCArIFwiOi8vXCIgKyBHbG9iYWwuaG9zdFNlcnZlcklwICsgXCI6XCIgKyBHbG9iYWwuaG9zdFNlcnZlclBvcnQ7XG4gICAgICAgIC8vc29ja2V0ID0gbmV3IFNvY2tKUyhzZXJ2ZXJVcmwgKyBcIi9zdG9tcFwiKTtcblxuICAgICAgICB2YXIgbWVzc2FnZVVzZXIgPSByZXF1aXJlKFwibWVzc2FnZURvbWFpblwiKS5tZXNzYWdlRG9tYWluO1xuICAgICAgICAvL3ZhciBtZXNzYWdlVXNlcjtcbiAgICAgICAgLy8tLS0tLS0tLS0tLW11c2ljIDpwbGF5IGJnbS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgdGhpcy5hdWRpb01uZyA9IHRoaXMuYXVkaW9NbmcuZ2V0Q29tcG9uZW50KCdBdWRpb01uZycpO1xuICAgICAgICB0aGlzLmF1ZGlvTW5nLnBsYXlNdXNpYygpO1xuICAgICAgICAvL2hpZGUgdGhlIGdhbWUgbW9kZVxuICAgICAgICBzZWxmLmdhbWVNb2RlTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgc2VsZi50YWJsZU5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHNlbGYuZ2FtZU1haW5NZW51LmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHNlbGYuZ2FtZU1haW5NZW51Lm9wYWNpdHkgPSAyNTU7XG4gICAgICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgICAgIC8vaW5pdGFsIHVzZXIgaW5mbyBpbiB0aGUgZ2FtZU1haW4gc2VuY2VcbiAgICAgICAgaWYgKEdsb2JhbC51c2VySW5mbyA9PSB1bmRlZmluZWQgfHwgR2xvYmFsLnVzZXJJbmZvID09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3I6IG5vIGZvdW5kIGNvcnJlY3QgdXNlciAscGxlYXNlIGNoZWNrIHNlcnZlciBvciBuZXR3b3JrLlwiKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciB1c2VySW5mbyA9IEdsb2JhbC51c2VySW5mbztcblxuICAgICAgICAgICAgLy9pbnRhbCB1c2VyIFRleHRcbiAgICAgICAgICAgIHNlbGYuaW50YWxVc2VySW5mb09uR2FtZU1haW5MYXllcigpO1xuICAgICAgICAgICAgLy9zZWxmLmluaXRhbFVzZXJJbmZvTGF5ZXIodXNlckluZm8pO1xuICAgICAgICAgICAgLy9pbml0YWwgdGhlIHVzZXIgbWVzc2FnZVxuICAgICAgICAgICAgbWVzc2FnZVVzZXIubWVzc2FnZUJlbG9uZ3NUb1ByaXZhdGVDaGFubGVOdW1iZXIgPSB1c2VySW5mby5yb29tTnVtYmVyO1xuICAgICAgICAgICAgLy9tZXNzYWdlQWN0aW9uXG4gICAgICAgICAgICBtZXNzYWdlVXNlci5tZXNzYWdlQWN0aW9uID0gXCJzZW5kVG9PdGhlclwiO1xuICAgICAgICAgICAgbWVzc2FnZVVzZXIubWVzc2FnZVR5cGUgPSBcInVzZXJcIjtcbiAgICAgICAgICAgIG1lc3NhZ2VVc2VyLm1lc3NhZ2VCb2R5ID0gSlNPTi5zdHJpbmdpZnkodXNlckluZm8pO1xuICAgICAgICAgICAgLy9zZWxmLnNlbmRXZWJTb2tlY3RNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZVVzZXIpXG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gY2MuZ2FtZS5vblN0b3AgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vICAgICBjYy5sb2coXCJzdG9wQXBwXCIpO1xuICAgICAgICAvLyB9XG4gICAgfSxcblxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLUNyZWF0ZSByb29tIGJ1dHRvbiBldmVudC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgam9pblJvb21faW5pdGFsVXNlckluZm86IGZ1bmN0aW9uIGpvaW5Sb29tX2luaXRhbFVzZXJJbmZvKCkge1xuICAgICAgICB0aGlzLmluaXRhbFVzZXJJbmZvTGF5ZXIoKTtcbiAgICB9LFxuXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0taW5pdGFsIHVzZXIgaW5mbyBsYXllci0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgaW50YWxVc2VySW5mb09uR2FtZU1haW5MYXllcjogZnVuY3Rpb24gaW50YWxVc2VySW5mb09uR2FtZU1haW5MYXllcigpIHtcbiAgICAgICAgLy8gdmFyIHRvcFVzZXJMYXllciA9IHRoaXMuZ2FtZU1haW5NZW51LmdldENoaWxkQnlOYW1lKFwidG9wSW5mb1VzZXJMYXllclwiKTtcbiAgICAgICAgLy8gdmFyIHRvcFVzZXJJbmZvTGF5ZXIgPSB0b3BVc2VyTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VySW5mb0xheWVyXCIpO1xuICAgICAgICAvLyB2YXIgdG9wVXNlckxheW91dCA9IHRvcFVzZXJJbmZvTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VySW5mb0xheW91dFwiKTtcbiAgICAgICAgLy8gdmFyIHRvcFVzZXJMYXlvdXQyID0gdG9wVXNlckxheW91dC5nZXRDaGlsZEJ5TmFtZShcInVzZXJJbmZvVGV4dExheW91dFwiKTtcblxuICAgICAgICAvLyB2YXIgdXNlck5hbWVMYWJsZU5vZGUgPSB0b3BVc2VyTGF5b3V0Mi5nZXRDaGlsZEJ5TmFtZShcInVzZXJOaWNrTmFtZUxhYmxlXCIpO1xuICAgICAgICAvLyB2YXIgdXNlckNvZGVMYWJsZU5vZGUgPSB0b3BVc2VyTGF5b3V0Mi5nZXRDaGlsZEJ5TmFtZShcInVzZXJDb2RlTGFibGVcIik7XG4gICAgICAgIC8vIHZhciB1c2VyRGVtb25kTGFibGVOb2RlID0gdG9wVXNlckxheW91dDIuZ2V0Q2hpbGRCeU5hbWUoXCJ1c2VyRGVtb25kTnVtYmVyXCIpO1xuXG4gICAgICAgIHZhciB1c2VyTmFtZUxhYmxlID0gdGhpcy51c2VyTmlja05hbWVMYWJsZU5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgdmFyIHVzZXJDb2RlTGFibGUgPSB0aGlzLnVzZXJDb2RlTGFibGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgdmFyIHVzZXJEZW1vbmRMYWJsZSA9IHRoaXMudXNlckRlbW9uZE51bWJlckxhYmxlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XG5cbiAgICAgICAgdXNlck5hbWVMYWJsZS5zdHJpbmcgPSBHbG9iYWwudXNlckluZm8ubmlja05hbWU7XG4gICAgICAgIHVzZXJEZW1vbmRMYWJsZS5zdHJpbmcgPSBHbG9iYWwudXNlckluZm8uZGlhbW9uZHNOdW1iZXI7XG4gICAgICAgIHVzZXJDb2RlTGFibGUuc3RyaW5nID0gR2xvYmFsLnVzZXJJbmZvLnVzZXJDb2RlO1xuICAgIH0sXG5cbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS13ZWIgc29rZWMgY29ubmVjdCBhbmQgc3Vic2NyaWJlIGFuZCBoYW5kbGUgcmVzaXZlIG1lc3NhZ2UtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIHdoZW4gdGhhIHRhYmxlIHNlbmNlIGVuZCAsaXQgd2lsbCBuZWVkIHJlbW92ZSBvbmxpbmUgdXNlciBhbmQgY2xvc2Ugd2Vic29rZWN0LS0tLS0tLS0tXG5cbiAgICAvL29wZW4gdXNlciBpcCBsb2dpbiB1cmxcblxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS11cGRhdGUgdXNlciBpcC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHVwZGF0ZVVzZXJJUDogZnVuY3Rpb24gdXBkYXRlVXNlcklQKGlkKSB7XG4gICAgICAgIHZhciB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgdmFyIHVybCA9IHNlcnZlclVybCArIFwiL3VzZXIvZ2V0TG9naW5Vc2VySVA/dXNlcklkPVwiICsgaWQ7XG4gICAgICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCAmJiB4aHIuc3RhdHVzID49IDIwMCAmJiB4aHIuc3RhdHVzIDwgNDAwKSB7XG4gICAgICAgICAgICAgICAgdmFyIHJlc3BvbnNlID0geGhyLnJlc3BvbnNlVGV4dDtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgR2xvYmFsLnVzZXJJbmZvLnB1YmxpY0lQQWRkcmVzcyA9IHJlc3BvbnNlO1xuICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgndGFibGUnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgeGhyLm9wZW4oXCJHRVRcIiwgdXJsLCB0cnVlKTtcbiAgICAgICAgeGhyLnNlbmQoKTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2Y4MTFmQmF0VTFGdGFqRHJxOENlU1U1JywgJ2luaUluZGV4Jyk7XG4vLyBzY3JpcHQvc2VydmljZS9pbmlJbmRleC5qc1xuXG52YXIgY2xpZW50O1xudmFyIHByaXZhdGVDbGllbnQ7XG52YXIgdXNlckluZm87XG52YXIgc2VydmVyVXJsO1xudmFyIHNvY2tldDtcbnZhciBnYW1lQWN0aW9uTGlzdEdldDtcbnZhciBvbmxpbmVDaGVja1VzZXI7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgZ2FtZUFjdGlvbkxpc3Q6IGNjLk5vZGUsXG4gICAgICAgIGNoZWNrT25saW5lVXNlcjogY2MuTm9kZVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcblxuICAgICAgICAvL3dlYmNoYXQgaGVhZCBpbWcgdGVzdC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgLypcbiAgICAgICAgdmFyIHVybCA9IFwiaHR0cDovL3d4LnFsb2dvLmNuL21tb3Blbi9nM01vblVadE5Ia2RtemljSWxpYng2aWFGcUFjNTZ2eExTVWZwYjZuNVdLU1lWWTBDaFFLa2lhSlNnUTFkWnVUT2d2TExyaEpiRVJRUTRlTXN2ODRlYXZIaWFpY2VxeGliSnhDZkhlLzQ2XCI7XG4gICAgICAgIHZhciB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwieGhyIHJlYWR5U3RhdGU6XCIgKyB4aHIucmVhZHlTdGF0ZSk7XG4gICAgICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCAmJiAoeGhyLnN0YXR1cyA+PSAyMDAgJiYgeGhyLnN0YXR1cyA8IDQwMCkpIHtcbiAgICAgICAgICAgICAgICB2YXIgcmVzcG9uc2UgPSB4aHIucmVzcG9uc2VUZXh0O1xuICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInhocjpcIiArIHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInhociByZXNwb25zZVR5cGU6XCIgKyB4aHIucmVzcG9uc2VUeXBlKTtcbiAgICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHhoci5vcGVuKFwiR0VUXCIsIHVybCwgdHJ1ZSk7XG4gICAgICAgIHhoci5zZW5kKCk7Ki9cbiAgICAgICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgIGdhbWVBY3Rpb25MaXN0R2V0ID0gdGhpcy5nYW1lQWN0aW9uTGlzdC5nZXRDb21wb25lbnQoXCJnYW1lQ29uZmlnQnV0dG9uTGlzdEFjdGlvblwiKTtcbiAgICAgICAgb25saW5lQ2hlY2tVc2VyID0gdGhpcy5jaGVja09ubGluZVVzZXIuZ2V0Q29tcG9uZW50KFwib25saW5lVXNlckNoZWNrXCIpO1xuICAgICAgICB1c2VySW5mbyA9IHJlcXVpcmUoXCJ1c2VySW5mb0RvbWFpblwiKS51c2VySW5mb0RvbWFpbjtcbiAgICAgICAgc2VydmVyVXJsID0gR2xvYmFsLmhvc3RIdHRwUHJvdG9jb2wgKyBcIjovL1wiICsgR2xvYmFsLmhvc3RTZXJ2ZXJJcCArIFwiOlwiICsgR2xvYmFsLmhvc3RTZXJ2ZXJQb3J0O1xuICAgICAgICBzb2NrZXQgPSBuZXcgU29ja0pTKHNlcnZlclVybCArIFwiL3N0b21wXCIpO1xuICAgICAgICBjb25zb2xlLmxvZyhcImNvbmVjdCB0byBzZXJ2ZXJcIik7XG4gICAgICAgIGNsaWVudCA9IFN0b21wLm92ZXIoc29ja2V0KTtcbiAgICAgICAgdmFyIGNzcmZIZWFkZXJOYW1lID0gXCJTZXQtQ29va2llXCI7XG4gICAgICAgIHZhciBjc3JmVG9rZW4gPSBcInNlc3Npb249QjIyNzY1NERCMTNCMjgzMjlGOTZEQjI5NTlGQUUyNkJcIjtcbiAgICAgICAgdmFyIGhlYWRlcnMgPSB7fTtcbiAgICAgICAgaGVhZGVyc1tjc3JmSGVhZGVyTmFtZV0gPSBjc3JmVG9rZW47XG4gICAgICAgIGNsaWVudC5jb25uZWN0KGhlYWRlcnMsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNsaWVudC5zdWJzY3JpYmUoXCIvcXVldWUvcHVzbWljR2FtZVB1c2hMb2dpblVzZXJJbmZvQ2hhbmxlXCIsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgdmFyIGJvZHlTdHIgPSBtZXNzYWdlLmJvZHk7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwiIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1wiKTtcbiAgICAgICAgICAgICAgICBjYy5sb2coYm9keVN0cik7XG4gICAgICAgICAgICAgICAgdmFyIG9iaiA9IEpTT04ucGFyc2UoYm9keVN0cik7XG4gICAgICAgICAgICAgICAgaWYgKG9iaiAhPSB1bmRlZmluZWQgJiYgb2JqICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBvYmopIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJJbmZvW3BdID0gb2JqW3BdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vKioqKioqKioqKioqd2UgbXVzdCBjaGVjayB1c2VyIGluIGhlcmUqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAgICAgICAgICAgICAgICAgIC8vTkVFRCBUTyBETyAqKioqKioqKioqKioqKioqKioqKlxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChHbG9iYWwudXNlckluZm8gPT0gbnVsbCB8fCBHbG9iYWwudXNlckluZm8gPT0gdW5kZWZpbmVkKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXNlckluZm8ubmlja25hbWU6XCIgKyB1c2VySW5mby5uaWNrTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInVzZXJJbmZvLmhlYWRJbWFnZUZpbGVOYW1lOlwiICsgdXNlckluZm8uaGVhZEltYWdlRmlsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgR2xvYmFsLnVzZXJJbmZvID0gdXNlckluZm87XG4gICAgICAgICAgICAgICAgICAgICAgICAvL3VwZGF0ZSB0aGUgdXNlciBwdWJsaWMgaXAgZnJvbSB1cmwgY2FsbFxuICAgICAgICAgICAgICAgICAgICAgICAgLy9zZWxmLnVwZGF0ZVVzZXJJUCh1c2VySW5mby5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvL1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9zZWxmLmluaXRhbFByaXZhdGVDaGFubGVGb3JVc2VyKHVzZXJJbmZvLnJvb21OdW1iZXIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvL3VzZXIgbG9naW4gc3VjY2VzcyAsZ28gdG8gZ2FtZSBtYWluIHNlbmNlXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NjLmRpcmVjdG9yLmxvYWRTY2VuZSgndGFibGUnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudC5kaXNjb25uZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGllbnQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2FtZUFjdGlvbkxpc3RHZXQuZW50ZXJNYWluRW50cnkoXCIxXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2FtZUFjdGlvbkxpc3RHZXQuc2hvd1VzZXJOaWNrTmFtZUFuZENvZGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdhbWVBY3Rpb25MaXN0R2V0LmNsb3NlTG9hZGluZ0ljb24oKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJObyBmb3VuZCBjb3JyZWN0IHVzZXIgaW5mbyByZXR1cm4gZnJvbSBzZXJ2ZXIgLHBsZWFzZSBjaGVjayAuXCIpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vc2VsZi50ZXN0TGFiZWwuc3RyaW5nID0gbWVzc2FnZS5ib2R5O1xuICAgICAgICAgICAgICAgIC8vJChcIiNoZWxsb0RpdlwiKS5hcHBlbmQobWVzc2FnZS5ib2R5KTtcblxuICAgICAgICAgICAgICAgIC8vY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdnYW1lTWFpbjInKTtcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBjYy5sb2coXCJ3ZWJzb2NrZXQgY29ubmVjdCBzdWJzY3JpYmUgRXJyb3I6MjMzXCIpO1xuICAgICAgICAgICAgICAgIC8vY2xpZW50LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjYy5sb2coXCJ3ZWJzb2NrZXQgY29ubmVjdCAgRXJyb3I6MjM0XCIpO1xuICAgICAgICAgICAgLy9jbGllbnQuZGlzY29ubmVjdCgpO1xuICAgICAgICB9KTtcblxuICAgICAgICAvL29ubGluZUNoZWNrVXNlci5jbGllbnQgPSBjbGllbnQ7XG4gICAgICAgIG9ubGluZUNoZWNrVXNlci5jaGVja29ubGluZVVzZXIoY2xpZW50KTtcblxuICAgICAgICBjYy5nYW1lLm9uU3RvcCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNjLmxvZyhcInN0b3BBcHAkJCQkJCQkJCQkJCQkJCQkJFwiKTtcbiAgICAgICAgICAgIC8vIGNsaWVudC5kaXNjb25uZWN0KCk7XG4gICAgICAgIH07XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG4gICAgb25EZXN0cm95OiBmdW5jdGlvbiBvbkRlc3Ryb3koKSB7XG4gICAgICAgIC8vY29sc2UgdGhlIHdlYnNva2VjdFxuICAgICAgICBjbGllbnQuZGlzY29ubmVjdCgpO1xuICAgICAgICBjYy5sb2coXCJvbkRlc3Ryb3lcIik7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS1pbml0YWwgcHJpdmF0ZSBjaGFubGUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gaW5pdGFsUHJpdmF0ZUNoYW5sZUZvclVzZXI6IGZ1bmN0aW9uIChyb29tTnVtYmVyKSB7XG4gICAgLy8gICAgIGNjLmxvZyhcInJvb21OdW1iZXI6XCIrcm9vbU51bWJlcik7XG4gICAgLy8gICAgIHByaXZhdGVDbGllbnQgPSBTdG9tcC5vdmVyKHNvY2tldCk7XG5cbiAgICAvLyAgICAgICAgIHByaXZhdGVDbGllbnQuY29ubmVjdCh7fSwgZnVuY3Rpb24gKCkge1xuICAgIC8vICAgICAgICAgICAgIHByaXZhdGVDbGllbnQuc3Vic2NyaWJlKFwiL3F1ZXVlL3ByaXZhdGVSb29tQ2hhbmxlXCIgKyByb29tTnVtYmVyLCBmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgIC8vICAgICAgICAgICAgICAgICB2YXIgYm9keVN0ciA9IG1lc3NhZ2UuYm9keTtcbiAgICAvLyAgICAgICAgICAgICAgICAgY2MubG9nKFwiZ2V0IG1lZXNnZSBmcm9tIHByaXZhdGUgY2hhbmxlOnByaXZhdGVSb29tQ2hhbmxlXCIrcm9vbU51bWJlcik7XG4gICAgLy8gICAgICAgICAgICAgfSk7XG4gICAgLy8gICAgICAgICB9LGZ1bmN0aW9uKCl7XG4gICAgLy8gICAgICAgICAgICAgIGNjLmxvZyhcImNvbm5lY3QgcHJpdmF0ZSBjaGFubGUgZXJyb3IgIVwiKTtcbiAgICAvLyAgICAgICAgIH0pO1xuXG4gICAgLy8gcHJpdmF0ZUNsaWVudENoYW5sZVxuICAgIC8vIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tZ2FtZSBzdG9wLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBnYW1lU3RvcDogZnVuY3Rpb24gZ2FtZVN0b3AoKSB7fSxcbiAgICBzZW5kVXNlckNvZGU6IGZ1bmN0aW9uIHNlbmRVc2VyQ29kZSgpIHtcbiAgICAgICAgLy9jbGllbnQuc2VuZChcIi9hcHAvdXNlcmNvZGVfcmVzaXZlX21lc3NhZ2VcIiwge30sIEpTT04uc3RyaW5naWZ5KFwidGVzdFwiKSk7XG4gICAgICAgIGdhbWVBY3Rpb25MaXN0R2V0LnNob3dMb2FkaW5nSWNvbigpO1xuICAgICAgICBjbGllbnQuc2VuZChcIi9hcHAvdXNlcmNvZGVfcmVzaXZlX21lc3NhZ2VcIiwge30sIFwidGVzdFwiKTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzVhMzQyMVpXZmRCem9yZ3kvRXJyQm41JywgJ2xvZ2luU2NyaXB0Jyk7XG4vLyBzY3JpcHQvY29udHJvbGxlcnMvbG9naW5TY3JpcHQuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge31cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzA4ZDQ3RU1Jc05EekxlUlB3N001UEsxJywgJ21lc3NhZ2VEb21haW4nKTtcbi8vIHNjcmlwdC9kb21haW5DbGFzcy9tZXNzYWdlRG9tYWluLmpzXG5cbnZhciBtZXNzYWdlRG9tYWluID0ge1xuXHRtZXNzYWdlQmVsb25nc1RvUHJpdmF0ZUNoYW5sZU51bWJlcjogMCxcblx0Ly9zZW5kVG9PdGhlcixzZW5kVG9TZXJ2ZXIsc2VuZFRvU2luZ2xlVXNlclxuXHRtZXNzYWdlQWN0aW9uOiBcIlwiLFxuXHRtZXNzYWdlVHlwZTogXCJcIixcblx0bWVzc2FnZUJvZHk6IFwiXCJcbn07XG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0bWVzc2FnZURvbWFpbjogbWVzc2FnZURvbWFpblxufTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzEzZDIxMjBOQ2hCSUl6b2tjc2EwcnBaJywgJ25vcm1hbFRpbWVyU2NyaXB0Jyk7XG4vLyBzY3JpcHQvdWkvbm9ybWFsVGltZXJTY3JpcHQuanNcblxudmFyIHRpbWVyVXBhdGU7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgdGltZUNvdW50OiBjYy5JbnRlZ2VyLFxuICAgICAgICB0aW1lckxhYmxlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYudGltZUNvdW50ID0gMTA7XG4gICAgICAgIHRpbWVyVXBhdGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgbGFibGUgPSBzZWxmLnRpbWVyTGFibGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgICAgIGxhYmxlLnN0cmluZyA9IFwiKFwiICsgc2VsZi50aW1lQ291bnQgKyBcIilcIjtcblxuICAgICAgICAgICAgc2VsZi50aW1lQ291bnQtLTtcblxuICAgICAgICAgICAgaWYgKHNlbGYudGltZUNvdW50ID09IC0xKSB7XG4gICAgICAgICAgICAgICAgLy9xdWVQYWlUaW1lckxhYmVsLGh1YW5QYWlUaW1lckxhYmVsXG4gICAgICAgICAgICAgICAgLy9cbiAgICAgICAgICAgICAgICBzZWxmLmVuZFRpbWVyKCk7XG4gICAgICAgICAgICAgICAgaWYgKHNlbGYudGltZXJMYWJsZS5uYW1lID09IFwicXVlUGFpVGltZXJMYWJlbFwiKSB7fVxuICAgICAgICAgICAgICAgIGlmIChzZWxmLnRpbWVyTGFibGUubmFtZSA9PSBcImh1YW5QYWlUaW1lckxhYmVsXCIpIHt9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHNlbGYuc3RyYXRUaW1lcigpO1xuICAgIH0sXG4gICAgc3RyYXRUaW1lcjogZnVuY3Rpb24gc3RyYXRUaW1lcigpIHtcblxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYuc2NoZWR1bGUodGltZXJVcGF0ZSwgMSk7XG4gICAgfSxcbiAgICBlbmRUaW1lcjogZnVuY3Rpb24gZW5kVGltZXIoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi51bnNjaGVkdWxlKHRpbWVyVXBhdGUpO1xuICAgIH1cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2JmYjAxR1lSSk5IWVpmbmJVcmcwR3FkJywgJ29ubGluZVVzZXJDaGVjaycpO1xuLy8gc2NyaXB0L3NlcnZpY2Uvb25saW5lVXNlckNoZWNrLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICAvLyBjbGllbnQ6IG51bGxcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG5cbiAgICBjaGVja29ubGluZVVzZXI6IGZ1bmN0aW9uIGNoZWNrb25saW5lVXNlcihjbGllbnQpIHtcblxuICAgICAgICB0aGlzLmNhbGxiYWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuXG4gICAgICAgICAgICBpZiAodXNlckluZm8gIT0gbnVsbCAmJiB1c2VySW5mbyAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB2YXIgb3BlbmlkID0gdXNlckluZm8ub3BlbmlkO1xuICAgICAgICAgICAgICAgIHZhciByb29tTnVtYmVyID0gdXNlckluZm8ucm9vbU51bWJlcjtcbiAgICAgICAgICAgICAgICB2YXIgbWVzc2FnZU9iaiA9IHRoaXMuYnVpbGRTZW5kTWVzc2FnZShvcGVuaWQsIHJvb21OdW1iZXIsIFwidXBkYXRlT25saW5Vc2VyRGF0ZVRpbWVcIik7XG4gICAgICAgICAgICAgICAgdGhpcy5zZW5kTWVzc2FnZVRvU2VydmVyKG1lc3NhZ2VPYmosIGNsaWVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgdGhpcy5zY2hlZHVsZSh0aGlzLmNhbGxiYWNrLCAxODAwKTtcbiAgICB9LFxuXG4gICAgcmVtb3ZlT25saW5lVXNlcjogZnVuY3Rpb24gcmVtb3ZlT25saW5lVXNlcihjbGllbnQsIHJvb21OdW1iZXIpIHtcbiAgICAgICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICBpZiAodXNlckluZm8gIT0gbnVsbCAmJiB1c2VySW5mbyAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHZhciBvcGVuaWQgPSB1c2VySW5mby5vcGVuaWQ7XG4gICAgICAgICAgICB2YXIgbWVzc2FnZU9iaiA9IHRoaXMuYnVpbGRTZW5kTWVzc2FnZShvcGVuaWQsIHJvb21OdW1iZXIsIFwidXBkYXRlT25saW5Vc2VyRGF0ZVRpbWVcIik7XG4gICAgICAgICAgICB0aGlzLnNlbmRNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZU9iaik7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIHNlbmRNZXNzYWdlVG9TZXJ2ZXI6IGZ1bmN0aW9uIHNlbmRNZXNzYWdlVG9TZXJ2ZXIobWVzc2FnZU9iaiwgY2xpZW50KSB7XG5cbiAgICAgICAgY2xpZW50LnNlbmQoXCIvYXBwL3VzZXJSZXNpdmVNZXNzYWdlXCIsIHt9LCBKU09OLnN0cmluZ2lmeShtZXNzYWdlT2JqKSk7XG4gICAgfSxcbiAgICBidWlsZFNlbmRNZXNzYWdlOiBmdW5jdGlvbiBidWlsZFNlbmRNZXNzYWdlKG1lc3NhZ2VCb2R5LCByb29tTnVtLCBhY3Rpb24pIHtcbiAgICAgICAgdmFyIG1lc3NhZ2VEb21haW4gPSByZXF1aXJlKFwibWVzc2FnZURvbWFpblwiKS5tZXNzYWdlRG9tYWluO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCZWxvbmdzVG9Qcml2YXRlQ2hhbmxlTnVtYmVyID0gcm9vbU51bTtcbiAgICAgICAgbWVzc2FnZURvbWFpbi5tZXNzYWdlQWN0aW9uID0gYWN0aW9uO1xuICAgICAgICBtZXNzYWdlRG9tYWluLm1lc3NhZ2VCb2R5ID0gbWVzc2FnZUJvZHk7XG5cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2VEb21haW47XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICczNmI0OHNDN3BWTFY3aFlkQ3NDdy9sYycsICdwYWlBY3Rpb24nKTtcbi8vIHNjcmlwdC91aS9wYWlBY3Rpb24uanNcblxudmFyIGFjdGlvbldpZHRoID0gW107XG52YXIgYWN0aW9uTmFtZSA9IFtdO1xudmFyIHRhYmxlUGFpQWN0aW9uU2NyaXB0O1xudmFyIHRhYmxlVXNlckluZm9Ob2RlU2NyaXB0O1xuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBhY3Rpb25Ob2RlOiBjYy5Ob2RlLFxuICAgICAgICB6aW1vTm9kZTogY2MuTm9kZSxcbiAgICAgICAgcGVuZ05vZGU6IGNjLk5vZGUsXG4gICAgICAgIGdhbmdOb2RlOiBjYy5Ob2RlLFxuICAgICAgICBodU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIGNhbmNsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHRhYmxlUGFpQWN0aW9uTm9kZTogY2MuTm9kZSxcbiAgICAgICAgdGFibGVVc2VySW5mb05vZGU6IGNjLk5vZGUsXG4gICAgICAgIHBhaUNodVBhaU5vZGU6IGNjLlByZWZhYlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgYWN0aW9uTmFtZSA9IFsnemltbycsICdwZW5nJywgJ2dhbmcnLCAnaHUnLCAnY2FuY2xlJ107XG4gICAgICAgIGFjdGlvbldpZHRoID0gWzIyNSwgMTY2LCAxMzcsIDEyMSwgMTEyXTtcbiAgICAgICAgLy9hY3Rpb25XaWR0aCA9IFsyMjUsIDE1NiwgMTU3LCAxNDEsIDExMl07XG4gICAgICAgIHRoaXMuYWN0aW9uTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy56aW1vTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5wZW5nTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5odU5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMuY2FuY2xlTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGFibGVQYWlBY3Rpb25TY3JpcHQgPSB0aGlzLnRhYmxlUGFpQWN0aW9uTm9kZS5nZXRDb21wb25lbnQoJ3RhYmxlUGFpQWN0aW9uJyk7XG4gICAgICAgIHRhYmxlVXNlckluZm9Ob2RlU2NyaXB0ID0gdGhpcy50YWJsZVVzZXJJbmZvTm9kZS5nZXRDb21wb25lbnQoJ3RhYmxlVXNlckluZm8nKTtcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbiAgICB0ZXN0U2hvd0FjdGlvbjogZnVuY3Rpb24gdGVzdFNob3dBY3Rpb24oKSB7XG4gICAgICAgIHZhciBhY3Rpb25BcnJheSA9IFsnY2FuY2xlJywgJ2dhbmcnLCAncGVuZyddO1xuICAgICAgICB0aGlzLnNob3dBY3Rpb24oYWN0aW9uQXJyYXkpO1xuICAgIH0sXG4gICAgdGVzdFBlbmdQYWk6IGZ1bmN0aW9uIHRlc3RQZW5nUGFpKCkge1xuICAgICAgICB0aGlzLnBlbmdBY3Rpb24oXCJ0ZXN0VXNlcjJcIiwgXCIzM1wiKTtcbiAgICAgICAgdGhpcy5wZW5nQWN0aW9uKFwidGVzdFVzZXIwXCIsIFwiMTFcIik7XG4gICAgICAgIHRoaXMucGVuZ0FjdGlvbihcInRlc3RVc2VyMVwiLCBcIjIyXCIpO1xuICAgICAgICB0aGlzLnBlbmdBY3Rpb24oXCJ0ZXN0VXNlcjNcIiwgXCIyOFwiKTtcbiAgICAgICAgLy90aGlzLmdhbmdBY3Rpb24oXCJ0ZXN0VXNlcjJcIiwgXCIyM1wiKTtcbiAgICAgICAgdGhpcy5wZW5nQWN0aW9uKFwidGVzdFVzZXIyXCIsIFwiMjNcIik7XG4gICAgfSxcblxuICAgIHNob3dBY3Rpb246IGZ1bmN0aW9uIHNob3dBY3Rpb24oYWN0aW9uQXJyYXkpIHtcbiAgICAgICAgLy9mcm9tIHJpZ2h0IHRvIGxlZnQgLHRoZSB4IGlzIHJlZHVjZS5cbiAgICAgICAgdmFyIHN0YXJ0WCA9IDE0NjtcbiAgICAgICAgdmFyIGFjdGlvbldpZHRoVGVtcCA9IFtdO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFjdGlvbkFycmF5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgbm9kZSA9IGNjLmZpbmQoYWN0aW9uQXJyYXlbaV0gKyBcIkFjdGlvbk5vZGVcIiwgdGhpcy5hY3Rpb25Ob2RlKTtcbiAgICAgICAgICAgIG5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIG5vZGUueCA9IHN0YXJ0WDtcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgYWN0aW9uTmFtZS5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgIGlmIChhY3Rpb25OYW1lW2pdID09IGFjdGlvbkFycmF5W2ldKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vYWN0aW9uV2lkdGhUZW1wLnB1c2goYWN0aW9uV2lkdGhbal0pO1xuICAgICAgICAgICAgICAgICAgICBzdGFydFggPSBzdGFydFggLSBhY3Rpb25XaWR0aFtqXSAtIDE1O1xuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJzdGFydFg6XCIgKyBzdGFydFgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuYWN0aW9uTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1QZW5nLEdhbmcsSHUgQWN0aW9uLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICBwZW5nQWN0aW9uOiBmdW5jdGlvbiBwZW5nQWN0aW9uKHVzZXJPcGVuSWQsIHBhaU51bWJlcikge1xuICAgICAgICB2YXIgdXNlciA9IHRhYmxlUGFpQWN0aW9uU2NyaXB0LmdldENvcnJlY3RVc2VyQnlPcGVuSWQodXNlck9wZW5JZCk7XG4gICAgICAgIHZhciBwb2ludEluZGV4ID0gdXNlci5wb2ludEluZGV4O1xuICAgICAgICAvL2RhdGEgbGF5ZXIgLS0tLS0tXG4gICAgICAgIHZhciBwYWlMaXN0ID0gdXNlci5wYWlMaXN0QXJyYXk7XG4gICAgICAgIHBhaUxpc3QgPSB0aGlzLnJlbW92ZUVsZW1lbnRCeU51bWJlckZyb21Vc2VyKHBhaUxpc3QsIHBhaU51bWJlciwgMik7XG4gICAgICAgIGNjLmxvZyhcInBlbmdBY3Rpb24gcGFpTGlzdDpcIiArIHBhaUxpc3QpO1xuICAgICAgICB1c2VyLnBhaUxpc3RBcnJheSA9IHBhaUxpc3Q7XG4gICAgICAgIHZhciBwZW5nTGlzdCA9IHVzZXIucGVuZ1BhaUxpc3Q7XG4gICAgICAgIGlmIChwZW5nTGlzdCA9PSBudWxsIHx8IHBlbmdMaXN0ID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcGVuZ0xpc3QgPSBbXTtcbiAgICAgICAgfVxuICAgICAgICBwZW5nTGlzdC5wdXNoKHBhaU51bWJlcik7XG4gICAgICAgIHVzZXIucGVuZ1BhaUxpc3QgPSBwZW5nTGlzdDtcbiAgICAgICAgLy91cGRhdGUgdXNlciB0byBnb2JhbFxuICAgICAgICB1c2VyID0gdGFibGVQYWlBY3Rpb25TY3JpcHQuc3luY2hyb25pemF0aW9uUGFpTGlzdCh1c2VyKTtcbiAgICAgICAgdGFibGVQYWlBY3Rpb25TY3JpcHQudXBkYXRlVXNlckxpc3RJbkdvYmFsKHVzZXIpO1xuICAgICAgICAvL2RhdGEgbGF5ZXIgZW5kIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgLy8tLS0tLS0tc2hvdyB1c2VyIHBhaSBsaXN0LS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgY2MubG9nKFwicGVuZ0FjdGlvbjpcIiArIHBvaW50SW5kZXgpO1xuICAgICAgICBpZiAocG9pbnRJbmRleCA9PSBcIjNcIikge1xuICAgICAgICAgICAgdGFibGVQYWlBY3Rpb25TY3JpcHQucmVtb3ZlQWxsTm9kZUZyb21TZWxmUGFpTGlzdCgpO1xuICAgICAgICAgICAgdGFibGVVc2VySW5mb05vZGVTY3JpcHQuaW50YWxTZWxmUGFpTGlzdCh1c2VyLnBhaUxpc3QpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGFibGVQYWlBY3Rpb25TY3JpcHQucmVtb3ZlQWxsTm9kZUZyb21PdGhlclBhaUxpc3QocG9pbnRJbmRleCk7XG4gICAgICAgICAgICAvL2lmIChwb2ludEluZGV4ICE9IFwiMlwiKVxuICAgICAgICAgICAgdGFibGVVc2VySW5mb05vZGVTY3JpcHQuaW5pdGFsT3RoZXJQYWlMaXN0KHVzZXIucGFpTGlzdCwgcG9pbnRJbmRleCwgXCJwZW5nTGlzdFwiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuaW5pdGFsUGVuZ0FuZEdhbmdDaHVQYWlMaXN0KHVzZXJPcGVuSWQsIHBhaU51bWJlcik7XG4gICAgfSxcbiAgICBnYW5nQWN0aW9uOiBmdW5jdGlvbiBnYW5nQWN0aW9uKHVzZXJPcGVuSWQsIHBhaU51bWJlcikge1xuICAgICAgICB2YXIgdXNlciA9IHRhYmxlUGFpQWN0aW9uU2NyaXB0LmdldENvcnJlY3RVc2VyQnlPcGVuSWQodXNlck9wZW5JZCk7XG4gICAgICAgIHZhciBwb2ludEluZGV4ID0gdXNlci5wb2ludEluZGV4O1xuICAgICAgICAvL2RhdGEgbGF5ZXIgLS0tLS0tXG4gICAgICAgIHZhciBwYWlMaXN0ID0gdXNlci5wYWlMaXN0QXJyYXk7XG4gICAgICAgIHBhaUxpc3QgPSB0aGlzLnJlbW92ZUVsZW1lbnRCeU51bWJlckZyb21Vc2VyKHBhaUxpc3QsIHBhaU51bWJlciwgMyk7XG4gICAgICAgIGNjLmxvZyhcImdhbmdBY3Rpb24gcGFpTGlzdDpcIiArIHBhaUxpc3QpO1xuICAgICAgICB1c2VyLnBhaUxpc3RBcnJheSA9IHBhaUxpc3Q7XG4gICAgICAgIHZhciBnYW5nTGlzdCA9IHVzZXIuZ2FuZ1BhaUxpc3Q7XG4gICAgICAgIGlmIChnYW5nTGlzdCA9PSBudWxsIHx8IGdhbmdMaXN0ID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgZ2FuZ0xpc3QgPSBbXTtcbiAgICAgICAgfVxuICAgICAgICBnYW5nTGlzdC5wdXNoKHBhaU51bWJlcik7XG4gICAgICAgIHVzZXIuZ2FuZ1BhaUxpc3QgPSBnYW5nTGlzdDtcbiAgICAgICAgLy8gbW9wYWlcbiAgICAgICAgLy91cGRhdGUgdXNlciB0byBnb2JhbFxuICAgICAgICB1c2VyID0gdGFibGVQYWlBY3Rpb25TY3JpcHQuc3luY2hyb25pemF0aW9uUGFpTGlzdCh1c2VyKTtcbiAgICAgICAgdGFibGVQYWlBY3Rpb25TY3JpcHQudXBkYXRlVXNlckxpc3RJbkdvYmFsKHVzZXIpO1xuICAgICAgICAvL2RhdGEgbGF5ZXIgZW5kIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgLy8tLS0tLS0tc2hvdyB1c2VyIHBhaSBsaXN0LS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgY2MubG9nKFwicGVuZ0FjdGlvbjpcIiArIHBvaW50SW5kZXgpO1xuICAgICAgICBpZiAocG9pbnRJbmRleCA9PSBcIjNcIikge1xuICAgICAgICAgICAgdGFibGVQYWlBY3Rpb25TY3JpcHQucmVtb3ZlQWxsTm9kZUZyb21TZWxmUGFpTGlzdCgpO1xuICAgICAgICAgICAgdGFibGVVc2VySW5mb05vZGVTY3JpcHQuaW50YWxTZWxmUGFpTGlzdCh1c2VyLnBhaUxpc3QpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGFibGVQYWlBY3Rpb25TY3JpcHQucmVtb3ZlQWxsTm9kZUZyb21PdGhlclBhaUxpc3QocG9pbnRJbmRleCk7XG4gICAgICAgICAgICAvLyBpZiAocG9pbnRJbmRleCAhPSBcIjJcIikge1xuICAgICAgICAgICAgdGFibGVVc2VySW5mb05vZGVTY3JpcHQuaW5pdGFsT3RoZXJQYWlMaXN0KHVzZXIucGFpTGlzdCwgcG9pbnRJbmRleCwgXCJnYW5nXCIpO1xuICAgICAgICAgICAgLy8gIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuaW5pdGFsUGVuZ0FuZEdhbmdDaHVQYWlMaXN0KHVzZXJPcGVuSWQsIHBhaU51bWJlcik7XG4gICAgfSxcblxuICAgIGh1QWN0aW9uOiBmdW5jdGlvbiBodUFjdGlvbih1c2VyT3BlbklkLCBwYWlOdW1iZXIpIHt9LFxuXG4gICAgaW5pdGFsUGVuZ0FuZEdhbmdDaHVQYWlMaXN0OiBmdW5jdGlvbiBpbml0YWxQZW5nQW5kR2FuZ0NodVBhaUxpc3QodXNlck9wZW5JZCwgcGFpTnVtYmVyKSB7XG4gICAgICAgIHZhciB1c2VyID0gdGFibGVQYWlBY3Rpb25TY3JpcHQuZ2V0Q29ycmVjdFVzZXJCeU9wZW5JZCh1c2VyT3BlbklkKTtcbiAgICAgICAgdmFyIHBvaW50SW5kZXggPSB1c2VyLnBvaW50SW5kZXg7XG4gICAgICAgIHZhciB0YWJsZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL3RhYmxlTm9kZVwiKTtcbiAgICAgICAgdmFyIHVzZXJQZW5nUGFpTGlzdE5vZGUgPSBjYy5maW5kKFwidXNlclwiICsgcG9pbnRJbmRleCArIFwiUGVuZ1BhaUxpc3ROb2RlXCIsIHRhYmxlTm9kZSk7XG4gICAgICAgIHVzZXJQZW5nUGFpTGlzdE5vZGUucmVtb3ZlQWxsQ2hpbGRyZW4oKTtcbiAgICAgICAgY2MubG9nKFwiMTY2OlwiICsgdXNlclBlbmdQYWlMaXN0Tm9kZS5jaGlsZHJlbi5sZW5ndGgpO1xuICAgICAgICB2YXIgcGVuZ0xpc3QgPSB1c2VyLnBlbmdQYWlMaXN0O1xuICAgICAgICB2YXIgZ2FuZ1BhaUxpc3QgPSB1c2VyLmdhbmdQYWlMaXN0O1xuICAgICAgICB2YXIgeCA9IDA7XG4gICAgICAgIHZhciB5ID0gMDtcbiAgICAgICAgaWYgKHBvaW50SW5kZXggPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIHVzZXIucGVuZ0dhbmdQYWlQb2ludCA9IDQxMDtcbiAgICAgICAgICAgIHkgPSAwO1xuICAgICAgICAgICAgeCA9IHVzZXIucGVuZ0dhbmdQYWlQb2ludDtcbiAgICAgICAgfSBlbHNlIGlmIChwb2ludEluZGV4ID09IFwiMVwiKSB7XG4gICAgICAgICAgICB1c2VyLnBlbmdHYW5nUGFpUG9pbnQgPSAtMjcwO1xuICAgICAgICAgICAgeSA9IDA7XG4gICAgICAgICAgICB4ID0gdXNlci5wZW5nR2FuZ1BhaVBvaW50O1xuICAgICAgICB9IGVsc2UgaWYgKHBvaW50SW5kZXggPT0gXCIyXCIpIHtcbiAgICAgICAgICAgIHVzZXIucGVuZ0dhbmdQYWlQb2ludCA9IC0yNTA7XG4gICAgICAgICAgICB5ID0gdXNlci5wZW5nR2FuZ1BhaVBvaW50O1xuICAgICAgICAgICAgeCA9IDA7XG4gICAgICAgIH0gZWxzZSBpZiAocG9pbnRJbmRleCA9PSBcIjRcIikge1xuICAgICAgICAgICAgdXNlci5wZW5nR2FuZ1BhaVBvaW50ID0gMTAwO1xuICAgICAgICAgICAgeSA9IHVzZXIucGVuZ0dhbmdQYWlQb2ludDtcbiAgICAgICAgICAgIHggPSAwO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5zaG93UGVuZ0dhbmdQYWlMaXN0T25UYWxiZShwZW5nTGlzdCwgZ2FuZ1BhaUxpc3QsIHBvaW50SW5kZXgsIHBhaU51bWJlciwgdXNlclBlbmdQYWlMaXN0Tm9kZSwgXCJwZW5nXCIsIHgsIHkpO1xuICAgIH0sXG5cbiAgICBzaG93UGVuZ0dhbmdQYWlMaXN0T25UYWxiZTogZnVuY3Rpb24gc2hvd1BlbmdHYW5nUGFpTGlzdE9uVGFsYmUocGVuZ0xpc3QsIGdhbmdMaXN0LCBwb2ludEluZGV4LCBwYWlOdW1iZXIsIHVzZXJQZW5nUGFpTGlzdE5vZGUsIHR5cGUsIHgsIHkpIHtcblxuICAgICAgICB2YXIgaXNHYW5nRmxhZ0xpc3QgPSBbXTtcbiAgICAgICAgdmFyIGZpbmFsWCA9IHg7XG4gICAgICAgIHZhciBmaW5hbFkgPSB5O1xuICAgICAgICBpZiAocGVuZ0xpc3QgIT0gbnVsbCAmJiBwZW5nTGlzdCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGVuZ0xpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAvL2dldCBmaW5hbCBwb2ludCBmb3IgZ2FuZ1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAxOyBqIDwgNDsgaisrKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIHBvaW50MCA9IHRoaXMuZ2V0Q29ycmVjdFBvaW50QnlJbmRleChwb2ludEluZGV4LCBmaW5hbFgsIGZpbmFsWSk7XG4gICAgICAgICAgICAgICAgICAgIGZpbmFsWCA9IHBvaW50MFswXTtcbiAgICAgICAgICAgICAgICAgICAgZmluYWxZID0gcG9pbnQwWzFdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB2YXIgdGVtcFBhaSA9IHBlbmdMaXN0W2ldICsgXCJcIjtcbiAgICAgICAgICAgICAgICB0ZW1wUGFpID0gdGVtcFBhaS50cmltKCk7XG4gICAgICAgICAgICAgICAgLy92YXIgaXNHYW5nXG4gICAgICAgICAgICAgICAgLy9ldmFsKFwidmFyICAgaXNHYW5nXCIgKyBwYWlOdW1iZXIrXCJcIiArIFwiID0gZmFsc2U7XCIpO1xuICAgICAgICAgICAgICAgIC8vIGlzR2FuZ0ZsYWdMaXN0W3BhcnNlSW50KHRlbXBQYWkpXSA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgLy8gZXZhbChcImNjLmxvZyggJ2lzR2FuZyAyMTY6JysgIGlzR2FuZ1wiICsgcGFpTnVtYmVyK1wiKVwiKTtcbiAgICAgICAgICAgICAgICB2YXIgcGFpUGF0aCA9IHRhYmxlUGFpQWN0aW9uU2NyaXB0LmdldENodVBhaU5hbWVCeU5vZGVOYW1lKHRlbXBQYWksIHBvaW50SW5kZXgpO1xuICAgICAgICAgICAgICAgIHZhciBtaWRkbGVQb2ludCA9IG51bGw7XG4gICAgICAgICAgICAgICAgLy8gY2MubG9nKFwiaXNHYW5nIGxvYWRSZXM6XCIgKyBpc0dhbmcpO1xuICAgICAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKHBhaVBhdGgsIChmdW5jdGlvbiAoZXJyLCBzcCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCItLS0tXCIgKyBlcnIubWVzc2FnZSB8fCBlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIHNlbmNvZFBhaVggPSAtMTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHNlbmNvZFBhaVkgPSAtMTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDE7IGogPCA0OyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwTm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMucGFpQ2h1UGFpTm9kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS5uYW1lID0gXCJwZW5ncGFpXCIgKyBwb2ludEluZGV4ICsgXCJfXCIgKyBwYWlOdW1iZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwicGVuZyB4OlwiICsgeCArIFwiLS0tLS15OlwiICsgeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS5wb3NpdGlvbiA9IGNjLnAoeCwgeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaiA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuY29kUGFpWCA9IHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuY29kUGFpWSA9IHk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwb2ludEluZGV4ID09IFwiMlwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcE5vZGUuc2V0TG9jYWxaT3JkZXIoMTAwIC0gaik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcE5vZGUuekluZGV4ID0gMTAwIC0gajtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBvaW50ID0gdGhpcy5nZXRDb3JyZWN0UG9pbnRCeUluZGV4KHBvaW50SW5kZXgsIHgsIHkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgeCA9IHBvaW50WzBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgeSA9IHBvaW50WzFdO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gcE5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUoc3ApO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXNlclBlbmdQYWlMaXN0Tm9kZS5hZGRDaGlsZChwTm9kZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KS5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChnYW5nTGlzdCAhPSBudWxsICYmIGdhbmdMaXN0ICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgZm9yICh2YXIgayA9IDA7IGsgPCBnYW5nTGlzdC5sZW5ndGg7IGsrKykge1xuICAgICAgICAgICAgICAgIHZhciB0ZW1wUGFpID0gZ2FuZ0xpc3Rba10gKyBcIlwiO1xuICAgICAgICAgICAgICAgIHRlbXBQYWkgPSB0ZW1wUGFpLnRyaW0oKTtcbiAgICAgICAgICAgICAgICB2YXIgcGFpUGF0aCA9IHRhYmxlUGFpQWN0aW9uU2NyaXB0LmdldENodVBhaU5hbWVCeU5vZGVOYW1lKHRlbXBQYWksIHBvaW50SW5kZXgpO1xuICAgICAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKHBhaVBhdGgsIChmdW5jdGlvbiAoZXJyLCBzcCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCItLS0tXCIgKyBlcnIubWVzc2FnZSB8fCBlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIHNlbmNvZFBhaVggPSAtMTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHNlbmNvZFBhaVkgPSAtMTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgbSA9IDE7IG0gPCA0OyBtKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwTm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMucGFpQ2h1UGFpTm9kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS5uYW1lID0gXCJwZW5ncGFpXCIgKyBwb2ludEluZGV4ICsgXCJfXCIgKyBwYWlOdW1iZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiZ2FuZyBtOlwiICsgbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJnYW5nIHg6XCIgKyBmaW5hbFggKyBcIi0tLS0teTpcIiArIGZpbmFsWSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS5wb3NpdGlvbiA9IGNjLnAoZmluYWxYLCBmaW5hbFkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG0gPT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbmNvZFBhaVggPSBmaW5hbFg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuY29kUGFpWSA9IGZpbmFsWTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBvaW50SW5kZXggPT0gXCIyXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS5zZXRMb2NhbFpPcmRlcigxMDAgLSBtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwTm9kZS56SW5kZXggPSAxMDAgLSBtO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcG9pbnQgPSB0aGlzLmdldENvcnJlY3RQb2ludEJ5SW5kZXgocG9pbnRJbmRleCwgZmluYWxYLCBmaW5hbFkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZmluYWxYID0gcG9pbnRbMF07XG4gICAgICAgICAgICAgICAgICAgICAgICBmaW5hbFkgPSBwb2ludFsxXTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHNwcml0ZSA9IHBOb2RlLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3ByaXRlLnNwcml0ZUZyYW1lID0gbmV3IGNjLlNwcml0ZUZyYW1lKHNwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJQZW5nUGFpTGlzdE5vZGUuYWRkQ2hpbGQocE5vZGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLy9pZiAoc2luZ2xlSXNHYW5nID09IHRydWUpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBOb2RlMiA9IGNjLmluc3RhbnRpYXRlKHRoaXMucGFpQ2h1UGFpTm9kZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwb2ludEluZGV4ID09IFwiM1wiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZW5jb2RQYWlZID0gc2VuY29kUGFpWSArIDE1O1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHBvaW50SW5kZXggPT0gXCIxXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbmNvZFBhaVkgPSBzZW5jb2RQYWlZIC0gMTA7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocG9pbnRJbmRleCA9PSBcIjJcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2VuY29kUGFpWCA9IHNlbmNvZFBhaVggKyAxMDtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbmNvZFBhaVggPSBzZW5jb2RQYWlYICsgMTA7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJpc0dhbmcgcGFpTnVtYmVyOlwiICsgcGFpTnVtYmVyKTtcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiaXNHYW5nIHBhaVBhdGg6XCIgKyBwYWlQYXRoKTtcblxuICAgICAgICAgICAgICAgICAgICBwTm9kZTIubmFtZSA9IFwicGVuZ3BhaVwiICsgcG9pbnRJbmRleCArIFwiX2dhbmdcIiArIHBhaU51bWJlcjtcbiAgICAgICAgICAgICAgICAgICAgcE5vZGUyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcImdhbmcgeDpcIiArIGZpbmFsWCArIFwiLS0tLS15OlwiICsgZmluYWxZKTtcbiAgICAgICAgICAgICAgICAgICAgcE5vZGUyLnBvc2l0aW9uID0gY2MucChzZW5jb2RQYWlYLCBzZW5jb2RQYWlZKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHNwcml0ZTIgPSBwTm9kZTIuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgICAgICAgICAgICAgIHNwcml0ZTIuc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUoc3ApO1xuICAgICAgICAgICAgICAgICAgICB1c2VyUGVuZ1BhaUxpc3ROb2RlLmFkZENoaWxkKHBOb2RlMik7XG4gICAgICAgICAgICAgICAgICAgIC8vaXNHYW5nID0gZmFsc2U7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgICAgIH0pLmJpbmQodGhpcykpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIGdldENvcnJlY3RQb2ludEJ5SW5kZXg6IGZ1bmN0aW9uIGdldENvcnJlY3RQb2ludEJ5SW5kZXgocG9pbnRJbmRleCwgeCwgeSkge1xuICAgICAgICB2YXIgcG9pbnQgPSBbXTtcbiAgICAgICAgaWYgKHBvaW50SW5kZXggPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIHggPSB4IC0gNDI7XG4gICAgICAgIH0gZWxzZSBpZiAocG9pbnRJbmRleCA9PSBcIjFcIikge1xuXG4gICAgICAgICAgICB4ID0geCArIDQyO1xuICAgICAgICB9IGVsc2UgaWYgKHBvaW50SW5kZXggPT0gXCIyXCIpIHtcblxuICAgICAgICAgICAgeSA9IHkgKyAzNTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHkgPSB5IC0gMzU7XG4gICAgICAgIH1cblxuICAgICAgICBwb2ludC5wdXNoKHgpO1xuICAgICAgICBwb2ludC5wdXNoKHkpO1xuICAgICAgICByZXR1cm4gcG9pbnQ7XG4gICAgfSxcblxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS1BY3Rpb24gZW5kLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgcmVtb3ZlRWxlbWVudEJ5TnVtYmVyRnJvbVVzZXI6IGZ1bmN0aW9uIHJlbW92ZUVsZW1lbnRCeU51bWJlckZyb21Vc2VyKHBhaUxpc3QsIHBhaU51bWJlciwgYikge1xuICAgICAgICB2YXIgYyA9IDE7XG4gICAgICAgIHdoaWxlIChjIDw9IGIpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFpTGlzdC5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgICAgIHZhciB0ZW1wID0gcGFpTGlzdFtpXSArIFwiXCI7XG4gICAgICAgICAgICAgICAgdGVtcCA9IHRlbXAudHJpbSgpO1xuICAgICAgICAgICAgICAgIGlmICh0ZW1wID09IHBhaU51bWJlcikge1xuICAgICAgICAgICAgICAgICAgICBwYWlMaXN0LnNwbGljZShpLCAxKTtcblxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjKys7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcGFpTGlzdDtcbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMjJmYTA3eWk3SlBkS2RtTXFvbW14WHMnLCAncHVibGljTWVzc2FnZUNvbnRyb2xsZXInKTtcbi8vIHNjcmlwdC9jb250cm9sbGVycy9wdWJsaWNNZXNzYWdlQ29udHJvbGxlci5qc1xuXG52YXIgc291cmNlX3g7XG52YXIgdGFyZ2V0X3g7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cblxuICAgICAgICBtZXNzYWdlTm9kZTogY2MuTm9kZVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgaWYgKHNvdXJjZV94ID09IG51bGwgfHwgc291cmNlX3ggPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzb3VyY2VfeCA9IHRoaXMubWVzc2FnZU5vZGUueDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGFyZ2V0X3ggPT0gbnVsbCB8fCB0YXJnZXRfeCA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRhcmdldF94ID0gc291cmNlX3ggLSAxMDAwO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHkgPSB0aGlzLm1lc3NhZ2VOb2RlLnk7XG4gICAgICAgIHZhciBhY3Rpb24gPSBjYy5yZXBlYXRGb3JldmVyKGNjLnNlcXVlbmNlKGNjLm1vdmVUbyg1LCBjYy5wKHRhcmdldF94LCB5KSksIGNjLnBsYWNlKGNjLnAoc291cmNlX3gsIHkpKSkpO1xuICAgICAgICB0aGlzLm1lc3NhZ2VOb2RlLnJ1bkFjdGlvbihhY3Rpb24pO1xuICAgIH1cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzBhODkyQytKVjFBdExTeWVRNmN4K1JLJywgJ3F1ZXBhaVNjcmlwdCcpO1xuLy8gc2NyaXB0L3VpL3F1ZXBhaVNjcmlwdC5qc1xuXG52YXIgYWxlck1lc3NhZ2U7XG52YXIgZ2FtZVRhYmxlTmV0V29yaztcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICB0b25nTm9kZTogY2MuTm9kZSxcbiAgICAgICAgdGlhb05vZGU6IGNjLk5vZGUsXG4gICAgICAgIHdhbk5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHRoaXNTZWxlY3ROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB3YWl0T3RoZXJVc2VyTm9kZTogY2MuTm9kZSxcbiAgICAgICAgcXVlUGFpTm9kZTogY2MuTm9kZSxcbiAgICAgICAgYWxlcnRNZXNzYWdlTm9kZTogY2MuTm9kZSxcbiAgICAgICAgZ2FtZVRhYmxlTmV0V29ya05vZGU6IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMud2FpdE90aGVyVXNlck5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudGhpc1NlbGVjdE5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgLy8gdGhpcy5xdWVQYWlOb2RlLmFjdGl2ZSA9ZmFsc2U7XG4gICAgICAgIGFsZXJNZXNzYWdlID0gdGhpcy5hbGVydE1lc3NhZ2VOb2RlLmdldENvbXBvbmVudChcImFsZXJ0TWVzc2FnZVBhbmxlXCIpO1xuICAgICAgICBnYW1lVGFibGVOZXRXb3JrID0gdGhpcy5nYW1lVGFibGVOZXRXb3JrTm9kZS5nZXRDb21wb25lbnQoXCJHYW1lVGFibGVOZXRXb3JrXCIpO1xuICAgIH0sXG5cbiAgICBxdWVQYWlDbGljazogZnVuY3Rpb24gcXVlUGFpQ2xpY2soZXZlbnQpIHtcbiAgICAgICAgdmFyIG5vZGUgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIHZhciBuYW1lID0gbm9kZS5uYW1lO1xuICAgICAgICB2YXIgcXVlID0gXCJcIjtcbiAgICAgICAgaWYgKG5hbWUgPT0gXCJ0b25nXCIpIHtcbiAgICAgICAgICAgIHF1ZSA9IFwiMVwiO1xuICAgICAgICB9XG4gICAgICAgIGlmIChuYW1lID09IFwidGlhb1wiKSB7XG4gICAgICAgICAgICBxdWUgPSBcIjJcIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobmFtZSA9PSBcIndhblwiKSB7XG4gICAgICAgICAgICBxdWUgPSBcIjNcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciB1c2VyTGlzdCA9IEdsb2JhbC51c2VyTGlzdDtcbiAgICAgICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdXNlckxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmICh1c2VyTGlzdFtpXS5vcGVuaWQgPT0gdXNlckluZm8ub3BlbmlkKSB7XG4gICAgICAgICAgICAgICAgdXNlckxpc3RbaV0ucXVlUGFpID0gcXVlO1xuICAgICAgICAgICAgICAgIHVzZXJJbmZvLnF1ZVBhaSA9IHF1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBHbG9iYWwudXNlckluZm8gPSB1c2VySW5mbztcbiAgICAgICAgLy9zaG93IG90aGVyIHdhaXQgb3RoZXIgdXNlciBzZWxlY3QgcGFpIFxuICAgICAgICB0aGlzLnRoaXNTZWxlY3ROb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLndhaXRPdGhlclVzZXJOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIC8vc2V0IGFjdGlvbiB0eXBlb2ZcbiAgICAgICAgR2xvYmFsLmNodVBhaUFjdGlvblR5cGUgPSBcIm5vcm1hbENodVBhaVwiO1xuICAgIH0sXG5cbiAgICBzaG93UXVlUGFpTm9kZTogZnVuY3Rpb24gc2hvd1F1ZVBhaU5vZGUoKSB7XG4gICAgICAgIHRoaXMucXVlUGFpTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgIH0sXG5cbiAgICBzZW5kUXVlUGFpOiBmdW5jdGlvbiBzZW5kUXVlUGFpKCkge1xuICAgICAgICBpZiAoR2xvYmFsLmh1YW5TYW5aaGFuZ1BhaUxpc3QubGVuZ3RoIDwgMykge1xuICAgICAgICAgICAgYWxlck1lc3NhZ2UudGV4dCA9IFwi5L2g5b+F6aG76YCJ5oup5LiJ5byg54mM77yBXCI7XG4gICAgICAgICAgICBhbGVyTWVzc2FnZS5zZXRUZXh0T2ZQYW5lbCgpO1xuICAgICAgICAgICAgYWxlck1lc3NhZ2UuYWxlcnRQYW5lbE5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vR2xvYmFsLmNodVBhaUFjdGlvblR5cGUgPSBcIlwiXG4gICAgICAgICAgICB0aGlzLndhaXRQYW5sZU5vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIGdhbWVUYWJsZU5ldFdvcmsuc2VuZEh1YW5TYW5aaGFuZygpO1xuICAgICAgICAgICAgdGFibGVVc2VySW5mby5kaXNhYmxlQWxsUGFpKCk7XG4gICAgICAgICAgICB0aGlzLnVuc2NoZWR1bGUodGltZXJVcGF0ZSk7XG4gICAgICAgIH1cbiAgICB9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICczZmMyYmFsT1JOUHpyMTdGOWdNYXY0bycsICdzaG93R2FtZU1vZGUnKTtcbi8vIHNjcmlwdC91aS9zaG93R2FtZU1vZGUuanNcblxuY2MuQ2xhc3Moe1xuICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gIHByb3BlcnRpZXM6IHtcbiAgICAvLyBmb286IHtcbiAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAvLyB9LFxuICAgIC8vIC4uLlxuICAgIGdhbWVNb2RlTGFibGU6IGNjLk5vZGUsXG4gICAgZ2FtZVJvb21OVW1iZXI6IGNjLk5vZGVcbiAgfSxcblxuICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcblxuICBzaG93R2FtZU1vZGU6IGZ1bmN0aW9uIHNob3dHYW1lTW9kZSgpIHtcbiAgICB2YXIgZ2FtZU1vZGUgPSBHbG9iYWwuZ2FtZU1vZGU7XG4gICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgIGlmIChnYW1lTW9kZSA9PSBudWxsIHx8IGdhbWVNb2RlID09IHVuZGVmaW5lZCkge1xuICAgICAgZ2FtZU1vZGUgPSByZXF1aXJlKFwiZ2FtZU1vZGVcIikuZ2FtZU1vZGU7XG4gICAgfVxuXG4gICAgdmFyIG1vZGVTdHIgPSBcIlwiO1xuICAgIGlmIChnYW1lTW9kZS56aU1vSmlhRGkgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICBtb2RlU3RyID0gbW9kZVN0ciArIFwi6Ieq5pG45Yqg5bqVXCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLnppTW9KaWFGYW4gKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICBtb2RlU3RyID0gbW9kZVN0ciArIFwi6Ieq5pG45Yqg55WqXCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLnppTW9IdSArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgIG1vZGVTdHIgPSBtb2RlU3RyICsgXCLoh6rmkbjog6FcIiArIFwiIFwiO1xuICAgIH1cbiAgICBpZiAoZ2FtZU1vZGUuZGlhblBhb0h1ICsgXCJcIiA9PSBcIjFcIikge1xuICAgICAgbW9kZVN0ciA9IG1vZGVTdHIgKyBcIueCueeCruiDoVwiICsgXCIgXCI7XG4gICAgfVxuICAgIGlmIChnYW1lTW9kZS5odWFuU2FuWmhhbmcgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICBtb2RlU3RyID0gbW9kZVN0ciArIFwi5o2i5LiJ5bygXCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLmRpYW5HYW5nSHVhX2RpYW5QYW8gKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICBtb2RlU3RyID0gbW9kZVN0ciArIFwi54K55p2g54K554KuXCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLmRpYW5HYW5nSHVhX3ppTW8gKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICBtb2RlU3RyID0gbW9kZVN0ciArIFwi54K55p2g6Ieq5pG4XCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLmRhaTE5SmlhbmdEdWkgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICBtb2RlU3RyID0gbW9kZVN0ciArIFwi5bim5bm65LmdXCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLm1lbmdRaW5nWmhvbmdaaGFuZyArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgIG1vZGVTdHIgPSBtb2RlU3RyICsgXCLpl6jmuIXkuK3lvKBcIiArIFwiIFwiO1xuICAgIH1cblxuICAgIGlmIChnYW1lTW9kZS50aWFuRGlIdSArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgIG1vZGVTdHIgPSBtb2RlU3RyICsgXCLlpKnlnLDog6FcIiArIFwiIFwiO1xuICAgIH1cblxuICAgIGlmIChnYW1lTW9kZS5mYW4yICsgXCJcIiA9PSBcIjFcIikge1xuICAgICAgbW9kZVN0ciA9IG1vZGVTdHIgKyBcIjLnlarlsIHpobZcIiArIFwiIFwiO1xuICAgIH1cbiAgICBpZiAoZ2FtZU1vZGUuZmFuMyArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgIG1vZGVTdHIgPSBtb2RlU3RyICsgXCIz55Wq5bCB6aG2XCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLmZhbjQgKyBcIlwiID09IFwiMVwiKSB7XG4gICAgICBtb2RlU3RyID0gbW9kZVN0ciArIFwiNOeVquWwgemhtlwiICsgXCIgXCI7XG4gICAgfVxuICAgIGlmIChnYW1lTW9kZS5yb3VuZENvdW50NCArIFwiXCIgPT0gXCIxXCIpIHtcbiAgICAgIG1vZGVTdHIgPSBtb2RlU3RyICsgXCI05bGA5LiA6L2uXCIgKyBcIiBcIjtcbiAgICB9XG4gICAgaWYgKGdhbWVNb2RlLnJvdW5kQ291bnQ4ICsgXCJcIiA9PSBcIjFcIikge1xuICAgICAgbW9kZVN0ciA9IG1vZGVTdHIgKyBcIjjlsYDkuIDova5cIiArIFwiIFwiO1xuICAgIH1cblxuICAgIHZhciBtb2RlTGFibGUgPSB0aGlzLmdhbWVNb2RlTGFibGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICB2YXIgcm9vbUxhYmxlID0gdGhpcy5nYW1lUm9vbU5VbWJlci5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xuICAgIG1vZGVMYWJsZS5zdHJpbmcgPSBtb2RlU3RyO1xuICAgIHJvb21MYWJsZS5zdHJpbmcgPSBcIuaIv+mXtOWPtzpcIiArIEdsb2JhbC5qb2luUm9vbU51bWJlcjtcbiAgfVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNDU2ODJRTVV4eEtrNWtuVXh3ekJXQ1knLCAndGFibGVBY3Rpb25Db250cm9sbGVyJyk7XG4vLyBzY3JpcHQvY29udHJvbGxlcnMvdGFibGVBY3Rpb25Db250cm9sbGVyLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICB0YWJsZU5ldFdvcmtBY3Rpb246IGNjLk5vZGUsXG4gICAgICAgIHJlYWR5SWNvbjogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHJlYWR5Tm90SWNvbjogY2MuU3ByaXRlRnJhbWVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcblxuICAgIHVzZXJSZWFkeVRvZ2dsZTogZnVuY3Rpb24gdXNlclJlYWR5VG9nZ2xlKGV2ZW50KSB7XG5cbiAgICAgICAgdmFyIG5vZGUgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIGlmIChub2RlLmFjdGl2ZSA9PSB0cnVlKSB7XG4gICAgICAgICAgICBub2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGNjLmxvZyhcInVzZXJSZWFkeVRvZ2dsZTpcIiArIG5vZGUubmFtZSk7XG4gICAgfVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnZDIzMDN3bUN0Ukh4Wnpubnp4SS9mcnYnLCAndGFibGVDZW50ZXJQb2ludCcpO1xuLy8gc2NyaXB0L3VpL3RhYmxlQ2VudGVyUG9pbnQuanNcblxudmFyIHRpbWVyVXBhdGU7XG52YXIgdGltZUNvdW50O1xudmFyIHBvaW50VXBkYXRlO1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIHVzZXIxUG9pbnQ6IGNjLk5vZGUsXG4gICAgICAgIHVzZXIyUG9pbnQ6IGNjLk5vZGUsXG4gICAgICAgIHVzZXIzUG9pbnQ6IGNjLk5vZGUsXG4gICAgICAgIHVzZXI0UG9pbnQ6IGNjLk5vZGUsXG4gICAgICAgIHVzZXIxUXVlcGFpOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyMlF1ZXBhaTogY2MuTm9kZSxcbiAgICAgICAgdXNlcjNRdWVwYWk6IGNjLk5vZGUsXG4gICAgICAgIHVzZXI0UXVlcGFpOiBjYy5Ob2RlLFxuICAgICAgICBpbmRleDogU3RyaW5nLFxuICAgICAgICB0ZW5Qb2ludDogY2MuTm9kZSxcbiAgICAgICAgbnVtUG9pbnQ6IGNjLk5vZGUsXG4gICAgICAgIG51bWJlclNwcml0ZTogW2NjLlNwcml0ZUZyYW1lXSxcbiAgICAgICAgY2VudGVyUG9pbnROb2RlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSBzZWxmIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5oaWRlQWxsUG9pbnQoKTtcbiAgICAgICAgdGltZUNvdW50ID0gMzA7XG4gICAgICAgIHRoaXMuaW5pdGFsQ2VudGVyTnVtKCk7XG4gICAgICAgIHRoaXMuaGlkZUFsbFF1ZVBhaSgpO1xuICAgICAgICB0aW1lclVwYXRlID0gZnVuY3Rpb24gKCkge1xuXG4gICAgICAgICAgICAvLyBjYy5sb2coXCJ0aW1lQ291bnQ6XCIgKyB0aW1lQ291bnQgKyBcIi0tLS1cIiArIHRpbWVDb3VudC5sZW5ndGgpO1xuXG4gICAgICAgICAgICB0aGlzLmluaXRhbENlbnRlck51bSgpO1xuICAgICAgICAgICAgdGltZUNvdW50LS07XG5cbiAgICAgICAgICAgIGlmICh0aW1lQ291bnQgPT0gLTEpIHtcbiAgICAgICAgICAgICAgICBzZWxmLmVuZFRpbWVyKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgcG9pbnRVcGRhdGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgcG9pbnQ7XG4gICAgICAgICAgICBpZiAoc2VsZi5pbmRleCA9PSBcIjFcIikge1xuICAgICAgICAgICAgICAgIHBvaW50ID0gc2VsZi51c2VyMVBvaW50O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNlbGYuaW5kZXggPT0gXCIyXCIpIHtcbiAgICAgICAgICAgICAgICBwb2ludCA9IHNlbGYudXNlcjJQb2ludDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChzZWxmLmluZGV4ID09IFwiM1wiKSB7XG4gICAgICAgICAgICAgICAgcG9pbnQgPSBzZWxmLnVzZXIzUG9pbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc2VsZi5pbmRleCA9PSBcIjRcIikge1xuICAgICAgICAgICAgICAgIHBvaW50ID0gc2VsZi51c2VyNFBvaW50O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAocG9pbnQuYWN0aXZlID09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgcG9pbnQuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcG9pbnQuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgc2VsZi5pbmRleCA9IFwiMVwiO1xuICAgICAgICBzZWxmLnN0cmF0VGltZXIoKTtcbiAgICB9LFxuICAgIGluaXRhbENlbnRlck51bTogZnVuY3Rpb24gaW5pdGFsQ2VudGVyTnVtKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHZhciB0ZW4gPSAtMTtcbiAgICAgICAgdmFyIG51bSA9IC0xO1xuICAgICAgICBpZiAoKHRpbWVDb3VudCArIFwiXCIpLmxlbmd0aCA8IDIpIHtcbiAgICAgICAgICAgIHRlbiA9IFwiMFwiO1xuICAgICAgICAgICAgbnVtID0gdGltZUNvdW50ICsgXCJcIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRlbiA9ICh0aW1lQ291bnQgKyBcIlwiKS5zdWJzdHJpbmcoMCwgMSk7XG4gICAgICAgICAgICBudW0gPSAodGltZUNvdW50ICsgXCJcIikuc3Vic3RyaW5nKDEpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRlbiAhPSAtMSkge1xuICAgICAgICAgICAgdGVuID0gcGFyc2VJbnQodGVuKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobnVtICE9IC0xKSB7XG4gICAgICAgICAgICBudW0gPSBwYXJzZUludChudW0pO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHRlblNjcmlwdCA9IHNlbGYudGVuUG9pbnQuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIHZhciBudW1TY3JpcHQgPSBzZWxmLm51bVBvaW50LmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xuXG4gICAgICAgIHRlblNjcmlwdC5zcHJpdGVGcmFtZSA9IHNlbGYubnVtYmVyU3ByaXRlW3Rlbl07XG4gICAgICAgIG51bVNjcmlwdC5zcHJpdGVGcmFtZSA9IHNlbGYubnVtYmVyU3ByaXRlW251bV07XG4gICAgfSxcblxuICAgIGhpZGVBbGxRdWVQYWk6IGZ1bmN0aW9uIGhpZGVBbGxRdWVQYWkoKSB7XG4gICAgICAgIHRoaXMudXNlcjFRdWVwYWkuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcjJRdWVwYWkuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcjNRdWVwYWkuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcjRRdWVwYWkuYWN0aXZlID0gZmFsc2U7XG4gICAgfSxcblxuICAgIGhpZGVBbGxQb2ludDogZnVuY3Rpb24gaGlkZUFsbFBvaW50KCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYudXNlcjFQb2ludC5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgc2VsZi51c2VyMlBvaW50LmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICBzZWxmLnVzZXIzUG9pbnQuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHNlbGYudXNlcjRQb2ludC5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgc3RyYXRUaW1lcjogZnVuY3Rpb24gc3RyYXRUaW1lcigpIHtcbiAgICAgICAgLy90aW1lQ291bnQgPSAxMDtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLnNjaGVkdWxlKHRpbWVyVXBhdGUsIDEpO1xuICAgICAgICBzZWxmLnNjaGVkdWxlKHBvaW50VXBkYXRlLCAwLjUpO1xuICAgIH0sXG4gICAgZW5kVGltZXI6IGZ1bmN0aW9uIGVuZFRpbWVyKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYudW5zY2hlZHVsZSh0aW1lclVwYXRlKTtcbiAgICAgICAgc2VsZi51bnNjaGVkdWxlKHBvaW50VXBkYXRlKTtcbiAgICAgICAgc2VsZi5oaWRlQWxsUG9pbnQoKTtcbiAgICB9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgc2VsZiBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc4NWQyMGJ3dDRwSThweTJ4N1dCVytGdCcsICd0YWJsZU1vUGFpQWN0aW9uJyk7XG4vLyBzY3JpcHQvdWkvdGFibGVNb1BhaUFjdGlvbi5qc1xuXG5cbnZhciB0YWJsZUFjdGlvblNjcmlwdDtcbnZhciB0YWJsZVVzZXJJbmZvU2NyaXB0O1xuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIHRhYmxlQWN0aW9uOiBjYy5Ob2RlLFxuICAgICAgICBsaVBhaVByZWZhYjogY2MuUHJlZmFiLFxuICAgICAgICB1c2VyM1BhaUxpc3ROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZVVzZXJJbmZvOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0YWJsZUFjdGlvblNjcmlwdCA9IHRoaXMudGFibGVBY3Rpb24uZ2V0Q29tcG9uZW50KFwidGFibGVQYWlBY3Rpb25cIik7XG4gICAgICAgIHRhYmxlVXNlckluZm9TY3JpcHQgPSB0aGlzLnRhYmxlVXNlckluZm8uZ2V0Q29tcG9uZW50KFwidGFibGVVc2VySW5mb1wiKTtcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbiAgICBtb1BhaUZyb21TZXJ2ZXI6IGZ1bmN0aW9uIG1vUGFpRnJvbVNlcnZlcih1c2VyT3BlbklkKSB7fSxcbiAgICBtb1BhaVRlc3Q6IGZ1bmN0aW9uIG1vUGFpVGVzdCgpIHtcbiAgICAgICAgdGhpcy5tb1BhaUFjdGlvbihcIjE1XCIsIFwidGVzdFVzZXIyXCIpO1xuICAgIH0sXG5cbiAgICBtb1BhaUFjdGlvbjogZnVuY3Rpb24gbW9QYWlBY3Rpb24ocGFpTnVtYmVyLCB1c2VyT3BlbklkKSB7XG4gICAgICAgIHZhciBwYWlMaXN0ID0gdGFibGVBY3Rpb25TY3JpcHQuZ2V0U2VsZlBhaUxpc3QoKTtcbiAgICAgICAgdmFyIGxhdHN0SW5kZXggPSAwO1xuICAgICAgICBpZiAocGFpTGlzdC5sZW5ndGggPT0gMTMpIHtcbiAgICAgICAgICAgIGxhdHN0SW5kZXggPSAxMztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxhdHN0SW5kZXggPSBwYWlMaXN0Lmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICB2YXIgcGFpTm9kZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMubGlQYWlQcmVmYWIpO1xuICAgICAgICB2YXIgc3ByaXRlID0gcGFpTm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgcGFpTm9kZS5uYW1lID0gXCJwYWlcIiArIGxhdHN0SW5kZXggKyBcIl9cIiArIHBhaU51bWJlcjtcblxuICAgICAgICB2YXIgaW5kZXggPSB0YWJsZVVzZXJJbmZvU2NyaXB0LmdldEN1cnJlY3RJbmRlT25TZWZsUGFpKHBhaU51bWJlcik7XG4gICAgICAgIHNwcml0ZS5zcHJpdGVGcmFtZSA9IHRhYmxlVXNlckluZm9TY3JpcHQubGlQYWlaaU1pYW5baW5kZXhdO1xuICAgICAgICB0aGlzLnVzZXIzUGFpTGlzdE5vZGUuYWRkQ2hpbGQocGFpTm9kZSk7XG4gICAgICAgIHBhaU5vZGUucG9zaXRpb24gPSBjYy5wKC01MjAgKyBsYXRzdEluZGV4ICogODAsIDApO1xuICAgICAgICAvLy0tLWRhdGEgbGF5ZXItLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICB2YXIgdXNlckxpc3QgPSBHbG9iYWwudXNlckxpc3Q7XG4gICAgICAgIHZhciB1c2VyO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXJPcGVuSWQpIHtcbiAgICAgICAgICAgICAgICB1c2VyID0gdXNlckxpc3RbaV07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdXNlci51c2VyTW9QYWkgPSBwYWlOdW1iZXI7XG4gICAgICAgIHRoaXMudXBkYXRlVXNlckxpc3RJbkdvYmFsKHVzZXIpO1xuICAgICAgICB2YXIgdGFibGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy90YWJsZU5vZGVcIik7XG4gICAgICAgIHZhciBwYXJlbnROb2RlID0gY2MuZmluZChcInVzZXIzUGFpTGlzdFwiLCB0YWJsZU5vZGUpO1xuXG4gICAgICAgIHRhYmxlQWN0aW9uU2NyaXB0LmVuYWJsZWRBbGxQYWkocGFyZW50Tm9kZSwgZmFsc2UpO1xuICAgIH0sXG5cbiAgICB1cGRhdGVVc2VyTGlzdEluR29iYWw6IGZ1bmN0aW9uIHVwZGF0ZVVzZXJMaXN0SW5Hb2JhbCh1c2VyKSB7XG4gICAgICAgIHZhciB1c2VyTGlzdCA9IEdsb2JhbC51c2VyTGlzdDtcblxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXIub3BlbmlkKSB7XG4gICAgICAgICAgICAgICAgdXNlckxpc3RbaV0gPSB1c2VyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIEdsb2JhbC51c2VyTGlzdCA9IHVzZXJMaXN0O1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdlMTVlNjUyV1NKSis0eVE1eUNDMFBSYScsICd0YWJsZU5ldFdvcmsnKTtcbi8vIHNjcmlwdC9kb21haW5DbGFzcy90YWJsZU5ldFdvcmsuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge31cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2NlNmIyamJUNzFQelphTDdSKy9ySEtRJywgJ3RhYmxlUGFpQWN0aW9uJyk7XG4vLyBzY3JpcHQvdWkvdGFibGVQYWlBY3Rpb24uanNcblxuXG52YXIgcGFpTGlzdFJlT3JkZXJDb3VudCA9IFwiM1wiO1xudmFyIG5vZGVNb3ZlWCA9IC0xO1xudmFyIG5vZGVNb3ZlWSA9IC0xO1xudmFyIHRhYmxlVXNlckluZm9TY3JpcHQ7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgcGFpQWN0aW9uVHlwZTogU3RyaW5nLFxuICAgICAgICBhbGVydE1lc3NhZ2VOb2RlOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHNlbGZDaHVQYWlMaXN0Tm9kZTogY2MuTm9kZSxcbiAgICAgICAgcGFpQ2h1UGFpTm9kZTogY2MuUHJlZmFiLFxuICAgICAgICB0aGVNb3ZlTm9kZTogY2MuTm9kZVxuICAgIH0sXG5cbiAgICAvL3RhYmxlVXNlckluZm86Y2MuTm9kZSxcbiAgICAvL3BhaUxpc3RSZU9yZGVyQ291bnQ6Y2MuSW50ZWdlcixcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICAvL2NodVBhaUFjdGlvblR5cGVcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdmFyIHRhYmxlVXNlckluZm8gPSBjYy5maW5kKFwidGFibGVVc2VySW5mb1wiKTtcbiAgICAgICAgdGFibGVVc2VySW5mb1NjcmlwdCA9IHRhYmxlVXNlckluZm8uZ2V0Q29tcG9uZW50KFwidGFibGVVc2VySW5mb1wiKTtcbiAgICB9LFxuXG4gICAgc2V0UGFpTGlzdFJlT3JkZXJDb3VudDogZnVuY3Rpb24gc2V0UGFpTGlzdFJlT3JkZXJDb3VudChudW1iZXIpIHtcbiAgICAgICAgcGFpTGlzdFJlT3JkZXJDb3VudCA9IG51bWJlcjtcbiAgICB9LFxuICAgIC8vLS0tLS0tLS0tLURhdGEgbGF5ZXIgdXRpbHMgZnVuY3Rpb24tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBnZXRDb3JyZWN0SW5kZXhCeU51bWJlcjogZnVuY3Rpb24gZ2V0Q29ycmVjdEluZGV4QnlOdW1iZXIocGFpTnVtYmVyLCB1c2VyKSB7XG5cbiAgICAgICAgdmFyIHBhaUxpc3RBcnJheSA9IHVzZXIucGFpTGlzdEFycmF5O1xuICAgICAgICB2YXIgaW5kZXggPSAtMTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0QXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChwYWlMaXN0QXJyYXlbaV0gPT0gcGFpTnVtYmVyKSB7XG4gICAgICAgICAgICAgICAgaW5kZXggPSBpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpbmRleDtcbiAgICB9LFxuXG4gICAgLy8tLS0tLS0tLS0tRGF0YSBsYXllciB1dGlscyBmdW5jdGlvbiBlbmQtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS1hY3Rpb24gbGF5ZXIgdXRpbHMgZnVuY3Rpb24tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgIGFkZFBhaUludG9QYWlMaXN0Tm9kZTogZnVuY3Rpb24gYWRkUGFpSW50b1BhaUxpc3ROb2RlKHVzZXJDaHVQYWlMaXN0Tm9kZSwgbmFtZSwgdXNlclBvaW50LCBwYWlOb2RlKSB7XG4gICAgICAgIHZhciB1c2VyID0gdGhpcy5nZXRDb3JyZWN0VXNlckJ5UG9pbnQodXNlclBvaW50KTtcbiAgICAgICAgdmFyIHVzZXJQYWlMaXN0ID0gdXNlci5wYWlMaXN0O1xuICAgICAgICB2YXIgeCA9IHVzZXIuY2h1cGFpTGlzdFg7XG4gICAgICAgIHZhciB5ID0gdXNlci5jaHVwYWlMaXN0WTtcbiAgICAgICAgdmFyIHBhaVBhdGggPSB0aGlzLmdldENodVBhaU5hbWVCeU5vZGVOYW1lKG5hbWUsIHVzZXJQb2ludCk7XG4gICAgICAgIGNjLmxvZyhcInBhaVBhdGg6XCIgKyBwYWlQYXRoKTtcbiAgICAgICAgdmFyIHBOb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5wYWlDaHVQYWlOb2RlKTtcblxuICAgICAgICBpZiAodXNlclBvaW50ID09IFwiM1wiKSB7XG4gICAgICAgICAgICBpZiAodXNlci5jaHVQYWlDb3VudCA+PSBwYWlMaXN0UmVPcmRlckNvdW50KSB7XG4gICAgICAgICAgICAgICAgcE5vZGUuc2V0TG9jYWxaT3JkZXIoMTApO1xuICAgICAgICAgICAgICAgIHBOb2RlLnpJbmRleCA9IDEwO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwTm9kZS5zZXRMb2NhbFpPcmRlcigyMCk7XG4gICAgICAgICAgICAgICAgcE5vZGUuekluZGV4ID0gMjA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodXNlclBvaW50ID09IFwiNFwiKSB7XG4gICAgICAgICAgICBwTm9kZS5zZXRMb2NhbFpPcmRlcigxMDAgLSBwYXJzZUludCh1c2VyLmNodVBhaUNvdW50KSk7XG4gICAgICAgICAgICBwTm9kZS56SW5kZXggPSAxMDAgLSBwYXJzZUludCh1c2VyLmNodVBhaUNvdW50KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vbGV0IHNwcml0ZSA9IHBOb2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpXG4gICAgICAgIHBOb2RlLm5hbWUgPSBcInBhaVwiICsgdXNlclBvaW50ICsgXCJfXCIgKyBuYW1lO1xuICAgICAgICBwTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgcE5vZGUucG9zaXRpb24gPSBjYy5wKHgsIHkpO1xuICAgICAgICAvL3BOb2RlLndpZHRoID0gNDI7XG4gICAgICAgIC8vcE5vZGUuaGVpZ2h0ID0gNjE7XG4gICAgICAgIHZhciBzcHJpdGUgPSBwTm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMocGFpUGF0aCwgZnVuY3Rpb24gKGVyciwgc3ApIHtcbiAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICAvLyAgY2MubG9nKFwiLS0tLVwiICsgZXJyLm1lc3NhZ2UgfHwgZXJyKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBjYy5sb2coXCI4NVwiKTtcblxuICAgICAgICAgICAgc3ByaXRlLnNwcml0ZUZyYW1lID0gbmV3IGNjLlNwcml0ZUZyYW1lKHNwKTtcblxuICAgICAgICAgICAgLy8gIGNjLmxvZyhcIjk5XCIpO1xuICAgICAgICAgICAgLy8gY2MubG9nKCdSZXN1bHQgc2hvdWxkIGJlIGEgc3ByaXRlIGZyYW1lOiAnICsgKHNwIGluc3RhbmNlb2YgY2MuU3ByaXRlRnJhbWUpKTtcbiAgICAgICAgICAgIC8vIHBOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH0pO1xuICAgICAgICB1c2VyQ2h1UGFpTGlzdE5vZGUuYWRkQ2hpbGQocE5vZGUpO1xuICAgICAgICB2YXIgcGFpTm9kZUFycmF5ID0gW107XG4gICAgICAgIHBhaU5vZGVBcnJheS5wdXNoKHBOb2RlKTtcbiAgICAgICAgcGFpTm9kZUFycmF5LnB1c2gocGFpTm9kZSk7XG4gICAgICAgIHBhaU5vZGVBcnJheS5wdXNoKHBhaU5vZGUucGFyZW50KTtcbiAgICAgICAgcGFpTm9kZUFycmF5LnB1c2godXNlclBhaUxpc3QpO1xuICAgICAgICBwYWlOb2RlQXJyYXkucHVzaCh1c2VyLm9wZW5pZCk7XG4gICAgICAgIHZhciBmaW5pc2hlZCA9IGNjLmNhbGxGdW5jKHRoaXMucGxheVNsZWZDaHVQYWlBY3Rpb25fYWRkQ2hpbGQsIHRoaXMsIHBhaU5vZGVBcnJheSk7XG4gICAgICAgIHZhciBtb3ZlVG9ZID0gMDtcblxuICAgICAgICBpZiAodXNlclBvaW50ID09IFwiM1wiKSB7XG4gICAgICAgICAgICBtb3ZlVG9ZID0geSArIDIyMDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodXNlclBvaW50ID09IFwiMVwiKSB7XG4gICAgICAgICAgICBtb3ZlVG9ZID0geSAtIDExMDtcbiAgICAgICAgfVxuICAgICAgICBjYy5sb2coXCJ5OlwiICsgeSk7XG4gICAgICAgIGNjLmxvZyhcIm1vdmVUb1k6XCIgKyBtb3ZlVG9ZKTtcbiAgICAgICAgdmFyIGFjdGlvbiA9IGNjLnNlcXVlbmNlKGNjLm1vdmVUbygwLjE1LCB4LCBtb3ZlVG9ZKSwgY2Muc2NhbGVUbygwLjE1LCAwLjUpLCBjYy5yZW1vdmVTZWxmKCksIGZpbmlzaGVkKTtcbiAgICAgICAgLy9pdCBpcyBvdGhlciB1c2VyIGNodXBhaSAsZ2V0IHRoZSBmaXJzdCBjaGlsZCBlbGVtZW50XG4gICAgICAgIGNjLmxvZyhcIjEyNzpcIiArIHBhaU5vZGUucGFyZW50LmNoaWxkcmVuQ291bnQpO1xuICAgICAgICBwYWlOb2RlLnJ1bkFjdGlvbihhY3Rpb24pO1xuXG4gICAgICAgIC8vdXNlci5jaHVQYWlDb3VudCA9IHVzZXIuY2h1UGFpQ291bnQgKyAxO1xuXG4gICAgICAgIC8vcmVtb3ZlIHBhaU5vZGUgZnJvbSBwYXJ0bmV0XG4gICAgICAgIGNjLmxvZyhcIjEzMjpcIiArIHBhaU5vZGUucGFyZW50Lm5hbWUpO1xuICAgICAgICAvLyBwYWlOb2RlLnJlbW92ZUZyb21QYXJlbnQoKTtcbiAgICAgICAgLy91c2VyQ2h1UGFpTGlzdE5vZGUuYWRkQ2hpbGQocGFpTm9kZSk7XG5cbiAgICAgICAgcmV0dXJuIHVzZXI7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS1nYW1lIGFjdGlvbi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBzbGVmQ2h1UGFpQWN0aW9uOiBmdW5jdGlvbiBzbGVmQ2h1UGFpQWN0aW9uKHBhaU51bWJlcikge1xuICAgICAgICB2YXIgcGFpTm9kZSA9IGNjLmZpbmQoXCJ1c2VyM05vZGVcIiwgdGhpcy50YWJsZU5vZGUpO1xuICAgICAgICB2YXIgY2hpbGRyZW4gPSBwYWlOb2RlLmNoaWxkcmVuO1xuICAgICAgICB2YXIgc2VsZlBhaUxpc3QgPSB0aGlzLmdldFNlbGZQYWlMaXN0KCk7XG4gICAgICAgIHZhciB1c2VySW5mbyA9IEdsb2JhbC51c2VySW5mbztcbiAgICAgICAgdmFyIG9wZW5pZCA9IHVzZXJJbmZvLm9wZW5pZDtcbiAgICAgICAgLy8tLS1kYXRhIGxheWVyIHN0YXJ0LS0tLS0tLS1cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICB2YXIgdGVtcCA9IGNoaWxkcmVkTmFtZS5zcGxpdChcIl9cIik7XG4gICAgICAgICAgICB2YXIgc1R5cGUgPSB0ZW1wWzFdLnRyaW0oKTtcbiAgICAgICAgICAgIHZhciBpbmRleCA9IHBhcnNlSW50KHRlbXBbMF0udHJpbSgpLnJlcGxhY2UoXCJwYWlcIiwgXCJcIikpO1xuICAgICAgICAgICAgaWYgKHBhaU51bWJlciA9PSBzVHlwZSkge1xuICAgICAgICAgICAgICAgIHNlbGZQYWlMaXN0LnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRVc2VyUGFpTGlzdChvcGVuaWQsIHNlbGZQYWlMaXN0KTtcblxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vKioqKmZpeCB0aGUgbm9kZSBuYW1lIGZvciB0aGUgbmV3IHBhaSBsaXN0LiAqL1xuXG4gICAgICAgIC8vLS0tLWRhdGEgbGF5ZXIgZW5kLS0tLS0tLS0tLS1cbiAgICAgICAgLy9pbnNlcnQgcGFpIGFjdGlvbiBjb21pYyBhY3Rpb24gLlxuICAgICAgICAvLyByZW1vdmUgdGhlIHBhaSBmcm9tIHNlbGYgbGlzdFxuICAgICAgICAvL21vdmUgcmVzdCBwYWkgdG8gY29ycmVjdCBwb2ludCAsYW5kIGtlZXAgdGhlIGJsYW5rIGZvciAxNCBwYWlcbiAgICAgICAgLy9pbnNlcnQgdGhlIDE0IHBhaSBpbnRvIGNvcnJlY3QgcG9pbnQgLlxuICAgIH0sXG4gICAgdGVzdE90aGVyQ2h1UGFpOiBmdW5jdGlvbiB0ZXN0T3RoZXJDaHVQYWkoKSB7XG4gICAgICAgIHRoaXMucGxheU90aGVyQ2h1UGFpQWN0aW9uKFwiMjJcIiwgXCIxXCIpO1xuICAgICAgICB0aGlzLnBsYXlPdGhlckNodVBhaUFjdGlvbihcIjI3XCIsIFwiMlwiKTtcbiAgICAgICAgdGhpcy5wbGF5T3RoZXJDaHVQYWlBY3Rpb24oXCIyN1wiLCBcIjRcIik7XG4gICAgICAgIHRoaXMuZGlzYWJsZUFsbFNsZWZQYWlBZnRlclF1ZVBhaSgpO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2Qgd2lsbCBleGVjdXRlIHRoZSBvdGhlciBjaHVwYWkgYWN0aW9uIFxuICAgICAqL1xuICAgIHBsYXlPdGhlckNodVBhaUFjdGlvbjogZnVuY3Rpb24gcGxheU90aGVyQ2h1UGFpQWN0aW9uKHBhaU51bWJlciwgdXNlclBvaW50KSB7XG4gICAgICAgIC8vdmFyIHVzZXIgPSB0aGlzLmdldENvcnJlY3RVc2VyQnlQb2ludCh1c2VyUG9pbnQpO1xuICAgICAgICB2YXIgcGFpUGF0aCA9IHRoaXMuZ2V0Q2h1UGFpTmFtZUJ5Tm9kZU5hbWUocGFpTnVtYmVyLCB1c2VyUG9pbnQpO1xuICAgICAgICAvLyB2YXIgeCA9IHVzZXIuY2h1cGFpTGlzdFg7XG4gICAgICAgIC8vICB2YXIgeSA9IHVzZXIuY2h1cGFpTGlzdFk7XG4gICAgICAgIHZhciB0YWJsZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL3RhYmxlTm9kZVwiKTtcbiAgICAgICAgdmFyIHVzZXJDaHVQYWlMaXN0Tm9kZSA9IGNjLmZpbmQoXCJ1c2VyXCIgKyB1c2VyUG9pbnQgKyBcIkNodWFQYWlMaXN0Tm9kZVwiLCB0YWJsZU5vZGUpO1xuICAgICAgICB2YXIgdXNlclBhaUxpc3QgPSBjYy5maW5kKFwidXNlclwiICsgdXNlclBvaW50ICsgXCJQYWlMaXN0XCIsIHRhYmxlTm9kZSk7XG4gICAgICAgIC8vIGNjLmxvZyhcInVzZXJQYWlMaXN0OlwiICsgdXNlclBhaUxpc3QubmFtZSk7XG4gICAgICAgIC8vICAgIGNjLmxvZyhcInVzZXJQYWlMaXN0IGNoaWxkcmVuOlwiICsgdXNlclBhaUxpc3QuY2hpbGRyZW4ubGVuZ3RoKTtcbiAgICAgICAgdmFyIHBhaU5vZGUgPSB1c2VyUGFpTGlzdC5jaGlsZHJlblswXTtcbiAgICAgICAgLy8gICBjYy5sb2coXCJwYWlOb2RlOlwiICsgcGFpTm9kZS5uYW1lKTtcbiAgICAgICAgdmFyIHVzZXIgPSB0aGlzLmFkZFBhaUludG9QYWlMaXN0Tm9kZSh1c2VyQ2h1UGFpTGlzdE5vZGUsIHBhaU51bWJlciwgdXNlclBvaW50LCBwYWlOb2RlKTtcblxuICAgICAgICB1c2VyID0gdGhpcy5maXhDdXJyZW50Q2h1UGFpUG9pbnQodXNlcik7XG4gICAgICAgIHRoaXMudXBkYXRlVXNlckxpc3RJbkdvYmFsKHVzZXIpO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2Qgd2lsbCBleGVjdXRlIHRoZSBhbmljYXRpb24gb2YgY2h1cGFpIGluIHNlbGYgcGFpIGxpc3RcbiAgICAgKi9cbiAgICBwbGF5U2xlZkNodVBhaUFjdGlvbjogZnVuY3Rpb24gcGxheVNsZWZDaHVQYWlBY3Rpb24ocGFpTm9kZSwgdXNlclBvaW50KSB7XG4gICAgICAgIC8vIHZhciB1c2VyID0gdGhpcy5nZXRDb3JyZWN0VXNlckJ5UG9pbnQodXNlclBvaW50KTtcbiAgICAgICAgdmFyIG5hbWUgPSBwYWlOb2RlLm5hbWU7XG5cbiAgICAgICAgdmFyIHRlbXBBcnJheSA9IG5hbWUuc3BsaXQoXCJfXCIpO1xuICAgICAgICBuYW1lID0gdGVtcEFycmF5WzFdO1xuXG4gICAgICAgIC8vIGNjLmxvZyhcInVzZXIuY2h1cGFpTGlzdFg6XCIgKyB1c2VyLmNodXBhaUxpc3RYKTtcblxuICAgICAgICAvLyBjYy5sb2coXCJ4OlwiICsgeCArIFwiLS0tLVwiICsgXCJ5OlwiICsgeSk7XG4gICAgICAgIC8vLCBjYy5yZW1vdmVTZWxmKClcblxuICAgICAgICAvL2FkZCB0aGUgdGFyZ2V0IHBhaSBpbnRvIHBhaSBsaXN0LlxuICAgICAgICB2YXIgcGFyZW50Tm9kZSA9IHBhaU5vZGUucGFyZW50LnBhcmVudDtcbiAgICAgICAgLy8gIGNjLmxvZyhcInBhcmVudE5vZGU6XCIgKyBwYXJlbnROb2RlLm5hbWUpO1xuICAgICAgICB2YXIgdXNlckNodVBhaUxpc3ROb2RlID0gY2MuZmluZChcInVzZXJcIiArIHVzZXJQb2ludCArIFwiQ2h1YVBhaUxpc3ROb2RlXCIsIHBhcmVudE5vZGUpO1xuICAgICAgICAvLyAgIGNjLmxvZyhcInVzZXJDaHVQYWlMaXN0Tm9kZTpcIiArIHVzZXJDaHVQYWlMaXN0Tm9kZSk7XG5cbiAgICAgICAgdmFyIHVzZXIgPSB0aGlzLmFkZFBhaUludG9QYWlMaXN0Tm9kZSh1c2VyQ2h1UGFpTGlzdE5vZGUsIG5hbWUsIHVzZXJQb2ludCwgcGFpTm9kZSk7XG4gICAgICAgIHVzZXIuY2h1UGFpUG9pbnRYID0gcGFpTm9kZS54O1xuICAgICAgICB1c2VyID0gdGhpcy5maXhDdXJyZW50Q2h1UGFpUG9pbnQodXNlcik7XG5cbiAgICAgICAgLy9Ob3csIHdlIG5lZWQgaW5zZXJ0IHRoZSAxNCBpbnRvIGNvcnJlY3QgcG9pbnRcbiAgICAgICAgdmFyIGNodXBhaUluZGV4ID0gcGFyc2VJbnQodGVtcEFycmF5WzBdLnJlcGxhY2UoXCJwYWlcIiwgXCJcIikpO1xuICAgICAgICB2YXIgbW9wYWlJbnNlcnRJbmRleCA9IHRoaXMuZ2V0UGFpSW5zZXJ0SW5kZXhCeTE0KCk7XG4gICAgICAgIGNjLmxvZyhcIm1vcGFpSW5zZXJ0SW5kZXg6XCIgKyBtb3BhaUluc2VydEluZGV4KTtcbiAgICAgICAgY2MubG9nKFwiY2h1cGFpSW5kZXg6XCIgKyBjaHVwYWlJbmRleCk7XG4gICAgICAgIC8vbW92ZSB0aGUgb3RoZXIgcGFpIGludG8gY29ycmVjdCBwb2ludFxuXG4gICAgICAgIGlmIChjaHVwYWlJbmRleCAhPSBtb3BhaUluc2VydEluZGV4KSB7XG4gICAgICAgICAgICBtb3BhaUluc2VydEluZGV4ID0gdGhpcy5tb3ZlT3RoZXJQYWlJbnRvQ29ycmVjdFBvaW50KG1vcGFpSW5zZXJ0SW5kZXgsIGNodXBhaUluZGV4KTtcbiAgICAgICAgfVxuICAgICAgICAvL21vdmUgdGhlIDE0IHBhaSBpbnRvIGNvcnJlY3QgcG9pbnRcbiAgICAgICAgdGhpcy5tb3ZlTGFzdGVzdFBhaVRvUG9pbnQobW9wYWlJbnNlcnRJbmRleCk7XG4gICAgICAgIC8vZGF0YWxheWVyIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgICAgICB2YXIgcGFpTGlzdCA9IHRoaXMucmVtb3ZlRWxlbWVudEJ5TnVtYmVyRnJvbVVzZXIocGFpTm9kZSwgMSk7XG4gICAgICAgIGNjLmxvZyhcIjIzNTpcIiArIHBhaUxpc3QpO1xuICAgICAgICB1c2VyLnBhaUxpc3RBcnJheSA9IHBhaUxpc3Q7XG4gICAgICAgIHVzZXIgPSB0aGlzLmluc2VydE1vUGFpSW50b1BhaUxpc3QodXNlcik7XG4gICAgICAgIHVzZXIgPSB0aGlzLnN5bmNocm9uaXphdGlvblBhaUxpc3QodXNlcik7XG4gICAgICAgIHVzZXIudXNlck1vUGFpID0gXCJcIjtcbiAgICAgICAgY2MubG9nKFwidXNlciBvcGVuaWQ6XCIgKyB1c2VyLm9wZW5pZCk7XG4gICAgICAgIHRoaXMudXBkYXRlVXNlckxpc3RJbkdvYmFsKHVzZXIpO1xuICAgICAgICBjYy5sb2coXCIyNDE6XCIgKyB1c2VyLnBhaUxpc3QpO1xuICAgICAgICAvL3RoaXMuZml4VXNlclNlbGZQYWlQb2luc3QoKTtcbiAgICAgICAgLy90aGlzLnJlbW92ZUFsbE5vZGVGcm9tU2VsZlBhaUxpc3QoKTtcbiAgICAgICAgLy90YWJsZVVzZXJJbmZvU2NyaXB0LmludGFsU2VsZlBhaUxpc3QodXNlci5wYWlMaXN0KTtcblxuICAgICAgICAvL2FkZCBwYWkgdG8gY29ycmVjdCBwb2ludCBcblxuICAgICAgICAvLyBwTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAvL2FkZCBpdCB0byBjdXJlcm50XG4gICAgICAgIC8vICBldmFsKFwidGhpcy51c2VyXCIgKyBwb2ludCArIFwiUGFpTGlzdE5vZGUuYWRkQ2hpbGQocGFpTm9kZSlcIik7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIGZpeCB0aGUgcG9pbnQgZm9yIHNlbGYgcGFpIGxpc3RcbiAgICAgKi9cblxuICAgIGZpeFVzZXJTZWxmUGFpUG9pbnN0OiBmdW5jdGlvbiBmaXhVc2VyU2VsZlBhaVBvaW5zdCgpIHtcbiAgICAgICAgdmFyIHRhYmxlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvdGFibGVOb2RlXCIpO1xuICAgICAgICB2YXIgcGFyZW50Tm9kZSA9IGNjLmZpbmQoXCJ1c2VyM1BhaUxpc3RcIiwgdGFibGVOb2RlKTtcbiAgICAgICAgdmFyIGNoaWxkcmVucyA9IHBhcmVudE5vZGUuY2hpbGRyZW47XG4gICAgICAgIHZhciBzdGFydFBvaW50ID0gLTUyMDtcbiAgICAgICAgY2MubG9nKFwiMjY0OlwiICsgY2hpbGRyZW5zLmxlbmd0aCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2hpbGRyZW5zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgY2hpbGQgPSBjaGlsZHJlbnNbaV07XG4gICAgICAgICAgICBjaGlsZC5wb3NpdGlvbiA9IGNjLnAoc3RhcnRQb2ludCArIGkgKiA3OSwgMCk7XG4gICAgICAgICAgICBjYy5sb2coXCJwb25pdDpcIiArIGkgKyBcIjpcIiArIChzdGFydFBvaW50ICsgaSAqIDc5KSArIFwiOjpcIiArIGNoaWxkLm5hbWUpO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIHBsYXlTbGVmSW5zZXJ0ZXJQYWlBY3Rpb246IGZ1bmN0aW9uIHBsYXlTbGVmSW5zZXJ0ZXJQYWlBY3Rpb24oY2h1cGFpSW5kZXgsIG1vcGFpSW5kZXgpIHtcbiAgICAgICAgLy9maXJzdCB3ZSBzaG91bGQgZGVjaWRlIGlmIG1vdmUgdGhlIHBhaSBvciBub3QgbW92ZVxuICAgICAgICBpZiAoY2h1cGFpSW5kZXggPT0gbW9wYWlJbmRleCkge30gZWxzZSBpZiAoY2h1cGFpSW5kZXggPiBtb3BhaUluZGV4KSB7fSBlbHNlIHtcbiAgICAgICAgICAgIC8vY2h1cGFpSW5kZXg8bW9wYWlJbmRleFxuXG4gICAgICAgIH1cbiAgICB9LFxuICAgIG1vdmVPdGhlclBhaUludG9Db3JyZWN0UG9pbnQ6IGZ1bmN0aW9uIG1vdmVPdGhlclBhaUludG9Db3JyZWN0UG9pbnQobW9wYWlJbnNlcnRJbmRleCwgY2h1UGFpSW5kZXgpIHtcblxuICAgICAgICB2YXIgdGFibGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy90YWJsZU5vZGVcIik7XG4gICAgICAgIHZhciBwYXJlbnROb2RlID0gY2MuZmluZChcInVzZXIzUGFpTGlzdFwiLCB0YWJsZU5vZGUpO1xuICAgICAgICB2YXIgY2hpbGRyZW4gPSBwYXJlbnROb2RlLmNoaWxkcmVuO1xuICAgICAgICBjYy5sb2coXCIyODg6XCIgKyBjaGlsZHJlbi5sZW5ndGgpO1xuICAgICAgICBjYy5sb2coXCJtb3BhaUluc2VydEluZGV4OlwiICsgbW9wYWlJbnNlcnRJbmRleCk7XG4gICAgICAgIGlmIChtb3BhaUluc2VydEluZGV4ID09IC0xKSB7XG4gICAgICAgICAgICBtb3BhaUluc2VydEluZGV4ID0gMDtcbiAgICAgICAgfVxuICAgICAgICBjYy5sb2coXCJjaHVQYWlJbmRleDpcIiArIGNodVBhaUluZGV4KTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgICAgICAgICBjYy5sb2coXCIyODggbmFtZTpcIiArIGNoaWxkLm5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIHZhciB1c2VyID0gdGhpcy5nZXRDb3JyZWN0VXNlckJ5UG9pbnQoXCIzXCIpO1xuICAgICAgICB2YXIgY2h1UGFpUG9pbnRYID0gdXNlci5jaHVQYWlQb2ludFg7XG4gICAgICAgIHZhciBtb3ZlRGlzdGFuY2UgPSAwO1xuXG4gICAgICAgIGlmIChtb3BhaUluc2VydEluZGV4ID4gY2h1UGFpSW5kZXgpIHtcbiAgICAgICAgICAgIGNjLmxvZyhcIj4+Pj4+OlwiKTtcblxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IGNodVBhaUluZGV4ICsgMTsgaSA8IG1vcGFpSW5zZXJ0SW5kZXg7IGkrKykge1xuICAgICAgICAgICAgICAgIHZhciBub2RlID0gY2hpbGRyZW5baV07XG4gICAgICAgICAgICAgICAgdmFyIGFjdGlvbiA9IGNjLm1vdmVUbygwLjEsIG5vZGUueCAtIDg0LCBub2RlLnkpO1xuICAgICAgICAgICAgICAgIG5vZGUucnVuQWN0aW9uKGFjdGlvbik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtb3BhaUluc2VydEluZGV4LS07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYy5sb2coXCI8PDw8PDw6XCIpO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IGNodVBhaUluZGV4IC0gMTsgaSA+IG1vcGFpSW5zZXJ0SW5kZXggLSAxOyBpLS0pIHtcbiAgICAgICAgICAgICAgICB2YXIgbm9kZSA9IGNoaWxkcmVuW2ldO1xuICAgICAgICAgICAgICAgIHZhciBhY3Rpb24gPSBjYy5tb3ZlVG8oMC4xLCBub2RlLnggKyA4NCwgbm9kZS55KTtcbiAgICAgICAgICAgICAgICBub2RlLnJ1bkFjdGlvbihhY3Rpb24pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIG1vcGFpSW5zZXJ0SW5kZXg7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBNb3ZlIHRoZSBsYXRlc3QgcGFpIGluIHRvIGNvcnJlY3QgcG9zaXRpb24gXG4gICAgICovXG4gICAgbW92ZUxhc3Rlc3RQYWlUb1BvaW50OiBmdW5jdGlvbiBtb3ZlTGFzdGVzdFBhaVRvUG9pbnQoaW5kZXgpIHtcbiAgICAgICAgaW5kZXggPSBwYXJzZUludChpbmRleCk7XG4gICAgICAgIHZhciBsYXRlc3RQYWlQb2ludCA9IHRoaXMuZ2V0UG9pbnN0QnlJbmRleEZyb21TZWxmUGFpTGlzdCgxMyk7XG4gICAgICAgIHZhciBsYXRlc3RQYWlYID0gbGF0ZXN0UGFpUG9pbnQueDtcbiAgICAgICAgdmFyIGNodVBhaVBvaW50ID0gdGhpcy5nZXRQb2luc3RCeUluZGV4RnJvbVNlbGZQYWlMaXN0KGluZGV4KTtcbiAgICAgICAgdmFyIGNodVBhaVggPSBjaHVQYWlQb2ludC54O1xuICAgICAgICB2YXIgcGFpbm9kZSA9IHRoaXMuZ2V0UGFpTm9kZUJ5SW5kZXgoMTMpO1xuXG4gICAgICAgIHZhciBjb250cm9uYWxYID0gY2h1UGFpWCArIE1hdGguYWJzKGxhdGVzdFBhaVggLSBjaHVQYWlYKSAvIDI7XG4gICAgICAgIGNodVBhaVBvaW50LnkgPSAwO1xuXG4gICAgICAgIHZhciBiZXppZXIgPSBbbGF0ZXN0UGFpUG9pbnQsIGNjLnAoY29udHJvbmFsWCwgMzApLCBjaHVQYWlQb2ludF07XG4gICAgICAgIHZhciBiZXppZXJUbyA9IGNjLmJlemllclRvKDAuNiwgYmV6aWVyKTtcblxuICAgICAgICBwYWlub2RlLnJ1bkFjdGlvbihiZXppZXJUbyk7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgcGxheVNsZWZDaHVQYWlBY3Rpb25fYWRkQ2hpbGQ6IGZ1bmN0aW9uIHBsYXlTbGVmQ2h1UGFpQWN0aW9uX2FkZENoaWxkKHRhcmdldCwgcE5vZGVBcnJheSkge1xuICAgICAgICB2YXIgcE5vZGUgPSBwTm9kZUFycmF5WzBdO1xuICAgICAgICB2YXIgcGFpTm9kZSA9IHBOb2RlQXJyYXlbMV07XG4gICAgICAgIHZhciBwYXJlbnQgPSBwTm9kZUFycmF5WzJdO1xuICAgICAgICB2YXIgcGFpTGlzdCA9IHBOb2RlQXJyYXlbM107XG4gICAgICAgIHZhciB1c2VyT3BlbklkID0gcE5vZGVBcnJheVs0XTtcbiAgICAgICAgY2MubG9nKFwicGxheVNsZWZDaHVQYWlBY3Rpb25fYWRkQ2hpbGQ6XCIgKyBwYWlOb2RlLm5hbWUpO1xuICAgICAgICBjYy5sb2coXCJwbGF5U2xlZkNodVBhaUFjdGlvbl9hZGRDaGlsZCBwYXJlbnQ6XCIgKyBwYXJlbnQubmFtZSk7XG4gICAgICAgIGNjLmxvZyhcInBsYXlTbGVmQ2h1UGFpQWN0aW9uX2FkZENoaWxkIHBhcmVudCBjaGlsZCBjb3VudDE6XCIgKyBwYXJlbnQuY2hpbGRyZW5Db3VudCk7XG4gICAgICAgIHBOb2RlLmFjdGl2ZSA9IHRydWU7XG5cbiAgICAgICAgdmFyIHNwcml0ZUZyYW1lID0gcGFpTm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZTtcbiAgICAgICAgdmFyIGRlcHMgPSBjYy5sb2FkZXIuZ2V0RGVwZW5kc1JlY3Vyc2l2ZWx5KHNwcml0ZUZyYW1lKTtcbiAgICAgICAgY2MubG9hZGVyLnJlbGVhc2UoZGVwcyk7XG4gICAgICAgIHBhaU5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgICAgICBjYy5sb2coXCJwbGF5U2xlZkNodVBhaUFjdGlvbl9hZGRDaGlsZCBwYXJlbnQgY2hpbGQgY291bnQyOlwiICsgcGFyZW50LmNoaWxkcmVuQ291bnQpO1xuICAgICAgICB0aGlzLnJlbW92ZUFsbE5vZGVGcm9tU2VsZlBhaUxpc3QoKTtcbiAgICAgICAgY2MubG9nKFwicGFpTGlzdDpcIiArIHBhaUxpc3QpO1xuXG4gICAgICAgIHZhciB1c2VyID0gdGhpcy5nZXRDb3JyZWN0VXNlckJ5T3BlbklkKHVzZXJPcGVuSWQpO1xuICAgICAgICBjYy5sb2coXCIzNzQ6XCIgKyB1c2VyLnBhaUxpc3QpO1xuICAgICAgICB0YWJsZVVzZXJJbmZvU2NyaXB0LmludGFsU2VsZlBhaUxpc3QodXNlci5wYWlMaXN0KTtcblxuICAgICAgICB0aGlzLmRpc2FibGVBbGxTbGVmUGFpKCk7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIFxuICAgICAqL1xuXG4gICAgdXBkYXRlVXNlckxpc3RJbkdvYmFsOiBmdW5jdGlvbiB1cGRhdGVVc2VyTGlzdEluR29iYWwodXNlcikge1xuICAgICAgICB2YXIgdXNlckxpc3QgPSBHbG9iYWwudXNlckxpc3Q7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1c2VyTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKHVzZXJMaXN0W2ldLm9wZW5pZCA9PSB1c2VyLm9wZW5pZCkge1xuICAgICAgICAgICAgICAgIHVzZXJMaXN0W2ldID0gdXNlcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBHbG9iYWwudXNlckxpc3QgPSB1c2VyTGlzdDtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIFRoaXMgbWV0aG9kIHdpbGwgIGZpeCB0aGUgcGFpIGluIHRoZSBjaHVwYWkgbGlzdCBwb2ludFxuICAgICAqL1xuXG4gICAgZml4Q3VycmVudENodVBhaVBvaW50OiBmdW5jdGlvbiBmaXhDdXJyZW50Q2h1UGFpUG9pbnQodXNlcikge1xuICAgICAgICAvLyB2YXIgdXNlciA9IHRoaXMuZ2V0Q29ycmVjdFVzZXJCeVBvaW50KHVzZXJQb2ludCk7XG4gICAgICAgIHZhciB1c2VySW5kZXggPSB1c2VyLnBvaW50SW5kZXg7XG4gICAgICAgIGlmICh1c2VySW5kZXggPT0gXCIxXCIpIHtcblxuICAgICAgICAgICAgaWYgKHVzZXIuY2h1UGFpQ291bnQgPT0gcGFpTGlzdFJlT3JkZXJDb3VudCkge1xuICAgICAgICAgICAgICAgIHVzZXIuY2h1cGFpTGlzdFkgPSAtOTU7XG4gICAgICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WCA9IDIxMDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WCA9IHVzZXIuY2h1cGFpTGlzdFggLSA0MjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYy5sb2coXCJ0aGlzLnBhaUxpc3RSZU9yZGVyQ291bnQ6XCIgKyBwYWlMaXN0UmVPcmRlckNvdW50KTtcbiAgICAgICAgaWYgKHVzZXJJbmRleCA9PSBcIjJcIikge1xuICAgICAgICAgICAgaWYgKHVzZXIuY2h1UGFpQ291bnQgPT0gcGFpTGlzdFJlT3JkZXJDb3VudCkge1xuICAgICAgICAgICAgICAgIHVzZXIuY2h1cGFpTGlzdFkgPSAxMjA7XG4gICAgICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WCA9IDIyNjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WSA9IHVzZXIuY2h1cGFpTGlzdFkgLSAzNTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodXNlckluZGV4ID09IFwiM1wiKSB7XG5cbiAgICAgICAgICAgIGlmICh1c2VyLmNodVBhaUNvdW50ID09IHBhaUxpc3RSZU9yZGVyQ291bnQpIHtcbiAgICAgICAgICAgICAgICB1c2VyLmNodXBhaUxpc3RZID0gMztcbiAgICAgICAgICAgICAgICB1c2VyLmNodXBhaUxpc3RYID0gLTIxMDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WCA9IHVzZXIuY2h1cGFpTGlzdFggKyA0MjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodXNlckluZGV4ID09IFwiNFwiKSB7XG4gICAgICAgICAgICBpZiAodXNlci5jaHVQYWlDb3VudCA9PSBwYWlMaXN0UmVPcmRlckNvdW50KSB7XG4gICAgICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WCA9IC0yMjU7XG4gICAgICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WSA9IC0xMjA7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHVzZXIuY2h1cGFpTGlzdFkgPSB1c2VyLmNodXBhaUxpc3RZICsgMzU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB1c2VyLmNodVBhaUNvdW50ID0gdXNlci5jaHVQYWlDb3VudCArIDE7XG4gICAgICAgIC8vIGNjLmxvZyhcInVzZXIuY2h1cGFpTGlzdFggMjAwOlwiK3VzZXIuY2h1cGFpTGlzdFgpO1xuICAgICAgICByZXR1cm4gdXNlcjtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIFRoaXMgbWV0aG9kIHdpbGwgZ2V0IHRoZSBjb3JyZWN0IGltYWdlIHBhdGggZnJvbSBpbWFnZSBmb2xkZXIgb2YgcmVzb3VyZWNzXG4gICAgICovXG4gICAgZ2V0Q2h1UGFpTmFtZUJ5Tm9kZU5hbWU6IGZ1bmN0aW9uIGdldENodVBhaU5hbWVCeU5vZGVOYW1lKHBhaU5hbWUsIHVzZXJJbmRleCkge1xuICAgICAgICB2YXIgcmV0dXJuTmFtZSA9IFwiXCI7XG4gICAgICAgIHZhciBiYWNrUHJlZml4ID0gXCJcIjtcbiAgICAgICAgdmFyIGZvbGRlck5hbWUgPSBcInVzZXJcIiArIHVzZXJJbmRleDtcbiAgICAgICAgdmFyIHR5cGUgPSBwYWlOYW1lWzBdO1xuICAgICAgICB2YXIgbnVtYmVyID0gcGFpTmFtZVsxXTtcbiAgICAgICAgdmFyIGZpcnN0UHJlZml4ID0gXCJcIjtcbiAgICAgICAgdmFyIGJhY2tQcmVmaXgyID0gXCJcIjtcbiAgICAgICAgaWYgKHVzZXJJbmRleCA9PSBcIjFcIikge1xuICAgICAgICAgICAgYmFja1ByZWZpeCA9IFwiLXVcIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodXNlckluZGV4ID09IFwiMlwiKSB7XG4gICAgICAgICAgICBiYWNrUHJlZml4ID0gXCItbFwiO1xuICAgICAgICB9XG4gICAgICAgIGlmICh1c2VySW5kZXggPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIGJhY2tQcmVmaXggPSBcIi1kXCI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHVzZXJJbmRleCA9PSBcIjRcIikge1xuICAgICAgICAgICAgYmFja1ByZWZpeCA9IFwiLXJcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0eXBlID09IFwiMVwiKSB7XG4gICAgICAgICAgICBmaXJzdFByZWZpeCA9IFwidG9uZ1wiO1xuICAgICAgICAgICAgYmFja1ByZWZpeDIgPSBcImJcIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZSA9PSBcIjJcIikge1xuICAgICAgICAgICAgZmlyc3RQcmVmaXggPSBcInRpYW9cIjtcbiAgICAgICAgICAgIGJhY2tQcmVmaXgyID0gXCJ0XCI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGUgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgIGZpcnN0UHJlZml4ID0gXCJ3YW5cIjtcbiAgICAgICAgICAgIGJhY2tQcmVmaXgyID0gXCJ3XCI7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm5OYW1lID0gZm9sZGVyTmFtZSArIFwiL1wiICsgZmlyc3RQcmVmaXggKyBiYWNrUHJlZml4ICsgXCIvXCIgKyBudW1iZXIgKyBiYWNrUHJlZml4MjtcbiAgICAgICAgcmV0dXJuIHJldHVybk5hbWU7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS1nYW1lIGFjdGlvbiBlbmQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHNldFVzZXJQYWlMaXN0OiBmdW5jdGlvbiBzZXRVc2VyUGFpTGlzdChvcGVuaWQsIHBhaUxpc3QpIHtcbiAgICAgICAgdmFyIHVzZXJMaXN0ID0gR2xvYmFsLnVzZXJMaXN0O1xuICAgICAgICB2YXIgcGFpTGlzdFN0ciA9IHBhaUxpc3QudG9TdHJpbmcoKTtcbiAgICAgICAgcGFpTGlzdFN0ciA9IHBhaUxpc3RTdHIucmVwbGFjZShcIltcIiwgXCJcIik7XG4gICAgICAgIHBhaUxpc3RTdHIgPSBwYWlMaXN0U3RyLnJlcGxhY2UoXCJdXCIsIFwiXCIpO1xuICAgICAgICAvLyAgIHZhciB1c2VySW5mbyA9IEdsb2JhbC51c2VySW5mbztcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1c2VyTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKHVzZXJMaXN0W2ldLm9wZW5pZCA9PSBvcGVuaWQpIHtcbiAgICAgICAgICAgICAgICB1c2VyTGlzdFtpXS5wYWlMaXN0QXJyYXkgPSBwYWlMaXN0O1xuICAgICAgICAgICAgICAgIHVzZXJMaXN0W2ldLnBhaUxpc3QgPSBwYWlMaXN0U3RyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgR2xvYmFsLnVzZXJMaXN0ID0gdXNlckxpc3Q7XG4gICAgfSxcbiAgICBnZXRDb3JyZWN0VXNlckJ5T3BlbklkOiBmdW5jdGlvbiBnZXRDb3JyZWN0VXNlckJ5T3BlbklkKHVzZXJPcGVuSWQpIHtcblxuICAgICAgICB2YXIgdXNlckxpc3QgPSBHbG9iYWwudXNlckxpc3Q7XG4gICAgICAgIHZhciB1c2VyO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXJPcGVuSWQpIHtcbiAgICAgICAgICAgICAgICB1c2VyID0gdXNlckxpc3RbaV07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdXNlcjtcbiAgICB9LFxuICAgIGdldENvcnJlY3RVc2VyQnlQb2ludDogZnVuY3Rpb24gZ2V0Q29ycmVjdFVzZXJCeVBvaW50KHBvaW50SW5kZXgpIHtcblxuICAgICAgICB2YXIgdXNlckxpc3QgPSBHbG9iYWwudXNlckxpc3Q7XG4gICAgICAgIHZhciB1c2VyO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ucG9pbnRJbmRleCA9PSBwb2ludEluZGV4KSB7XG4gICAgICAgICAgICAgICAgdXNlciA9IHVzZXJMaXN0W2ldO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHVzZXI7XG4gICAgfSxcbiAgICBnZXRTZWxmUGFpTGlzdDogZnVuY3Rpb24gZ2V0U2VsZlBhaUxpc3QoKSB7XG5cbiAgICAgICAgdmFyIHVzZXJMaXN0ID0gR2xvYmFsLnVzZXJMaXN0O1xuICAgICAgICB2YXIgdXNlckluZm8gPSBHbG9iYWwudXNlckluZm87XG4gICAgICAgIHZhciBwYWlMaXN0O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXJJbmZvLm9wZW5pZCkge1xuICAgICAgICAgICAgICAgIHBhaUxpc3QgPSB1c2VyTGlzdFtpXS5wYWlMaXN0QXJyYXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcGFpTGlzdDtcbiAgICB9LFxuXG4gICAgZ2V0UXVlUGFpOiBmdW5jdGlvbiBnZXRRdWVQYWkoKSB7XG4gICAgICAgIHZhciBxdWVQYWk7XG4gICAgICAgIHZhciB1c2VyTGlzdCA9IEdsb2JhbC51c2VyTGlzdDtcbiAgICAgICAgdmFyIHVzZXJJbmZvID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXJJbmZvLm9wZW5pZCkge1xuICAgICAgICAgICAgICAgIHF1ZVBhaSA9IHVzZXJMaXN0W2ldLnF1ZVBhaTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBxdWVQYWk7XG4gICAgfSxcblxuICAgIGNodVBhaUFjdGlvbjogZnVuY3Rpb24gY2h1UGFpQWN0aW9uKGV2ZW50KSB7XG5cbiAgICAgICAgdmFyIGFjdGlvblR5cGUgPSBHbG9iYWwuY2h1UGFpQWN0aW9uVHlwZTtcbiAgICAgICAgdmFyIGdhbWVNb2RlID0gR2xvYmFsLmdhbWVNb2RlO1xuICAgICAgICB2YXIgaHVhblNhblpoYW5nUGFpTGlzdCA9IEdsb2JhbC5odWFuU2FuWmhhbmdQYWlMaXN0O1xuICAgICAgICB2YXIgbm9kZSA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgdmFyIG5hbWUgPSBub2RlLm5hbWU7XG4gICAgICAgIHZhciB0ZW1wID0gbmFtZS5zcGxpdChcIl9cIik7XG4gICAgICAgIHZhciBwYWlOdW1UeHQgPSB0ZW1wWzFdO1xuICAgICAgICB2YXIgY2h1UGFpSW5kZXggPSAtMTtcbiAgICAgICAgY2h1UGFpSW5kZXggPSB0ZW1wWzBdLnJlcGxhY2UoXCJwYWlcIik7XG5cbiAgICAgICAgLy9GaXggdGhlIGdhbWUgbW9kZSBhb2xsb3cgaHVhbnNhbnpoYW5nXG4gICAgICAgIGdhbWVNb2RlLmh1YW5TYW5aaGFuZyA9IFwiMVwiO1xuICAgICAgICAvLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXG4gICAgICAgIC8vIHZhciBpbmRleCA9IHBhcnNlSW50KG5hbWUuc3Vic3RyaW5nKDcpKTtcbiAgICAgICAgLy8gY2MubG9nKFwiaW5kZXg6XCIgKyBpbmRleCk7XG4gICAgICAgIC8vdmFyIHBhaUxpc3QgPSB0aGlzLmdldFNlbGZQYWlMaXN0KCk7XG4gICAgICAgIGNjLmxvZyhcIkdsb2JhbC5jaHVQYWlBY3Rpb25UeXBlOlwiICsgR2xvYmFsLmNodVBhaUFjdGlvblR5cGUpO1xuICAgICAgICB2YXIgcGFyZW50Tm9kZSA9IG5vZGUucGFyZW50O1xuICAgICAgICBpZiAobm9kZS55ID09IDApIHtcbiAgICAgICAgICAgIC8vbW92ZSBvdXRcbiAgICAgICAgICAgIHZhciBhY3Rpb24gPSBjYy5tb3ZlVG8oMC4xLCBub2RlLngsIG5vZGUueSArIDIwKTtcbiAgICAgICAgICAgIG5vZGUucnVuQWN0aW9uKGFjdGlvbik7XG4gICAgICAgICAgICBpZiAoR2xvYmFsLmNodVBhaUFjdGlvblR5cGUgPT0gXCJodWFuU2FuWmhhbmdcIikge1xuICAgICAgICAgICAgICAgIGlmIChnYW1lTW9kZS5odWFuU2FuWmhhbmcgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgLy9jYy5sb2coXCJwYXJlbnROb2RlOlwiICsgcGFyZW50Tm9kZS5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGh1YW5TYW5aaGFuZ1BhaUxpc3QubGVuZ3RoIDwgMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaHVhblNhblpoYW5nUGFpTGlzdC5wdXNoKHBhaU51bVR4dCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy9kaXNhYmxlIGFsbCBvdGhlciBwYWlcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXNhYmxlQWxsU2xlZlBhaUV4Y2VwdFNlbGVjdGVkKHBhcmVudE5vZGUsIG5vZGUsIGh1YW5TYW5aaGFuZ1BhaUxpc3QpO1xuICAgICAgICAgICAgICAgICAgICAvL31cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucHV0QmFja0FsbFBhaUV4Y2VwdENsaWNrUGFpKHBhcmVudE5vZGUsIG5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcblxuICAgICAgICAgICAgaWYgKEdsb2JhbC5jaHVQYWlBY3Rpb25UeXBlID09IFwiaHVhblNhblpoYW5nXCIpIHtcbiAgICAgICAgICAgICAgICAvL2h1YW4gc2FuemhhbmcgbW92ZSBiYWNrXG4gICAgICAgICAgICAgICAgaWYgKGdhbWVNb2RlLmh1YW5TYW5aaGFuZyA9PSBcIjFcIikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWN0aW9uID0gY2MubW92ZVRvKDAuMSwgbm9kZS54LCAwKTtcbiAgICAgICAgICAgICAgICAgICAgbm9kZS5ydW5BY3Rpb24oYWN0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGh1YW5TYW5aaGFuZ1BhaUxpc3QgPT0gbnVsbCB8fCBodWFuU2FuWmhhbmdQYWlMaXN0ID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbmFibGVkQWxsU2VsZlBhaShwYXJlbnROb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGh1YW5TYW5aaGFuZ1BhaUxpc3Quc3BsaWNlKGh1YW5TYW5aaGFuZ1BhaUxpc3QubGVuZ3RoIC0gMSwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaHVhblNhblpoYW5nUGFpTGlzdC5sZW5ndGggPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZW5hYmxlZEFsbFNlbGZQYWkocGFyZW50Tm9kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChodWFuU2FuWmhhbmdQYWlMaXN0Lmxlbmd0aCA8IDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbmFibGVkU2xlZlNlbGZQYWkocGFyZW50Tm9kZSwgaHVhblNhblpoYW5nUGFpTGlzdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvL25vcm1hbCBjaHVwYWlcbiAgICAgICAgICAgICAgICAvL2VuYWJsZSBhbGwgcGFpIGFmdGVyIHF1ZXBhaSBjbGVhblxuICAgICAgICAgICAgICAgIHRoaXMucGxheVNsZWZDaHVQYWlBY3Rpb24obm9kZSwgXCIzXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY2MubG9nKFwiaHVhblNhblpoYW5nUGFpTGlzdDpcIiArIGh1YW5TYW5aaGFuZ1BhaUxpc3QudG9TdHJpbmcoKSk7XG4gICAgfSxcblxuICAgIGdldFR5cGVCeU5hbWU6IGZ1bmN0aW9uIGdldFR5cGVCeU5hbWUoY2hpbGRyZWROYW1lKSB7XG4gICAgICAgIHZhciB0ZW1wID0gY2hpbGRyZWROYW1lLnNwbGl0KFwiX1wiKTtcbiAgICAgICAgdmFyIHNUeXBlID0gdGVtcFsxXTtcbiAgICAgICAgc1R5cGUgPSBzVHlwZS5zdWJzdHJpbmcoMCwgMSk7XG4gICAgICAgIHJldHVybiBzVHlwZTtcbiAgICB9LFxuXG4gICAgcHV0QmFja0FsbFBhaUV4Y2VwdENsaWNrUGFpOiBmdW5jdGlvbiBwdXRCYWNrQWxsUGFpRXhjZXB0Q2xpY2tQYWkocGFyZW50Tm9kZSwgY2xpY2tQYWlOYW1lKSB7XG4gICAgICAgIHZhciBjaGlsZHJlbiA9IHBhcmVudE5vZGUuY2hpbGRyZW47XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICBpZiAoY2hpbGRyZWROYW1lICE9IGNsaWNrUGFpTmFtZSkge1xuICAgICAgICAgICAgICAgIGlmIChjaGlsZHJlbltpXS55ID4gMCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWN0aW9uID0gY2MubW92ZVRvKDAuMSwgY2hpbGRyZW5baV0ueCwgMCk7XG4gICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuW2ldLnJ1bkFjdGlvbihhY3Rpb24pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgb25FbmFibGU6IGZ1bmN0aW9uIG9uRW5hYmxlKCkge1xuICAgICAgICBjYy5sb2coXCJ0aGlzIG5vZGUgOlwiICsgdGhpcy5ub2RlLm5hbWUgKyBcIiAgZW5hYmxlZFwiKTtcbiAgICB9LFxuICAgIG9uRGlzYWJsZTogZnVuY3Rpb24gb25EaXNhYmxlKCkge1xuICAgICAgICBjYy5sb2coXCJ0aGlzIG5vZGUgOlwiICsgdGhpcy5ub2RlLm5hbWUgKyBcIiAgZGlzYWJsZWRcIik7XG4gICAgfSxcbiAgICB0aHJvd0FjdGlvbkZvck5vZGU6IGZ1bmN0aW9uIHRocm93QWN0aW9uRm9yTm9kZSh0aGVOb2RlKSB7XG4gICAgICAgIGNjLmxvZyhcIiB0aHJvd0FjdGlvbkZvck5vZGU6XCIpO1xuICAgICAgICAvLyAgdmFyIHNvdXJjZVk7XG4gICAgICAgIC8vIHZhciBzb3VyY2VYO1xuICAgICAgICB0aGVOb2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbiAoZXZlbnQpIHtcblxuICAgICAgICAgICAgY2MubG9nKFwidG91Y2ggc3RhcnQ6XCIgKyB0aGVOb2RlLm5hbWUpO1xuICAgICAgICAgICAgdGhpcy5zb3VyY2VZID0gdGhpcy55O1xuICAgICAgICAgICAgdGhpcy5zb3VyY2VYID0gdGhpcy54O1xuICAgICAgICAgICAgY2MubG9nKFwiY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQ6XCIgKyB0aGlzLnNvdXJjZVkpO1xuICAgICAgICB9LCB0aGVOb2RlKTtcbiAgICAgICAgdGhlTm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgIGNjLmxvZyhcInRvdWNoIG1vdmUgOlwiICsgdGhpcy5uYW1lKTtcbiAgICAgICAgICAgIC8vdmFyIHRvdWNoZXMgPSBldmVudC4uZ2V0RGVsdGFYKCk7XG4gICAgICAgICAgICAvL3ZhciB0b3VjaGVzTG9jID0gdG91Y2hlc1swXS5nZXRMb2NhdGlvbigpO1xuICAgICAgICAgICAgLy8gIGNjLmxvZyhcIiB0b3VjaGVzTG9jOlwiICsgdG91Y2hlc0xvYy50b1N0cmluZygpKTtcblxuICAgICAgICAgICAgdmFyIHggPSBldmVudC5nZXREZWx0YVgoKTtcbiAgICAgICAgICAgIHZhciB5ID0gZXZlbnQuZ2V0RGVsdGFZKCk7XG4gICAgICAgICAgICB0aGlzLnggKz0geDtcbiAgICAgICAgICAgIHRoaXMueSArPSB5O1xuXG4gICAgICAgICAgICB2YXIgYnRuID0gdGhpcy5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgICAgIGlmIChidG4gIT0gbnVsbCAmJiBidG4gIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgYnRuLmludGVyYWN0YWJsZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGJ0bi5lbmFibGVBdXRvR3JheUVmZmVjdCA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyB0aGlzLnRoZU1vdmVOb2RlID0gdGhlTm9kZTtcbiAgICAgICAgICAgIC8vIGNjLmxvZyhcIiBub2RlTW92ZVg6XCIgKyBub2RlTW92ZVgpO1xuICAgICAgICAgICAgLy8gICBjYy5sb2coXCIgbm9kZU1vdmVZOlwiICsgbm9kZU1vdmVZKTtcbiAgICAgICAgICAgIC8vdmFyIHggPSB0b3VjaGVzWzBdLmdldExvY2F0aW9uWCgpO1xuICAgICAgICB9LCB0aGVOb2RlKTtcbiAgICAgICAgdGhlTm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgICAgY2MubG9nKFwiY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5EOlwiICsgdGhlTm9kZS5zb3VyY2VZKTtcbiAgICAgICAgICAgIHZhciBlbmRZID0gTWF0aC5mbG9vcihNYXRoLmFicyh0aGVOb2RlLnkgLSB0aGVOb2RlLnNvdXJjZVkpKTtcbiAgICAgICAgICAgIGNjLmxvZyhcImVuZFk6XCIgKyBlbmRZKTtcblxuICAgICAgICAgICAgaWYgKGVuZFkgPiAxMDApIHtcbiAgICAgICAgICAgICAgICB2YXIgbmFtZSA9IHRoZU5vZGUubmFtZTtcbiAgICAgICAgICAgICAgICBpZiAobmFtZS5pbmRleE9mKFwiX1wiKSA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHRlbXBBcnJheSA9IG5hbWUuc3BsaXQoXCJfXCIpO1xuICAgICAgICAgICAgICAgICAgICBuYW1lID0gdGVtcEFycmF5WzFdO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgdmFyIHBhcnRlbk5hbWUgPSB0aGVOb2RlLnBhcmVudC5uYW1lO1xuICAgICAgICAgICAgICAgIHBhcnRlbk5hbWUgPSBwYXJ0ZW5OYW1lLnJlcGxhY2UoXCJQYWlMaXN0XCIsIFwiXCIpO1xuICAgICAgICAgICAgICAgIHZhciB1c2VyUG9pbnQgPSBwYXJ0ZW5OYW1lLnJlcGxhY2UoXCJ1c2VyXCIsIFwiXCIpO1xuICAgICAgICAgICAgICAgIHZhciB0YWJsZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL3RhYmxlTm9kZVwiKTtcbiAgICAgICAgICAgICAgICB2YXIgdXNlckNodVBhaUxpc3ROb2RlID0gY2MuZmluZChwYXJ0ZW5OYW1lICsgXCJDaHVhUGFpTGlzdE5vZGVcIiwgdGFibGVOb2RlKTtcbiAgICAgICAgICAgICAgICBjYy5sb2coXCJ1c2VyQ2h1UGFpTGlzdE5vZGU6XCIgKyB1c2VyQ2h1UGFpTGlzdE5vZGUubmFtZSk7XG5cbiAgICAgICAgICAgICAgICB2YXIgdXNlciA9IHRoaXMuYWRkUGFpSW50b1BhaUxpc3ROb2RlKHVzZXJDaHVQYWlMaXN0Tm9kZSwgbmFtZSwgdXNlclBvaW50LCB0aGVOb2RlKTtcblxuICAgICAgICAgICAgICAgIHVzZXIgPSB0aGlzLmZpeEN1cnJlbnRDaHVQYWlQb2ludCh1c2VyKTtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVVzZXJMaXN0SW5Hb2JhbCh1c2VyKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdmFyIGJ0biA9IHRoZU5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgICAgICAgICAgYnRuLmludGVyYWN0YWJsZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhlTm9kZS54ID0gdGhlTm9kZS5zb3VyY2VYO1xuICAgICAgICAgICAgICAgIHRoZU5vZGUueSA9IHRoZU5vZGUuc291cmNlWTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy92YXIgeCA9IHRvdWNoZXNbMF0uZ2V0TG9jYXRpb25YKCk7XG4gICAgICAgIH0sIHRoaXMpO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogdGhpcy5ub2RlLm9uKCd0b3VjaHN0YXJ0JywgZnVuY3Rpb24oZXZlbnQpIHtcbiAgICB2YXIgdG91Y2hlcyA9IGV2ZW50LmdldFRvdWNoZXMoKTtcbiAgICB2YXIgeCA9IHRvdWNoZXNbMF0uZ2V0TG9jYXRpb25YKCk7XG4gICAgfSwgdGhpcyk7XG4gICAgICovXG4gICAgZGlzYWJsZUFsbFNsZWZQYWk6IGZ1bmN0aW9uIGRpc2FibGVBbGxTbGVmUGFpKCkge1xuICAgICAgICB2YXIgdGFibGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy90YWJsZU5vZGVcIik7XG4gICAgICAgIHZhciBwYXJlbnROb2RlID0gY2MuZmluZChcInVzZXIzUGFpTGlzdFwiLCB0YWJsZU5vZGUpO1xuICAgICAgICB2YXIgY2hpbGRyZW4gPSBwYXJlbnROb2RlLmNoaWxkcmVuO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICB2YXIgY2hpbGRyZWROYW1lID0gY2hpbGRyZW5baV0ubmFtZTtcbiAgICAgICAgICAgIGNjLmxvZyhcInRocm93QWN0aW9uRm9yTm9kZSBjaGlsZHJlZE5hbWU6XCIgKyBjaGlsZHJlZE5hbWUpO1xuICAgICAgICAgICAgdmFyIGJ0biA9IGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgICAgICAgICAgaWYgKGJ0biAhPSBudWxsICYmIGJ0biAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBidG4uZW5hYmxlQXV0b0dyYXlFZmZlY3QgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBidG4uaW50ZXJhY3RhYmxlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgYnRuLmRpc2FibGVkQ29sb3IgPSBuZXcgY2MuQ29sb3IoMjU1LCAyNTUsIDI1NSk7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwiZGlzYWJsZUFsbFNsZWZQYWk6XCIgKyBidG4uZW5hYmxlQXV0b0dyYXlFZmZlY3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICAvL3RvdWNobW92ZSwndG91Y2hzdGFydCcsdG91Y2hlbmRcbiAgICAvLyB3aGVuIHRoZSBtbyBwYWkgYWN0aW9uIGV4ZWN1dGUsaXQgd2lsbCBkaXNhYmxlZCBhbGwgb3RoZXIgcGFpIHR5cGUgLGlmIHRoZSBxdWUgcGFpIHR5cGUgaW4gdGhlIHBhaSBsaXN0XG4gICAgZGlzYWJsZUFsbFNsZWZQYWlBZnRlclF1ZVBhaTogZnVuY3Rpb24gZGlzYWJsZUFsbFNsZWZQYWlBZnRlclF1ZVBhaSgpIHtcbiAgICAgICAgY2MubG9nKFwidGhyb3dBY3Rpb25Gb3JOb2RlIGRpc2FibGVBbGxTbGVmUGFpQWZ0ZXJRdWVQYWk6XCIpO1xuICAgICAgICB2YXIgdGFibGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy90YWJsZU5vZGVcIik7XG4gICAgICAgIHZhciBwYXJlbnROb2RlID0gY2MuZmluZChcInVzZXIzUGFpTGlzdFwiLCB0YWJsZU5vZGUpO1xuXG4gICAgICAgIHZhciBleGlzdEZsYWcgPSB0aGlzLmNoZWNrUXVlUGFpSW5TZWxmKCk7XG4gICAgICAgIC8vaWYgKGV4aXN0RmxhZykge1xuICAgICAgICB2YXIgY2hpbGRyZW4gPSBwYXJlbnROb2RlLmNoaWxkcmVuO1xuICAgICAgICBjYy5sb2coXCJ0aHJvd0FjdGlvbkZvck5vZGUgY2hpbGRyZW4gbGVuZ3RoOlwiICsgY2hpbGRyZW4ubGVuZ3RoKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICBjYy5sb2coXCJ0aHJvd0FjdGlvbkZvck5vZGUgY2hpbGRyZWROYW1lOlwiICsgY2hpbGRyZWROYW1lKTtcbiAgICAgICAgICAgIHZhciBidG4gPSBjaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgICAgIHZhciBzVHlwZSA9IHRoaXMuZ2V0VHlwZUJ5TmFtZShjaGlsZHJlZE5hbWUpO1xuICAgICAgICAgICAgLy9pZiAoc1R5cGUgPT0gcXVlKSB7XG5cbiAgICAgICAgICAgIGJ0bi5pbnRlcmFjdGFibGUgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLnRocm93QWN0aW9uRm9yTm9kZShjaGlsZHJlbltpXSk7XG4gICAgICAgICAgICAvL30gZWxzZSB7XG4gICAgICAgICAgICAvLyAgIGJ0bi5pbnRlcmFjdGFibGUgPSBmYWxzZTtcbiAgICAgICAgICAgIC8vICB9XG4gICAgICAgIH1cbiAgICAgICAgLy99XG4gICAgfSxcbiAgICAvLyBhZnRlciBhbGwgcXVlIHBhaSBjbGVhbiAsdGhlIGFsbCBvdGhlciBwYWkgc2hvdWxkIGJlIGVuYWJsZVxuICAgIGVuYWJsZWRBbGxQYWlBZnRlclF1ZVBhaTogZnVuY3Rpb24gZW5hYmxlZEFsbFBhaUFmdGVyUXVlUGFpKHBhcmVudE5vZGUpIHtcbiAgICAgICAgdmFyIGV4aXN0RmxhZyA9IHRoaXMuY2hlY2tRdWVQYWlJblNlbGYoKTtcblxuICAgICAgICBpZiAoZXhpc3RGbGFnID09IGZhbHNlKSB7XG4gICAgICAgICAgICB0aGlzLmVuYWJsZWRBbGxQYWkocGFyZW50Tm9kZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvL2Rpc2FibGUgb3RoZXIgcGFpICxvbmx5IGVuYWJsZSB0aGUgcXVlIHBhaVxuXG4gICAgICAgIH1cbiAgICB9LFxuICAgIGVuYWJsZWRBbGxQYWk6IGZ1bmN0aW9uIGVuYWJsZWRBbGxQYWkocGFyZW50Tm9kZSwgYXV0b0dyYXkpIHtcbiAgICAgICAgdmFyIGNoaWxkcmVuID0gcGFyZW50Tm9kZS5jaGlsZHJlbjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGJ0biA9IGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgICAgICAgICAgaWYgKGF1dG9HcmF5ICE9IG51bGwgJiYgYXV0b0dyYXkgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgYnRuLmVuYWJsZUF1dG9HcmF5RWZmZWN0ID0gYXV0b0dyYXk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGJ0bi5pbnRlcmFjdGFibGUgPSB0cnVlO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBlbmFibGVkU2xlZlNlbGZQYWk6IGZ1bmN0aW9uIGVuYWJsZWRTbGVmU2VsZlBhaShwYXJlbnROb2RlLCBodWFuU2FuWmhhbmdQYWlMaXN0KSB7XG4gICAgICAgIHZhciBmaXJzdEVsZW1lbnQxID0gKGh1YW5TYW5aaGFuZ1BhaUxpc3RbMF0gKyBcIlwiKS50cmltKCk7XG4gICAgICAgIC8vY2MubG9nKFwiZmlyc3RFbGVtZW50OlwiICsgZmlyc3RFbGVtZW50MSk7XG4gICAgICAgIHZhciB0eXBlID0gZmlyc3RFbGVtZW50MVswXTtcbiAgICAgICAgdmFyIGNoaWxkcmVuID0gcGFyZW50Tm9kZS5jaGlsZHJlbjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICB2YXIgc1R5cGUgPSB0aGlzLmdldFR5cGVCeU5hbWUoY2hpbGRyZWROYW1lKTtcbiAgICAgICAgICAgIGlmIChzVHlwZSA9PSB0eXBlKSB7XG4gICAgICAgICAgICAgICAgdmFyIGJ0biA9IGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgICAgICAgICAgICAgIGJ0bi5pbnRlcmFjdGFibGUgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBlbmFibGVkQWxsU2VsZlBhaTogZnVuY3Rpb24gZW5hYmxlZEFsbFNlbGZQYWkocGFyZW50Tm9kZSkge1xuICAgICAgICAvLyAgY2MubG9nKFwiZW5hYmxlZEFsbFNlbGZQYWlcIik7XG4gICAgICAgIHZhciB2ID0gdGhpcy5nZXRMZXNzM051bWJlclR5cGUocGFyZW50Tm9kZSk7XG4gICAgICAgIHZhciB2c3RyID0gdi50b1N0cmluZygpO1xuICAgICAgICAvL2NjLmxvZyhcInZzdHI6XCIgKyB2c3RyKTtcbiAgICAgICAgdmFyIGNoaWxkcmVuID0gcGFyZW50Tm9kZS5jaGlsZHJlbjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICB2YXIgc1R5cGUgPSB0aGlzLmdldFR5cGVCeU5hbWUoY2hpbGRyZWROYW1lKTtcbiAgICAgICAgICAgIGlmICh2c3RyLmluZGV4T2Yoc1R5cGUpID49IDApIHt9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHZhciBidG4gPSBjaGlsZHJlbltpXS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgICAgICAgICBidG4uaW50ZXJhY3RhYmxlID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgZ2V0TGVzczNOdW1iZXJUeXBlOiBmdW5jdGlvbiBnZXRMZXNzM051bWJlclR5cGUocGFyZW50Tm9kZSkge1xuICAgICAgICB2YXIgdjEgPSAwO1xuICAgICAgICB2YXIgdjIgPSAwO1xuICAgICAgICB2YXIgdjMgPSAwO1xuICAgICAgICB2YXIgY2hpbGRyZW4gPSBwYXJlbnROb2RlLmNoaWxkcmVuO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICB2YXIgY2hpbGRyZWROYW1lID0gY2hpbGRyZW5baV0ubmFtZTtcbiAgICAgICAgICAgIHZhciBzVHlwZSA9IHRoaXMuZ2V0VHlwZUJ5TmFtZShjaGlsZHJlZE5hbWUpO1xuICAgICAgICAgICAgaWYgKHNUeXBlID09IFwiMVwiKSB7XG4gICAgICAgICAgICAgICAgdjErKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChzVHlwZSA9PSBcIjJcIikge1xuICAgICAgICAgICAgICAgIHYyKys7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc1R5cGUgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgICAgICB2MysrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHYgPSBbXTtcbiAgICAgICAgaWYgKHYxIDwgMykge1xuICAgICAgICAgICAgdi5wdXNoKFwiMVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodjIgPCAzKSB7XG4gICAgICAgICAgICB2LnB1c2goXCIyXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2MyA8IDMpIHtcbiAgICAgICAgICAgIHYucHVzaChcIjNcIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHY7XG4gICAgfSxcbiAgICBkaXNhYmxlQWxsU2xlZlBhaUV4Y2VwdFNlbGVjdGVkOiBmdW5jdGlvbiBkaXNhYmxlQWxsU2xlZlBhaUV4Y2VwdFNlbGVjdGVkKHBhcmVudE5vZGUsIG5vZGUsIGh1YW5TYW5aaGFuZ1BhaUxpc3QpIHtcbiAgICAgICAgLy9jYy5sb2coXCJkaXNhYmxlQWxsU2xlZlBhaUV4Y2VwdFNlbGVjdGVkXCIpO1xuICAgICAgICB2YXIgY2hpbGRyZW4gPSBwYXJlbnROb2RlLmNoaWxkcmVuO1xuICAgICAgICB2YXIgZmlyc3RFbGVtZW50MSA9IChodWFuU2FuWmhhbmdQYWlMaXN0WzBdICsgXCJcIikudHJpbSgpO1xuICAgICAgICAvL2NjLmxvZyhcImZpcnN0RWxlbWVudDpcIiArIGZpcnN0RWxlbWVudDEpO1xuICAgICAgICB2YXIgdHlwZSA9IGZpcnN0RWxlbWVudDFbMF07XG4gICAgICAgIC8vIGNjLmxvZyhcImZpcnN0RWxlbWVudDogXCIgKyBcIi0tLVwiICsgdHlwZSk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIGlmIChjaGlsZHJlbltpXS55ID09IDApIHtcbiAgICAgICAgICAgICAgICBpZiAobm9kZS5uYW1lICE9IGNoaWxkcmVuW2ldLm5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzVHlwZSA9IHRoaXMuZ2V0VHlwZUJ5TmFtZShjaGlsZHJlZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAvLyAgY2MubG9nKFwic1R5cGU6XCIgKyBzVHlwZSArIFwiLS0tLS1cIiArIHR5cGUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc1R5cGUgIT0gdHlwZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGJ0biA9IGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnRuLmludGVyYWN0YWJsZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGh1YW5TYW5aaGFuZ1BhaUxpc3QubGVuZ3RoID09IDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobm9kZS55ID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGJ0biA9IGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidG4uaW50ZXJhY3RhYmxlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLXV0aWxzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGluc2VydFBhaUludG9QYWlMaXN0QnlQYWlBbmRPcGVuSWQ6IGZ1bmN0aW9uIGluc2VydFBhaUludG9QYWlMaXN0QnlQYWlBbmRPcGVuSWQocGFpTnVtYmVyLCB1c2VyT3BlbklkKSB7XG4gICAgICAgIHZhciBjdXJyZW50VXNlciA9IHRoaXMuZ2V0Q29ycmVjdFVzZXJCeU9wZW5JZCh1c2VyT3BlbklkKTtcbiAgICAgICAgdmFyIHBhaUxpc3QgPSBjdXJyZW50VXNlci5wYWlMaXN0QXJyYXk7XG4gICAgICAgIGlmIChwYWlOdW1iZXIgIT0gbnVsbCAmJiBwYWlOdW1iZXIgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBwYWlOdW1iZXIgPSBwYXJzZUludChwYWlOdW1iZXIudHJpbSgpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGFpTGlzdC5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICB2YXIgdGVtcCA9IFtdO1xuICAgICAgICAgICAgdmFyIGluc2VydEZsYWcgPSBmYWxzZTtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFpTGlzdC5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgICAgIHZhciBwID0gcGFpTGlzdFtpXSArIFwiXCI7XG4gICAgICAgICAgICAgICAgdmFyIHBhaSA9IHBhcnNlSW50KHAudHJpbSgpKTtcbiAgICAgICAgICAgICAgICBjYy5sb2coXCJsb29wIHBhaTpcIiArIHBhaSk7XG4gICAgICAgICAgICAgICAgaWYgKHBhaU51bWJlciA8IHBhaSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaW5zZXJ0RmxhZyA9PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiaW5zZXJ0RmxhZyBwYWk6XCIgKyBwYWlOdW1iZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcC5wdXNoKHBhaU51bWJlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbnNlcnRGbGFnID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0ZW1wLnB1c2gocGFpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHVzZXIucGFpTGlzdEFycmF5ID0gdGVtcDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHBhaUxpc3QucHVzaChwYWlOdW1iZXIpO1xuICAgICAgICAgICAgdXNlci5wYWlMaXN0QXJyYXkgPSBwYWlMaXN0O1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHVzZXIucGFpTGlzdEFycmF5O1xuICAgIH0sXG4gICAgaW5zZXJ0TW9QYWlJbnRvUGFpTGlzdDogZnVuY3Rpb24gaW5zZXJ0TW9QYWlJbnRvUGFpTGlzdCh1c2VyKSB7XG4gICAgICAgIHZhciBtb1BhaSA9IHVzZXIudXNlck1vUGFpO1xuICAgICAgICBpZiAobW9QYWkgIT0gbnVsbCAmJiBtb1BhaSAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIG1vUGFpID0gcGFyc2VJbnQobW9QYWkudHJpbSgpKTtcbiAgICAgICAgICAgIGNjLmxvZyhcIm1vUGFpOlwiICsgbW9QYWkpO1xuICAgICAgICAgICAgdmFyIHBhaUxpc3QgPSB1c2VyLnBhaUxpc3RBcnJheTtcbiAgICAgICAgICAgIGlmIChwYWlMaXN0Lmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgICAgICB2YXIgdGVtcCA9IFtdO1xuICAgICAgICAgICAgICAgIHZhciBpbnNlcnRGbGFnID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0Lmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwID0gcGFpTGlzdFtpXSArIFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwYWkgPSBwYXJzZUludChwLnRyaW0oKSk7XG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcImxvb3AgcGFpOlwiICsgcGFpKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1vUGFpIDwgcGFpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW5zZXJ0RmxhZyA9PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcImluc2VydEZsYWcgcGFpOlwiICsgbW9QYWkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXAucHVzaChtb1BhaSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5zZXJ0RmxhZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGVtcC5wdXNoKHBhaSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHVzZXIucGFpTGlzdEFycmF5ID0gdGVtcDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcGFpTGlzdC5wdXNoKG1vUGFpKTtcbiAgICAgICAgICAgICAgICB1c2VyLnBhaUxpc3RBcnJheSA9IHBhaUxpc3Q7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2MubG9nKFwidXNlciBvcGVuOlwiICsgdXNlci5vcGVuaWQpO1xuICAgICAgICBjYy5sb2coXCJpbnNlcnRNb1BhaUludG9QYWlMaXN0IHVzZXIucGFpTGlzdEFycmF5OlwiICsgdXNlci5wYWlMaXN0QXJyYXkudG9TdHJpbmcoKSk7XG4gICAgICAgIHJldHVybiB1c2VyO1xuICAgIH0sXG4gICAgaW5zZXJ0SHVQYWlJbnRvUGFpTGlzdDogZnVuY3Rpb24gaW5zZXJ0SHVQYWlJbnRvUGFpTGlzdCh1c2VyKSB7XG4gICAgICAgIHZhciBtb1BhaSA9IHVzZXIudXNlck1vUGFpO1xuICAgICAgICBpZiAobW9QYWkgIT0gbnVsbCAmJiBtb1BhaSAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIG1vUGFpID0gcGFyc2VJbnQobW9QYWkudHJpbSgpKTtcbiAgICAgICAgICAgIGNjLmxvZyhcIm1vUGFpOlwiICsgbW9QYWkpO1xuICAgICAgICAgICAgdmFyIHBhaUxpc3QgPSB1c2VyLnBhaUxpc3RBcnJheTtcbiAgICAgICAgICAgIGlmIChwYWlMaXN0Lmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgICAgICB2YXIgdGVtcCA9IFtdO1xuICAgICAgICAgICAgICAgIHZhciBpbnNlcnRGbGFnID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0Lmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwID0gcGFpTGlzdFtpXSArIFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwYWkgPSBwYXJzZUludChwLnRyaW0oKSk7XG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcImxvb3AgcGFpOlwiICsgcGFpKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1vUGFpIDwgcGFpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW5zZXJ0RmxhZyA9PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcImluc2VydEZsYWcgcGFpOlwiICsgbW9QYWkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXAucHVzaChtb1BhaSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5zZXJ0RmxhZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGVtcC5wdXNoKHBhaSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHVzZXIucGFpTGlzdEFycmF5ID0gdGVtcDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcGFpTGlzdC5wdXNoKG1vUGFpKTtcbiAgICAgICAgICAgICAgICB1c2VyLnBhaUxpc3RBcnJheSA9IHBhaUxpc3Q7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2MubG9nKFwidXNlciBvcGVuOlwiICsgdXNlci5vcGVuaWQpO1xuICAgICAgICBjYy5sb2coXCJpbnNlcnRNb1BhaUludG9QYWlMaXN0IHVzZXIucGFpTGlzdEFycmF5OlwiICsgdXNlci5wYWlMaXN0QXJyYXkudG9TdHJpbmcoKSk7XG4gICAgICAgIHJldHVybiB1c2VyO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogU3luY2hyb25pemF0aW9uIHRoZSBwYWkgbGlzdCBhcnJheSBpbnRvIHVzZXIgcGFpIHN0cmluZyBcbiAgICAgKi9cblxuICAgIHN5bmNocm9uaXphdGlvblBhaUxpc3Q6IGZ1bmN0aW9uIHN5bmNocm9uaXphdGlvblBhaUxpc3QodXNlcikge1xuXG4gICAgICAgIHZhciBwYWlMaXN0ID0gdXNlci5wYWlMaXN0QXJyYXk7XG4gICAgICAgIHZhciB0ZW1wID0gXCJcIjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0Lmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICB0ZW1wID0gdGVtcCArIHBhaUxpc3RbaV0gKyBcIixcIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGVtcC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB0ZW1wID0gdGVtcC5zdWJzdHJpbmcoMCwgdGVtcC5sZW5ndGggLSAxKTtcbiAgICAgICAgfVxuICAgICAgICB1c2VyLnBhaUxpc3QgPSB0ZW1wO1xuICAgICAgICByZXR1cm4gdXNlcjtcbiAgICB9LFxuICAgIHJlbW92ZUVsZW1lbnRCeU51bWJlckJ5UGFpTGlzdEZyb21Vc2VyOiBmdW5jdGlvbiByZW1vdmVFbGVtZW50QnlOdW1iZXJCeVBhaUxpc3RGcm9tVXNlcihwYWlMaXN0LCBwYWlOdW1iZXIsIGIpIHtcbiAgICAgICAgdmFyIGMgPSAwO1xuICAgICAgICAvLyBjYy5sb2coXCIxMDQzOlwiICsgcGFpTGlzdC50b1N0cmluZygpKTtcbiAgICAgICAgd2hpbGUgKHRoaXMuY29udGFpbnMocGFpTGlzdCwgcGFpTnVtYmVyKSAmJiBjICE9IGIpIHtcbiAgICAgICAgICAgIC8vIGNjLmxvZyhcIjEwNDQ6IGNcIiArYytcIi0tLWI6XCIrYik7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhaUxpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgdGVtcCA9IHBhaUxpc3RbaV0gKyBcIlwiO1xuICAgICAgICAgICAgICAgIHRlbXAgPSB0ZW1wLnRyaW0oKTtcbiAgICAgICAgICAgICAgICBpZiAodGVtcCA9PSBwYWlOdW1iZXIgKyBcIlwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHBhaUxpc3Quc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgICAgICBjKys7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vY2MubG9nKFwiMTA1NjpcIiArIHBhaUxpc3QudG9TdHJpbmcoKSk7XG4gICAgICAgIHJldHVybiBwYWlMaXN0O1xuICAgIH0sXG4gICAgY29udGFpbnM6IGZ1bmN0aW9uIGNvbnRhaW5zKGFycmF5LCBvYmopIHtcbiAgICAgICAgdmFyIGkgPSBhcnJheS5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChpLS0pIHtcbiAgICAgICAgICAgIGlmIChhcnJheVtpXSA9PT0gb2JqKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogcmVtb3ZlIGEgZWxlbWVudCBmcm9tIHBhaUxpc3Qgb2YgdXNlciBzZWxmXG4gICAgICogYi0tLXJlbW92ZSBlbGVtZW50IG51bWJlci5cbiAgICAgKi9cbiAgICByZW1vdmVFbGVtZW50QnlOdW1iZXJGcm9tVXNlcjogZnVuY3Rpb24gcmVtb3ZlRWxlbWVudEJ5TnVtYmVyRnJvbVVzZXIobm9kZSwgYikge1xuICAgICAgICB2YXIgbnVtYmVyID0gbm9kZS5uYW1lO1xuICAgICAgICB2YXIgYyA9IDA7XG4gICAgICAgIHZhciB0ZW1wID0gbnVtYmVyLnNwbGl0KFwiX1wiKTtcbiAgICAgICAgbnVtYmVyID0gdGVtcFsxXTtcbiAgICAgICAgdmFyIHBhaUxpc3QgPSB0aGlzLmdldFNlbGZQYWlMaXN0KCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFpTGlzdC5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIHRlbXAgPSBwYWlMaXN0W2ldICsgXCJcIjtcbiAgICAgICAgICAgIHRlbXAgPSB0ZW1wLnRyaW0oKTtcbiAgICAgICAgICAgIGlmICh0ZW1wID09IG51bWJlcikge1xuICAgICAgICAgICAgICAgIHBhaUxpc3Quc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgIGMrKztcbiAgICAgICAgICAgICAgICBpZiAoYyA9PSBiKSB7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBwYWlMaXN0O1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogR2V0IHNlbGYgcGFpIG5vZGUgYnkgaW5kZXhcbiAgICAgKi9cbiAgICBnZXRQYWlOb2RlQnlJbmRleDogZnVuY3Rpb24gZ2V0UGFpTm9kZUJ5SW5kZXgoaW5kZXgpIHtcbiAgICAgICAgdmFyIHRhYmxlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvdGFibGVOb2RlXCIpO1xuICAgICAgICB2YXIgcGFyZW50Tm9kZSA9IGNjLmZpbmQoXCJ1c2VyM1BhaUxpc3RcIiwgdGFibGVOb2RlKTtcbiAgICAgICAgdmFyIGNoaWxkcmVuID0gcGFyZW50Tm9kZS5jaGlsZHJlbjtcbiAgICAgICAgaWYgKGluZGV4ID49IGNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgICAgICAgaW5kZXggPSBjaGlsZHJlbi5sZW5ndGggLSAxO1xuICAgICAgICB9XG4gICAgICAgIGNjLmxvZyhcImdldFBhaU5vZGVCeUluZGV4OlwiICsgaW5kZXgpO1xuICAgICAgICB2YXIgY2hpbGRyZWROb2RlID0gY2hpbGRyZW5baW5kZXhdO1xuICAgICAgICByZXR1cm4gY2hpbGRyZWROb2RlO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBwb2ludCBmcm9tIHNlbGYgcGFpIGxpc3QgYnkgaW5kZXggXG4gICAgICpcbiAgICAgKi9cblxuICAgIGdldFBvaW5zdEJ5SW5kZXhGcm9tU2VsZlBhaUxpc3Q6IGZ1bmN0aW9uIGdldFBvaW5zdEJ5SW5kZXhGcm9tU2VsZlBhaUxpc3QoaW5kZXgpIHtcbiAgICAgICAgY2MubG9nKFwiZ2V0UG9pbnN0QnlJbmRleEZyb21TZWxmUGFpTGlzdDE6XCIgKyBpbmRleCk7XG4gICAgICAgIHZhciB0YWJsZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL3RhYmxlTm9kZVwiKTtcbiAgICAgICAgdmFyIHBhcmVudE5vZGUgPSBjYy5maW5kKFwidXNlcjNQYWlMaXN0XCIsIHRhYmxlTm9kZSk7XG4gICAgICAgIHZhciBjaGlsZHJlbiA9IHBhcmVudE5vZGUuY2hpbGRyZW47XG4gICAgICAgIGNjLmxvZyhcImNoaWxkcmVuLmxlbmd0aDpcIiArIGNoaWxkcmVuLmxlbmd0aCk7XG4gICAgICAgIGlmIChpbmRleCA+PSBjaGlsZHJlbi5sZW5ndGgpIHtcbiAgICAgICAgICAgIGluZGV4ID0gY2hpbGRyZW4ubGVuZ3RoIC0gMTtcbiAgICAgICAgfVxuICAgICAgICBjYy5sb2coXCJnZXRQb2luc3RCeUluZGV4RnJvbVNlbGZQYWlMaXN0MjpcIiArIGluZGV4KTtcbiAgICAgICAgdmFyIGNoaWxkcmVkTm9kZSA9IGNoaWxkcmVuW2luZGV4XTtcblxuICAgICAgICB2YXIgcG9pbnQgPSBjYy5wKGNoaWxkcmVkTm9kZS54LCBjaGlsZHJlZE5vZGUueSk7XG4gICAgICAgIHJldHVybiBwb2ludDtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIENoZWNrIGl0IHF1ZSBwYWkgaW4gdGhlIHNlbGYgcGFpIGxpc3RcbiAgICAgKi9cblxuICAgIGNoZWNrUXVlUGFpSW5TZWxmOiBmdW5jdGlvbiBjaGVja1F1ZVBhaUluU2VsZigpIHtcbiAgICAgICAgdmFyIHRhYmxlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvdGFibGVOb2RlXCIpO1xuICAgICAgICB2YXIgcGFyZW50Tm9kZSA9IGNjLmZpbmQoXCJ1c2VyM0NodWFQYWlMaXN0Tm9kZVwiLCB0YWJsZU5vZGUpO1xuICAgICAgICB2YXIgcXVlID0gdGhpcy5nZXRRdWVQYWkoKTtcbiAgICAgICAgdmFyIGNoaWxkcmVuID0gcGFyZW50Tm9kZS5jaGlsZHJlbjtcbiAgICAgICAgdmFyIGV4aXN0RmxhZyA9IGZhbHNlO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICB2YXIgY2hpbGRyZWROYW1lID0gY2hpbGRyZW5baV0ubmFtZTtcbiAgICAgICAgICAgIHZhciBzVHlwZSA9IHRoaXMuZ2V0VHlwZUJ5TmFtZShjaGlsZHJlZE5hbWUpO1xuICAgICAgICAgICAgaWYgKHNUeXBlID09IHF1ZSkge1xuICAgICAgICAgICAgICAgIGV4aXN0RmxhZyA9PSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGV4aXN0RmxhZztcbiAgICB9LFxuICAgIHJlbW92ZUFsbE5vZGVGcm9tU2VsZlBhaUxpc3Q6IGZ1bmN0aW9uIHJlbW92ZUFsbE5vZGVGcm9tU2VsZlBhaUxpc3QoKSB7XG4gICAgICAgIHZhciB0YWJsZU5vZGUgPSBjYy5maW5kKFwiQ2FudmFzL3RhYmxlTm9kZVwiKTtcbiAgICAgICAgdmFyIHBhcmVudE5vZGUgPSBjYy5maW5kKFwidXNlcjNQYWlMaXN0XCIsIHRhYmxlTm9kZSk7XG4gICAgICAgIHZhciBjb3VudCA9IHBhcmVudE5vZGUuY2hpbGRyZW5Db3VudDtcbiAgICAgICAgY2MubG9nKFwicGFyZW50Tm9kZTogXCIgKyBwYXJlbnROb2RlLm5hbWUpO1xuICAgICAgICBjYy5sb2coXCJOb2RlIENoaWxkcmVuIENvdW50IDEwMTA6IFwiICsgY291bnQpO1xuICAgICAgICBwYXJlbnROb2RlLnJlbW92ZUFsbENoaWxkcmVuKCk7XG4gICAgfSxcbiAgICByZW1vdmVBbGxOb2RlRnJvbU90aGVyUGFpTGlzdDogZnVuY3Rpb24gcmVtb3ZlQWxsTm9kZUZyb21PdGhlclBhaUxpc3QocG9pbnQpIHtcbiAgICAgICAgdmFyIHRhYmxlTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvdGFibGVOb2RlXCIpO1xuICAgICAgICB2YXIgcGFyZW50Tm9kZSA9IGNjLmZpbmQoXCJ1c2VyXCIgKyBwb2ludCArIFwiUGFpTGlzdFwiLCB0YWJsZU5vZGUpO1xuICAgICAgICB2YXIgY291bnQgPSBwYXJlbnROb2RlLmNoaWxkcmVuQ291bnQ7XG4gICAgICAgIGNjLmxvZyhcInBhcmVudE5vZGU6IFwiICsgcGFyZW50Tm9kZS5uYW1lKTtcbiAgICAgICAgY2MubG9nKFwiTm9kZSBDaGlsZHJlbiBDb3VudCAxMDEwOiBcIiArIGNvdW50KTtcbiAgICAgICAgcGFyZW50Tm9kZS5yZW1vdmVBbGxDaGlsZHJlbigpO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBjb3JyZWN0IGluZGV4IGJ5IHRoZSAxNCBwYWkgXG4gICAgICovXG4gICAgZ2V0UGFpSW5zZXJ0SW5kZXhCeTE0OiBmdW5jdGlvbiBnZXRQYWlJbnNlcnRJbmRleEJ5MTQoKSB7XG4gICAgICAgIHZhciBpbmRleCA9IC0xO1xuICAgICAgICB2YXIgdGFibGVOb2RlID0gY2MuZmluZChcIkNhbnZhcy90YWJsZU5vZGVcIik7XG4gICAgICAgIHZhciBwYXJlbnROb2RlID0gY2MuZmluZChcInVzZXIzUGFpTGlzdFwiLCB0YWJsZU5vZGUpO1xuICAgICAgICB2YXIgdXNlciA9IHRoaXMuZ2V0Q29ycmVjdFVzZXJCeVBvaW50KFwiM1wiKTtcbiAgICAgICAgdmFyIG1vUGFpID0gcGFyc2VJbnQodXNlci51c2VyTW9QYWkpO1xuICAgICAgICB2YXIgcGFpTGlzdCA9IHRoaXMuZ2V0U2VsZlBhaUxpc3QoKTtcbiAgICAgICAgaWYgKHBhaUxpc3QubGVuZ3RoID09IDEpIHtcblxuICAgICAgICAgICAgaW5kZXggPSAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIGZpcnN0UGFpID0gcGFpTGlzdFswXSArIFwiXCI7XG4gICAgICAgICAgICBmaXJzdFBhaSA9IGZpcnN0UGFpLnRyaW0oKTtcbiAgICAgICAgICAgIHZhciBtaW5QYWkgPSBwYXJzZUludChmaXJzdFBhaSk7XG4gICAgICAgICAgICB2YXIgbWF4SW5kZXggPSBwYWlMaXN0Lmxlbmd0aCAtIDE7XG4gICAgICAgICAgICBpZiAobWF4SW5kZXggPT0gMTMpIHtcbiAgICAgICAgICAgICAgICBtYXhJbmRleCA9IDEyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIGxhc3RQYWkgPSBwYWlMaXN0W21heEluZGV4XSArIFwiXCI7XG4gICAgICAgICAgICBsYXN0UGFpID0gbGFzdFBhaS50cmltKCk7XG4gICAgICAgICAgICB2YXIgbWF4UGFpID0gcGFyc2VJbnQobGFzdFBhaSk7XG4gICAgICAgICAgICBjYy5sb2coXCJtb1BhaTpcIiArIG1vUGFpKTtcbiAgICAgICAgICAgIGNjLmxvZyhcIm1pblBhaTpcIiArIG1pblBhaSk7XG4gICAgICAgICAgICBjYy5sb2coXCJtYXhQYWk6XCIgKyBtYXhQYWkpO1xuICAgICAgICAgICAgaWYgKG1vUGFpIDwgbWluUGFpKSB7XG4gICAgICAgICAgICAgICAgaW5kZXggPSAwO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChtb1BhaSA+IG1heFBhaSkge1xuICAgICAgICAgICAgICAgIGluZGV4ID0gcGFpTGlzdC5sZW5ndGg7XG4gICAgICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtYXhJbmRleDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwYWlHZXQgPSBwYWlMaXN0W2ldICsgXCJcIjtcbiAgICAgICAgICAgICAgICAgICAgcGFpR2V0ID0gcGFpR2V0LnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBhaSA9IHBhcnNlSW50KHBhaUdldCk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBuZXh0SSA9IGkgKyAxO1xuICAgICAgICAgICAgICAgICAgICBpZiAobmV4dEkgPT0gcGFpTGlzdC5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5leHRJID0gaTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmIChuZXh0SSA9PSBpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbmRleCA9IHBhaUxpc3QubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG5leHRQYWlTdHIgPSBwYWlMaXN0W25leHRJXSArIFwiXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZXh0UGFpU3RyID0gbmV4dFBhaVN0ci50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbmV4dFBhaSA9IHBhcnNlSW50KG5leHRQYWlTdHIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwicGFpOlwiICsgcGFpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm5leHRQYWk6XCIgKyBuZXh0UGFpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwYWkgPCBtb1BhaSAmJiBtb1BhaSA8IG5leHRQYWkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCA9IG5leHRJO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGluZGV4O1xuICAgIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS11dGlscyBlbmQtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIHVwZGF0ZShkdCkge1xuICAgICAgICAvLyBpZiAodGhpcy50aGVNb3ZlTm9kZSAhPSBudWxsICYmIHRoaXMudGhlTW92ZU5vZGUgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIC8vICAgICBjYy5sb2coXCJ1cGRhdGUgdGhpcy50aGVNb3ZlTm9kZS5pbnRlcmFjdGFibGU6XCIgKyB0aGlzLnRoZU1vdmVOb2RlLmludGVyYWN0YWJsZSk7XG4gICAgICAgIC8vICAgICBpZiAodGhpcy50aGVNb3ZlTm9kZS5pbnRlcmFjdGFibGUgPT0gdHJ1ZSB8fCB0aGlzLnRoZU1vdmVOb2RlLmludGVyYWN0YWJsZSA9PXVuZGVmaW5lZCkge1xuICAgICAgICAvLyAgICAgICAgIGNjLmxvZyhcInVwZGF0ZTpcIiArIHRoaXMudGhlTW92ZU5vZGUubmFtZSk7XG4gICAgICAgIC8vICAgICAgICAgaWYgKG5vZGVNb3ZlWCAhPTAgJiYgbm9kZU1vdmVZICE9MCkge1xuXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgIHRoaXMudGhlTW92ZU5vZGUuc2V0UG9zaXRpb24odGhpcy50aGVNb3ZlTm9kZS54K25vZGVNb3ZlWCx0aGlzLnRoZU1vdmVOb2RlLnkrbm9kZU1vdmVZKTtcblxuICAgICAgICAvLyAgICAgICAgIH1cblxuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdjNTlhN3BZSGp4TWlxMUdPWU5UN0VPbicsICd0YWJsZVVzZXJJbmZvJyk7XG4vLyBzY3JpcHQvY29udHJvbGxlcnMvdGFibGVVc2VySW5mby5qc1xuXG52YXIgaHVhblBhaVNjcmlwdDtcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuXG4gICAgICAgIHVzZXJJbmZvMTogY2MuTm9kZSxcbiAgICAgICAgdXNlckluZm8yOiBjYy5Ob2RlLFxuICAgICAgICB1c2VySW5mbzM6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJJbmZvNDogY2MuTm9kZSxcbiAgICAgICAgdGFibGVBY3Rpb25Ob2RlOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHVzZXJSZWFkeUljb25PazogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHVzZXJSZWFkeUljb25Ob3RPazogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIHRhYmxlR2FtZU1vZGU6IGNjLk5vZGUsXG4gICAgICAgIHRhYmxlSGVhZDogY2MuTm9kZSxcblxuICAgICAgICB1c2VyMVJlYWROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyMlJlYWROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyM1JlYWROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyNFJlYWROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB0YWJsZVRpdGxlTm9kZTogY2MuTm9kZSxcblxuICAgICAgICB1c2VyMVBhaUxpc3ROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyMlBhaUxpc3ROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyNFBhaUxpc3ROb2RlOiBjYy5Ob2RlLFxuICAgICAgICB1c2VyM1BhaUxpc3ROb2RlOiBjYy5Ob2RlLFxuICAgICAgICBsaVBhaVByZWZhYjogY2MuUHJlZmFiLFxuICAgICAgICBiYWNrTm9kZTogY2MuUHJlZmFiLFxuXG4gICAgICAgIGxpUGFpWmlNaWFuOiBbY2MuU3ByaXRlRnJhbWVdLFxuICAgICAgICBjZVBhaTogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIGNlUGFpTGVmdDogY2MuU3ByaXRlRnJhbWUsXG4gICAgICAgIGJhY2tQYWk6IGNjLlNwcml0ZUZyYW1lLFxuXG4gICAgICAgIHF1ZXBhaU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIHRhYmxlQ2VudGVyUG9pbnQ6IGNjLk5vZGUsXG4gICAgICAgIGh1YW5QYWlTY3JpcHROb2RlOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICAvLyB0aGlzLnVzZXJJbmZvMS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgLy8gdGhpcy51c2VySW5mbzIuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIC8vIHRoaXMudXNlckluZm8zLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAvLyB0aGlzLnVzZXJJbmZvNC5hY3RpdmUgPSBmYWxzZTtcblxuICAgICAgICAvLyB0aGlzLmluaXRhbFVzZXJQYWkoKTtcbiAgICAgICAgLy8gdGhpcy5kaXNhYmxlZEh1YW5TYW5aaGFuZ1BhaSgpO1xuICAgICAgICBodWFuUGFpU2NyaXB0ID0gdGhpcy5odWFuUGFpU2NyaXB0Tm9kZS5nZXRDb21wb25lbnQoXCJodWFuUGFpVUlcIik7XG4gICAgfSxcbiAgICAvL3RoaXMgZnVuY3Rpb24gb25seSBpbml0YWwgYSBnYW9iYWwgdXNlciBsaXN0IGZvciB0ZXN0XG4gICAgLyoqXG4gICAgICogY2h1UGFpQ291bnRcbiAgICAgKiB1c2VyIDEgY2h1cGFpIGxpc3QgcG9pbnQgOnggLTIxMCx5IC00NSBcbiAgICAgKiB1c2VyIDIgY2h1cGFpIGxpc3QgcG9pbnQgOnggLTIxMCx5IC00NVxuICAgICAqIFxuICAgICAqL1xuICAgIHRlc3RJbml0YWxVc2VyTGlzdDogZnVuY3Rpb24gdGVzdEluaXRhbFVzZXJMaXN0KCkge1xuICAgICAgICB2YXIgcGFpTGlzdCA9IFtcIjExLCAxMSwgMTMsIDE0LCAxOCwgMjEsIDI0LCAzMiwgMzMsIDM0LCAzNCwgMzUsIDM1LCAzNVwiLCBcIjE1LCAxNywgMTgsIDIyLCAyMiwgMjMsIDI5LCAyOSwgMjksIDMzLCAzNiwgMzcsIDM5XCIsIFwiMTYsIDE3LCAxOSwgMjMsIDIzLCAyMywgMjQsIDMxLCAzMiwgMzMsIDMzLCAzNCwgMzZcIiwgXCIxNSwgMTUsIDE1LCAxOCwgMjIsIDIyLCAyNSwgMjYsIDI4LCAyOCwgMjksIDM0LCAzOFwiXTtcbiAgICAgICAgdmFyIHVzZXJMaXN0ID0gW107XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgNTsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgbyA9IG5ldyBPYmplY3QoKTtcbiAgICAgICAgICAgIG8uaWQgPSBpO1xuICAgICAgICAgICAgby5uaWNrTmFtZSA9IFwidGVzdFVzZXJcIiArIGk7XG4gICAgICAgICAgICBvLmhlYWRJbWFnZUZpbGVOYW1lID0gXCJ0ZXN0VXNlclwiICsgaSArIFwiLmpwZ1wiO1xuICAgICAgICAgICAgby5kaWFtb25kc051bWJlciA9IFwiMzBcIjtcbiAgICAgICAgICAgIG8uY291bnRyeSA9IFwiQ05cIjtcbiAgICAgICAgICAgIG8ub3BlbmlkID0gXCJ0ZXN0VXNlclwiICsgaTtcbiAgICAgICAgICAgIG8udW5pb25pZCA9IFwidGVzdFVzZXJcIiArIGk7XG4gICAgICAgICAgICBvLnVzZXJDb2RlID0gXCJ0ZXN0VXNlclwiICsgaTtcbiAgICAgICAgICAgIG8ucHVibGljSXAgPSBcIjEyNy4wLjAuMVwiO1xuICAgICAgICAgICAgby5wYWlMaXN0ID0gcGFpTGlzdFtpXTtcbiAgICAgICAgICAgIG8uZ2FtZVJlYWR5U3RhdHUgPSBcIjFcIjtcbiAgICAgICAgICAgIG8uZ2FtZVNjb3JlQ291bnQgPSBcIjFcIjtcbiAgICAgICAgICAgIG8ucG9pbnRJbmRleCA9IGkgKyAxO1xuICAgICAgICAgICAgby5oZWFkSW1hZ2VGaWxlTmFtZSA9IFwiMVwiO1xuXG4gICAgICAgICAgICBpZiAoaSA9PSAwKSB7XG4gICAgICAgICAgICAgICAgby56aHVhbmcgPSBcIjFcIjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgby56aHVhbmcgPSBcIjBcIjtcbiAgICAgICAgICAgICAgICBpZiAoaSA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgIG8udXNlck1vUGFpID0gXCIyMlwiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdXNlckxpc3QucHVzaChvKTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgZ2FtZU1vZGUgPSByZXF1aXJlKFwiZ2FtZU1vZGVcIikuZ2FtZU1vZGU7XG4gICAgICAgIHZhciB1c2VySW5mbyA9IHJlcXVpcmUoXCJ1c2VySW5mb0RvbWFpblwiKS51c2VySW5mb0RvbWFpbjtcbiAgICAgICAgdXNlckluZm8ub3BlbmlkID0gXCJ0ZXN0VXNlcjJcIjtcbiAgICAgICAgZ2FtZU1vZGUuaHVhblNhblpoYW5nID0gXCIxXCI7XG4gICAgICAgIEdsb2JhbC5nYW1lTW9kZSA9IGdhbWVNb2RlO1xuICAgICAgICBHbG9iYWwudXNlckxpc3QgPSB1c2VyTGlzdDtcbiAgICAgICAgR2xvYmFsLnVzZXJJbmZvID0gdXNlckluZm87XG4gICAgICAgIEdsb2JhbC5jaHVQYWlBY3Rpb25UeXBlID0gXCJub3JtYWxDaHVQYWlcIjtcbiAgICB9LFxuICAgIC8vdHlwZTppbml0YWxcbiAgICBpbml0YWxVc2VyUGFpOiBmdW5jdGlvbiBpbml0YWxVc2VyUGFpKGluaXRhbFR5cGUpIHtcbiAgICAgICAgLy9pbml0YWwgdGhlIHRlc3QgZGF0YVxuICAgICAgICAvLyB0aGlzLnRlc3RJbml0YWxVc2VyTGlzdCgpO1xuICAgICAgICAvLyBjYy5sb2coXCJHbG9iYWwuY2h1UGFpQWN0aW9uVHlwZSBpbml0YWxVc2VyUGFpOlwiK0dsb2JhbC5jaHVQYWlBY3Rpb25UeXBlKTtcbiAgICAgICAgLy9oaWRlIGdhbWUgbW9kZVxuICAgICAgICB0aGlzLnRhYmxlR2FtZU1vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudGFibGVIZWFkLmFjdGl2ZSA9IHRydWU7XG5cbiAgICAgICAgLy9oaWRlIHVzZXIgcmVhZHkgaWNvblxuICAgICAgICB0aGlzLnVzZXIxUmVhZE5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcjJSZWFkTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy51c2VyM1JlYWROb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnVzZXI0UmVhZE5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIC8vaGlkZSB0aXRsZVxuICAgICAgICB0aGlzLnRhYmxlVGl0bGVOb2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAvL2ZpeCB1c2VyIHBvaW50XG4gICAgICAgIHZhciB1c2VyTGlzdCA9IEdsb2JhbC51c2VyTGlzdDtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1c2VyTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIHVzZXIgPSB1c2VyTGlzdFtpXTtcbiAgICAgICAgICAgIC8vc2hvdyBjdXJyZW50IHVzZXIgbm9kZVxuICAgICAgICAgICAgaWYgKHVzZXIucG9pbnRJbmRleCAhPSBudWxsICYmIHVzZXIucG9pbnRJbmRleCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBjYy5sb2codXNlci5wb2ludEluZGV4KTtcbiAgICAgICAgICAgICAgICAvL2ZpeCB1c2VyIHBvaW50XG4gICAgICAgICAgICAgICAgaWYgKHVzZXIucG9pbnRJbmRleCAhPSBcIjNcIikge1xuICAgICAgICAgICAgICAgICAgICBldmFsKFwidGhpcy51c2VySW5mb1wiICsgdXNlci5wb2ludEluZGV4ICsgXCIuYWN0aXZlID0gdHJ1ZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maXhVc2VyUG9pbnRCeUluZGV4KHVzZXIucG9pbnRJbmRleCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZXZhbChcInRoaXMudXNlckluZm9cIiArIHVzZXIucG9pbnRJbmRleCArIFwiLmFjdGl2ZSA9IGZhbHNlXCIpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHZhciBwYWlMaXN0ID0gdXNlci5wYWlMaXN0O1xuICAgICAgICAgICAgICAgIGlmIChwYWlMaXN0ICE9IG51bGwgJiYgcGFpTGlzdCAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVzZXIucG9pbnRJbmRleCArIFwiXCIgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vaW5pdGFsIHNlbGYgcGFpXG4gICAgICAgICAgICAgICAgICAgICAgICBHbG9iYWwuY2h1UGFpQWN0aW9uVHlwZSA9IFwiaHVhblNhblpoYW5nXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICBHbG9iYWwuaHVhblNhblpoYW5nUGFpTGlzdCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdXNlci5wYWlMaXN0QXJyYXkgPSB0aGlzLmludGFsU2VsZlBhaUxpc3QocGFpTGlzdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyLmNodXBhaUxpc3RYID0gLTIxMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXIuY2h1cGFpTGlzdFkgPSAtNDU7XG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyLmNodVBhaUNvdW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXIucGFpTGlzdEFycmF5ID0gdGhpcy5pbml0YWxPdGhlclBhaUxpc3QocGFpTGlzdCwgdXNlci5wb2ludEluZGV4LCBpbml0YWxUeXBlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXIgPSB0aGlzLmluaXRhbE90aGVyVXNlckNodVBhaVBvaW50KHVzZXIsIHVzZXIucG9pbnRJbmRleCArIFwiXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9pbnRhbCBvdGhlciB1c2VyIHBhaVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy9wdXQgYmFjayB0aGUgdXNlciBsaXN0IHRvIGdvYmFsXG5cbiAgICAgICAgR2xvYmFsLnVzZXJMaXN0ID0gdXNlckxpc3Q7XG4gICAgICAgIC8vc2hvdyBodWFuUGFpU2NyaXB0XG4gICAgICAgIGh1YW5QYWlTY3JpcHQuc2hvd0h1YW5QYWlOb2RlKCk7XG4gICAgfSxcblxuICAgIC8vaW5pdGFsIG90aGVyIHVzZXIgY2h1cGFpIHN0YXJ0IHBvaW50XG4gICAgaW5pdGFsT3RoZXJVc2VyQ2h1UGFpUG9pbnQ6IGZ1bmN0aW9uIGluaXRhbE90aGVyVXNlckNodVBhaVBvaW50KHVzZXIsIHBvaW50KSB7XG5cbiAgICAgICAgaWYgKHBvaW50ID09IFwiMVwiKSB7XG4gICAgICAgICAgICB1c2VyLmNodXBhaUxpc3RYID0gMjEwO1xuICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WSA9IC00NTtcbiAgICAgICAgfSBlbHNlIGlmIChwb2ludCA9PSBcIjJcIikge1xuICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WCA9IDE3MDtcbiAgICAgICAgICAgIHVzZXIuY2h1cGFpTGlzdFkgPSAxMjA7XG4gICAgICAgIH0gZWxzZSBpZiAocG9pbnQgPT0gXCI0XCIpIHtcbiAgICAgICAgICAgIHVzZXIuY2h1cGFpTGlzdFggPSAtMTcwO1xuICAgICAgICAgICAgdXNlci5jaHVwYWlMaXN0WSA9IC0xMjA7XG4gICAgICAgIH1cbiAgICAgICAgdXNlci5jaHVQYWlDb3VudCA9IDA7XG4gICAgICAgIHJldHVybiB1c2VyO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogXG4gICAgICovXG4gICAgZ2V0TWluTGVuUGFpTGlzdEZyb21QYWk6IGZ1bmN0aW9uIGdldE1pbkxlblBhaUxpc3RGcm9tUGFpKHBhaUxpc3QpIHtcbiAgICAgICAgdmFyIHYxID0gW107XG4gICAgICAgIHZhciB2MiA9IFtdO1xuICAgICAgICB2YXIgdjMgPSBbXTtcblxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhaUxpc3QubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHZhciBwYWkgPSBwYWlMaXN0W2ldO1xuICAgICAgICAgICAgdmFyIHNUeXBlID0gcGFpICsgXCJcIjtcbiAgICAgICAgICAgIHZhciBzVHlwZSA9IHNUeXBlLnN1YnN0cmluZygwLCAxKTtcbiAgICAgICAgICAgIGlmIChzVHlwZSA9PSBcIjFcIikge1xuICAgICAgICAgICAgICAgIHYxLnB1c2goc1R5cGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNUeXBlID09IFwiMlwiKSB7XG4gICAgICAgICAgICAgICAgdjIucHVzaChzVHlwZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc1R5cGUgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgICAgICB2My5wdXNoKHNUeXBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHZhciByZXN1bHRBcnJheSA9IFt2MS5sZW5ndGgsIHYyLmxlbmd0aCwgdjMubGVuZ3RoXTtcbiAgICAgICAgdmFyIHJlc3VsdEFycmF5MiA9IFt2MSwgdjIsIHYzXTtcbiAgICAgICAgcmVzdWx0QXJyYXkuc29ydCgpO1xuICAgICAgICB2YXIgbCA9IDA7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMzsgaSsrKSB7XG4gICAgICAgICAgICBpZiAocmVzdWx0QXJyYXlbaV0gPj0gMykge1xuICAgICAgICAgICAgICAgIGwgPSByZXN1bHRBcnJheVtpXTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgcmV0dXJuQXJyYXk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMzsgaSsrKSB7XG4gICAgICAgICAgICBpZiAocmVzdWx0QXJyYXkyW2ldLmxlbmd0aCA9PSBsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuQXJyYXkgPSByZXN1bHRBcnJheTJbaV07XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDM7IGkrKykge1xuICAgICAgICAgICAgdmFyIHBhaU5hbWUgPSBcInBhaVwiICsgaSArIFwiX1wiICsgcmV0dXJuQXJyYXlbaV0udHJpbSgpO1xuICAgICAgICAgICAgdmFyIHBhaU5vZGUgPSBjYy5maW5kKHBhaU5hbWUsIHRoaXMudXNlcjNQYWlMaXN0Tm9kZSk7XG4gICAgICAgICAgICBwYWlOb2RlLnkgPSAyMDtcbiAgICAgICAgICAgIEdsb2JhbC5odWFuU2FuWmhhbmdQYWlMaXN0LnB1c2gocmV0dXJuQXJyYXlbaV0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJldHVybkFycmF5O1xuICAgIH0sXG5cbiAgICBnZXRMZXNzM051bWJlclR5cGU6IGZ1bmN0aW9uIGdldExlc3MzTnVtYmVyVHlwZShwYXJlbnROb2RlKSB7XG4gICAgICAgIHZhciB2MSA9IDA7XG4gICAgICAgIHZhciB2MiA9IDA7XG4gICAgICAgIHZhciB2MyA9IDA7XG4gICAgICAgIHZhciBjaGlsZHJlbiA9IHBhcmVudE5vZGUuY2hpbGRyZW47XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHZhciBjaGlsZHJlZE5hbWUgPSBjaGlsZHJlbltpXS5uYW1lO1xuICAgICAgICAgICAgdmFyIHRlbXAgPSBjaGlsZHJlZE5hbWUuc3BsaXQoXCJfXCIpO1xuICAgICAgICAgICAgdmFyIHNUeXBlID0gdGVtcFsxXTtcbiAgICAgICAgICAgIHZhciBzVHlwZSA9IHNUeXBlLnN1YnN0cmluZygwLCAxKTtcbiAgICAgICAgICAgIGlmIChzVHlwZSA9PSBcIjFcIikge1xuICAgICAgICAgICAgICAgIHYxKys7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc1R5cGUgPT0gXCIyXCIpIHtcbiAgICAgICAgICAgICAgICB2MisrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNUeXBlID09IFwiM1wiKSB7XG4gICAgICAgICAgICAgICAgdjMrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHZhciB2ID0gW107XG4gICAgICAgIGlmICh2MSA8IDMpIHtcbiAgICAgICAgICAgIHYucHVzaChcIjFcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHYyIDwgMykge1xuICAgICAgICAgICAgdi5wdXNoKFwiMlwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodjMgPCAzKSB7XG4gICAgICAgICAgICB2LnB1c2goXCIzXCIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2O1xuICAgIH0sXG4gICAgZGlzYWJsZUFsbFBhaTogZnVuY3Rpb24gZGlzYWJsZUFsbFBhaSgpIHtcbiAgICAgICAgdmFyIGNoaWxkcmVuID0gdGhpcy51c2VyM1BhaUxpc3ROb2RlLmNoaWxkcmVuO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICB2YXIgYnRuID0gY2hpbGRyZW5baV0uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgICAgICBidG4uaW50ZXJhY3RhYmxlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGRpc2FibGVkUXVlUGFpOiBmdW5jdGlvbiBkaXNhYmxlZFF1ZVBhaSgpIHtcbiAgICAgICAgdmFyIHVzZXJMaXN0ID0gR2xvYmFsLnVzZXJMaXN0O1xuICAgICAgICB2YXIgdXNlckluZm8gPSBHbG9iYWwudXNlckluZm87XG4gICAgICAgIHZhciBxdWVQYWkgPSBcIlwiO1xuICAgICAgICB2YXIgcGFpTGlzdDtcbiAgICAgICAgdmFyIGV4aXN0RmxhZyA9IGZhbHNlO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IHVzZXJJbmZvLm9wZW5pZCkge1xuICAgICAgICAgICAgICAgIHF1ZVBhaSA9IHVzZXJMaXN0W2ldLnF1ZVBhaTtcbiAgICAgICAgICAgICAgICBwYWlMaXN0ID0gdXNlckxpc3RbaV0ucGFpTGlzdEFycmF5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHBhaUxpc3QgIT0gbnVsbCkge1xuICAgICAgICAgICAgaWYgKHF1ZVBhaSAhPSBudWxsICYmIHF1ZVBhaS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlMaXN0Lmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzVHlwZSA9IHBhaUxpc3RbaV0udHJpbSgpICsgXCJcIjtcbiAgICAgICAgICAgICAgICAgICAgc1R5cGUgPSBzVHlwZS5zdWJzdHJpbmcoMCwgMSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzVHlwZSA9PSBxdWVQYWkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0RmxhZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZXhpc3RGbGFnKSB7XG4gICAgICAgICAgICB2YXIgY2hpbGRyZW4gPSB0aGlzLnVzZXIzUGFpTGlzdE5vZGUuY2hpbGRyZW47XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICAgICAgdmFyIHRlbXAgPSBjaGlsZHJlZE5hbWUuc3BsaXQoXCJfXCIpO1xuICAgICAgICAgICAgICAgIHZhciBzVHlwZSA9IHRlbXBbMV07XG4gICAgICAgICAgICAgICAgc1R5cGUgPSBzVHlwZS5zdWJzdHJpbmcoMCwgMSk7XG4gICAgICAgICAgICAgICAgaWYgKHNUeXBlICE9IHF1ZVBhaSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYnRuID0gY2hpbGRyZW5baV0uZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgICAgICAgICAgICAgIGJ0bi5pbnRlcmFjdGFibGUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgZ2V0U2xlZlVzZXI6IGZ1bmN0aW9uIGdldFNsZWZVc2VyKCkge1xuICAgICAgICB2YXIgZ29iYWxVc2VyID0gR2xvYmFsLnVzZXJJbmZvO1xuICAgICAgICB2YXIgdXNlckxpc3QgPSBHbG9iYWwudXNlckxpc3Q7XG4gICAgICAgIHZhciB1c2VyO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodXNlckxpc3RbaV0ub3BlbmlkID09IGdvYmFsVXNlci5vcGVuaWQpIHtcbiAgICAgICAgICAgICAgICB1c2VyID0gdXNlckxpc3RbaV07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdXNlcjtcbiAgICB9LFxuICAgIC8vRm9yY2Ugc2VsZWN0IHNhbiB6aGFuZyBwYWkgYWZ0ZXIgdGhlIHRpbWVyIGVuZFxuXG4gICAgZm9yY2VGaWxsSHVhblNhblpoYW5nTGlzdDogZnVuY3Rpb24gZm9yY2VGaWxsSHVhblNhblpoYW5nTGlzdCgpIHtcbiAgICAgICAgdmFyIHBhaUxpc3QgPSB0aGlzLmdldFNsZWZVc2VyKCkucGFpTGlzdEFycmF5O1xuICAgICAgICB0aGlzLmdldE1pbkxlblBhaUxpc3RGcm9tUGFpKHBhaUxpc3QpO1xuICAgIH0sXG5cbiAgICAvL3doZW4gaHVhbiBzYW4gemhhbmcgd29yaywgdGhpcyB3aWxsIGRpc2FibGVkIGxlc3MgMyBudW1iZXIgcGFpXG4gICAgZGlzYWJsZWRIdWFuU2FuWmhhbmdQYWk6IGZ1bmN0aW9uIGRpc2FibGVkSHVhblNhblpoYW5nUGFpKCkge1xuXG4gICAgICAgIHZhciBjaGlsZHJlbiA9IHRoaXMudXNlcjNQYWlMaXN0Tm9kZS5jaGlsZHJlbjtcbiAgICAgICAgdmFyIHYgPSB0aGlzLmdldExlc3MzTnVtYmVyVHlwZSh0aGlzLnVzZXIzUGFpTGlzdE5vZGUpO1xuICAgICAgICB2YXIgdnN0ciA9IHYudG9TdHJpbmcoKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgdmFyIGNoaWxkcmVkTmFtZSA9IGNoaWxkcmVuW2ldLm5hbWU7XG4gICAgICAgICAgICB2YXIgdGVtcCA9IGNoaWxkcmVkTmFtZS5zcGxpdChcIl9cIik7XG4gICAgICAgICAgICB2YXIgc1R5cGUgPSB0ZW1wWzFdO1xuICAgICAgICAgICAgc1R5cGUgPSBzVHlwZS5zdWJzdHJpbmcoMCwgMSk7XG4gICAgICAgICAgICBpZiAodnN0ci5pbmRleE9mKHNUeXBlKSA+PSAwKSB7XG4gICAgICAgICAgICAgICAgdmFyIGJ0biA9IGNoaWxkcmVuW2ldLmdldENvbXBvbmVudChjYy5CdXR0b24pO1xuICAgICAgICAgICAgICAgIGJ0bi5pbnRlcmFjdGFibGUgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBpbml0YWxPdGhlclBhaUxpc3Q6IGZ1bmN0aW9uIGluaXRhbE90aGVyUGFpTGlzdChwYWlMaXN0LCBwb2ludCwgaW5pVHlwZSkge1xuICAgICAgICB2YXIgcGFpQXJyYXkgPSBwYWlMaXN0LnNwbGl0KFwiLFwiKTtcbiAgICAgICAgdmFyIHN0YXJ0WCA9IDA7XG4gICAgICAgIHZhciBzdGFydFkgPSAwO1xuICAgICAgICBjYy5sb2coXCIqKioqKioqKmluaXRhbE90aGVyUGFpTGlzdDpcIiArIHBhaUxpc3QgKyBcIi0tLS1cIiArIHBvaW50KTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYWlBcnJheS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKHBhaUFycmF5W2ldICE9IG51bGwgJiYgcGFpQXJyYXlbaV0gIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKHBhaUFycmF5W2ldICE9IFwiXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBhaU5vZGU7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzcHJpdGU7XG4gICAgICAgICAgICAgICAgICAgIHBhaU5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJhY2tOb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5uYW1lID0gXCJwYWlcIiArIGkgKyBcIl9cIiArIHBhaUFycmF5W2ldLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgc3ByaXRlID0gcGFpTm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBvaW50ID09IFwiMVwiKSB7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHNwcml0ZS5zcHJpdGVGcmFtZSA9IHRoaXMuYmFja1BhaTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vdGhpcy51c2VyMVBhaUxpc3ROb2RlLmFkZENoaWxkKHBhaU5vZGUpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBvaW50ID09IFwiMlwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNwcml0ZS5zcHJpdGVGcmFtZSA9IHRoaXMuY2VQYWlMZWZ0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL3RoaXMudXNlcjJQYWlMaXN0Tm9kZS5hZGRDaGlsZChwYWlOb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5jZVBhaTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoaXMudXNlcjRQYWlMaXN0Tm9kZS5hZGRDaGlsZChwYWlOb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGV2YWwoXCJ0aGlzLnVzZXJcIiArIHBvaW50ICsgXCJQYWlMaXN0Tm9kZS5hZGRDaGlsZChwYWlOb2RlKVwiKTtcbiAgICAgICAgICAgICAgICAgICAgLy9maXggdGhlIHVzZXIgMVxuICAgICAgICAgICAgICAgICAgICBpZiAocG9pbnQgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0WCA9IDM4MDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhaU5vZGUucm90YXRpb24gPSAxODA7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYWlOb2RlLnBvc2l0aW9uID0gY2MucChzdGFydFggLSBpICogNTUsIDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy90aGlzLnVzZXIxUGFpTGlzdE5vZGUuYWRkQ2hpbGQocGFpTm9kZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAocG9pbnQgPT0gXCIyXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0WCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW5pVHlwZSA9PSBcImluaXRhbFwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnRZID0gLTIxMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnRZID0gLTgwO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWlOb2RlLnBvc2l0aW9uID0gY2MucChzdGFydFgsIHN0YXJ0WSArIGkgKiAyOCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaSA9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiMzM3IHN0YXJ0WTpcIiArIHN0YXJ0WSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBwYWlOb2RlLnpJbmRleCA9IHBhaUFycmF5Lmxlbmd0aCAtIGk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYWlOb2RlLndpZHRoID0gNDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYWlOb2RlLmhlaWdodCA9IDg1O1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9wYXJlbnROb2RlXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAocG9pbnQgPT0gXCI0XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0WCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGFydFkgPSAtMjEwO1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAoc3RhcnRYLCBzdGFydFkgKyBpICogMjgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS56SW5kZXggPSBwYWlBcnJheS5sZW5ndGggLSBpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS53aWR0aCA9IDQwO1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5oZWlnaHQgPSA4NTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBwYWlBcnJheTtcbiAgICB9LFxuICAgIGludGFsU2VsZlBhaUxpc3Q6IGZ1bmN0aW9uIGludGFsU2VsZlBhaUxpc3QocGFpTGlzdCkge1xuXG4gICAgICAgIHZhciBzdGFydFBvaW50ID0gLTUyMDtcbiAgICAgICAgdmFyIHBhaUFycmF5ID0gcGFpTGlzdC5zcGxpdChcIixcIik7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFpQXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChwYWlBcnJheVtpXSAhPSBudWxsICYmIHBhaUFycmF5W2ldICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIHZhciBwYWlOb2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5saVBhaVByZWZhYik7XG4gICAgICAgICAgICAgICAgdmFyIGJ0biA9IHBhaU5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG5cbiAgICAgICAgICAgICAgICB2YXIgc3ByaXRlID0gcGFpTm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgICAgICAgICBwYWlOb2RlLm5hbWUgPSBcInBhaVwiICsgaSArIFwiX1wiICsgcGFpQXJyYXlbaV0udHJpbSgpO1xuICAgICAgICAgICAgICAgIC8vdmFyIGltYWdlVXJsID0gXCIvaW1nLzl0XCI7XG4gICAgICAgICAgICAgICAgLy92YXIgaW1hZ2VVcmwgPSB0aGlzLmdldENvcnJlY3ROYW1lT25TZWxmUGFpKHBhaUFycmF5W2ldKTtcbiAgICAgICAgICAgICAgICAvL2NjLmxvZyhcImltZzM6XCIgKyBpbWFnZVVybCk7XG4gICAgICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICBjYy5sb2FkZXIubG9hZChpbWFnZVVybCwgZnVuY3Rpb24gKGVyciwgdGV4dHVyZSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcihlcnIubWVzc2FnZSB8fCBlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHZhciBmcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcbiAgICAgICAgICAgICAgICAgICAgc3ByaXRlLnNwcml0ZUZyYW1lID0gZnJhbWU7XG4gICAgICAgICAgICAgICAgfSk7Ki9cbiAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSB0aGlzLmdldEN1cnJlY3RJbmRlT25TZWZsUGFpKHBhaUFycmF5W2ldKTtcbiAgICAgICAgICAgICAgICBzcHJpdGUuc3ByaXRlRnJhbWUgPSB0aGlzLmxpUGFpWmlNaWFuW2luZGV4XTtcbiAgICAgICAgICAgICAgICB0aGlzLnVzZXIzUGFpTGlzdE5vZGUuYWRkQ2hpbGQocGFpTm9kZSk7XG4gICAgICAgICAgICAgICAgaWYgKGkgPT0gMTMpIHtcbiAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAoc3RhcnRQb2ludCArIGkgKiA4MCwgMCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcGFpTm9kZS5wb3NpdGlvbiA9IGNjLnAoc3RhcnRQb2ludCArIGkgKiA3OSwgMCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHBhaUFycmF5O1xuICAgIH0sXG5cbiAgICBnZXRDdXJyZWN0SW5kZU9uU2VmbFBhaTogZnVuY3Rpb24gZ2V0Q3VycmVjdEluZGVPblNlZmxQYWkocGFpKSB7XG4gICAgICAgIHBhaSA9IChwYWkgKyBcIlwiKS50cmltKCk7XG4gICAgICAgIHZhciB0eXBlID0gKHBhaSArIFwiXCIpLnN1YnN0cmluZygwLCAxKTtcbiAgICAgICAgdmFyIHBhaU51bSA9IChwYWkgKyBcIlwiKS5zdWJzdHJpbmcoMSk7XG4gICAgICAgIC8vdG9uZyAxMS0xOVxuICAgICAgICAvL3RpYW8gMjEtMjlcbiAgICAgICAgLy93YW4gIDMxLTM5XG4gICAgICAgIHZhciBpbmRleCA9IC0xO1xuXG4gICAgICAgIGlmICh0eXBlID09IFwiMVwiKSB7XG4gICAgICAgICAgICBpbmRleCA9IHBhcnNlSW50KHBhaU51bSkgLSAxO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHR5cGUgPT0gXCIyXCIpIHtcbiAgICAgICAgICAgIGluZGV4ID0gcGFyc2VJbnQocGFpTnVtKSArIDg7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodHlwZSA9PSBcIjNcIikge1xuICAgICAgICAgICAgaW5kZXggPSBwYXJzZUludChwYWlOdW0pICsgMTc7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gaW5kZXg7XG4gICAgfSxcblxuICAgIGdldENvcnJlY3ROYW1lT25TZWxmUGFpOiBmdW5jdGlvbiBnZXRDb3JyZWN0TmFtZU9uU2VsZlBhaShwYWkpIHtcbiAgICAgICAgcGFpID0gKHBhaSArIFwiXCIpLnRyaW0oKTtcbiAgICAgICAgY2MubG9nKFwiaW1nMTpcIiArIHBhaSArIFwiLS1cIiArIHBhaS5sZW5ndGgpO1xuICAgICAgICB2YXIgdHlwZSA9IChwYWkgKyBcIlwiKS5zdWJzdHJpbmcoMCwgMSk7XG4gICAgICAgIHZhciBwYWlOdW0gPSAocGFpICsgXCJcIikuc3Vic3RyaW5nKDEpO1xuICAgICAgICB2YXIgcHJlZml4ID0gXCJcIjtcbiAgICAgICAgdmFyIHBhdGggPSBcIlwiO1xuXG4gICAgICAgIGlmICh0eXBlID09IFwiMVwiKSB7XG4gICAgICAgICAgICBwYXRoID0gXCJpbWFnZS90YWJsZS9wYWkvbGlwYWkvdG9uZy9cIjtcbiAgICAgICAgICAgIHByZWZpeCA9IFwiYlwiO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlID09IFwiMlwiKSB7XG4gICAgICAgICAgICBwYXRoID0gXCJpbWFnZS90YWJsZS9wYWkvbGlwYWkvdGlhby9cIjtcbiAgICAgICAgICAgIHByZWZpeCA9IFwidFwiO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlID09IFwiM1wiKSB7XG4gICAgICAgICAgICBwYXRoID0gXCJpbWFnZS90YWJsZS9wYWkvbGlwYWkvd2FuL1wiO1xuICAgICAgICAgICAgcHJlZml4ID0gXCJ3XCI7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgaW1nID0gcGF0aCArIHBhaU51bSArIHByZWZpeDtcbiAgICAgICAgY2MubG9nKFwiaW1nMjpcIiArIGltZyk7XG4gICAgICAgIHJldHVybiBpbWc7XG4gICAgfSxcblxuICAgIGZpeFVzZXJQb2ludEJ5SW5kZXg6IGZ1bmN0aW9uIGZpeFVzZXJQb2ludEJ5SW5kZXgoaW5kZXgpIHtcbiAgICAgICAgaWYgKGluZGV4ID09IFwiMVwiKSB7XG4gICAgICAgICAgICB2YXIgd2lkZ2V0ID0gdGhpcy51c2VySW5mbzEuZ2V0Q29tcG9uZW50KGNjLldpZGdldCk7XG4gICAgICAgICAgICB3aWRnZXQudG9wID0gLTIwO1xuICAgICAgICAgICAgLy8gd2lkZ2V0LmlzQWxpZ25SaWdodCA9IHRydWU7XG4gICAgICAgICAgICAvLyB3aWRnZXQucmlnaHQgPSAyMTA7XG4gICAgICAgICAgICAvL3RoaXMudXNlckluZm8xLnk9LTIwO1xuICAgICAgICAgICAgY2MubG9nKFwiZml4VXNlclBvaW50QnlJbmRleCAxOlwiICsgdGhpcy51c2VySW5mbzEueSk7XG4gICAgICAgICAgICAvL3RoaXMudXNlckluZm8xLnkgPTQxMDtcbiAgICAgICAgICAgIHRoaXMudXNlckluZm8xLnggPSA0NTc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluZGV4ID09IFwiMlwiKSB7XG4gICAgICAgICAgICAvL3ZhciB3aWRnZXQgPSB0aGlzLnVzZXJJbmZvMi5nZXRDb21wb25lbnQoY2MuV2lkZ2V0KTtcbiAgICAgICAgICAgIC8vd2lkZ2V0LmxlZnQgPSA2MDtcbiAgICAgICAgICAgIHRoaXMudXNlckluZm8yLnggPSAtNjA3O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGluZGV4ID09IFwiNFwiKSB7XG4gICAgICAgICAgICAvL3ZhciB3aWRnZXQgPSB0aGlzLnVzZXJJbmZvNC5nZXRDb21wb25lbnQoY2MuV2lkZ2V0KTtcbiAgICAgICAgICAgIC8vd2lkZ2V0LnJpZ2h0ID0gNjA7XG4gICAgICAgICAgICB0aGlzLnVzZXJJbmZvNC54ID0gNjA3O1xuICAgICAgICB9XG4gICAgfSxcbiAgICBpbnRhbFVzZXJJbmZvUmVhZHlJY29uOiBmdW5jdGlvbiBpbnRhbFVzZXJJbmZvUmVhZHlJY29uKCkge1xuXG4gICAgICAgIHZhciB1c2VyTGlzdCA9IEdsb2JhbC51c2VyTGlzdDtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1c2VyTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIHVzZXIgPSB1c2VyTGlzdFtpXTtcbiAgICAgICAgICAgIHZhciB1c2VyTm9kZU5hbWUgPSBcInVzZXJcIiArIHVzZXIucG9pbnRJbmRleCArIFwiTm9kZVwiO1xuICAgICAgICAgICAgY2MubG9nKFwidXNlck5vZGVOYW1lOlwiICsgdXNlck5vZGVOYW1lKTtcbiAgICAgICAgICAgIHZhciB1c2VyTm9kZSA9IGNjLmZpbmQodXNlck5vZGVOYW1lLCB0aGlzLnRhYmxlTm9kZSk7XG4gICAgICAgICAgICB2YXIgdXNlckluZm9Ob2RlID0gY2MuZmluZChcInVzZXJJbmZvTm9kZVwiLCB1c2VyTm9kZSk7XG4gICAgICAgICAgICAvL3ZhciB1c2VyTmlja05hbWVOb2RlID0gY2MuZmluZChcInVzZXJOaWNrTmFtZUJnXCIsIHVzZXJJbmZvTm9kZSk7XG4gICAgICAgICAgICB2YXIgdXNlclJlYWR5aWNvbk5vZGUgPSBjYy5maW5kKFwidXNlclJlYWR5Tm9kZVwiLCB1c2VySW5mb05vZGUpO1xuICAgICAgICAgICAgdmFyIHVzZXJSZWFkeUJ0bk5vZGUgPSBjYy5maW5kKFwicmVhZHlCdXR0b25cIiwgdXNlclJlYWR5aWNvbk5vZGUpO1xuICAgICAgICAgICAgdmFyIHMgPSB1c2VyUmVhZHlCdG5Ob2RlLmdldENvbXBvbmVudChjYy5TcHJpdGUpO1xuICAgICAgICAgICAgY2MubG9nKFwidXNlci5nYW1lUmVhZHlTdGF0dTpcIiArIHVzZXIuZ2FtZVJlYWR5U3RhdHUpO1xuICAgICAgICAgICAgaWYgKHVzZXIuZ2FtZVJlYWR5U3RhdHUgPT0gXCIxXCIpIHtcbiAgICAgICAgICAgICAgICBzLnNwcml0ZUZyYW1lID0gdGhpcy51c2VyUmVhZHlJY29uT2s7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHMuc3ByaXRlRnJhbWUgPSB0aGlzLnVzZXJSZWFkeUljb25Ob3RPaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBpbml0YWxVc2VySW5mb0Zyb21Hb2JhbExpc3Q6IGZ1bmN0aW9uIGluaXRhbFVzZXJJbmZvRnJvbUdvYmFsTGlzdCgpIHtcbiAgICAgICAgLy9oaWRlICB0YWJsZSAgcGFpIHN0YXJ0aW5nXG4gICAgICAgIHRoaXMucXVlcGFpTm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy50YWJsZUNlbnRlclBvaW50LmFjdGl2ZSA9IGZhbHNlO1xuXG4gICAgICAgIHZhciBudW1iZXJPcmRlciA9IFszLCA0LCAxLCAyXTtcbiAgICAgICAgdmFyIHVzZXJMaXN0ID0gR2xvYmFsLnVzZXJMaXN0O1xuICAgICAgICB2YXIgdXNlckluZm8gPSBHbG9iYWwudXNlckluZm87XG4gICAgICAgIHZhciBnYW1lTW9kZSA9IEdsb2JhbC5nYW1lTW9kZTtcbiAgICAgICAgdmFyIGdhbWVQZW9wbGUgPSBnYW1lTW9kZS5nYW1lUGVvcGxlTnVtYmVyO1xuICAgICAgICB2YXIgaW5kZXggPSAtMTtcbiAgICAgICAgaWYgKHVzZXJMaXN0ICE9IG51bGwgJiYgdXNlckxpc3QgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB2YXIgdGVtcExpc3QgPSBbXTtcbiAgICAgICAgICAgIC8vMS5maW5kIHRoZSBzdGFydCBpbmRleFxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB1c2VyTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIHZhciB0YWJsZVVzZXJJbmZvID0gdXNlckxpc3RbaV07XG4gICAgICAgICAgICAgICAgaWYgKGluZGV4IDwgMCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodXNlckluZm8ub3BlbmlkID09IHRhYmxlVXNlckluZm8ub3BlbmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wTGlzdC5wdXNoKHRhYmxlVXNlckluZm8pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXggPSBpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcExpc3QucHVzaCh0YWJsZVVzZXJJbmZvKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYy5sb2coXCJpbmRleDpcIiArIGluZGV4KTtcbiAgICAgICAgICAgIGlmIChpbmRleCA9PSAwKSB7XG4gICAgICAgICAgICAgICAgaWYgKGdhbWVQZW9wbGUgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgbnVtYmVyT3JkZXIgPSBbMywgNCwgMl07XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKGdhbWVQZW9wbGUgPT0gXCIyXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgbnVtYmVyT3JkZXIgPSBbMywgMV07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGluZGV4ID09IDEpIHtcbiAgICAgICAgICAgICAgICBpZiAoZ2FtZVBlb3BsZSA9PSBcIjRcIikge1xuICAgICAgICAgICAgICAgICAgICBudW1iZXJPcmRlciA9IFsyLCAzLCA0LCAxXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGdhbWVQZW9wbGUgPT0gXCIzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgbnVtYmVyT3JkZXIgPSBbMiwgMywgNF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChnYW1lUGVvcGxlID09IFwiMlwiKSB7XG4gICAgICAgICAgICAgICAgICAgIG51bWJlck9yZGVyID0gWzEsIDNdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpbmRleCA9PSAyKSB7XG4gICAgICAgICAgICAgICAgaWYgKGdhbWVQZW9wbGUgPT0gXCI0XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgbnVtYmVyT3JkZXIgPSBbMSwgMiwgMywgNF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChnYW1lUGVvcGxlID09IFwiM1wiKSB7XG4gICAgICAgICAgICAgICAgICAgIG51bWJlck9yZGVyID0gWzQsIDIsIDNdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpbmRleCA9PSAzKSB7XG4gICAgICAgICAgICAgICAgaWYgKGdhbWVQZW9wbGUgPT0gXCI0XCIpIHtcbiAgICAgICAgICAgICAgICAgICAgbnVtYmVyT3JkZXIgPSBbNCwgMSwgMiwgM107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChnYW1lUGVvcGxlID09IFwiM1wiKSB7XG4gICAgICAgICAgICAgICAgICAgIG51bWJlck9yZGVyID0gWzQsIDIsIDNdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gaWYgKGluZGV4ID4gMCkge1xuICAgICAgICAgICAgLy8gICAgIGZvciAodmFyIGkgPSAwOyBpIDwgaW5kZXg7IGkrKykge1xuICAgICAgICAgICAgLy8gICAgICAgICB0ZW1wTGlzdC5wdXNoKHVzZXJMaXN0W2ldKTtcbiAgICAgICAgICAgIC8vICAgICB9XG4gICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgIC8vc3RhcnQgZmlsbCB0aGUgdXNlciBpbmZvIGZyb20gaW5kZXhcbiAgICAgICAgICAgIGNjLmxvZyhcIm51bWJlck9yZGVyOlwiICsgbnVtYmVyT3JkZXIudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHVzZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIHVzZXIgPSB1c2VyTGlzdFtpXTtcbiAgICAgICAgICAgICAgICB1c2VyLnBvaW50SW5kZXggPSBudW1iZXJPcmRlcltpXTtcbiAgICAgICAgICAgICAgICB1c2VyTGlzdFtpXSA9IHVzZXI7XG4gICAgICAgICAgICAgICAgdmFyIHVzZXJOb2RlTmFtZSA9IFwidXNlclwiICsgbnVtYmVyT3JkZXJbaV0gKyBcIk5vZGVcIjtcbiAgICAgICAgICAgICAgICAvL3ZhciB0ZXN0SGVhSW1hZ2V1cmwgPSBcImh0dHA6Ly93eC5xbG9nby5jbi9tbW9wZW4vUG85bWttM1o0MnRvbFlweFVWcFk2bXZDbXFhbGliT3BjSjJqRzNRemE1cWd0aWJPMU5MRk5VRjdpY3dDaWJ4UGljYkdta29pY2lhcUtFSWR2dnZlSUJmRVFxYWw4dmtpYXZISWVxRlQvMFwiO1xuICAgICAgICAgICAgICAgIHZhciBzZXJ2ZXJVcmwgPSBHbG9iYWwuaG9zdEh0dHBQcm90b2NvbCArIFwiOi8vXCIgKyBHbG9iYWwuaG9zdFNlcnZlcklwICsgXCI6XCIgKyBHbG9iYWwuaG9zdFNlcnZlclBvcnQ7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwiaGVhZEltYWdlRmlsZU5hbWU6XCIgKyB1c2VyLmhlYWRJbWFnZUZpbGVOYW1lKTtcbiAgICAgICAgICAgICAgICB2YXIgdGVzdEhlYUltYWdldXJsID0gc2VydmVyVXJsICsgXCIvd2ViY2hhdEltYWdlL1wiICsgdXNlckluZm8uaGVhZEltYWdlRmlsZU5hbWU7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwidGVzdEhlYUltYWdldXJsOlwiICsgdGVzdEhlYUltYWdldXJsKTtcbiAgICAgICAgICAgICAgICB2YXIgdXNlck5vZGUgPSBjYy5maW5kKHVzZXJOb2RlTmFtZSwgdGhpcy50YWJsZU5vZGUpO1xuICAgICAgICAgICAgICAgIHZhciB1c2VySW5mb05vZGUgPSBjYy5maW5kKFwidXNlckluZm9Ob2RlXCIsIHVzZXJOb2RlKTtcbiAgICAgICAgICAgICAgICB2YXIgdXNlck5pY2tOYW1lTm9kZSA9IGNjLmZpbmQoXCJ1c2VyTmlja05hbWVCZ1wiLCB1c2VySW5mb05vZGUpO1xuICAgICAgICAgICAgICAgIHZhciB1c2VyTmlja05hbWVMYWJsZU5vZGUgPSBjYy5maW5kKFwidXNlck5pY2tOYW1lXCIsIHVzZXJOaWNrTmFtZU5vZGUpO1xuICAgICAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkKHRlc3RIZWFJbWFnZXVybCwgZnVuY3Rpb24gKGVyciwgdGV4dHVyZSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUodGV4dHVyZSk7XG4gICAgICAgICAgICAgICAgICAgIHVzZXJJbmZvTm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IGZyYW1lO1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgdmFyIHVzZXJOaWNrTmFtZUxhYmxlID0gdXNlck5pY2tOYW1lTGFibGVOb2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XG4gICAgICAgICAgICAgICAgdXNlck5pY2tOYW1lTGFibGUuc3RyaW5nID0gdXNlci5uaWNrTmFtZTtcbiAgICAgICAgICAgICAgICB1c2VyTm9kZS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgR2xvYmFsLnVzZXJMaXN0ID0gdXNlckxpc3Q7XG4gICAgICAgICAgICB0aGlzLmludGFsVXNlckluZm9SZWFkeUljb24oKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzAzOGIxTEQ4c2RBb0tGWGN5NUswZmxOJywgJ3VzZXJJbmZvRG9tYWluJyk7XG4vLyBzY3JpcHQvZG9tYWluQ2xhc3MvdXNlckluZm9Eb21haW4uanNcblxudmFyIHVzZXJJbmZvRG9tYWluID0geyBpZDogMjUsXG4gIGFnZW50TGV2ZWw6IDAsXG4gIGNpdHk6IFwiXCIsXG4gIGNvdW50cnk6IFwiXCIsXG4gIGRpYW1vbmRzTnVtYmVyOiAwLFxuICBnYW1lQ291bnQ6IDAsXG4gIGhlYWRpbWd1cmw6IFwiXCIsXG4gIG5pY2tOYW1lOiBcIlwiLFxuICBvcGVuaWQ6IFwiXCIsXG4gIHByb3ZpbmNlOiBcIlwiLFxuICBzZXg6IDEsXG4gIHVuaW9uaWQ6IFwiXCIsXG4gIHVzZXJDb2RlOiBcIlwiLFxuICB1c2VyVHlwZTogXCJcIixcbiAgd2luQ291bnQ6IDAsXG4gIC8vdXNlckdhbWVpbmdTdGF0dTpcIlwiLFxuICBwdWJsaWNJUEFkZHJlc3M6IFwiXCIsXG4gIHJvb21OdW1iZXI6IFwiXCIsXG4gIHBhaUxpc3Q6IFwiXCIsXG4gIGdhbWVSZWFkeVN0YXR1OiBcIlwiLFxuICBnYW1lUm91bmRTY29yZTogXCJcIixcbiAgZ2FtZVNjb3JlQ291bnQ6IFwiXCIsXG4gIGhlYWRJbWFnZUZpbGVOYW1lOiBcIlwiXG59O1xuLy9nYW1laW5nU3RhdHU6XCJcIixcbm1vZHVsZS5leHBvcnRzID0ge1xuICB1c2VySW5mb0RvbWFpbjogdXNlckluZm9Eb21haW5cbn07XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc2ZTFlYlRWMEgxR2tacGZGblZBOTAwQycsICd3ZWJTb2tlY3RNZXNzYWdlJyk7XG4vLyBzY3JpcHQvc2VydmljZS93ZWJTb2tlY3RNZXNzYWdlLmpzXG5cbi8vdmFyIHN0b21wPXJlcXVpcmUoJ3N0b21wJyk7XG52YXIgY2xpZW50O1xudmFyIHByaXZhdGVDbGllbnQ7XG52YXIgdXNlckluZm87XG52YXIgc2VydmVyVXJsO1xudmFyIHNvY2tldDtcbi8vV2Vic29rZWN0IG9ubHkgd29yayBvbiB0aGUgc2VuY2UgLHdoZW4gdGhlIHN3aXRjaCBzZW5jZSAsdGhlIHdlYnNva2VjdCB3aWxsIGJlIGxvc3Qsd2Ugc2hvdWxkIGtlZXAgdGhlIHdlYnNva2VjdCBvbiBvbmUgc2VuY2VcbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5odHRwOi8vY24uYmluZy5jb20vXG4gICAgICAgIHRlc3RMYWJlbDogY2MuTGFiZWwsXG4gICAgICAgIHNjcmlwdE5vZGU6IGNjLk5vZGUsXG4gICAgICAgIG1haW5NZW51OiBjYy5Ob2RlLFxuICAgICAgICBpbmRleDogY2MuTm9kZSxcbiAgICAgICAgZ2FtZUFjdGlvbkxpc3Q6IGNjLk5vZGVcblxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLmdhbWVTdG9wKCk7XG4gICAgICAgIC8vY2MuZ2FtZS5hZGRQZXJzaXN0Um9vdE5vZGUoc2VsZi5zY3JpcHROb2RlKTtcblxuICAgICAgICBzZXJ2ZXJVcmwgPSBHbG9iYWwuaG9zdEh0dHBQcm90b2NvbCArIFwiOi8vXCIgKyBHbG9iYWwuaG9zdFNlcnZlcklwICsgXCI6XCIgKyBHbG9iYWwuaG9zdFNlcnZlclBvcnQ7XG4gICAgICAgIGlmIChHbG9iYWwudXNlckluZm8gPT0gbnVsbCB8fCBHbG9iYWwudXNlckluZm8gPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB2YXIgdXNlckluZm8gPSByZXF1aXJlKFwidXNlckluZm9Eb21haW5cIikudXNlckluZm9Eb21haW47XG4gICAgICAgICAgICAvL3dpbmRvdy5pbyA9IFNvY2tldElPLmNvbm5lY3Q7XG4gICAgICAgICAgICAvL3ZhciBwMnBzb2NrZXQgPSAgd2luZG93LmlvLmNvbm5lY3QoXCJcIik7XG4gICAgICAgICAgICAvL3ZhciBwMnAgPSBuZXcgUDJQKHAycHNvY2tldCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcImlvIGluc3RhbHNcIik7XG4gICAgICAgICAgICAvL3ZhciBzaGFPYmogPSBuZXcganNTSEEoXCJTSEEtMVwiLCBcIlRFWFRcIik7XG4gICAgICAgICAgICAvL3NoYU9iai51cGRhdGUoXCJUaGlzIGlzIGEgdGVzdFwiKTtcbiAgICAgICAgICAgIC8vIHZhciBoYXNoID0gc2hhT2JqLmdldEhhc2goXCJIRVhcIik7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcImhhc2ggc2hhMTpcIitoYXNoKTtcbiAgICAgICAgICAgIC8vaWYgKGNjLnN5cy5pc05hdGl2ZSkge1xuICAgICAgICAgICAgc29ja2V0ID0gbmV3IFNvY2tKUyhzZXJ2ZXJVcmwgKyBcIi9zdG9tcFwiKTtcbiAgICAgICAgICAgIC8vfSBlbHNlIHtcbiAgICAgICAgICAgIC8vICBzb2NrZXQgPSBuZXcgU29ja1dlYkpTKHNlcnZlclVybCArIFwiL3N0b21wXCIpO1xuICAgICAgICAgICAgLy99XG4gICAgICAgICAgICAvL2lvLmNvbm5lY3RcbiAgICAgICAgICAgIC8vdmFyIHNvY2tldD13aW5kb3cuaW8oJ2h0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9zdG9tcCcpO1xuICAgICAgICAgICAgLy92YXIgYWxsb3dlZE9yaWdpbnMgPSBcImh0dHA6Ly9sb2NhbGhvc3Q6KiBodHRwOi8vMTI3LjAuMC4xOipcIjtcbiAgICAgICAgICAgIC8vdmFyIHBhdGggPSAnL3N0b21wJztcbiAgICAgICAgICAgIC8vIHZhciBzb2NrZXQgPSB3aW5kb3cuaW8uY29ubmVjdCgnaHR0cDovL2xvY2FsaG9zdDo4MDgwL3N0b21wJyk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImNvbmVjdCB0byBzZXJ2ZXJcIik7XG4gICAgICAgICAgICBjbGllbnQgPSBTdG9tcC5vdmVyKHNvY2tldCk7XG4gICAgICAgICAgICAvL29wZW4gYSBjaGFubGUgdG8gbGlzdCBsb2dpbiBtZXNzYWdlIGZyb20gc2VydmVyXG4gICAgICAgICAgICBjbGllbnQuY29ubmVjdCh7fSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGNsaWVudC5zdWJzY3JpYmUoXCIvcXVldWUvcHVzbWljR2FtZVB1c2hMb2dpblVzZXJJbmZvQ2hhbmxlXCIsIGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBib2R5U3RyID0gbWVzc2FnZS5ib2R5O1xuICAgICAgICAgICAgICAgICAgICB2YXIgb2JqID0gSlNPTi5wYXJzZShib2R5U3RyKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iaiAhPSB1bmRlZmluZWQgJiYgb2JqICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIHAgaW4gb2JqKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlckluZm9bcF0gPSBvYmpbcF07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInVzZXJJbmZvLm5pY2tuYW1lOlwiICsgdXNlckluZm8ubmlja05hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgR2xvYmFsLnVzZXJJbmZvID0gdXNlckluZm87XG4gICAgICAgICAgICAgICAgICAgICAgICAvL3VwZGF0ZSB0aGUgdXNlciBwdWJsaWMgaXAgZnJvbSB1cmwgY2FsbFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi51cGRhdGVVc2VySVAodXNlckluZm8uaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy9cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vc2VsZi5pbml0YWxQcml2YXRlQ2hhbmxlRm9yVXNlcih1c2VySW5mby5yb29tTnVtYmVyKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy91c2VyIGxvZ2luIHN1Y2Nlc3MgLGdvIHRvIGdhbWUgbWFpbiBzZW5jZVxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ3RhYmxlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmluZGV4LmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tYWluTWVudS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIk5vIGZvdW5kIGNvcnJlY3QgdXNlciBpbmZvIHJldHVybiBmcm9tIHNlcnZlciAscGxlYXNlIGNoZWNrIC5cIik7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvL3NlbGYudGVzdExhYmVsLnN0cmluZyA9IG1lc3NhZ2UuYm9keTtcbiAgICAgICAgICAgICAgICAgICAgLy8kKFwiI2hlbGxvRGl2XCIpLmFwcGVuZChtZXNzYWdlLmJvZHkpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdnYW1lTWFpbjInKTtcbiAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIndlYnNvY2tldCBjb25uZWN0IHN1YnNjcmliZSBFcnJvcjoyMzNcIik7XG4gICAgICAgICAgICAgICAgICAgIC8vY2xpZW50LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBjYy5sb2coXCJ3ZWJzb2NrZXQgY29ubmVjdCAgRXJyb3I6MjM0XCIpO1xuICAgICAgICAgICAgICAgIC8vY2xpZW50LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLy0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvL0dvYmFsIHVzZXJJbmZvIGFscmVhZHkgZ2V0IHRoZSB2YWx1ZSAsZHJpY3RseSB0byB0byBnYW1lTWFpbjJcbiAgICAgICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ3RhYmxlJyk7XG4gICAgICAgICAgICB9XG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG4gICAgc2VuZFdlYlNva2VjdE1lc3NhZ2VUb1NlcnZlcjogZnVuY3Rpb24gc2VuZFdlYlNva2VjdE1lc3NhZ2VUb1NlcnZlcigpIHtcbiAgICAgICAgdmFyIG8gPSBuZXcgT2JqZWN0KCk7XG4gICAgICAgIG8udG9rZW4gPSBcInRlc3Qgd29yZFwiO1xuICAgICAgICBjbGllbnQuc2VuZChcIi9hcHAvcmVzaXZlQWxsVXNlckNoYW5sZVwiLCB7fSwgSlNPTi5zdHJpbmdpZnkobykpO1xuICAgIH0sXG4gICAgLy9zZW5kIHdlYmNoYXQgb3BudW5pZCB0byBzZXJ2ZXIgdG8gbG9naW4gdXNlclxuICAgIGxvZ2luVXNlclRvU2VydmVyQnlUb2tlbjogZnVuY3Rpb24gbG9naW5Vc2VyVG9TZXJ2ZXJCeVRva2VuKCkge1xuICAgICAgICB2YXIgbyA9IG5ldyBPYmplY3QoKTtcbiAgICAgICAgby50b2tlbiA9IFwidGVzdCB3b3JkXCI7XG4gICAgICAgIGNsaWVudC5zZW5kKFwiL2FwcC9wdXNtaWNHYW1lTG9naW5Vc2VyQ2hhbmxlXCIsIHt9LCBKU09OLnN0cmluZ2lmeShvKSk7XG4gICAgfSxcbiAgICAvL29wZW4gdXNlciBpcCBsb2dpbiB1cmxcbiAgICB1cGRhdGVVc2VySVA6IGZ1bmN0aW9uIHVwZGF0ZVVzZXJJUChpZCkge1xuICAgICAgICB2YXIgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHZhciB1cmwgPSBzZXJ2ZXJVcmwgKyBcIi91c2VyL2dldExvZ2luVXNlcklQP3VzZXJJZD1cIiArIGlkO1xuICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHhoci5yZWFkeVN0YXRlID09IDQgJiYgeGhyLnN0YXR1cyA+PSAyMDAgJiYgeGhyLnN0YXR1cyA8IDQwMCkge1xuICAgICAgICAgICAgICAgIHZhciByZXNwb25zZSA9IHhoci5yZXNwb25zZVRleHQ7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgIEdsb2JhbC51c2VySW5mby5wdWJsaWNJUEFkZHJlc3MgPSByZXNwb25zZTtcbiAgICAgICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ3RhYmxlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHhoci5vcGVuKFwiR0VUXCIsIHVybCwgdHJ1ZSk7XG4gICAgICAgIHhoci5zZW5kKCk7XG4gICAgfSxcblxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBvbkRlc3Ryb3k6IGZ1bmN0aW9uIG9uRGVzdHJveSgpIHtcbiAgICAgICAgLy9jb2xzZSB0aGUgd2Vic29rZWN0XG4gICAgICAgIGNsaWVudC5kaXNjb25uZWN0KCk7XG4gICAgfSxcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS1pbml0YWwgcHJpdmF0ZSBjaGFubGUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gaW5pdGFsUHJpdmF0ZUNoYW5sZUZvclVzZXI6IGZ1bmN0aW9uIChyb29tTnVtYmVyKSB7XG4gICAgLy8gICAgIGNjLmxvZyhcInJvb21OdW1iZXI6XCIrcm9vbU51bWJlcik7XG4gICAgLy8gICAgIHByaXZhdGVDbGllbnQgPSBTdG9tcC5vdmVyKHNvY2tldCk7XG5cbiAgICAvLyAgICAgICAgIHByaXZhdGVDbGllbnQuY29ubmVjdCh7fSwgZnVuY3Rpb24gKCkge1xuICAgIC8vICAgICAgICAgICAgIHByaXZhdGVDbGllbnQuc3Vic2NyaWJlKFwiL3F1ZXVlL3ByaXZhdGVSb29tQ2hhbmxlXCIgKyByb29tTnVtYmVyLCBmdW5jdGlvbiAobWVzc2FnZSkge1xuICAgIC8vICAgICAgICAgICAgICAgICB2YXIgYm9keVN0ciA9IG1lc3NhZ2UuYm9keTtcbiAgICAvLyAgICAgICAgICAgICAgICAgY2MubG9nKFwiZ2V0IG1lZXNnZSBmcm9tIHByaXZhdGUgY2hhbmxlOnByaXZhdGVSb29tQ2hhbmxlXCIrcm9vbU51bWJlcik7XG4gICAgLy8gICAgICAgICAgICAgfSk7XG4gICAgLy8gICAgICAgICB9LGZ1bmN0aW9uKCl7XG4gICAgLy8gICAgICAgICAgICAgIGNjLmxvZyhcImNvbm5lY3QgcHJpdmF0ZSBjaGFubGUgZXJyb3IgIVwiKTtcbiAgICAvLyAgICAgICAgIH0pO1xuXG4gICAgLy8gcHJpdmF0ZUNsaWVudENoYW5sZVxuICAgIC8vIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tZ2FtZSBzdG9wLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBnYW1lU3RvcDogZnVuY3Rpb24gZ2FtZVN0b3AoKSB7XG4gICAgICAgIGNjLmdhbWUub25TdG9wID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY2MubG9nKFwic3RvcEFwcFwiKTtcbiAgICAgICAgfTtcbiAgICB9LFxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS13ZWJzb2tlY3QgZXJyb3IgY2FsbGJhY2stLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGVycm9yX2NhbGxiYWNrOiBmdW5jdGlvbiBlcnJvcl9jYWxsYmFjayhlcnJvcikge1xuICAgICAgICAvLyBkaXNwbGF5IHRoZSBlcnJvcidzIG1lc3NhZ2UgaGVhZGVyOlxuICAgICAgICBjYy5sb2coXCJTZWxmIEVycm9yOlwiICsgZXJyb3IpO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyJdfQ==