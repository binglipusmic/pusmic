const actionMessageDomain = 
	{
		messageAction:"",
        messageExecuteFlag:"",
        messageExecuteResult:"",
        useropenid:"",
	}
module.exports = {
	actionMessageDomain: actionMessageDomain
};
