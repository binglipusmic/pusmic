const gameConfigSetting = 
	{
		music:"1",
        musicEffect:"1",
        publicIpLimit:"0",
        gpsLimit:"0",
	}
module.exports = {
	gameConfigSetting: gameConfigSetting
};