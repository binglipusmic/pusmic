const gameStep = 
	{   id:0,
      fromUserOpenid:"",
      actionName:"",
      paiNumber:"",
      toUserOpenid:"", 
      joinRoomNumber:"",
      
      //gameingStatu:"",
    }
module.exports = {
	gameStep: gameStep
};