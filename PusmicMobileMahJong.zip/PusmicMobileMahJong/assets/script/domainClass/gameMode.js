const gameMode = 
	{
		ziMoJiaDi: 1,
		ziMoJiaFan: 0,
        ziMoHu:1,
        dianPaoHu:0,
        huanSanZhang :1,
		dianGangHua_dianPao: 1,
        dianGangHua_ziMo:0,
        dai19JiangDui:1,
        mengQingZhongZhang:0,
        tianDiHu:0,
        fan2:0,
        fan3:1,
        fan4:0,
        fan6:0,
        roundCount4:1,
        roundCount8:0,
        gamePeopleNumber:0,
        publicIpLimit:0,
        gpsLimit:0
	}
module.exports = {
	gameMode: gameMode
};