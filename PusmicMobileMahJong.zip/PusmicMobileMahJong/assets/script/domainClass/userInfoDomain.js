const userInfoDomain = 
	{   id:25,
      agentLevel:0,
      city:"",
      country:"",
      diamondsNumber:0,
      gameCount:0,
      headimgurl:"",
      nickName:"",
      openid:"",
      province:"",
      sex:1,
      unionid:"",
      userCode:"",
      userType:"",
      winCount:0,
      //userGameingStatu:"",
      publicIPAddress:"",
      roomNumber:"",
      paiList:"",
      gameReadyStatu:"",
      gameRoundScore:"",
      gameScoreCount:"",
      headImageFileName:"",
      //gameingStatu:"",
    }
module.exports = {
	userInfoDomain: userInfoDomain
};