//
//  AppDelegate.h
//  transcoding(MP3)
//
//  Created by xindong on 16/11/12.
//  Copyright © 2016年 xindong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

