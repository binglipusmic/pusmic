//
//  ViewController.h
//  Demo_RecordAndPlayVoice
//
//  Created by Ihefe_Hanrovey on 2016/11/3.
//  Copyright © 2016年 Ihefe_Hanrovey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

