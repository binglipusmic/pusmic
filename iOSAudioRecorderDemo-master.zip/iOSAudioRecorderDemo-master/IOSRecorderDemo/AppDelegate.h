//
//  AppDelegate.h
//  IOSRecorderDemo
//
//  Created by Xinhou Jiang on 29/12/16.
//  Copyright © 2016年 Xinhou Jiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

